'use client'

import { useEffect, useState, useCallback, useMemo } from 'react'
import {
  Plus, Pencil, Trash2, Loader2, Trophy, RefreshCw, ArrowUpDown,
  AlertTriangle, CheckCircle2
} from 'lucide-react'
import { Card, CardContent } from '@/components/ui/card'
import { Badge } from '@/components/ui/badge'
import { Button } from '@/components/ui/button'
import { Input } from '@/components/ui/input'
import { Skeleton } from '@/components/ui/skeleton'
import { Label } from '@/components/ui/label'
import {
  Table, TableBody, TableCell, TableHead, TableHeader, TableRow
} from '@/components/ui/table'
import {
  Dialog, DialogContent, DialogDescription, DialogFooter,
  DialogHeader, DialogTitle
} from '@/components/ui/dialog'
import {
  Select, SelectContent, SelectItem, SelectTrigger, SelectValue
} from '@/components/ui/select'

// ============ TYPES ============
interface Team {
  id: string
  name: string
  shortName: string | null
  logo: string | null
  color: string | null
}

interface League {
  id: string
  name: string
  nameEn: string | null
  country: string | null
  type: string
  season: string | null
  isActive: boolean
  teamCount: number
}

interface Standing {
  id: string
  leagueId: string
  teamId: string
  season: string | null
  position: number
  played: number
  won: number
  drawn: number
  lost: number
  goalsFor: number
  goalsAgainst: number
  goalDifference: number
  points: number
  form: string | null
  team: Team
  league: {
    id: string
    name: string
    season: string | null
  }
}

// ============ MAIN COMPONENT ============
export default function AdminStandingsPage() {
  // Data state
  const [standings, setStandings] = useState<Standing[]>([])
  const [leagues, setLeagues] = useState<League[]>([])
  const [teams, setTeams] = useState<Team[]>([])
  const [loading, setLoading] = useState(true)
  const [submitting, setSubmitting] = useState(false)

  // Filter state
  const [selectedLeagueId, setSelectedLeagueId] = useState<string>('')
  const [selectedSeason, setSelectedSeason] = useState<string>('')

  // Dialog state
  const [addDialogOpen, setAddDialogOpen] = useState(false)
  const [editDialogOpen, setEditDialogOpen] = useState(false)
  const [deleteDialogOpen, setDeleteDialogOpen] = useState(false)
  const [standingToDelete, setStandingToDelete] = useState<Standing | null>(null)

  // Recalculate state
  const [recalculating, setRecalculating] = useState(false)

  // Add form state
  const [addForm, setAddForm] = useState({
    leagueId: '',
    teamId: '',
    season: '',
    position: '1',
    played: '0',
    won: '0',
    drawn: '0',
    lost: '0',
    goalsFor: '0',
    goalsAgainst: '0',
    points: '0',
    form: '',
  })

  // Edit form state
  const [editForm, setEditForm] = useState({
    id: '',
    position: 0,
    played: 0,
    won: 0,
    drawn: 0,
    lost: 0,
    goalsFor: 0,
    goalsAgainst: 0,
    goalDifference: 0,
    points: 0,
    form: '',
  })

  // ============ FETCH DATA ============
  const fetchLeagues = useCallback(async () => {
    try {
      const res = await fetch('/api/leagues')
      const data = await res.json()
      setLeagues(data.leagues || [])
    } catch {
      // silently fail
    }
  }, [])

  const fetchTeams = useCallback(async () => {
    try {
      const res = await fetch('/api/teams')
      const data = await res.json()
      setTeams(data.teams || [])
    } catch {
      // silently fail
    }
  }, [])

  const fetchStandings = useCallback(async () => {
    if (!selectedLeagueId) {
      setStandings([])
      return
    }
    try {
      setLoading(true)
      const params = new URLSearchParams({ leagueId: selectedLeagueId })
      if (selectedSeason) params.set('season', selectedSeason)
      const res = await fetch(`/api/admin/standings?${params.toString()}`)
      const data = await res.json()
      setStandings(data.standings || [])
    } catch {
      // silently fail
    } finally {
      setLoading(false)
    }
  }, [selectedLeagueId, selectedSeason])

  useEffect(() => {
    fetchLeagues()
    fetchTeams()
  }, [fetchLeagues, fetchTeams])

  useEffect(() => {
    fetchStandings()
  }, [fetchStandings])

  // Auto-select first league
  useEffect(() => {
    if (leagues.length > 0 && !selectedLeagueId) {
      setSelectedLeagueId(leagues[0].id)
    }
  }, [leagues, selectedLeagueId])

  // Get available seasons for selected league
  const availableSeasons = useMemo(() => {
    const seasons = new Set<string>()
    leagues.forEach(l => {
      if (l.season) seasons.add(l.season)
    })
    return Array.from(seasons).sort().reverse()
  }, [leagues])

  // Get selected league's season
  const selectedLeague = useMemo(() => {
    return leagues.find(l => l.id === selectedLeagueId)
  }, [leagues, selectedLeagueId])

  // Filter teams that are not already in standings for this league
  const availableTeams = useMemo(() => {
    const usedTeamIds = new Set(standings.map(s => s.teamId))
    return teams.filter(t => !usedTeamIds.has(t.id))
  }, [teams, standings])

  // ============ FORM HANDLERS ============
  const resetAddForm = () => {
    setAddForm({
      leagueId: selectedLeagueId || '',
      teamId: '',
      season: selectedLeague?.season || '',
      position: String(standings.length + 1),
      played: '0', won: '0', drawn: '0', lost: '0',
      goalsFor: '0', goalsAgainst: '0', points: '0', form: '',
    })
  }

  const openAddDialog = () => {
    resetAddForm()
    setAddDialogOpen(true)
  }

  const openEditDialog = (standing: Standing) => {
    setEditForm({
      id: standing.id,
      position: standing.position,
      played: standing.played,
      won: standing.won,
      drawn: standing.drawn,
      lost: standing.lost,
      goalsFor: standing.goalsFor,
      goalsAgainst: standing.goalsAgainst,
      goalDifference: standing.goalDifference,
      points: standing.points,
      form: standing.form || '',
    })
    setEditDialogOpen(true)
  }

  const openDeleteDialog = (standing: Standing) => {
    setStandingToDelete(standing)
    setDeleteDialogOpen(true)
  }

  // Auto-calculate goal difference in add form
  const addGoalDifference = useMemo(() => {
    return parseInt(addForm.goalsFor || '0') - parseInt(addForm.goalsAgainst || '0')
  }, [addForm.goalsFor, addForm.goalsAgainst])

  // Auto-calculate goal difference in edit form
  const editGoalDifference = useMemo(() => {
    return editForm.goalsFor - editForm.goalsAgainst
  }, [editForm.goalsFor, editForm.goalsAgainst])

  // ============ SUBMIT HANDLERS ============
  const handleAdd = async () => {
    if (!addForm.leagueId || !addForm.teamId) return
    setSubmitting(true)
    try {
      await fetch('/api/admin/standings', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          leagueId: addForm.leagueId,
          teamId: addForm.teamId,
          season: addForm.season || undefined,
          position: parseInt(addForm.position),
          played: parseInt(addForm.played),
          won: parseInt(addForm.won),
          drawn: parseInt(addForm.drawn),
          lost: parseInt(addForm.lost),
          goalsFor: parseInt(addForm.goalsFor),
          goalsAgainst: parseInt(addForm.goalsAgainst),
          goalDifference: addGoalDifference,
          points: parseInt(addForm.points),
          form: addForm.form || undefined,
        }),
      })
      setAddDialogOpen(false)
      fetchStandings()
    } catch {
      // silently fail
    } finally {
      setSubmitting(false)
    }
  }

  const handleEdit = async () => {
    if (!editForm.id) return
    setSubmitting(true)
    try {
      await fetch('/api/admin/standings', {
        method: 'PUT',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          id: editForm.id,
          position: editForm.position,
          played: editForm.played,
          won: editForm.won,
          drawn: editForm.drawn,
          lost: editForm.lost,
          goalsFor: editForm.goalsFor,
          goalsAgainst: editForm.goalsAgainst,
          goalDifference: editGoalDifference,
          points: editForm.points,
          form: editForm.form || undefined,
        }),
      })
      setEditDialogOpen(false)
      fetchStandings()
    } catch {
      // silently fail
    } finally {
      setSubmitting(false)
    }
  }

  const handleDelete = async () => {
    if (!standingToDelete) return
    setSubmitting(true)
    try {
      await fetch(`/api/admin/standings?id=${standingToDelete.id}`, {
        method: 'DELETE',
      })
      setDeleteDialogOpen(false)
      setStandingToDelete(null)
      fetchStandings()
    } catch {
      // silently fail
    } finally {
      setSubmitting(false)
    }
  }

  const handleRecalculatePositions = async () => {
    if (!selectedLeagueId || standings.length === 0) return
    setRecalculating(true)
    try {
      // Sort by points (desc), then goal difference (desc), then goals for (desc)
      const sorted = [...standings].sort((a, b) => {
        if (b.points !== a.points) return b.points - a.points
        if (b.goalDifference !== a.goalDifference) return b.goalDifference - a.goalDifference
        return b.goalsFor - a.goalsFor
      })

      // Update each standing's position
      for (let i = 0; i < sorted.length; i++) {
        await fetch('/api/admin/standings', {
          method: 'PUT',
          headers: { 'Content-Type': 'application/json' },
          body: JSON.stringify({
            id: sorted[i].id,
            position: i + 1,
          }),
        })
      }
      fetchStandings()
    } catch {
      // silently fail
    } finally {
      setRecalculating(false)
    }
  }

  // ============ FORM BADGE RENDERER ============
  const renderFormBadges = (formStr: string | null) => {
    if (!formStr) return <span className="text-xs text-gray-400">-</span>
    const results = formStr.slice(-5).split('')
    return (
      <div className="flex items-center gap-1">
        {results.map((r, i) => (
          <Badge
            key={i}
            className={`size-6 p-0 flex items-center justify-center text-[10px] font-bold border-0 ${
              r === 'W' ? 'bg-green-500 text-white' :
              r === 'D' ? 'bg-yellow-500 text-white' :
              r === 'L' ? 'bg-red-500 text-white' :
              'bg-gray-200 text-gray-500'
            }`}
          >
            {r === 'W' ? 'ف' : r === 'D' ? 'ت' : r === 'L' ? 'خ' : r}
          </Badge>
        ))}
      </div>
    )
  }

  // ============ POSITION STYLE ============
  const getPositionStyle = (position: number) => {
    if (position === 1) return 'bg-yellow-400 text-yellow-900 font-bold'
    if (position === 2) return 'bg-gray-300 text-gray-700 font-semibold'
    if (position === 3) return 'bg-amber-600 text-white font-semibold'
    if (position <= 4) return 'bg-emerald-100 text-emerald-700'
    return 'bg-gray-100 text-gray-600'
  }

  // ============ RENDER ============
  return (
    <div className="space-y-5">
      {/* Header */}
      <div className="flex items-center justify-between flex-wrap gap-3">
        <div>
          <h2 className="text-xl font-bold text-gray-800">إدارة الترتيب</h2>
          <p className="text-sm text-gray-500 mt-0.5">إدارة جداول ترتيب البطولات والفرق</p>
        </div>
        <div className="flex items-center gap-2">
          <Button
            variant="outline"
            size="sm"
            onClick={fetchStandings}
            className="gap-1.5"
          >
            <RefreshCw className="size-3.5" />
            تحديث
          </Button>
          <Button
            variant="outline"
            size="sm"
            onClick={handleRecalculatePositions}
            disabled={recalculating || standings.length === 0}
            className="gap-1.5 border-amber-300 text-amber-700 hover:bg-amber-50"
          >
            {recalculating ? (
              <Loader2 className="size-3.5 animate-spin" />
            ) : (
              <ArrowUpDown className="size-3.5" />
            )}
            إعادة حساب المراكز
          </Button>
          <Button
            className="bg-emerald-500 hover:bg-emerald-600 shadow-sm shadow-emerald-500/25 gap-1.5"
            onClick={openAddDialog}
            disabled={!selectedLeagueId}
          >
            <Plus className="size-4" />
            إضافة فريق
          </Button>
        </div>
      </div>

      {/* League & Season Selector */}
      <Card className="border-0 shadow-sm">
        <CardContent className="p-4">
          <div className="flex items-center gap-4 flex-wrap">
            <div className="flex items-center gap-2">
              <Trophy className="size-5 text-amber-500" />
              <Label className="text-sm font-semibold text-gray-700">البطولة:</Label>
            </div>
            <Select value={selectedLeagueId} onValueChange={setSelectedLeagueId}>
              <SelectTrigger className="w-64 bg-white border-gray-200">
                <SelectValue placeholder="اختر البطولة" />
              </SelectTrigger>
              <SelectContent>
                {leagues.map(league => (
                  <SelectItem key={league.id} value={league.id}>
                    {league.name} {league.season ? `(${league.season})` : ''}
                  </SelectItem>
                ))}
              </SelectContent>
            </Select>

            {availableSeasons.length > 0 && (
              <>
                <div className="flex items-center gap-2">
                  <Label className="text-sm font-semibold text-gray-700">الموسم:</Label>
                </div>
                <Select value={selectedSeason} onValueChange={setSelectedSeason}>
                  <SelectTrigger className="w-40 bg-white border-gray-200">
                    <SelectValue placeholder="كل المواسم" />
                  </SelectTrigger>
                  <SelectContent>
                    <SelectItem value="all">كل المواسم</SelectItem>
                    {availableSeasons.map(s => (
                      <SelectItem key={s} value={s}>{s}</SelectItem>
                    ))}
                  </SelectContent>
                </Select>
              </>
            )}

            {standings.length > 0 && (
              <Badge variant="outline" className="h-9 px-3 text-xs mr-auto">
                {standings.length} فريق
              </Badge>
            )}
          </div>
        </CardContent>
      </Card>

      {/* Standings Table */}
      {!selectedLeagueId ? (
        <Card className="border-0 shadow-sm">
          <CardContent className="py-16">
            <div className="flex flex-col items-center gap-3 text-gray-400">
              <Trophy className="size-12 text-gray-300" />
              <p className="text-sm">اختر بطولة لعرض الترتيب</p>
            </div>
          </CardContent>
        </Card>
      ) : loading ? (
        <div className="space-y-3">
          {Array.from({ length: 8 }).map((_, i) => (
            <Skeleton key={i} className="h-12 w-full rounded-xl" />
          ))}
        </div>
      ) : (
        <Card className="border-0 shadow-sm overflow-hidden">
          <CardContent className="p-0">
            <Table>
              <TableHeader>
                <TableRow className="bg-gray-50/80">
                  <TableHead className="text-center text-xs font-semibold text-gray-500 w-12">#</TableHead>
                  <TableHead className="text-right text-xs font-semibold text-gray-500 min-w-[180px]">الفريق</TableHead>
                  <TableHead className="text-center text-xs font-semibold text-gray-500 w-12">لعب</TableHead>
                  <TableHead className="text-center text-xs font-semibold text-gray-500 w-12">فوز</TableHead>
                  <TableHead className="text-center text-xs font-semibold text-gray-500 w-12">تعادل</TableHead>
                  <TableHead className="text-center text-xs font-semibold text-gray-500 w-12">خسارة</TableHead>
                  <TableHead className="text-center text-xs font-semibold text-gray-500 w-12">له</TableHead>
                  <TableHead className="text-center text-xs font-semibold text-gray-500 w-12">عليه</TableHead>
                  <TableHead className="text-center text-xs font-semibold text-gray-500 w-12">فارق</TableHead>
                  <TableHead className="text-center text-xs font-semibold text-gray-500 w-14 font-bold">نقاط</TableHead>
                  <TableHead className="text-center text-xs font-semibold text-gray-500 w-32">آخر 5</TableHead>
                  <TableHead className="text-center text-xs font-semibold text-gray-500 w-20">إجراءات</TableHead>
                </TableRow>
              </TableHeader>
              <TableBody>
                {standings.length === 0 ? (
                  <TableRow>
                    <TableCell colSpan={12} className="text-center py-12 text-gray-400">
                      <div className="flex flex-col items-center gap-2">
                        <Trophy className="size-10 text-gray-300" />
                        <p>لا توجد فرق في الترتيب</p>
                        <Button
                          size="sm"
                          className="mt-2 bg-emerald-500 hover:bg-emerald-600 gap-1"
                          onClick={openAddDialog}
                        >
                          <Plus className="size-3.5" />إضافة فريق
                        </Button>
                      </div>
                    </TableCell>
                  </TableRow>
                ) : (
                  standings
                    .sort((a, b) => a.position - b.position)
                    .map((standing) => (
                      <TableRow
                        key={standing.id}
                        className={`hover:bg-gray-50/50 transition-colors ${
                          standing.position <= 3 ? 'bg-amber-50/30' : ''
                        }`}
                      >
                        {/* Position */}
                        <TableCell className="text-center">
                          <span className={`inline-flex size-7 items-center justify-center rounded-full text-xs ${getPositionStyle(standing.position)}`}>
                            {standing.position}
                          </span>
                        </TableCell>

                        {/* Team */}
                        <TableCell>
                          <div className="flex items-center gap-2.5">
                            <div
                              className="size-8 rounded-full flex items-center justify-center text-white text-xs font-bold shrink-0 shadow-sm"
                              style={{ backgroundColor: standing.team.color || '#10b981' }}
                            >
                              {(standing.team.shortName || standing.team.name).charAt(0)}
                            </div>
                            <span className="text-sm font-medium text-gray-700 truncate">
                              {standing.team.name}
                            </span>
                          </div>
                        </TableCell>

                        {/* Played */}
                        <TableCell className="text-center text-sm text-gray-600">
                          {standing.played}
                        </TableCell>

                        {/* Won */}
                        <TableCell className="text-center text-sm font-medium text-green-600">
                          {standing.won}
                        </TableCell>

                        {/* Drawn */}
                        <TableCell className="text-center text-sm text-yellow-600">
                          {standing.drawn}
                        </TableCell>

                        {/* Lost */}
                        <TableCell className="text-center text-sm text-red-500">
                          {standing.lost}
                        </TableCell>

                        {/* Goals For */}
                        <TableCell className="text-center text-sm text-gray-600">
                          {standing.goalsFor}
                        </TableCell>

                        {/* Goals Against */}
                        <TableCell className="text-center text-sm text-gray-600">
                          {standing.goalsAgainst}
                        </TableCell>

                        {/* Goal Difference */}
                        <TableCell className="text-center">
                          <span className={`text-sm font-semibold ${
                            standing.goalDifference > 0 ? 'text-green-600' :
                            standing.goalDifference < 0 ? 'text-red-500' :
                            'text-gray-500'
                          }`}>
                            {standing.goalDifference > 0 ? '+' : ''}{standing.goalDifference}
                          </span>
                        </TableCell>

                        {/* Points */}
                        <TableCell className="text-center">
                          <span className="inline-flex items-center justify-center bg-emerald-100 text-emerald-700 font-bold text-sm rounded-lg px-2.5 py-0.5 min-w-[36px]">
                            {standing.points}
                          </span>
                        </TableCell>

                        {/* Form */}
                        <TableCell className="text-center">
                          {renderFormBadges(standing.form)}
                        </TableCell>

                        {/* Actions */}
                        <TableCell>
                          <div className="flex items-center justify-center gap-1">
                            <Button
                              variant="ghost"
                              size="icon"
                              className="size-7 text-blue-500 hover:text-blue-700 hover:bg-blue-50"
                              onClick={() => openEditDialog(standing)}
                            >
                              <Pencil className="size-3.5" />
                            </Button>
                            <Button
                              variant="ghost"
                              size="icon"
                              className="size-7 text-red-400 hover:text-red-600 hover:bg-red-50"
                              onClick={() => openDeleteDialog(standing)}
                            >
                              <Trash2 className="size-3.5" />
                            </Button>
                          </div>
                        </TableCell>
                      </TableRow>
                    ))
                )}
              </TableBody>
            </Table>
          </CardContent>
        </Card>
      )}

      {/* ============ ADD STANDING DIALOG ============ */}
      <Dialog open={addDialogOpen} onOpenChange={setAddDialogOpen}>
        <DialogContent className="max-w-xl max-h-[90vh] overflow-y-auto" dir="rtl">
          <DialogHeader>
            <DialogTitle className="flex items-center gap-2">
              <Plus className="size-5 text-emerald-500" />
              إضافة فريق للترتيب
            </DialogTitle>
            <DialogDescription>أدخل بيانات الفريق في جدول الترتيب</DialogDescription>
          </DialogHeader>

          <div className="space-y-5 py-2">
            {/* League */}
            <div className="space-y-2">
              <Label className="text-sm font-semibold flex items-center gap-1.5">
                <Trophy className="size-3.5 text-amber-500" />
                البطولة *
              </Label>
              <Select
                value={addForm.leagueId}
                onValueChange={v => setAddForm(p => ({ ...p, leagueId: v }))}
              >
                <SelectTrigger className="w-full">
                  <SelectValue placeholder="اختر البطولة" />
                </SelectTrigger>
                <SelectContent>
                  {leagues.map(l => (
                    <SelectItem key={l.id} value={l.id}>{l.name}</SelectItem>
                  ))}
                </SelectContent>
              </Select>
            </div>

            {/* Team */}
            <div className="space-y-2">
              <Label className="text-sm font-semibold">الفريق *</Label>
              <Select
                value={addForm.teamId}
                onValueChange={v => setAddForm(p => ({ ...p, teamId: v }))}
              >
                <SelectTrigger className="w-full">
                  <SelectValue placeholder="اختر الفريق" />
                </SelectTrigger>
                <SelectContent>
                  {availableTeams.map(t => (
                    <SelectItem key={t.id} value={t.id}>
                      <div className="flex items-center gap-2">
                        <div
                          className="size-4 rounded-full shrink-0"
                          style={{ backgroundColor: t.color || '#10b981' }}
                        />
                        {t.name}
                      </div>
                    </SelectItem>
                  ))}
                </SelectContent>
              </Select>
              {availableTeams.length === 0 && (
                <p className="text-xs text-amber-600 flex items-center gap-1">
                  <AlertTriangle className="size-3" />
                  جميع الفرق مضافة بالفعل لهذه البطولة
                </p>
              )}
            </div>

            {/* Season & Position */}
            <div className="grid grid-cols-2 gap-4">
              <div className="space-y-2">
                <Label className="text-sm font-semibold">الموسم</Label>
                <Input
                  value={addForm.season}
                  onChange={e => setAddForm(p => ({ ...p, season: e.target.value }))}
                  placeholder="2024-2025"
                />
              </div>
              <div className="space-y-2">
                <Label className="text-sm font-semibold">المركز</Label>
                <Input
                  type="number"
                  min="1"
                  value={addForm.position}
                  onChange={e => setAddForm(p => ({ ...p, position: e.target.value }))}
                />
              </div>
            </div>

            {/* Played */}
            <div className="space-y-2">
              <Label className="text-sm font-semibold">مباريات لُعبت</Label>
              <Input
                type="number"
                min="0"
                value={addForm.played}
                onChange={e => setAddForm(p => ({ ...p, played: e.target.value }))}
              />
            </div>

            {/* Stats Grid */}
            <div className="grid grid-cols-3 gap-3">
              <div className="space-y-2">
                <Label className="text-sm font-semibold text-green-600">فوز</Label>
                <Input
                  type="number"
                  min="0"
                  value={addForm.won}
                  onChange={e => setAddForm(p => ({ ...p, won: e.target.value }))}
                />
              </div>
              <div className="space-y-2">
                <Label className="text-sm font-semibold text-yellow-600">تعادل</Label>
                <Input
                  type="number"
                  min="0"
                  value={addForm.drawn}
                  onChange={e => setAddForm(p => ({ ...p, drawn: e.target.value }))}
                />
              </div>
              <div className="space-y-2">
                <Label className="text-sm font-semibold text-red-500">خسارة</Label>
                <Input
                  type="number"
                  min="0"
                  value={addForm.lost}
                  onChange={e => setAddForm(p => ({ ...p, lost: e.target.value }))}
                />
              </div>
            </div>

            <div className="grid grid-cols-3 gap-3">
              <div className="space-y-2">
                <Label className="text-sm font-semibold">أهداف له</Label>
                <Input
                  type="number"
                  min="0"
                  value={addForm.goalsFor}
                  onChange={e => setAddForm(p => ({ ...p, goalsFor: e.target.value }))}
                />
              </div>
              <div className="space-y-2">
                <Label className="text-sm font-semibold">أهداف عليه</Label>
                <Input
                  type="number"
                  min="0"
                  value={addForm.goalsAgainst}
                  onChange={e => setAddForm(p => ({ ...p, goalsAgainst: e.target.value }))}
                />
              </div>
              <div className="space-y-2">
                <Label className="text-sm font-semibold">فارق الأهداف</Label>
                <Input
                  type="number"
                  value={addGoalDifference}
                  disabled
                  className="bg-gray-50"
                />
              </div>
            </div>

            <div className="grid grid-cols-2 gap-4">
              <div className="space-y-2">
                <Label className="text-sm font-semibold text-emerald-600">النقاط</Label>
                <Input
                  type="number"
                  min="0"
                  value={addForm.points}
                  onChange={e => setAddForm(p => ({ ...p, points: e.target.value }))}
                />
              </div>
              <div className="space-y-2">
                <Label className="text-sm font-semibold">الآخرية (W/D/L)</Label>
                <Input
                  value={addForm.form}
                  onChange={e => setAddForm(p => ({ ...p, form: e.target.value.toUpperCase() }))}
                  placeholder="WDLLW"
                  dir="ltr"
                  maxLength={5}
                />
              </div>
            </div>

            {addForm.form && (
              <div className="flex items-center gap-2 p-2 bg-gray-50 rounded-lg">
                <span className="text-xs text-gray-500">معاينة:</span>
                {renderFormBadges(addForm.form.toUpperCase())}
              </div>
            )}
          </div>

          <DialogFooter className="gap-2">
            <Button variant="outline" onClick={() => setAddDialogOpen(false)}>إلغاء</Button>
            <Button
              className="bg-emerald-500 hover:bg-emerald-600 gap-1.5"
              onClick={handleAdd}
              disabled={submitting || !addForm.leagueId || !addForm.teamId || availableTeams.length === 0}
            >
              {submitting && <Loader2 className="size-4 animate-spin" />}
              إضافة للترتيب
            </Button>
          </DialogFooter>
        </DialogContent>
      </Dialog>

      {/* ============ EDIT STANDING DIALOG ============ */}
      <Dialog open={editDialogOpen} onOpenChange={setEditDialogOpen}>
        <DialogContent className="max-w-xl max-h-[90vh] overflow-y-auto" dir="rtl">
          <DialogHeader>
            <DialogTitle className="flex items-center gap-2">
              <Pencil className="size-5 text-blue-500" />
              تعديل بيانات الترتيب
            </DialogTitle>
            <DialogDescription>قم بتعديل إحصائيات الفريق في جدول الترتيب</DialogDescription>
          </DialogHeader>

          <div className="space-y-5 py-2">
            {/* Position & Played */}
            <div className="grid grid-cols-2 gap-4">
              <div className="space-y-2">
                <Label className="text-sm font-semibold">المركز</Label>
                <Input
                  type="number"
                  min="1"
                  value={editForm.position}
                  onChange={e => setEditForm(p => ({ ...p, position: parseInt(e.target.value) || 0 }))}
                />
              </div>
              <div className="space-y-2">
                <Label className="text-sm font-semibold">مباريات لُعبت</Label>
                <Input
                  type="number"
                  min="0"
                  value={editForm.played}
                  onChange={e => setEditForm(p => ({ ...p, played: parseInt(e.target.value) || 0 }))}
                />
              </div>
            </div>

            {/* Stats Grid */}
            <div className="grid grid-cols-3 gap-3">
              <div className="space-y-2">
                <Label className="text-sm font-semibold text-green-600">فوز</Label>
                <Input
                  type="number"
                  min="0"
                  value={editForm.won}
                  onChange={e => setEditForm(p => ({ ...p, won: parseInt(e.target.value) || 0 }))}
                />
              </div>
              <div className="space-y-2">
                <Label className="text-sm font-semibold text-yellow-600">تعادل</Label>
                <Input
                  type="number"
                  min="0"
                  value={editForm.drawn}
                  onChange={e => setEditForm(p => ({ ...p, drawn: parseInt(e.target.value) || 0 }))}
                />
              </div>
              <div className="space-y-2">
                <Label className="text-sm font-semibold text-red-500">خسارة</Label>
                <Input
                  type="number"
                  min="0"
                  value={editForm.lost}
                  onChange={e => setEditForm(p => ({ ...p, lost: parseInt(e.target.value) || 0 }))}
                />
              </div>
            </div>

            <div className="grid grid-cols-3 gap-3">
              <div className="space-y-2">
                <Label className="text-sm font-semibold">أهداف له</Label>
                <Input
                  type="number"
                  min="0"
                  value={editForm.goalsFor}
                  onChange={e => setEditForm(p => ({ ...p, goalsFor: parseInt(e.target.value) || 0 }))}
                />
              </div>
              <div className="space-y-2">
                <Label className="text-sm font-semibold">أهداف عليه</Label>
                <Input
                  type="number"
                  min="0"
                  value={editForm.goalsAgainst}
                  onChange={e => setEditForm(p => ({ ...p, goalsAgainst: parseInt(e.target.value) || 0 }))}
                />
              </div>
              <div className="space-y-2">
                <Label className="text-sm font-semibold">فارق الأهداف</Label>
                <Input
                  type="number"
                  value={editGoalDifference}
                  disabled
                  className="bg-gray-50"
                />
              </div>
            </div>

            <div className="grid grid-cols-2 gap-4">
              <div className="space-y-2">
                <Label className="text-sm font-semibold text-emerald-600">النقاط</Label>
                <Input
                  type="number"
                  min="0"
                  value={editForm.points}
                  onChange={e => setEditForm(p => ({ ...p, points: parseInt(e.target.value) || 0 }))}
                />
              </div>
              <div className="space-y-2">
                <Label className="text-sm font-semibold">الآخرية (W/D/L)</Label>
                <Input
                  value={editForm.form}
                  onChange={e => setEditForm(p => ({ ...p, form: e.target.value.toUpperCase() }))}
                  placeholder="WDLLW"
                  dir="ltr"
                  maxLength={5}
                />
              </div>
            </div>

            {editForm.form && (
              <div className="flex items-center gap-2 p-2 bg-gray-50 rounded-lg">
                <span className="text-xs text-gray-500">معاينة:</span>
                {renderFormBadges(editForm.form.toUpperCase())}
              </div>
            )}

            {/* Auto-calculated summary */}
            <div className="bg-emerald-50 border border-emerald-200 rounded-lg p-3 flex items-center gap-2">
              <CheckCircle2 className="size-4 text-emerald-600 shrink-0" />
              <div className="text-xs text-emerald-700">
                <span className="font-semibold">ملخص:</span>{' '}
                {editForm.played} مباراة | {editForm.won} فوز | {editForm.drawn} تعادل | {editForm.lost} خسارة |{' '}
                <span className="font-bold">{editForm.points} نقطة</span> | فارق {editGoalDifference > 0 ? '+' : ''}{editGoalDifference}
              </div>
            </div>
          </div>

          <DialogFooter className="gap-2">
            <Button variant="outline" onClick={() => setEditDialogOpen(false)}>إلغاء</Button>
            <Button
              className="bg-blue-500 hover:bg-blue-600 gap-1.5"
              onClick={handleEdit}
              disabled={submitting}
            >
              {submitting && <Loader2 className="size-4 animate-spin" />}
              تحديث البيانات
            </Button>
          </DialogFooter>
        </DialogContent>
      </Dialog>

      {/* ============ DELETE CONFIRMATION DIALOG ============ */}
      <Dialog open={deleteDialogOpen} onOpenChange={setDeleteDialogOpen}>
        <DialogContent className="max-w-md" dir="rtl">
          <DialogHeader>
            <DialogTitle className="flex items-center gap-2 text-red-600">
              <Trash2 className="size-5" />
              تأكيد الحذف
            </DialogTitle>
            <DialogDescription>
              هل أنت متأكد من حذف هذا الفريق من جدول الترتيب؟ لا يمكن التراجع عن هذا الإجراء.
            </DialogDescription>
          </DialogHeader>

          {standingToDelete && (
            <div className="bg-red-50 border border-red-200 rounded-lg p-3 flex items-center gap-3">
              <div
                className="size-10 rounded-full flex items-center justify-center text-white text-sm font-bold shrink-0"
                style={{ backgroundColor: standingToDelete.team.color || '#10b981' }}
              >
                {(standingToDelete.team.shortName || standingToDelete.team.name).charAt(0)}
              </div>
              <div>
                <p className="font-semibold text-gray-800">{standingToDelete.team.name}</p>
                <p className="text-xs text-gray-500">
                  المركز {standingToDelete.position} | {standingToDelete.points} نقطة
                </p>
              </div>
            </div>
          )}

          <DialogFooter className="gap-2">
            <Button variant="outline" onClick={() => setDeleteDialogOpen(false)}>إلغاء</Button>
            <Button
              variant="destructive"
              className="gap-1.5"
              onClick={handleDelete}
              disabled={submitting}
            >
              {submitting && <Loader2 className="size-4 animate-spin" />}
              حذف من الترتيب
            </Button>
          </DialogFooter>
        </DialogContent>
      </Dialog>
    </div>
  )
}
