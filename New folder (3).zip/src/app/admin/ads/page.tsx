'use client'

import { useEffect, useState, useCallback } from 'react'
import {
  DollarSign, Plus, Eye, MousePointer, TrendingUp, MoreVertical,
  Edit3, Trash2, Power, PowerOff, ExternalLink, Image as ImageIcon,
  Code, LayoutGrid, Search, Filter, Copy, Check, BarChart3, Calendar,
  Megaphone, Monitor, Smartphone, ToggleLeft, Layout, MapPin, Clock,
  ArrowUpDown, RefreshCw, ChevronDown, Globe, ToggleRight
} from 'lucide-react'
import { Card, CardContent } from '@/components/ui/card'
import { Badge } from '@/components/ui/badge'
import { Button } from '@/components/ui/button'
import { Input } from '@/components/ui/input'
import { Label } from '@/components/ui/label'
import { Switch } from '@/components/ui/switch'
import { Textarea } from '@/components/ui/textarea'
import { Tabs, TabsContent, TabsList, TabsTrigger } from '@/components/ui/tabs'
import {
  Table, TableBody, TableCell, TableHead, TableHeader, TableRow
} from '@/components/ui/table'
import {
  Dialog, DialogContent, DialogFooter,
  DialogHeader, DialogTitle
} from '@/components/ui/dialog'
import {
  Select, SelectContent, SelectItem, SelectTrigger, SelectValue
} from '@/components/ui/select'
import {
  DropdownMenu, DropdownMenuContent, DropdownMenuItem,
  DropdownMenuSeparator, DropdownMenuTrigger
} from '@/components/ui/dropdown-menu'
import { Tooltip, TooltipContent, TooltipProvider, TooltipTrigger } from '@/components/ui/tooltip'

// ===== أنواع الإعلانات =====
interface AdData {
  id: string
  title: string
  position: string
  type: string
  advertiser: string | null
  imageUrl: string | null
  linkUrl: string | null
  content: string | null
  isActive: boolean
  priority: number
  targetPages: string | null
  width: string | null
  height: string | null
  startDate: string | null
  endDate: string | null
  impressions: number
  clicks: number
  createdAt: string
  updatedAt: string
}

interface AdsStats {
  totalAds: number
  activeAds: number
  totalImpressions: number
  totalClicks: number
  avgCtr: string
}

// ===== ثوابت =====
const POSITIONS = [
  { value: 'header_banner', label: 'بانر الهيدر', desc: 'أعلى الصفحة - عرض كامل', icon: Monitor, color: 'blue' },
  { value: 'home_featured', label: 'الرئيسية - مميز', desc: 'منطقة مميزة بالصفحة الرئيسية', icon: LayoutGrid, color: 'emerald' },
  { value: 'sidebar_top', label: 'أعلى الجانبي', desc: 'أعلى الشريط الجانبي', icon: Layout, color: 'purple' },
  { value: 'sidebar_bottom', label: 'أسفل الجانبي', desc: 'أسفل الشريط الجانبي', icon: Layout, color: 'violet' },
  { value: 'article_top', label: 'أعلى المقال', desc: 'قبل محتوى المقال', icon: Layout, color: 'amber' },
  { value: 'article_middle', label: 'وسط المقال', desc: 'بين فقرات المقال', icon: Layout, color: 'orange' },
  { value: 'article_bottom', label: 'أسفل المقال', desc: 'بعد محتوى المقال', icon: Layout, color: 'rose' },
  { value: 'match_banner', label: 'بانر المباراة', desc: 'صفحة تفاصيل المباراة', icon: LayoutGrid, color: 'teal' },
  { value: 'footer_banner', label: 'بانر الفوتر', desc: 'أسفل الصفحة - عرض كامل', icon: Smartphone, color: 'cyan' },
]

const AD_TYPES = [
  { value: 'image', label: 'صورة مع رابط', icon: ImageIcon, color: 'emerald' },
  { value: 'html', label: 'كود HTML', icon: Code, color: 'violet' },
  { value: 'adsense', label: 'Google AdSense', icon: DollarSign, color: 'amber' },
]

const TARGET_PAGES = [
  { value: 'all', label: 'جميع الصفحات', icon: Globe },
  { value: 'home', label: 'الرئيسية', icon: LayoutGrid },
  { value: 'news', label: 'الأخبار', icon: Megaphone },
  { value: 'article', label: 'تفاصيل المقال', icon: Layout },
  { value: 'matches', label: 'المباريات', icon: LayoutGrid },
  { value: 'match_detail', label: 'تفاصيل المباراة', icon: LayoutGrid },
]

const SIZE_PRESETS = [
  { value: 'responsive', label: 'متجاوب (عرض كامل)', desc: 'يتكيف مع حجم الشاشة' },
  { value: '728x90', label: 'بانر كبير (728×90)', desc: 'مناسب للهيدر والفوتر' },
  { value: '300x250', label: 'مستطيل متوسط (300×250)', desc: 'مناسب للجانبي والمقال' },
  { value: '160x600', label: 'ناطحة سحاب (160×600)', desc: 'مناسب للشريط الجانبي' },
  { value: '320x100', label: 'موبايل (320×100)', desc: 'مناسب للأجهزة المحمولة' },
  { value: '970x90', label: 'بانر كبير جداً (970×90)', desc: 'مناسب للهيدر الواسع' },
  { value: 'custom', label: 'مخصص', desc: 'أدخل الأبعاد يدوياً' },
]

const positionLabel = (pos: string) => POSITIONS.find(p => p.value === pos)?.label || pos
const typeLabel = (type: string) => AD_TYPES.find(t => t.value === type)?.label || type

function formatDate(dateStr: string | null) {
  if (!dateStr) return '—'
  const d = new Date(dateStr)
  return d.toLocaleDateString('ar-EG', { year: 'numeric', month: 'short', day: 'numeric' })
}

function formatNumber(num: number) {
  if (num >= 1000000) return (num / 1000000).toFixed(1) + 'M'
  if (num >= 1000) return (num / 1000).toFixed(1) + 'K'
  return num.toString()
}

const emptyForm = {
  title: '',
  position: 'header_banner',
  type: 'image',
  advertiser: '',
  imageUrl: '',
  linkUrl: '',
  content: '',
  isActive: true,
  priority: 0,
  targetPages: 'all',
  sizePreset: 'responsive',
  width: '',
  height: '',
  startDate: '',
  endDate: '',
}

// ===== مكون خريطة مواضع الإعلانات =====
function PositionMap({ ads, onPositionClick }: { ads: AdData[], onPositionClick: (position: string) => void }) {
  const getPositionCount = (pos: string) => ads.filter(a => a.position === pos && a.isActive).length

  return (
    <div className="relative bg-card border rounded-2xl overflow-hidden">
      {/* عنوان */}
      <div className="px-5 py-3.5 border-b bg-gradient-to-l from-emerald-50 to-transparent dark:from-emerald-950/20">
        <div className="flex items-center gap-2.5">
          <div className="flex items-center justify-center size-8 rounded-xl bg-emerald-600 text-white shadow-md shadow-emerald-500/25">
            <MapPin className="w-4 h-4" />
          </div>
          <div>
            <span className="font-bold text-sm">خريطة مواضع الإعلانات</span>
            <p className="text-[11px] text-muted-foreground">اضغط على أي موضع لفلترة الإعلانات</p>
          </div>
        </div>
      </div>

      {/* الخريطة */}
      <div className="p-6">
        <div className="relative bg-muted/20 rounded-xl border-2 border-dashed border-muted-foreground/10 p-4 min-h-[500px]">
          {/* هيدر */}
          <div
            className="bg-blue-50 dark:bg-blue-950/30 border-2 border-blue-200 dark:border-blue-800 rounded-lg p-3 cursor-pointer hover:bg-blue-100 dark:hover:bg-blue-950/50 transition-colors mb-4"
            onClick={() => onPositionClick('header_banner')}
          >
            <div className="flex items-center justify-between">
              <div className="flex items-center gap-2">
                <Monitor className="size-4 text-blue-500" />
                <span className="text-xs font-bold text-blue-700 dark:text-blue-400">بانر الهيدر</span>
              </div>
              {getPositionCount('header_banner') > 0 && (
                <Badge className="bg-blue-500 text-white text-[10px] h-5 px-1.5">
                  {getPositionCount('header_banner')}
                </Badge>
              )}
            </div>
          </div>

          {/* المنطقة الرئيسية */}
          <div className="grid grid-cols-12 gap-3 mb-4">
            {/* الجانبي الأيسر */}
            <div className="col-span-3 space-y-3">
              <div
                className="bg-purple-50 dark:bg-purple-950/30 border-2 border-purple-200 dark:border-purple-800 rounded-lg p-3 cursor-pointer hover:bg-purple-100 dark:hover:bg-purple-950/50 transition-colors"
                onClick={() => onPositionClick('sidebar_top')}
              >
                <div className="flex items-center justify-between">
                  <span className="text-[10px] font-bold text-purple-700 dark:text-purple-400">أعلى الجانبي</span>
                  {getPositionCount('sidebar_top') > 0 && (
                    <Badge className="bg-purple-500 text-white text-[9px] h-4 px-1">
                      {getPositionCount('sidebar_top')}
                    </Badge>
                  )}
                </div>
              </div>
              <div
                className="bg-violet-50 dark:bg-violet-950/30 border-2 border-violet-200 dark:border-violet-800 rounded-lg p-3 cursor-pointer hover:bg-violet-100 dark:hover:bg-violet-950/50 transition-colors"
                onClick={() => onPositionClick('sidebar_bottom')}
              >
                <div className="flex items-center justify-between">
                  <span className="text-[10px] font-bold text-violet-700 dark:text-violet-400">أسفل الجانبي</span>
                  {getPositionCount('sidebar_bottom') > 0 && (
                    <Badge className="bg-violet-500 text-white text-[9px] h-4 px-1">
                      {getPositionCount('sidebar_bottom')}
                    </Badge>
                  )}
                </div>
              </div>
            </div>

            {/* المحتوى الرئيسي */}
            <div className="col-span-6 space-y-3">
              {/* مميز بالرئيسية */}
              <div
                className="bg-emerald-50 dark:bg-emerald-950/30 border-2 border-emerald-200 dark:border-emerald-800 rounded-lg p-3 cursor-pointer hover:bg-emerald-100 dark:hover:bg-emerald-950/50 transition-colors"
                onClick={() => onPositionClick('home_featured')}
              >
                <div className="flex items-center justify-between">
                  <div className="flex items-center gap-2">
                    <LayoutGrid className="size-3.5 text-emerald-500" />
                    <span className="text-xs font-bold text-emerald-700 dark:text-emerald-400">الرئيسية - مميز</span>
                  </div>
                  {getPositionCount('home_featured') > 0 && (
                    <Badge className="bg-emerald-500 text-white text-[10px] h-5 px-1.5">
                      {getPositionCount('home_featured')}
                    </Badge>
                  )}
                </div>
              </div>

              {/* أعلى المقال */}
              <div
                className="bg-amber-50 dark:bg-amber-950/30 border-2 border-amber-200 dark:border-amber-800 rounded-lg p-2 cursor-pointer hover:bg-amber-100 dark:hover:bg-amber-950/50 transition-colors"
                onClick={() => onPositionClick('article_top')}
              >
                <div className="flex items-center justify-between">
                  <span className="text-[10px] font-bold text-amber-700 dark:text-amber-400">أعلى المقال</span>
                  {getPositionCount('article_top') > 0 && (
                    <Badge className="bg-amber-500 text-white text-[9px] h-4 px-1">
                      {getPositionCount('article_top')}
                    </Badge>
                  )}
                </div>
              </div>

              {/* محتوى المقال (محاكاة) */}
              <div className="space-y-1.5 px-2">
                <div className="h-2 bg-muted/40 rounded w-full" />
                <div className="h-2 bg-muted/40 rounded w-4/5" />
                <div className="h-2 bg-muted/40 rounded w-full" />
              </div>

              {/* وسط المقال */}
              <div
                className="bg-orange-50 dark:bg-orange-950/30 border-2 border-orange-200 dark:border-orange-800 rounded-lg p-2 cursor-pointer hover:bg-orange-100 dark:hover:bg-orange-950/50 transition-colors"
                onClick={() => onPositionClick('article_middle')}
              >
                <div className="flex items-center justify-between">
                  <span className="text-[10px] font-bold text-orange-700 dark:text-orange-400">وسط المقال</span>
                  {getPositionCount('article_middle') > 0 && (
                    <Badge className="bg-orange-500 text-white text-[9px] h-4 px-1">
                      {getPositionCount('article_middle')}
                    </Badge>
                  )}
                </div>
              </div>

              {/* محتوى المقال (محاكاة) */}
              <div className="space-y-1.5 px-2">
                <div className="h-2 bg-muted/40 rounded w-full" />
                <div className="h-2 bg-muted/40 rounded w-3/4" />
              </div>

              {/* أسفل المقال */}
              <div
                className="bg-rose-50 dark:bg-rose-950/30 border-2 border-rose-200 dark:border-rose-800 rounded-lg p-2 cursor-pointer hover:bg-rose-100 dark:hover:bg-rose-950/50 transition-colors"
                onClick={() => onPositionClick('article_bottom')}
              >
                <div className="flex items-center justify-between">
                  <span className="text-[10px] font-bold text-rose-700 dark:text-rose-400">أسفل المقال</span>
                  {getPositionCount('article_bottom') > 0 && (
                    <Badge className="bg-rose-500 text-white text-[9px] h-4 px-1">
                      {getPositionCount('article_bottom')}
                    </Badge>
                  )}
                </div>
              </div>
            </div>

            {/* الجانبي الأيمن - بانر المباراة */}
            <div className="col-span-3 space-y-3">
              <div
                className="bg-teal-50 dark:bg-teal-950/30 border-2 border-teal-200 dark:border-teal-800 rounded-lg p-3 cursor-pointer hover:bg-teal-100 dark:hover:bg-teal-950/50 transition-colors"
                onClick={() => onPositionClick('match_banner')}
              >
                <div className="flex items-center justify-between">
                  <span className="text-[10px] font-bold text-teal-700 dark:text-teal-400">بانر المباراة</span>
                  {getPositionCount('match_banner') > 0 && (
                    <Badge className="bg-teal-500 text-white text-[9px] h-4 px-1">
                      {getPositionCount('match_banner')}
                    </Badge>
                  )}
                </div>
              </div>
            </div>
          </div>

          {/* فوتر */}
          <div
            className="bg-cyan-50 dark:bg-cyan-950/30 border-2 border-cyan-200 dark:border-cyan-800 rounded-lg p-3 cursor-pointer hover:bg-cyan-100 dark:hover:bg-cyan-950/50 transition-colors"
            onClick={() => onPositionClick('footer_banner')}
          >
            <div className="flex items-center justify-between">
              <div className="flex items-center gap-2">
                <Smartphone className="size-4 text-cyan-500" />
                <span className="text-xs font-bold text-cyan-700 dark:text-cyan-400">بانر الفوتر</span>
              </div>
              {getPositionCount('footer_banner') > 0 && (
                <Badge className="bg-cyan-500 text-white text-[10px] h-5 px-1.5">
                  {getPositionCount('footer_banner')}
                </Badge>
              )}
            </div>
          </div>
        </div>
      </div>
    </div>
  )
}

// ===== المكون الرئيسي =====
export default function AdminAdsPage() {
  const [ads, setAds] = useState<AdData[]>([])
  const [stats, setStats] = useState<AdsStats>({ totalAds: 0, activeAds: 0, totalImpressions: 0, totalClicks: 0, avgCtr: '0.00' })
  const [loading, setLoading] = useState(true)
  const [searchQuery, setSearchQuery] = useState('')
  const [filterPosition, setFilterPosition] = useState('all')
  const [filterStatus, setFilterStatus] = useState<'all' | 'active' | 'inactive'>('all')
  const [activeTab, setActiveTab] = useState('list')

  // حالة النموذج
  const [showDialog, setShowDialog] = useState(false)
  const [editingId, setEditingId] = useState<string | null>(null)
  const [form, setForm] = useState({ ...emptyForm })
  const [saving, setSaving] = useState(false)
  const [copiedId, setCopiedId] = useState<string | null>(null)

  // حالة الحذف
  const [deleteId, setDeleteId] = useState<string | null>(null)
  const [deleting, setDeleting] = useState(false)

  // حالة المعاينة
  const [previewAd, setPreviewAd] = useState<AdData | null>(null)

  const fetchAds = useCallback(async () => {
    try {
      setLoading(true)
      const res = await fetch('/api/admin/ads')
      if (!res.ok) throw new Error('فشل في جلب الإعلانات')
      const data = await res.json()
      setAds(data.ads || [])
      setStats(data.stats || { totalAds: 0, activeAds: 0, totalImpressions: 0, totalClicks: 0, avgCtr: '0.00' })
    } catch (err) {
      console.error(err)
    } finally {
      setLoading(false)
    }
  }, [])

  useEffect(() => {
    fetchAds()
  }, [fetchAds])

  // فتح نموذج إنشاء
  const openCreate = () => {
    setEditingId(null)
    setForm({ ...emptyForm })
    setShowDialog(true)
  }

  // فتح نموذج تعديل
  const openEdit = (ad: AdData) => {
    setEditingId(ad.id)
    setForm({
      title: ad.title,
      position: ad.position,
      type: ad.type,
      advertiser: ad.advertiser || '',
      imageUrl: ad.imageUrl || '',
      linkUrl: ad.linkUrl || '',
      content: ad.content || '',
      isActive: ad.isActive,
      priority: ad.priority,
      targetPages: ad.targetPages || 'all',
      sizePreset: 'custom',
      width: ad.width || '',
      height: ad.height || '',
      startDate: ad.startDate ? new Date(ad.startDate).toISOString().split('T')[0] : '',
      endDate: ad.endDate ? new Date(ad.endDate).toISOString().split('T')[0] : '',
    })
    setShowDialog(true)
  }

  // تكرار إعلان
  const duplicateAd = (ad: AdData) => {
    setEditingId(null)
    setForm({
      title: ad.title + ' (نسخة)',
      position: ad.position,
      type: ad.type,
      advertiser: ad.advertiser || '',
      imageUrl: ad.imageUrl || '',
      linkUrl: ad.linkUrl || '',
      content: ad.content || '',
      isActive: false, // النسخة تكون متوقفة افتراضياً
      priority: ad.priority,
      targetPages: ad.targetPages || 'all',
      sizePreset: 'custom',
      width: ad.width || '',
      height: ad.height || '',
      startDate: '',
      endDate: '',
    })
    setShowDialog(true)
  }

  // حفظ الإعلان
  const handleSave = async () => {
    if (!form.title || !form.position) return

    try {
      setSaving(true)

      let width = form.width
      let height = form.height

      if (form.sizePreset !== 'custom' && form.sizePreset !== 'responsive') {
        const parts = form.sizePreset.split('x')
        width = parts[0] + 'px'
        height = parts[1] + 'px'
      } else if (form.sizePreset === 'responsive') {
        width = 'responsive'
        height = 'auto'
      }

      const payload = {
        title: form.title,
        position: form.position,
        type: form.type,
        advertiser: form.advertiser || null,
        imageUrl: form.imageUrl || null,
        linkUrl: form.linkUrl || null,
        content: form.content || null,
        isActive: form.isActive,
        priority: form.priority,
        targetPages: form.targetPages,
        width: width || null,
        height: height || null,
        startDate: form.startDate || null,
        endDate: form.endDate || null,
      }

      if (editingId) {
        const res = await fetch(`/api/admin/ads/${editingId}`, {
          method: 'PATCH',
          headers: { 'Content-Type': 'application/json' },
          body: JSON.stringify(payload),
        })
        if (!res.ok) throw new Error('فشل في تحديث الإعلان')
      } else {
        const res = await fetch('/api/admin/ads', {
          method: 'POST',
          headers: { 'Content-Type': 'application/json' },
          body: JSON.stringify(payload),
        })
        if (!res.ok) throw new Error('فشل في إنشاء الإعلان')
      }

      setShowDialog(false)
      fetchAds()
    } catch (err) {
      console.error(err)
      alert('حدث خطأ أثناء الحفظ')
    } finally {
      setSaving(false)
    }
  }

  // تبديل حالة الإعلان
  const toggleActive = async (ad: AdData) => {
    try {
      const res = await fetch(`/api/admin/ads/${ad.id}`, {
        method: 'PATCH',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ isActive: !ad.isActive }),
      })
      if (!res.ok) throw new Error('فشل في تحديث الحالة')
      fetchAds()
    } catch (err) {
      console.error(err)
    }
  }

  // حذف إعلان
  const handleDelete = async () => {
    if (!deleteId) return
    try {
      setDeleting(true)
      const res = await fetch(`/api/admin/ads/${deleteId}`, { method: 'DELETE' })
      if (!res.ok) throw new Error('فشل في حذف الإعلان')
      setDeleteId(null)
      fetchAds()
    } catch (err) {
      console.error(err)
      alert('حدث خطأ أثناء الحذف')
    } finally {
      setDeleting(false)
    }
  }

  // نسخ كود الإعلان
  const copyEmbedCode = async (ad: AdData) => {
    const code = `<AdBanner position="${ad.position}" page="${ad.targetPages || 'all'}" />`
    try {
      await navigator.clipboard.writeText(code)
      setCopiedId(ad.id)
      setTimeout(() => setCopiedId(null), 2000)
    } catch {
      // fallback
    }
  }

  // فلترة الإعلانات
  const filteredAds = ads.filter(ad => {
    const matchSearch = !searchQuery || ad.title.toLowerCase().includes(searchQuery.toLowerCase()) || (ad.advertiser || '').toLowerCase().includes(searchQuery.toLowerCase())
    const matchPosition = filterPosition === 'all' || ad.position === filterPosition
    const matchStatus = filterStatus === 'all' || (filterStatus === 'active' ? ad.isActive : !ad.isActive)
    return matchSearch && matchPosition && matchStatus
  })

  const ctr = (ad: AdData) => ad.impressions > 0 ? ((ad.clicks / ad.impressions) * 100).toFixed(2) : '0.00'

  // عند الضغط على موضع في خريطة المواضع
  const handlePositionMapClick = (position: string) => {
    setFilterPosition(position)
    setActiveTab('list')
  }

  // حساب الإعلانات النشطة والمنتهية
  const now = new Date()
  const expiredAds = ads.filter(a => a.endDate && new Date(a.endDate) < now)
  const scheduledAds = ads.filter(a => a.startDate && new Date(a.startDate) > now)

  return (
    <TooltipProvider>
      <div className="space-y-6" dir="rtl">
        {/* ===== رأس الصفحة ===== */}
        <div className="flex items-center justify-between flex-wrap gap-4">
          <div>
            <h2 className="text-2xl font-bold text-foreground flex items-center gap-2">
              <div className="flex items-center justify-center size-9 rounded-xl bg-emerald-600 text-white shadow-lg shadow-emerald-600/25">
                <Megaphone className="size-5" />
              </div>
              إدارة الإعلانات
            </h2>
            <p className="text-sm text-muted-foreground mt-1">إنشاء وإدارة الإعلانات التي تظهر في جميع صفحات الموقع</p>
          </div>
          <div className="flex items-center gap-2">
            <Button variant="outline" size="sm" onClick={fetchAds} className="gap-1.5">
              <RefreshCw className="size-3.5" />
              تحديث
            </Button>
            <Button onClick={openCreate} className="bg-emerald-600 hover:bg-emerald-700 shadow-lg shadow-emerald-600/25 gap-2">
              <Plus className="size-4" />
              إعلان جديد
            </Button>
          </div>
        </div>

        {/* ===== بطاقات الإحصائيات ===== */}
        <div className="grid grid-cols-2 md:grid-cols-5 gap-4">
          <Card className="p-4 border-0 bg-gradient-to-bl from-blue-50 to-blue-100/50 dark:from-blue-950/40 dark:to-blue-900/20">
            <div className="flex items-center gap-3">
              <div className="size-10 rounded-xl bg-blue-500/15 flex items-center justify-center">
                <LayoutGrid className="size-5 text-blue-600 dark:text-blue-400" />
              </div>
              <div>
                <p className="text-xs text-muted-foreground">إجمالي الإعلانات</p>
                <p className="text-xl font-bold text-foreground">{stats.totalAds}</p>
              </div>
            </div>
          </Card>
          <Card className="p-4 border-0 bg-gradient-to-bl from-emerald-50 to-emerald-100/50 dark:from-emerald-950/40 dark:to-emerald-900/20">
            <div className="flex items-center gap-3">
              <div className="size-10 rounded-xl bg-emerald-500/15 flex items-center justify-center">
                <Power className="size-5 text-emerald-600 dark:text-emerald-400" />
              </div>
              <div>
                <p className="text-xs text-muted-foreground">نشطة</p>
                <p className="text-xl font-bold text-foreground">{stats.activeAds}</p>
              </div>
            </div>
          </Card>
          <Card className="p-4 border-0 bg-gradient-to-bl from-violet-50 to-violet-100/50 dark:from-violet-950/40 dark:to-violet-900/20">
            <div className="flex items-center gap-3">
              <div className="size-10 rounded-xl bg-violet-500/15 flex items-center justify-center">
                <Eye className="size-5 text-violet-600 dark:text-violet-400" />
              </div>
              <div>
                <p className="text-xs text-muted-foreground">المشاهدات</p>
                <p className="text-xl font-bold text-foreground">{formatNumber(stats.totalImpressions)}</p>
              </div>
            </div>
          </Card>
          <Card className="p-4 border-0 bg-gradient-to-bl from-amber-50 to-amber-100/50 dark:from-amber-950/40 dark:to-amber-900/20">
            <div className="flex items-center gap-3">
              <div className="size-10 rounded-xl bg-amber-500/15 flex items-center justify-center">
                <MousePointer className="size-5 text-amber-600 dark:text-amber-400" />
              </div>
              <div>
                <p className="text-xs text-muted-foreground">النقرات</p>
                <p className="text-xl font-bold text-foreground">{formatNumber(stats.totalClicks)}</p>
              </div>
            </div>
          </Card>
          <Card className="p-4 border-0 bg-gradient-to-bl from-rose-50 to-rose-100/50 dark:from-rose-950/40 dark:to-rose-900/20">
            <div className="flex items-center gap-3">
              <div className="size-10 rounded-xl bg-rose-500/15 flex items-center justify-center">
                <TrendingUp className="size-5 text-rose-600 dark:text-rose-400" />
              </div>
              <div>
                <p className="text-xs text-muted-foreground">معدل النقر CTR</p>
                <p className="text-xl font-bold text-foreground">{stats.avgCtr}%</p>
              </div>
            </div>
          </Card>
        </div>

        {/* ===== تنبيهات ===== */}
        {expiredAds.length > 0 && (
          <div className="bg-red-50 dark:bg-red-950/30 border border-red-200 dark:border-red-800 rounded-xl p-4 flex items-center gap-3">
            <div className="size-8 rounded-lg bg-red-500/15 flex items-center justify-center shrink-0">
              <Clock className="size-4 text-red-500" />
            </div>
            <div>
              <p className="text-sm font-semibold text-red-700 dark:text-red-400">
                {expiredAds.length} إعلان منتهي الصلاحية
              </p>
              <p className="text-xs text-red-600/70 dark:text-red-400/60">
                يوجد إعلانات انتهت فترة عرضها، يمكنك تجديدها أو إيقافها
              </p>
            </div>
          </div>
        )}

        {scheduledAds.length > 0 && (
          <div className="bg-blue-50 dark:bg-blue-950/30 border border-blue-200 dark:border-blue-800 rounded-xl p-4 flex items-center gap-3">
            <div className="size-8 rounded-lg bg-blue-500/15 flex items-center justify-center shrink-0">
              <Calendar className="size-4 text-blue-500" />
            </div>
            <div>
              <p className="text-sm font-semibold text-blue-700 dark:text-blue-400">
                {scheduledAds.length} إعلان مجدول
              </p>
              <p className="text-xs text-blue-600/70 dark:text-blue-400/60">
                إعلانات سيتم تفعيلها تلقائياً عند حلول موعدها
              </p>
            </div>
          </div>
        )}

        {/* ===== التبويبات ===== */}
        <Tabs value={activeTab} onValueChange={setActiveTab}>
          <TabsList className="bg-muted/40 p-1 rounded-xl">
            <TabsTrigger value="list" className="gap-1.5 rounded-lg text-xs">
              <LayoutGrid className="size-3.5" />
              قائمة الإعلانات
            </TabsTrigger>
            <TabsTrigger value="map" className="gap-1.5 rounded-lg text-xs">
              <MapPin className="size-3.5" />
              خريطة المواضع
            </TabsTrigger>
            <TabsTrigger value="analytics" className="gap-1.5 rounded-lg text-xs">
              <BarChart3 className="size-3.5" />
              التحليلات
            </TabsTrigger>
          </TabsList>

          {/* ===== تبويب القائمة ===== */}
          <TabsContent value="list" className="space-y-4 mt-4">
            {/* فلاتر البحث */}
            <div className="flex flex-wrap items-center gap-3">
              <div className="relative flex-1 min-w-[200px]">
                <Search className="absolute right-3 top-1/2 -translate-y-1/2 size-4 text-muted-foreground" />
                <Input
                  placeholder="بحث بإسم الإعلان أو المعلن..."
                  value={searchQuery}
                  onChange={e => setSearchQuery(e.target.value)}
                  className="pr-9"
                />
              </div>
              <Select value={filterPosition} onValueChange={setFilterPosition}>
                <SelectTrigger className="w-[180px]">
                  <Filter className="size-4 ml-1 text-muted-foreground" />
                  <SelectValue placeholder="الموضع" />
                </SelectTrigger>
                <SelectContent>
                  <SelectItem value="all">جميع المواضع</SelectItem>
                  {POSITIONS.map(p => (
                    <SelectItem key={p.value} value={p.value}>{p.label}</SelectItem>
                  ))}
                </SelectContent>
              </Select>
              <Select value={filterStatus} onValueChange={(v: any) => setFilterStatus(v)}>
                <SelectTrigger className="w-[140px]">
                  <SelectValue placeholder="الحالة" />
                </SelectTrigger>
                <SelectContent>
                  <SelectItem value="all">الكل</SelectItem>
                  <SelectItem value="active">نشط</SelectItem>
                  <SelectItem value="inactive">متوقف</SelectItem>
                </SelectContent>
              </Select>
              {(filterPosition !== 'all' || filterStatus !== 'all' || searchQuery) && (
                <Button
                  variant="ghost"
                  size="sm"
                  onClick={() => {
                    setFilterPosition('all')
                    setFilterStatus('all')
                    setSearchQuery('')
                  }}
                  className="text-xs gap-1"
                >
                  مسح الفلاتر
                </Button>
              )}
            </div>

            {/* جدول الإعلانات */}
            {loading ? (
              <div className="space-y-3">
                {Array.from({ length: 4 }).map((_, i) => (
                  <div key={i} className="h-16 bg-muted/30 rounded-xl animate-pulse" />
                ))}
              </div>
            ) : filteredAds.length === 0 ? (
              <Card className="p-12 text-center border-dashed">
                <div className="size-16 rounded-full bg-muted/50 flex items-center justify-center mx-auto mb-4">
                  <DollarSign className="size-8 text-muted-foreground/40" />
                </div>
                <h3 className="font-bold text-lg text-muted-foreground">
                  {searchQuery || filterPosition !== 'all' || filterStatus !== 'all'
                    ? 'لا توجد نتائج'
                    : 'لا توجد إعلانات'}
                </h3>
                <p className="text-sm text-muted-foreground/70 mt-1">
                  {searchQuery || filterPosition !== 'all' || filterStatus !== 'all'
                    ? 'جرب تغيير معايير البحث'
                    : 'ابدأ بإضافة إعلان جديد ليظهر في صفحات الموقع'}
                </p>
                {!searchQuery && filterPosition === 'all' && filterStatus === 'all' && (
                  <Button onClick={openCreate} className="mt-4 bg-emerald-600 hover:bg-emerald-700 gap-2">
                    <Plus className="size-4" />
                    إعلان جديد
                  </Button>
                )}
              </Card>
            ) : (
              <Card className="overflow-hidden border-0 shadow-sm">
                <Table>
                  <TableHeader>
                    <TableRow className="bg-muted/30 hover:bg-muted/30">
                      <TableHead className="text-right font-semibold">الإعلان</TableHead>
                      <TableHead className="text-right font-semibold">الموضع</TableHead>
                      <TableHead className="text-right font-semibold">النوع</TableHead>
                      <TableHead className="text-right font-semibold">الصفحات</TableHead>
                      <TableHead className="text-right font-semibold">الحالة</TableHead>
                      <TableHead className="text-right font-semibold">المشاهدات</TableHead>
                      <TableHead className="text-right font-semibold">النقرات</TableHead>
                      <TableHead className="text-right font-semibold">CTR</TableHead>
                      <TableHead className="text-right font-semibold w-[60px]">إجراءات</TableHead>
                    </TableRow>
                  </TableHeader>
                  <TableBody>
                    {filteredAds.map((ad) => {
                      const isExpired = ad.endDate ? new Date(ad.endDate) < now : false
                      const isScheduled = ad.startDate ? new Date(ad.startDate) > now : false

                      return (
                        <TableRow key={ad.id} className="group hover:bg-muted/20 transition-colors">
                          <TableCell>
                            <div className="flex items-center gap-3">
                              {ad.imageUrl ? (
                                <div className="size-10 rounded-lg overflow-hidden bg-muted border shrink-0">
                                  <img src={ad.imageUrl} alt="" className="w-full h-full object-cover" />
                                </div>
                              ) : (
                                <div className="size-10 rounded-lg bg-gradient-to-br from-emerald-100 to-teal-100 dark:from-emerald-900/30 dark:to-teal-900/30 flex items-center justify-center shrink-0">
                                  {ad.type === 'image' ? <ImageIcon className="size-4 text-emerald-600 dark:text-emerald-400" /> :
                                   ad.type === 'adsense' ? <DollarSign className="size-4 text-amber-600 dark:text-amber-400" /> :
                                   <Code className="size-4 text-violet-600 dark:text-violet-400" />}
                                </div>
                              )}
                              <div className="min-w-0">
                                <p className="font-semibold text-sm truncate max-w-[200px]">{ad.title}</p>
                                {ad.advertiser && (
                                  <p className="text-xs text-muted-foreground truncate">{ad.advertiser}</p>
                                )}
                              </div>
                            </div>
                          </TableCell>
                          <TableCell>
                            <Tooltip>
                              <TooltipTrigger>
                                <Badge variant="secondary" className="text-xs font-medium">{positionLabel(ad.position)}</Badge>
                              </TooltipTrigger>
                              <TooltipContent>
                                <p>{POSITIONS.find(p => p.value === ad.position)?.desc}</p>
                              </TooltipContent>
                            </Tooltip>
                          </TableCell>
                          <TableCell>
                            <span className="text-xs text-muted-foreground">{typeLabel(ad.type)}</span>
                          </TableCell>
                          <TableCell>
                            <span className="text-xs text-muted-foreground">
                              {TARGET_PAGES.find(p => p.value === ad.targetPages)?.label || ad.targetPages || 'الكل'}
                            </span>
                          </TableCell>
                          <TableCell>
                            <button onClick={() => toggleActive(ad)} className="focus:outline-none">
                              <Badge
                                variant="secondary"
                                className={`text-xs font-semibold cursor-pointer transition-colors ${
                                  isExpired
                                    ? 'bg-red-100 text-red-700 dark:bg-red-900/40 dark:text-red-400'
                                    : isScheduled
                                    ? 'bg-blue-100 text-blue-700 dark:bg-blue-900/40 dark:text-blue-400'
                                    : ad.isActive
                                    ? 'bg-emerald-100 text-emerald-700 dark:bg-emerald-900/40 dark:text-emerald-400 hover:bg-emerald-200 dark:hover:bg-emerald-900/60'
                                    : 'bg-gray-100 text-gray-500 dark:bg-gray-800 dark:text-gray-400 hover:bg-gray-200 dark:hover:bg-gray-700'
                                }`}
                              >
                                {isExpired ? '● منتهي' : isScheduled ? '● مجدول' : ad.isActive ? '● نشط' : '○ متوقف'}
                              </Badge>
                            </button>
                          </TableCell>
                          <TableCell className="text-sm tabular-nums">{formatNumber(ad.impressions)}</TableCell>
                          <TableCell className="text-sm tabular-nums">{formatNumber(ad.clicks)}</TableCell>
                          <TableCell className="text-sm font-semibold tabular-nums">
                            <span className={
                              parseFloat(ctr(ad)) > 2 ? 'text-emerald-600 dark:text-emerald-400' :
                              parseFloat(ctr(ad)) > 0.5 ? 'text-amber-600 dark:text-amber-400' :
                              'text-muted-foreground'
                            }>
                              {ctr(ad)}%
                            </span>
                          </TableCell>
                          <TableCell>
                            <DropdownMenu>
                              <DropdownMenuTrigger asChild>
                                <Button variant="ghost" size="icon" className="size-8 opacity-0 group-hover:opacity-100 transition-opacity">
                                  <MoreVertical className="size-4" />
                                </Button>
                              </DropdownMenuTrigger>
                              <DropdownMenuContent align="end" className="w-44">
                                <DropdownMenuItem onClick={() => openEdit(ad)} className="gap-2">
                                  <Edit3 className="size-4" /> تعديل
                                </DropdownMenuItem>
                                <DropdownMenuItem onClick={() => duplicateAd(ad)} className="gap-2">
                                  <Copy className="size-4" /> تكرار
                                </DropdownMenuItem>
                                <DropdownMenuItem onClick={() => setPreviewAd(ad)} className="gap-2">
                                  <Eye className="size-4" /> معاينة
                                </DropdownMenuItem>
                                <DropdownMenuItem onClick={() => toggleActive(ad)} className="gap-2">
                                  {ad.isActive ? <><PowerOff className="size-4" /> إيقاف</> : <><Power className="size-4" /> تفعيل</>}
                                </DropdownMenuItem>
                                <DropdownMenuItem onClick={() => copyEmbedCode(ad)} className="gap-2">
                                  {copiedId === ad.id ? <><Check className="size-4 text-emerald-500" /> تم النسخ</> : <><Code className="size-4" /> نسخ الكود</>}
                                </DropdownMenuItem>
                                <DropdownMenuSeparator />
                                <DropdownMenuItem onClick={() => setDeleteId(ad.id)} className="gap-2 text-red-600 dark:text-red-400">
                                  <Trash2 className="size-4" /> حذف
                                </DropdownMenuItem>
                              </DropdownMenuContent>
                            </DropdownMenu>
                          </TableCell>
                        </TableRow>
                      )
                    })}
                  </TableBody>
                </Table>
              </Card>
            )}
          </TabsContent>

          {/* ===== تبويب خريطة المواضع ===== */}
          <TabsContent value="map" className="mt-4">
            <PositionMap ads={ads} onPositionClick={handlePositionMapClick} />
          </TabsContent>

          {/* ===== تبويب التحليلات ===== */}
          <TabsContent value="analytics" className="space-y-4 mt-4">
            <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
              {/* أداء الإعلانات حسب الموضع */}
              <Card className="border-0 shadow-sm">
                <div className="px-5 py-3.5 border-b bg-gradient-to-l from-violet-50 to-transparent dark:from-violet-950/20">
                  <div className="flex items-center gap-2.5">
                    <div className="flex items-center justify-center size-8 rounded-xl bg-violet-600 text-white shadow-md shadow-violet-500/25">
                      <BarChart3 className="w-4 h-4" />
                    </div>
                    <span className="font-bold text-sm">أداء الإعلانات حسب الموضع</span>
                  </div>
                </div>
                <div className="p-4 space-y-3">
                  {POSITIONS.map(pos => {
                    const posAds = ads.filter(a => a.position === pos.value)
                    const totalImpressions = posAds.reduce((s, a) => s + a.impressions, 0)
                    const totalClicks = posAds.reduce((s, a) => s + a.clicks, 0)
                    const posCtr = totalImpressions > 0 ? ((totalClicks / totalImpressions) * 100).toFixed(2) : '0.00'
                    const activeCount = posAds.filter(a => a.isActive).length

                    return (
                      <div key={pos.value} className="flex items-center gap-3 p-3 bg-muted/20 rounded-xl">
                        <div className="size-8 rounded-lg bg-muted/50 flex items-center justify-center shrink-0">
                          <pos.icon className="size-4 text-muted-foreground" />
                        </div>
                        <div className="flex-1 min-w-0">
                          <div className="flex items-center justify-between">
                            <span className="text-sm font-semibold truncate">{pos.label}</span>
                            <div className="flex items-center gap-2">
                              <span className="text-xs text-muted-foreground">
                                {activeCount}/{posAds.length} نشط
                              </span>
                            </div>
                          </div>
                          <div className="flex items-center gap-4 mt-1.5">
                            <span className="text-[11px] text-muted-foreground flex items-center gap-1">
                              <Eye className="size-3" /> {formatNumber(totalImpressions)}
                            </span>
                            <span className="text-[11px] text-muted-foreground flex items-center gap-1">
                              <MousePointer className="size-3" /> {formatNumber(totalClicks)}
                            </span>
                            <span className={`text-[11px] font-semibold ${
                              parseFloat(posCtr) > 2 ? 'text-emerald-600 dark:text-emerald-400' :
                              parseFloat(posCtr) > 0.5 ? 'text-amber-600 dark:text-amber-400' :
                              'text-muted-foreground'
                            }`}>
                              CTR: {posCtr}%
                            </span>
                          </div>
                        </div>
                      </div>
                    )
                  })}
                </div>
              </Card>

              {/* أفضل الإعلانات أداءً */}
              <Card className="border-0 shadow-sm">
                <div className="px-5 py-3.5 border-b bg-gradient-to-l from-emerald-50 to-transparent dark:from-emerald-950/20">
                  <div className="flex items-center gap-2.5">
                    <div className="flex items-center justify-center size-8 rounded-xl bg-emerald-600 text-white shadow-md shadow-emerald-500/25">
                      <TrendingUp className="w-4 h-4" />
                    </div>
                    <span className="font-bold text-sm">أفضل الإعلانات أداءً</span>
                  </div>
                </div>
                <div className="p-4 space-y-3">
                  {[...ads]
                    .sort((a, b) => {
                      const ctrA = a.impressions > 0 ? a.clicks / a.impressions : 0
                      const ctrB = b.impressions > 0 ? b.clicks / b.impressions : 0
                      return ctrB - ctrA
                    })
                    .slice(0, 8)
                    .map((ad, idx) => (
                      <div key={ad.id} className="flex items-center gap-3 p-3 bg-muted/20 rounded-xl">
                        <div className={`size-7 rounded-lg flex items-center justify-center shrink-0 font-bold text-xs ${
                          idx === 0 ? 'bg-amber-100 text-amber-700 dark:bg-amber-900/40 dark:text-amber-400' :
                          idx === 1 ? 'bg-gray-100 text-gray-600 dark:bg-gray-800 dark:text-gray-400' :
                          idx === 2 ? 'bg-orange-100 text-orange-700 dark:bg-orange-900/40 dark:text-orange-400' :
                          'bg-muted/50 text-muted-foreground'
                        }`}>
                          {idx + 1}
                        </div>
                        <div className="flex-1 min-w-0">
                          <p className="text-sm font-semibold truncate">{ad.title}</p>
                          <div className="flex items-center gap-3 mt-1">
                            <span className="text-[11px] text-muted-foreground">{positionLabel(ad.position)}</span>
                            <span className={`text-[11px] font-semibold ${
                              parseFloat(ctr(ad)) > 2 ? 'text-emerald-600 dark:text-emerald-400' :
                              'text-muted-foreground'
                            }`}>
                              CTR: {ctr(ad)}%
                            </span>
                          </div>
                        </div>
                        <div className="text-left shrink-0">
                          <p className="text-sm font-semibold tabular-nums">{formatNumber(ad.clicks)}</p>
                          <p className="text-[10px] text-muted-foreground">نقرة</p>
                        </div>
                      </div>
                    ))
                  }
                  {ads.length === 0 && (
                    <div className="text-center py-8 text-muted-foreground text-sm">
                      لا توجد بيانات أداء بعد
                    </div>
                  )}
                </div>
              </Card>
            </div>
          </TabsContent>
        </Tabs>

        {/* ===== حوار الإنشاء/التعديل ===== */}
        <Dialog open={showDialog} onOpenChange={setShowDialog}>
          <DialogContent className="max-w-2xl max-h-[90vh] overflow-y-auto" dir="rtl">
            <DialogHeader>
              <DialogTitle className="flex items-center gap-2">
                <div className="flex items-center justify-center size-8 rounded-xl bg-emerald-600 text-white">
                  <Megaphone className="size-4" />
                </div>
                {editingId ? 'تعديل الإعلان' : 'إعلان جديد'}
              </DialogTitle>
            </DialogHeader>

            <div className="space-y-5">
              {/* عنوان الإعلان والمعلن */}
              <div className="grid grid-cols-2 gap-4">
                <div className="space-y-2">
                  <Label className="text-sm font-semibold">عنوان الإعلان *</Label>
                  <Input
                    placeholder="مثال: إعلان بيت إن سبورت"
                    value={form.title}
                    onChange={e => setForm({ ...form, title: e.target.value })}
                  />
                </div>
                <div className="space-y-2">
                  <Label className="text-sm font-semibold">اسم المعلن</Label>
                  <Input
                    placeholder="مثال: beIN Sports"
                    value={form.advertiser}
                    onChange={e => setForm({ ...form, advertiser: e.target.value })}
                  />
                </div>
              </div>

              {/* الموضع والنوع */}
              <div className="grid grid-cols-2 gap-4">
                <div className="space-y-2">
                  <Label className="text-sm font-semibold">الموضع *</Label>
                  <Select value={form.position} onValueChange={v => setForm({ ...form, position: v })}>
                    <SelectTrigger><SelectValue /></SelectTrigger>
                    <SelectContent>
                      {POSITIONS.map(p => (
                        <SelectItem key={p.value} value={p.value}>
                          <div className="flex items-center gap-2">
                            <p.icon className="size-3.5 text-muted-foreground" />
                            {p.label}
                          </div>
                        </SelectItem>
                      ))}
                    </SelectContent>
                  </Select>
                  <p className="text-[11px] text-muted-foreground">
                    {POSITIONS.find(p => p.value === form.position)?.desc}
                  </p>
                </div>
                <div className="space-y-2">
                  <Label className="text-sm font-semibold">نوع الإعلان</Label>
                  <Select value={form.type} onValueChange={v => setForm({ ...form, type: v })}>
                    <SelectTrigger><SelectValue /></SelectTrigger>
                    <SelectContent>
                      {AD_TYPES.map(t => (
                        <SelectItem key={t.value} value={t.value}>
                          <div className="flex items-center gap-2">
                            <t.icon className="size-3.5 text-muted-foreground" />
                            {t.label}
                          </div>
                        </SelectItem>
                      ))}
                    </SelectContent>
                  </Select>
                </div>
              </div>

              {/* الصفحات المستهدفة */}
              <div className="space-y-2">
                <Label className="text-sm font-semibold">الصفحات المستهدفة</Label>
                <Select value={form.targetPages} onValueChange={v => setForm({ ...form, targetPages: v })}>
                  <SelectTrigger><SelectValue /></SelectTrigger>
                  <SelectContent>
                    {TARGET_PAGES.map(p => (
                      <SelectItem key={p.value} value={p.value}>
                        <div className="flex items-center gap-2">
                          <p.icon className="size-3.5 text-muted-foreground" />
                          {p.label}
                        </div>
                      </SelectItem>
                    ))}
                  </SelectContent>
                </Select>
              </div>

              {/* حجم الإعلان */}
              <div className="space-y-2">
                <Label className="text-sm font-semibold">حجم الإعلان</Label>
                <Select value={form.sizePreset} onValueChange={v => setForm({ ...form, sizePreset: v })}>
                  <SelectTrigger><SelectValue /></SelectTrigger>
                  <SelectContent>
                    {SIZE_PRESETS.map(s => (
                      <SelectItem key={s.value} value={s.value}>
                        <div>
                          <span>{s.label}</span>
                          <span className="text-muted-foreground text-[10px] mr-2">{s.desc}</span>
                        </div>
                      </SelectItem>
                    ))}
                  </SelectContent>
                </Select>
                {form.sizePreset === 'custom' && (
                  <div className="grid grid-cols-2 gap-3 mt-2">
                    <Input placeholder="العرض (مثال: 300px)" value={form.width} onChange={e => setForm({ ...form, width: e.target.value })} />
                    <Input placeholder="الارتفاع (مثال: 250px)" value={form.height} onChange={e => setForm({ ...form, height: e.target.value })} />
                  </div>
                )}
              </div>

              {/* محتوى حسب نوع الإعلان */}
              {form.type === 'image' && (
                <div className="space-y-4">
                  <div className="space-y-2">
                    <Label className="text-sm font-semibold">رابط صورة الإعلان *</Label>
                    <Input
                      placeholder="https://example.com/ad-image.jpg"
                      value={form.imageUrl}
                      onChange={e => setForm({ ...form, imageUrl: e.target.value })}
                    />
                    {form.imageUrl && (
                      <div className="mt-2 rounded-lg overflow-hidden border bg-muted/20 max-h-40">
                        <img src={form.imageUrl} alt="معاينة" className="w-full h-full object-contain" />
                      </div>
                    )}
                  </div>
                  <div className="space-y-2">
                    <Label className="text-sm font-semibold">رابط عند النقر</Label>
                    <Input
                      placeholder="https://example.com/landing-page"
                      value={form.linkUrl}
                      onChange={e => setForm({ ...form, linkUrl: e.target.value })}
                      dir="ltr"
                    />
                  </div>
                </div>
              )}

              {form.type === 'html' && (
                <div className="space-y-2">
                  <Label className="text-sm font-semibold">كود HTML *</Label>
                  <Textarea
                    placeholder="<div>محتوى الإعلان HTML</div>"
                    value={form.content}
                    onChange={e => setForm({ ...form, content: e.target.value })}
                    rows={6}
                    dir="ltr"
                    className="font-mono text-sm"
                  />
                </div>
              )}

              {form.type === 'adsense' && (
                <div className="space-y-2">
                  <Label className="text-sm font-semibold">كود Google AdSense *</Label>
                  <Textarea
                    placeholder="<!-- Google AdSense code -->"
                    value={form.content}
                    onChange={e => setForm({ ...form, content: e.target.value })}
                    rows={6}
                    dir="ltr"
                    className="font-mono text-sm"
                  />
                </div>
              )}

              {/* الأولوية والتواريخ */}
              <div className="grid grid-cols-3 gap-4">
                <div className="space-y-2">
                  <Label className="text-sm font-semibold flex items-center gap-1">
                    <ArrowUpDown className="size-3.5" /> الأولوية
                  </Label>
                  <Input
                    type="number"
                    min="0"
                    max="100"
                    value={form.priority}
                    onChange={e => setForm({ ...form, priority: Number(e.target.value) })}
                  />
                  <p className="text-[11px] text-muted-foreground">أعلى = يظهر أولاً</p>
                </div>
                <div className="space-y-2">
                  <Label className="text-sm font-semibold flex items-center gap-1">
                    <Calendar className="size-3.5" /> تاريخ البداية
                  </Label>
                  <Input
                    type="date"
                    value={form.startDate}
                    onChange={e => setForm({ ...form, startDate: e.target.value })}
                  />
                </div>
                <div className="space-y-2">
                  <Label className="text-sm font-semibold flex items-center gap-1">
                    <Calendar className="size-3.5" /> تاريخ الانتهاء
                  </Label>
                  <Input
                    type="date"
                    value={form.endDate}
                    onChange={e => setForm({ ...form, endDate: e.target.value })}
                  />
                </div>
              </div>

              {/* حالة التفعيل */}
              <div className="flex items-center justify-between p-4 bg-muted/30 rounded-xl">
                <div className="flex items-center gap-3">
                  {form.isActive ? (
                    <ToggleRight className="size-5 text-emerald-600 dark:text-emerald-400" />
                  ) : (
                    <ToggleLeft className="size-5 text-muted-foreground" />
                  )}
                  <div>
                    <Label className="text-sm font-semibold">حالة الإعلان</Label>
                    <p className="text-xs text-muted-foreground mt-0.5">
                      {form.isActive ? 'الإعلان نشط وسيظهر في الصفحات' : 'الإعلان متوقف ولن يظهر'}
                    </p>
                  </div>
                </div>
                <Switch
                  checked={form.isActive}
                  onCheckedChange={v => setForm({ ...form, isActive: v })}
                />
              </div>
            </div>

            <DialogFooter className="gap-2 mt-4">
              <Button variant="outline" onClick={() => setShowDialog(false)}>إلغاء</Button>
              <Button
                onClick={handleSave}
                disabled={saving || !form.title || !form.position}
                className="bg-emerald-600 hover:bg-emerald-700 min-w-[120px]"
              >
                {saving ? 'جاري الحفظ...' : editingId ? 'حفظ التعديلات' : 'إنشاء الإعلان'}
              </Button>
            </DialogFooter>
          </DialogContent>
        </Dialog>

        {/* ===== حوار المعاينة ===== */}
        <Dialog open={!!previewAd} onOpenChange={() => setPreviewAd(null)}>
          <DialogContent className="max-w-lg" dir="rtl">
            <DialogHeader>
              <DialogTitle className="flex items-center gap-2">
                <Eye className="size-5 text-emerald-500" />
                معاينة الإعلان - {previewAd?.title}
              </DialogTitle>
            </DialogHeader>
            {previewAd && (
              <div className="space-y-4">
                <div className="bg-muted/20 rounded-xl p-4 border border-dashed">
                  {previewAd.type === 'image' && previewAd.imageUrl && (
                    <div className="rounded-lg overflow-hidden">
                      {previewAd.linkUrl ? (
                        <a href={previewAd.linkUrl} target="_blank" rel="noopener noreferrer" className="block">
                          <img src={previewAd.imageUrl} alt={previewAd.title} className="w-full object-contain hover:opacity-90 transition-opacity" />
                        </a>
                      ) : (
                        <img src={previewAd.imageUrl} alt={previewAd.title} className="w-full object-contain" />
                      )}
                    </div>
                  )}
                  {previewAd.type === 'html' && previewAd.content && (
                    <div dangerouslySetInnerHTML={{ __html: previewAd.content }} />
                  )}
                  {previewAd.type === 'adsense' && (
                    <div className="text-center py-6 text-muted-foreground text-sm border border-dashed rounded-lg">
                      <DollarSign className="size-8 mx-auto mb-2 opacity-40" />
                      كود Google AdSense (يظهر عند النشر)
                    </div>
                  )}
                </div>
                <div className="grid grid-cols-2 gap-3 text-sm">
                  <div className="bg-muted/20 rounded-lg p-3">
                    <span className="text-muted-foreground text-xs">الموضع</span>
                    <p className="font-semibold mt-0.5">{positionLabel(previewAd.position)}</p>
                  </div>
                  <div className="bg-muted/20 rounded-lg p-3">
                    <span className="text-muted-foreground text-xs">النوع</span>
                    <p className="font-semibold mt-0.5">{typeLabel(previewAd.type)}</p>
                  </div>
                  <div className="bg-muted/20 rounded-lg p-3">
                    <span className="text-muted-foreground text-xs">الصفحات</span>
                    <p className="font-semibold mt-0.5">{TARGET_PAGES.find(p => p.value === previewAd.targetPages)?.label || previewAd.targetPages}</p>
                  </div>
                  <div className="bg-muted/20 rounded-lg p-3">
                    <span className="text-muted-foreground text-xs">الأولوية</span>
                    <p className="font-semibold mt-0.5">{previewAd.priority}</p>
                  </div>
                  <div className="bg-muted/20 rounded-lg p-3">
                    <span className="text-muted-foreground text-xs">الحالة</span>
                    <p className="font-semibold mt-0.5">{previewAd.isActive ? '● نشط' : '○ متوقف'}</p>
                  </div>
                  <div className="bg-muted/20 rounded-lg p-3">
                    <span className="text-muted-foreground text-xs">النقرات / المشاهدات</span>
                    <p className="font-semibold mt-0.5">{formatNumber(previewAd.clicks)} / {formatNumber(previewAd.impressions)}</p>
                  </div>
                  {previewAd.width && (
                    <div className="bg-muted/20 rounded-lg p-3">
                      <span className="text-muted-foreground text-xs">الأبعاد</span>
                      <p className="font-semibold mt-0.5">{previewAd.width} × {previewAd.height || 'auto'}</p>
                    </div>
                  )}
                  {previewAd.startDate && (
                    <div className="bg-muted/20 rounded-lg p-3">
                      <span className="text-muted-foreground text-xs">الفترة</span>
                      <p className="font-semibold mt-0.5 text-xs">
                        {formatDate(previewAd.startDate)} - {formatDate(previewAd.endDate)}
                      </p>
                    </div>
                  )}
                </div>
                {previewAd.linkUrl && (
                  <div className="flex items-center gap-2 text-sm text-muted-foreground bg-muted/20 rounded-lg p-3">
                    <ExternalLink className="size-4 shrink-0" />
                    <span className="truncate" dir="ltr">{previewAd.linkUrl}</span>
                  </div>
                )}
              </div>
            )}
          </DialogContent>
        </Dialog>

        {/* ===== حوار تأكيد الحذف ===== */}
        <Dialog open={!!deleteId} onOpenChange={() => setDeleteId(null)}>
          <DialogContent className="max-w-sm" dir="rtl">
            <DialogHeader>
              <DialogTitle className="text-red-600 flex items-center gap-2">
                <Trash2 className="size-5" />
                تأكيد الحذف
              </DialogTitle>
            </DialogHeader>
            <p className="text-sm text-muted-foreground">
              هل أنت متأكد من حذف هذا الإعلان؟ لا يمكن التراجع عن هذا الإجراء.
            </p>
            <DialogFooter className="gap-2">
              <Button variant="outline" onClick={() => setDeleteId(null)}>إلغاء</Button>
              <Button onClick={handleDelete} disabled={deleting} variant="destructive">
                {deleting ? 'جاري الحذف...' : 'حذف'}
              </Button>
            </DialogFooter>
          </DialogContent>
        </Dialog>
      </div>
    </TooltipProvider>
  )
}
