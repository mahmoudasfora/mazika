'use client'

import { Shield, Plus, Search } from 'lucide-react'
import { Card, CardContent, CardHeader, CardTitle, CardDescription } from '@/components/ui/card'
import { Badge } from '@/components/ui/badge'
import { Button } from '@/components/ui/button'
import { Input } from '@/components/ui/input'

const ROLE_LABELS: Record<string, string> = {
  admin: 'مدير',
  editor: 'محرر',
  author: 'كاتب',
  moderator: 'مشرف',
  user: 'مستخدم',
}

const ROLE_COLORS: Record<string, string> = {
  admin: 'bg-red-100 text-red-700 dark:bg-red-900 dark:text-red-300',
  editor: 'bg-blue-100 text-blue-700 dark:bg-blue-900 dark:text-blue-300',
  author: 'bg-green-100 text-green-700 dark:bg-green-900 dark:text-green-300',
  moderator: 'bg-purple-100 text-purple-700 dark:bg-purple-900 dark:text-purple-300',
  user: 'bg-gray-100 text-gray-700 dark:bg-gray-800 dark:text-gray-300',
}

const mockUsers = [
  { id: '1', name: 'أحمد محمد', email: 'admin@sportplus.com', role: 'admin', createdAt: '2024-01-15', articles: 12 },
  { id: '2', name: 'محمد علي', email: 'editor@sportplus.com', role: 'editor', createdAt: '2024-02-20', articles: 45 },
  { id: '3', name: 'سارة أحمد', email: 'author@sportplus.com', role: 'author', createdAt: '2024-03-10', articles: 28 },
  { id: '4', name: 'عمر حسن', email: 'moderator@sportplus.com', role: 'moderator', createdAt: '2024-04-05', articles: 0 },
]

export default function AdminUsersPage() {
  return (
    <div className="space-y-6">
      <div className="flex items-center justify-between">
        <h2 className="text-xl font-bold">إدارة المستخدمين</h2>
        <Button className="bg-emerald-600 hover:bg-emerald-700">
          <Plus className="size-4 ml-1" />
          مستخدم جديد
        </Button>
      </div>

      {/* Search & Filter */}
      <div className="flex items-center gap-3">
        <div className="relative flex-1 max-w-sm">
          <Search className="absolute right-3 top-1/2 -translate-y-1/2 size-4 text-muted-foreground" />
          <Input placeholder="بحث عن مستخدم..." className="pr-9" />
        </div>
      </div>

      {/* Users Grid */}
      <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
        {mockUsers.map((user) => (
          <Card key={user.id} className="hover:shadow-md transition-shadow">
            <CardContent className="p-4">
              <div className="flex items-start gap-3">
                <div className="size-12 rounded-full bg-emerald-100 dark:bg-emerald-900 flex items-center justify-center text-emerald-700 dark:text-emerald-300 font-bold text-lg shrink-0">
                  {user.name.charAt(0)}
                </div>
                <div className="flex-1 min-w-0">
                  <div className="flex items-center justify-between">
                    <p className="font-medium text-foreground">{user.name}</p>
                    <Badge variant="secondary" className={`text-[10px] ${ROLE_COLORS[user.role] || ''}`}>
                      {ROLE_LABELS[user.role] || user.role}
                    </Badge>
                  </div>
                  <p className="text-sm text-muted-foreground truncate">{user.email}</p>
                  <div className="flex items-center gap-4 mt-2 text-xs text-muted-foreground">
                    <span>تاريخ الانضمام: {user.createdAt}</span>
                    {user.articles > 0 && <span>المقالات: {user.articles}</span>}
                  </div>
                </div>
              </div>
            </CardContent>
          </Card>
        ))}
      </div>

      {/* Role Explanation */}
      <Card>
        <CardHeader>
          <CardTitle className="text-base flex items-center gap-2">
            <Shield className="size-5 text-emerald-500" />
            الصلاحيات
          </CardTitle>
          <CardDescription>شرح أدوار المستخدمين وصلاحياتهم</CardDescription>
        </CardHeader>
        <CardContent>
          <div className="space-y-3">
            {Object.entries(ROLE_LABELS).map(([key, label]) => (
              <div key={key} className="flex items-center gap-3">
                <Badge variant="secondary" className={`text-[10px] min-w-[60px] justify-center ${ROLE_COLORS[key] || ''}`}>
                  {label}
                </Badge>
                <p className="text-sm text-muted-foreground">
                  {key === 'admin' && 'صلاحيات كاملة - إدارة الموقع بالكامل بما في ذلك المستخدمين والإعدادات'}
                  {key === 'editor' && 'إدارة المحتوى - إنشاء وتعديل ونشر المقالات وإدارة المباريات'}
                  {key === 'author' && 'كتابة المحتوى - إنشاء المقالات فقط ولا يمكنه النشر مباشرة'}
                  {key === 'moderator' && 'إدارة التعليقات - مراجعة وحذف التعليقات المخالفة'}
                  {key === 'user' && 'مستخدم عادي - تصفح الموقع والتعليق والتوقعات'}
                </p>
              </div>
            ))}
          </div>
        </CardContent>
      </Card>
    </div>
  )
}
