'use client'

import { useEffect, useState, useCallback } from 'react'
import {
  MessageSquare, Search, Filter, CheckCircle2, XCircle, Trash2,
  Loader2, AlertTriangle, CheckCheck, User, Clock
} from 'lucide-react'
import { Card, CardContent } from '@/components/ui/card'
import { Badge } from '@/components/ui/badge'
import { Button } from '@/components/ui/button'
import { Input } from '@/components/ui/input'
import { Skeleton } from '@/components/ui/skeleton'
import { Avatar, AvatarFallback, AvatarImage } from '@/components/ui/avatar'
import {
  Table, TableBody, TableCell, TableHead, TableHeader, TableRow
} from '@/components/ui/table'
import {
  Select, SelectContent, SelectItem, SelectTrigger, SelectValue
} from '@/components/ui/select'
import {
  AlertDialog, AlertDialogAction, AlertDialogCancel, AlertDialogContent,
  AlertDialogDescription, AlertDialogFooter, AlertDialogHeader, AlertDialogTitle
} from '@/components/ui/alert-dialog'
import { timeAgo } from '@/lib/sports-utils'

interface CommentUser {
  id: string
  name: string
  avatar: string | null
}

interface CommentArticle {
  id: string
  title: string
}

interface Comment {
  id: string
  articleId: string
  userId: string
  content: string
  isApproved: boolean
  createdAt: string
  user: CommentUser
  article: CommentArticle
}

export default function AdminCommentsPage() {
  const [comments, setComments] = useState<Comment[]>([])
  const [loading, setLoading] = useState(true)
  const [searchQuery, setSearchQuery] = useState('')
  const [statusFilter, setStatusFilter] = useState('all')
  const [deleteTarget, setDeleteTarget] = useState<Comment | null>(null)
  const [deleting, setDeleting] = useState(false)
  const [togglingId, setTogglingId] = useState<string | null>(null)
  const [bulkApproving, setBulkApproving] = useState(false)

  const fetchComments = useCallback(async () => {
    try {
      setLoading(true)
      const params = new URLSearchParams()
      if (statusFilter !== 'all') {
        params.set('isApproved', statusFilter === 'approved' ? 'true' : 'false')
      }
      if (searchQuery.trim()) {
        params.set('search', searchQuery.trim())
      }
      params.set('limit', '100')
      const res = await fetch(`/api/admin/comments?${params.toString()}`)
      const data = await res.json()
      setComments(data.comments || [])
    } catch {
      // silently fail
    } finally {
      setLoading(false)
    }
  }, [statusFilter, searchQuery])

  useEffect(() => { fetchComments() }, [fetchComments])

  const totalComments = comments.length
  const pendingComments = comments.filter(c => !c.isApproved).length
  const approvedComments = comments.filter(c => c.isApproved).length

  const handleToggleApproval = async (comment: Comment) => {
    setTogglingId(comment.id)
    try {
      const res = await fetch('/api/admin/comments', {
        method: 'PUT',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          id: comment.id,
          isApproved: !comment.isApproved,
        }),
      })
      if (res.ok) {
        setComments(prev =>
          prev.map(c =>
            c.id === comment.id ? { ...c, isApproved: !c.isApproved } : c
          )
        )
      }
    } catch {
      // silently fail
    } finally {
      setTogglingId(null)
    }
  }

  const handleDelete = async () => {
    if (!deleteTarget) return
    setDeleting(true)
    try {
      const res = await fetch(`/api/admin/comments?id=${deleteTarget.id}`, {
        method: 'DELETE',
      })
      if (res.ok) {
        setComments(prev => prev.filter(c => c.id !== deleteTarget.id))
      }
    } catch {
      // silently fail
    } finally {
      setDeleting(false)
      setDeleteTarget(null)
    }
  }

  const handleBulkApprove = async () => {
    const pendingIds = comments.filter(c => !c.isApproved).map(c => c.id)
    if (pendingIds.length === 0) return
    setBulkApproving(true)
    try {
      await Promise.all(
        pendingIds.map(id =>
          fetch('/api/admin/comments', {
            method: 'PUT',
            headers: { 'Content-Type': 'application/json' },
            body: JSON.stringify({ id, isApproved: true }),
          })
        )
      )
      setComments(prev =>
        prev.map(c => ({ ...c, isApproved: true }))
      )
    } catch {
      // silently fail
    } finally {
      setBulkApproving(false)
    }
  }

  const truncateContent = (text: string, maxLen: number = 60) => {
    if (text.length <= maxLen) return text
    return text.substring(0, maxLen) + '...'
  }

  const getUserInitials = (name: string) => {
    return name.charAt(0)
  }

  // Loading skeleton
  if (loading) {
    return (
      <div className="space-y-5">
        {/* Stats Skeleton */}
        <div className="grid grid-cols-1 sm:grid-cols-3 gap-4">
          {Array.from({ length: 3 }).map((_, i) => (
            <Card key={i} className="border-0 shadow-sm">
              <CardContent className="p-5">
                <div className="flex items-center gap-3">
                  <Skeleton className="size-10 rounded-xl" />
                  <div className="space-y-2">
                    <Skeleton className="h-4 w-20" />
                    <Skeleton className="h-6 w-12" />
                  </div>
                </div>
              </CardContent>
            </Card>
          ))}
        </div>
        {/* Table Skeleton */}
        <Card className="border-0 shadow-sm">
          <CardContent className="p-0">
            <div className="p-4 space-y-3">
              {Array.from({ length: 6 }).map((_, i) => (
                <Skeleton key={i} className="h-12 w-full rounded-lg" />
              ))}
            </div>
          </CardContent>
        </Card>
      </div>
    )
  }

  return (
    <div className="space-y-5">
      {/* Header */}
      <div className="flex items-center justify-between flex-wrap gap-3">
        <div className="flex items-center gap-2">
          <MessageSquare className="size-5 text-emerald-500" />
          <h2 className="text-xl font-bold text-gray-800">إدارة التعليقات</h2>
        </div>
        {pendingComments > 0 && (
          <Button
            className="bg-emerald-500 hover:bg-emerald-600 shadow-sm shadow-emerald-500/25 gap-1.5"
            onClick={handleBulkApprove}
            disabled={bulkApproving}
          >
            {bulkApproving ? (
              <Loader2 className="size-4 animate-spin" />
            ) : (
              <CheckCheck className="size-4" />
            )}
            اعتماد الكل المعلّق ({pendingComments})
          </Button>
        )}
      </div>

      {/* Stats Cards */}
      <div className="grid grid-cols-1 sm:grid-cols-3 gap-4">
        <Card className="border-0 shadow-sm">
          <CardContent className="p-5">
            <div className="flex items-center gap-3">
              <div className="size-10 rounded-xl bg-gray-100 flex items-center justify-center">
                <MessageSquare className="size-5 text-gray-500" />
              </div>
              <div>
                <p className="text-xs text-gray-400 font-medium">إجمالي التعليقات</p>
                <p className="text-2xl font-bold text-gray-800">{totalComments}</p>
              </div>
            </div>
          </CardContent>
        </Card>
        <Card className="border-0 shadow-sm">
          <CardContent className="p-5">
            <div className="flex items-center gap-3">
              <div className="size-10 rounded-xl bg-amber-50 flex items-center justify-center">
                <Clock className="size-5 text-amber-500" />
              </div>
              <div>
                <p className="text-xs text-gray-400 font-medium">بانتظار الاعتماد</p>
                <p className="text-2xl font-bold text-amber-600">{pendingComments}</p>
              </div>
            </div>
          </CardContent>
        </Card>
        <Card className="border-0 shadow-sm">
          <CardContent className="p-5">
            <div className="flex items-center gap-3">
              <div className="size-10 rounded-xl bg-emerald-50 flex items-center justify-center">
                <CheckCircle2 className="size-5 text-emerald-500" />
              </div>
              <div>
                <p className="text-xs text-gray-400 font-medium">معتمدة</p>
                <p className="text-2xl font-bold text-emerald-600">{approvedComments}</p>
              </div>
            </div>
          </CardContent>
        </Card>
      </div>

      {/* Search & Filter Bar */}
      <div className="flex items-center gap-3 flex-wrap">
        <div className="relative flex-1 max-w-xs">
          <Search className="absolute right-3 top-1/2 -translate-y-1/2 size-4 text-gray-300" />
          <Input
            placeholder="بحث في التعليقات..."
            value={searchQuery}
            onChange={(e) => setSearchQuery(e.target.value)}
            className="bg-white border-gray-200 pr-9 h-9 text-sm"
          />
        </div>
        <Select value={statusFilter} onValueChange={setStatusFilter}>
          <SelectTrigger className="w-40 h-9 bg-white border-gray-200 text-sm">
            <Filter className="size-3.5 ml-1 text-gray-400" />
            <SelectValue placeholder="الحالة" />
          </SelectTrigger>
          <SelectContent>
            <SelectItem value="all">الكل</SelectItem>
            <SelectItem value="pending">معلّق</SelectItem>
            <SelectItem value="approved">معتمد</SelectItem>
          </SelectContent>
        </Select>
        <span className="text-xs text-gray-400">{comments.length} تعليق</span>
      </div>

      {/* Comments Table */}
      <Card className="border-0 shadow-sm overflow-hidden">
        <CardContent className="p-0">
          <Table>
            <TableHeader>
              <TableRow className="bg-gray-50/80">
                <TableHead className="text-right text-xs font-semibold text-gray-500">المستخدم</TableHead>
                <TableHead className="text-right text-xs font-semibold text-gray-500">المقال</TableHead>
                <TableHead className="text-right text-xs font-semibold text-gray-500">التعليق</TableHead>
                <TableHead className="text-right text-xs font-semibold text-gray-500">الحالة</TableHead>
                <TableHead className="text-right text-xs font-semibold text-gray-500">التاريخ</TableHead>
                <TableHead className="text-right text-xs font-semibold text-gray-500">إجراءات</TableHead>
              </TableRow>
            </TableHeader>
            <TableBody>
              {comments.length === 0 ? (
                <TableRow>
                  <TableCell colSpan={6} className="text-center py-16">
                    <div className="flex flex-col items-center gap-2">
                      <MessageSquare className="size-10 text-gray-200" />
                      <p className="text-gray-400 text-sm">لا توجد تعليقات</p>
                    </div>
                  </TableCell>
                </TableRow>
              ) : (
                comments.map((comment) => (
                  <TableRow
                    key={comment.id}
                    className={`transition-colors ${
                      !comment.isApproved
                        ? 'bg-amber-50/60 hover:bg-amber-50/80'
                        : 'hover:bg-gray-50/50'
                    }`}
                  >
                    {/* User */}
                    <TableCell>
                      <div className="flex items-center gap-2">
                        <Avatar className="size-8 border border-gray-100">
                          {comment.user?.avatar ? (
                            <AvatarImage src={comment.user.avatar} alt={comment.user.name} />
                          ) : null}
                          <AvatarFallback className="bg-emerald-100 text-emerald-700 text-xs font-bold">
                            {comment.user?.name ? getUserInitials(comment.user.name) : '?'}
                          </AvatarFallback>
                        </Avatar>
                        <span className="text-sm font-medium text-gray-700 max-w-[100px] truncate">
                          {comment.user?.name || 'مجهول'}
                        </span>
                      </div>
                    </TableCell>

                    {/* Article */}
                    <TableCell className="max-w-[150px]">
                      <p className="text-xs text-gray-500 truncate">
                        {comment.article?.title || '-'}
                      </p>
                    </TableCell>

                    {/* Content */}
                    <TableCell className="max-w-[200px]">
                      <p className="text-sm text-gray-700" title={comment.content}>
                        {truncateContent(comment.content)}
                      </p>
                    </TableCell>

                    {/* Status */}
                    <TableCell>
                      {comment.isApproved ? (
                        <Badge
                          variant="secondary"
                          className="text-[9px] border-0 bg-emerald-50 text-emerald-600"
                        >
                          <CheckCircle2 className="size-3 ml-0.5" />
                          معتمد
                        </Badge>
                      ) : (
                        <Badge
                          variant="secondary"
                          className="text-[9px] border-0 bg-amber-50 text-amber-600"
                        >
                          <Clock className="size-3 ml-0.5" />
                          معلّق
                        </Badge>
                      )}
                    </TableCell>

                    {/* Date */}
                    <TableCell>
                      <span className="text-[11px] text-gray-400">
                        {timeAgo(comment.createdAt)}
                      </span>
                    </TableCell>

                    {/* Actions */}
                    <TableCell>
                      <div className="flex items-center gap-0.5">
                        {/* Approve / Unapprove Toggle */}
                        {comment.isApproved ? (
                          <Button
                            variant="ghost"
                            size="icon"
                            className="size-7 text-amber-500 hover:text-amber-600 hover:bg-amber-50"
                            onClick={() => handleToggleApproval(comment)}
                            disabled={togglingId === comment.id}
                            title="إلغاء الاعتماد"
                          >
                            {togglingId === comment.id ? (
                              <Loader2 className="size-3.5 animate-spin" />
                            ) : (
                              <XCircle className="size-3.5" />
                            )}
                          </Button>
                        ) : (
                          <Button
                            variant="ghost"
                            size="icon"
                            className="size-7 text-emerald-500 hover:text-emerald-600 hover:bg-emerald-50"
                            onClick={() => handleToggleApproval(comment)}
                            disabled={togglingId === comment.id}
                            title="اعتماد"
                          >
                            {togglingId === comment.id ? (
                              <Loader2 className="size-3.5 animate-spin" />
                            ) : (
                              <CheckCircle2 className="size-3.5" />
                            )}
                          </Button>
                        )}

                        {/* Delete */}
                        <Button
                          variant="ghost"
                          size="icon"
                          className="size-7 text-gray-400 hover:text-red-500 hover:bg-red-50"
                          onClick={() => setDeleteTarget(comment)}
                          title="حذف"
                        >
                          <Trash2 className="size-3.5" />
                        </Button>
                      </div>
                    </TableCell>
                  </TableRow>
                ))
              )}
            </TableBody>
          </Table>
        </CardContent>
      </Card>

      {/* Delete Confirmation Dialog */}
      <AlertDialog open={!!deleteTarget} onOpenChange={(open) => { if (!open) setDeleteTarget(null) }}>
        <AlertDialogContent dir="rtl">
          <AlertDialogHeader>
            <AlertDialogTitle className="flex items-center gap-2 text-right">
              <AlertTriangle className="size-5 text-red-500" />
              تأكيد حذف التعليق
            </AlertDialogTitle>
            <AlertDialogDescription className="text-right">
              هل أنت متأكد من حذف هذا التعليق؟ لا يمكن التراجع عن هذا الإجراء.
            </AlertDialogDescription>
            {deleteTarget && (
              <div className="mt-3 p-3 rounded-lg bg-gray-50 border border-gray-100">
                <div className="flex items-center gap-2 mb-1.5">
                  <User className="size-3.5 text-gray-400" />
                  <span className="text-xs font-medium text-gray-600">{deleteTarget.user?.name || 'مجهول'}</span>
                </div>
                <p className="text-sm text-gray-700 leading-relaxed">
                  {truncateContent(deleteTarget.content, 120)}
                </p>
              </div>
            )}
          </AlertDialogHeader>
          <AlertDialogFooter className="flex-row gap-2 justify-end">
            <AlertDialogCancel className="h-9">إلغاء</AlertDialogCancel>
            <AlertDialogAction
              onClick={handleDelete}
              disabled={deleting}
              className="bg-red-500 hover:bg-red-600 text-white h-9 gap-1.5"
            >
              {deleting && <Loader2 className="size-4 animate-spin" />}
              حذف التعليق
            </AlertDialogAction>
          </AlertDialogFooter>
        </AlertDialogContent>
      </AlertDialog>
    </div>
  )
}
