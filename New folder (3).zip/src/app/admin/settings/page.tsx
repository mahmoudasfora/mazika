'use client'

import { useState } from 'react'
import { BarChart3, Megaphone, Loader2, Globe, Bell, Palette, Database } from 'lucide-react'
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from '@/components/ui/card'
import { Button } from '@/components/ui/button'
import { Input } from '@/components/ui/input'
import { Textarea } from '@/components/ui/textarea'
import { Label } from '@/components/ui/label'
import { Switch } from '@/components/ui/switch'
import {
  Select, SelectContent, SelectItem, SelectTrigger, SelectValue
} from '@/components/ui/select'
import { Tabs, TabsContent, TabsList, TabsTrigger } from '@/components/ui/tabs'

export default function AdminSettingsPage() {
  const [siteName, setSiteName] = useState('سبورت بلس')
  const [siteDescription, setSiteDescription] = useState('منصة الأخبار الرياضية العربية')
  const [saving, setSaving] = useState(false)

  const [seoKeywords, setSeoKeywords] = useState('أخبار رياضية، كرة قدم، دوري، مباريات')
  const [seoDescription, setSeoDescription] = useState('منصتك الأولى للأخبار الرياضية العربية - تغطية شاملة لأهم الأحداث')

  const [notifNewArticle, setNotifNewArticle] = useState(true)
  const [notifLiveMatch, setNotifLiveMatch] = useState(true)
  const [notifBreaking, setNotifBreaking] = useState(true)

  const handleSave = async () => {
    setSaving(true)
    await new Promise(resolve => setTimeout(resolve, 1000))
    setSaving(false)
  }

  return (
    <div className="space-y-6">
      <h2 className="text-xl font-bold">الإعدادات</h2>

      <Tabs defaultValue="general" dir="rtl">
        <TabsList className="grid w-full grid-cols-4 mb-4">
          <TabsTrigger value="general" className="text-xs">
            <Globe className="size-4 ml-1" />
            عام
          </TabsTrigger>
          <TabsTrigger value="seo" className="text-xs">
            <BarChart3 className="size-4 ml-1" />
            SEO
          </TabsTrigger>
          <TabsTrigger value="notifications" className="text-xs">
            <Bell className="size-4 ml-1" />
            إشعارات
          </TabsTrigger>
          <TabsTrigger value="advanced" className="text-xs">
            <Database className="size-4 ml-1" />
            متقدم
          </TabsTrigger>
        </TabsList>

        {/* General Settings */}
        <TabsContent value="general">
          <Card>
            <CardHeader>
              <CardTitle className="text-base flex items-center gap-2">
                <Globe className="size-5 text-emerald-500" />
                إعدادات عامة
              </CardTitle>
              <CardDescription>إعدادات الموقع الأساسية</CardDescription>
            </CardHeader>
            <CardContent className="space-y-4">
              <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                <div className="space-y-2">
                  <Label>اسم الموقع</Label>
                  <Input value={siteName} onChange={(e) => setSiteName(e.target.value)} />
                </div>
                <div className="space-y-2">
                  <Label>اللغة الافتراضية</Label>
                  <Select defaultValue="ar">
                    <SelectTrigger><SelectValue /></SelectTrigger>
                    <SelectContent>
                      <SelectItem value="ar">العربية</SelectItem>
                      <SelectItem value="en">English</SelectItem>
                    </SelectContent>
                  </Select>
                </div>
              </div>
              <div className="space-y-2">
                <Label>وصف الموقع</Label>
                <Textarea value={siteDescription} onChange={(e) => setSiteDescription(e.target.value)} rows={3} />
              </div>
              <div className="space-y-2">
                <Label>الشعار (رابط)</Label>
                <Input placeholder="https://example.com/logo.png" />
              </div>
              <div className="flex items-center gap-2">
                <Switch defaultChecked />
                <Label>تفعيل الوضع الداكن تلقائياً</Label>
              </div>
              <div className="flex justify-end">
                <Button className="bg-emerald-600 hover:bg-emerald-700" onClick={handleSave} disabled={saving}>
                  {saving && <Loader2 className="size-4 ml-1 animate-spin" />}
                  حفظ الإعدادات
                </Button>
              </div>
            </CardContent>
          </Card>
        </TabsContent>

        {/* SEO Settings */}
        <TabsContent value="seo">
          <Card>
            <CardHeader>
              <CardTitle className="text-base flex items-center gap-2">
                <BarChart3 className="size-5 text-emerald-500" />
                إعدادات SEO
              </CardTitle>
              <CardDescription>تحسين محركات البحث</CardDescription>
            </CardHeader>
            <CardContent className="space-y-4">
              <div className="space-y-2">
                <Label>الكلمات المفتاحية</Label>
                <Input
                  value={seoKeywords}
                  onChange={(e) => setSeoKeywords(e.target.value)}
                  placeholder="أخبار رياضية، كرة قدم، دوري"
                />
                <p className="text-xs text-muted-foreground">مفصولة بفواصل</p>
              </div>
              <div className="space-y-2">
                <Label>وصف الميتا</Label>
                <Textarea
                  value={seoDescription}
                  onChange={(e) => setSeoDescription(e.target.value)}
                  placeholder="وصف مختصر للموقع لمحركات البحث"
                  rows={3}
                />
                <p className="text-xs text-muted-foreground">{seoDescription.length}/160 حرف</p>
              </div>
              <div className="space-y-2">
                <Label>OG Image (رابط)</Label>
                <Input placeholder="https://example.com/og-image.png" />
              </div>
              <div className="flex items-center gap-2">
                <Switch defaultChecked />
                <Label>تفعيل Sitemap تلقائي</Label>
              </div>
              <div className="flex items-center gap-2">
                <Switch defaultChecked />
                <Label>تفعيل Robots.txt</Label>
              </div>
              <div className="flex justify-end">
                <Button className="bg-emerald-600 hover:bg-emerald-700">حفظ</Button>
              </div>
            </CardContent>
          </Card>
        </TabsContent>

        {/* Notifications Settings */}
        <TabsContent value="notifications">
          <Card>
            <CardHeader>
              <CardTitle className="text-base flex items-center gap-2">
                <Bell className="size-5 text-emerald-500" />
                إعدادات الإشعارات
              </CardTitle>
              <CardDescription>إدارة الإشعارات والتنبيهات</CardDescription>
            </CardHeader>
            <CardContent className="space-y-4">
              <div className="space-y-4">
                <div className="flex items-center justify-between p-3 rounded-lg bg-muted/30">
                  <div>
                    <p className="font-medium text-sm">إشعارات المقالات الجديدة</p>
                    <p className="text-xs text-muted-foreground">إرسال إشعار عند نشر مقال جديد</p>
                  </div>
                  <Switch checked={notifNewArticle} onCheckedChange={setNotifNewArticle} />
                </div>
                <div className="flex items-center justify-between p-3 rounded-lg bg-muted/30">
                  <div>
                    <p className="font-medium text-sm">إشعارات المباريات المباشرة</p>
                    <p className="text-xs text-muted-foreground">إرسال إشعار عند بدء مباراة مباشرة</p>
                  </div>
                  <Switch checked={notifLiveMatch} onCheckedChange={setNotifLiveMatch} />
                </div>
                <div className="flex items-center justify-between p-3 rounded-lg bg-muted/30">
                  <div>
                    <p className="font-medium text-sm">الأخبار العاجلة</p>
                    <p className="text-xs text-muted-foreground">إرسال إشعار فوري للأخبار العاجلة</p>
                  </div>
                  <Switch checked={notifBreaking} onCheckedChange={setNotifBreaking} />
                </div>
              </div>

              <div className="space-y-2 pt-2">
                <Label>قنوات الإشعارات</Label>
                <div className="grid grid-cols-2 gap-3">
                  <div className="flex items-center gap-2 p-3 rounded-lg border">
                    <Switch defaultChecked />
                    <div>
                      <p className="text-sm font-medium">Push Notifications</p>
                      <p className="text-xs text-muted-foreground">إشعارات المتصفح</p>
                    </div>
                  </div>
                  <div className="flex items-center gap-2 p-3 rounded-lg border">
                    <Switch />
                    <div>
                      <p className="text-sm font-medium">Telegram</p>
                      <p className="text-xs text-muted-foreground">بوت تيليجرام</p>
                    </div>
                  </div>
                  <div className="flex items-center gap-2 p-3 rounded-lg border">
                    <Switch />
                    <div>
                      <p className="text-sm font-medium">WhatsApp</p>
                      <p className="text-xs text-muted-foreground">رسائل واتساب</p>
                    </div>
                  </div>
                  <div className="flex items-center gap-2 p-3 rounded-lg border">
                    <Switch defaultChecked />
                    <div>
                      <p className="text-sm font-medium">البريد الإلكتروني</p>
                      <p className="text-xs text-muted-foreground">رسائل بريدية</p>
                    </div>
                  </div>
                </div>
              </div>

              <div className="flex justify-end">
                <Button className="bg-emerald-600 hover:bg-emerald-700">حفظ</Button>
              </div>
            </CardContent>
          </Card>
        </TabsContent>

        {/* Advanced Settings */}
        <TabsContent value="advanced">
          <Card>
            <CardHeader>
              <CardTitle className="text-base flex items-center gap-2">
                <Database className="size-5 text-emerald-500" />
                إعدادات متقدمة
              </CardTitle>
              <CardDescription>إعدادات تقنية متقدمة</CardDescription>
            </CardHeader>
            <CardContent className="space-y-4">
              <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                <div className="space-y-2">
                  <Label>معدل تحديث المباريات (ثانية)</Label>
                  <Input type="number" defaultValue="60" />
                </div>
                <div className="space-y-2">
                  <Label>عدد المقالات في الصفحة</Label>
                  <Input type="number" defaultValue="12" />
                </div>
              </div>
              <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                <div className="space-y-2">
                  <Label>المنطقة الزمنية</Label>
                  <Select defaultValue="africa_cairo">
                    <SelectTrigger><SelectValue /></SelectTrigger>
                    <SelectContent>
                      <SelectItem value="africa_cairo">القاهرة (GMT+2)</SelectItem>
                      <SelectItem value="asia_riyadh">الرياض (GMT+3)</SelectItem>
                      <SelectItem value="asia_dubai">دبي (GMT+4)</SelectItem>
                      <SelectItem value="africa_casablanca">الدار البيضاء (GMT+1)</SelectItem>
                    </SelectContent>
                  </Select>
                </div>
                <div className="space-y-2">
                  <Label>صيغة التاريخ</Label>
                  <Select defaultValue="arabic">
                    <SelectTrigger><SelectValue /></SelectTrigger>
                    <SelectContent>
                      <SelectItem value="arabic">عربي (١٥ مايو ٢٠٢٤)</SelectItem>
                      <SelectItem value="numeric">رقمي (15/05/2024)</SelectItem>
                      <SelectItem value="iso">ISO (2024-05-15)</SelectItem>
                    </SelectContent>
                  </Select>
                </div>
              </div>
              <div className="flex items-center gap-2">
                <Switch defaultChecked />
                <Label>تفعيل التخزين المؤقت (Cache)</Label>
              </div>
              <div className="flex items-center gap-2">
                <Switch defaultChecked />
                <Label>تفعيل ضغط الصور تلقائياً</Label>
              </div>
              <div className="p-4 rounded-lg bg-amber-50 dark:bg-amber-950/30 border border-amber-200 dark:border-amber-800">
                <p className="text-sm font-medium text-amber-700 dark:text-amber-400">منطقة الخطر</p>
                <p className="text-xs text-muted-foreground mt-1">إعادة تعيين البيانات أو حذفها بشكل نهائي</p>
                <div className="flex gap-3 mt-3">
                  <Button variant="outline" size="sm">مسح التخزين المؤقت</Button>
                  <Button variant="destructive" size="sm">إعادة تعيين البيانات</Button>
                </div>
              </div>
              <div className="flex justify-end">
                <Button className="bg-emerald-600 hover:bg-emerald-700">حفظ</Button>
              </div>
            </CardContent>
          </Card>
        </TabsContent>
      </Tabs>
    </div>
  )
}
