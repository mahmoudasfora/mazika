'use client'

import { useState } from 'react'
import Link from 'next/link'
import { usePathname } from 'next/navigation'
import {
  Menu, X, Home, LayoutDashboard, FileText, Trophy,
  Megaphone, Users, UserCircle, Settings, DollarSign, Shield,
  Search, Bell, ChevronDown, LogOut, BookOpen, MessageSquare,
  BarChart3, Target, BellRing, Crosshair
} from 'lucide-react'
import { Badge } from '@/components/ui/badge'
import { Button } from '@/components/ui/button'
import { Input } from '@/components/ui/input'

const SIDEBAR_LINKS = [
  // الرئيسية
  { href: '/admin', label: 'لوحة التحكم', icon: LayoutDashboard, exact: true },
  // المحتوى الرياضي
  { href: '/admin/matches', label: 'المباريات', icon: Trophy },
  { href: '/admin/leagues', label: 'البطولات', icon: Megaphone },
  { href: '/admin/standings', label: 'الترتيب', icon: BarChart3 },
  { href: '/admin/teams', label: 'الفرق', icon: Users },
  { href: '/admin/players', label: 'اللاعبين', icon: UserCircle },
  { href: '/admin/top-scorers', label: 'الهدافون', icon: Target },
  // المحتوى الإخباري
  { href: '/admin/articles', label: 'المقالات', icon: FileText },
  { href: '/admin/comments', label: 'التعليقات', icon: MessageSquare },
  // التفاعل
  { href: '/admin/predictions', label: 'التوقعات', icon: Crosshair },
  { href: '/admin/notifications', label: 'الإشعارات', icon: BellRing },
  // النظام
  { href: '/admin/users', label: 'المستخدمين', icon: Shield },
  { href: '/admin/pages', label: 'الصفحات', icon: BookOpen },
  { href: '/admin/ads', label: 'الإعلانات', icon: DollarSign },
  { href: '/admin/settings', label: 'الإعدادات', icon: Settings },
]

export default function AdminLayout({ children }: { children: React.ReactNode }) {
  const pathname = usePathname()
  const [sidebarOpen, setSidebarOpen] = useState(false)
  const [searchQuery, setSearchQuery] = useState('')

  const isActive = (href: string, exact?: boolean) => {
    if (exact) return pathname === href
    return pathname.startsWith(href)
  }

  return (
    <div dir="rtl" className="flex min-h-screen bg-[#F8F9FA]">
      {/* Mobile Overlay */}
      {sidebarOpen && (
        <div
          className="fixed inset-0 z-40 bg-black/50 lg:hidden"
          onClick={() => setSidebarOpen(false)}
        />
      )}

      {/* Sidebar - Light Theme */}
      <aside
        className={`
          fixed top-0 right-0 z-50 h-full w-[260px] bg-white border-l border-gray-200
          transform transition-transform duration-300 flex flex-col
          lg:relative lg:translate-x-0 lg:z-auto
          ${sidebarOpen ? 'translate-x-0' : 'translate-x-full lg:translate-x-0'}
        `}
      >
        {/* Sidebar Header - Logo */}
        <div className="p-5 border-b border-gray-100">
          <Link href="/admin" className="flex items-center gap-3">
            <div className="size-10 rounded-xl overflow-hidden shadow-md shadow-emerald-500/30">
              <img src="/favicon.png" alt="سبورت بلس" className="size-full object-cover" />
            </div>
            <div>
              <h2 className="font-bold text-lg text-gray-800">سبورت بلس</h2>
              <p className="text-[10px] text-gray-400">لوحة التحكم</p>
            </div>
          </Link>
          <Button
            variant="ghost"
            size="icon"
            className="absolute top-4 left-4 text-gray-400 hover:text-gray-600 lg:hidden"
            onClick={() => setSidebarOpen(false)}
          >
            <X className="size-5" />
          </Button>
        </div>

        {/* Navigation Links */}
        <nav className="flex-1 p-3 space-y-0.5 overflow-y-auto">
          {SIDEBAR_LINKS.map((item) => {
            const Icon = item.icon
            const active = isActive(item.href, item.exact)
            return (
              <Link
                key={item.href}
                href={item.href}
                onClick={() => setSidebarOpen(false)}
                className={`
                  w-full flex items-center gap-3 px-4 py-2.5 rounded-xl text-sm font-medium transition-all duration-200
                  ${active
                    ? 'bg-emerald-50 text-emerald-600 shadow-sm'
                    : 'text-gray-500 hover:bg-gray-50 hover:text-gray-700'
                  }
                `}
              >
                <Icon className={`size-[18px] ${active ? 'text-emerald-500' : ''}`} />
                {item.label}
              </Link>
            )
          })}
        </nav>

        {/* Back to Site */}
        <div className="px-3 pb-2">
          <Link
            href="/"
            className="flex items-center gap-3 px-4 py-2.5 rounded-xl text-sm font-medium text-gray-400 hover:bg-gray-50 hover:text-gray-600 transition-all"
          >
            <Home className="size-[18px]" />
            العودة للموقع
          </Link>
        </div>

        {/* User Profile at Bottom */}
        <div className="p-4 border-t border-gray-100">
          <div className="flex items-center gap-3">
            <div className="size-10 rounded-full bg-gradient-to-br from-emerald-400 to-emerald-600 flex items-center justify-center text-white text-sm font-bold shadow-md">
              م
            </div>
            <div className="flex-1 min-w-0">
              <p className="text-sm font-semibold text-gray-800">المدير</p>
              <p className="text-[11px] text-gray-400 truncate">admin@sportplus.com</p>
            </div>
            <button className="text-gray-300 hover:text-gray-500 transition-colors">
              <LogOut className="size-4" />
            </button>
          </div>
        </div>
      </aside>

      {/* Main Content */}
      <main className="flex-1 min-w-0 flex flex-col">
        {/* Top Header Bar */}
        <header className="sticky top-0 z-30 bg-white border-b border-gray-100 px-6 py-3">
          <div className="flex items-center justify-between">
            <div className="flex items-center gap-4">
              {/* Mobile Menu */}
              <Button
                variant="ghost"
                size="icon"
                className="lg:hidden text-gray-500"
                onClick={() => setSidebarOpen(true)}
              >
                <Menu className="size-5" />
              </Button>

              {/* Page Title */}
              <div>
                <h1 className="text-lg font-bold text-gray-800">
                  {SIDEBAR_LINKS.find(l => isActive(l.href, l.exact))?.label || 'لوحة التحكم'}
                </h1>
              </div>
            </div>

            {/* Right Side Actions */}
            <div className="flex items-center gap-3">
              {/* Search */}
              <div className="hidden md:flex items-center relative">
                <Search className="absolute right-3 size-4 text-gray-300" />
                <Input
                  placeholder="بحث..."
                  value={searchQuery}
                  onChange={(e) => setSearchQuery(e.target.value)}
                  className="w-56 h-9 bg-gray-50 border-gray-100 text-sm pr-9 placeholder:text-gray-300 focus:bg-white"
                />
              </div>

              {/* Live Badge */}
              <Badge className="bg-red-50 text-red-600 border border-red-200 hover:bg-red-50 gap-1 text-[11px] font-medium px-2.5">
                <span className="size-1.5 rounded-full bg-red-500 animate-pulse" />
                مباشر
              </Badge>

              {/* Notifications */}
              <Button variant="ghost" size="icon" className="relative text-gray-400 hover:text-gray-600">
                <Bell className="size-5" />
                <span className="absolute top-1 right-1 size-4 rounded-full bg-red-500 text-white text-[9px] flex items-center justify-center font-bold">
                  8
                </span>
              </Button>

              {/* User Dropdown */}
              <div className="hidden sm:flex items-center gap-2 px-3 py-1.5 rounded-xl bg-gray-50 cursor-pointer hover:bg-gray-100 transition-colors">
                <div className="size-8 rounded-full bg-gradient-to-br from-emerald-400 to-emerald-600 flex items-center justify-center text-white text-xs font-bold">
                  م
                </div>
                <span className="text-sm font-medium text-gray-700">المدير</span>
                <ChevronDown className="size-3.5 text-gray-400" />
              </div>
            </div>
          </div>
        </header>

        {/* Content Area */}
        <div className="flex-1 p-6">
          {children}
        </div>
      </main>
    </div>
  )
}
