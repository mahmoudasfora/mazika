'use client'

import { useEffect, useState, useCallback, useMemo } from 'react'
import {
  Plus, Pencil, Trash2, Loader2, Trophy, Target, Users,
  Medal, AlertTriangle, TrendingUp
} from 'lucide-react'
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card'
import { Badge } from '@/components/ui/badge'
import { Button } from '@/components/ui/button'
import { Input } from '@/components/ui/input'
import { Skeleton } from '@/components/ui/skeleton'
import { Label } from '@/components/ui/label'
import { Tabs, TabsList, TabsTrigger, TabsContent } from '@/components/ui/tabs'
import {
  Table, TableBody, TableCell, TableHead, TableHeader, TableRow
} from '@/components/ui/table'
import {
  Dialog, DialogContent, DialogDescription, DialogFooter,
  DialogHeader, DialogTitle, DialogTrigger
} from '@/components/ui/dialog'
import {
  Select, SelectContent, SelectItem, SelectTrigger, SelectValue
} from '@/components/ui/select'
import {
  AlertDialog, AlertDialogAction, AlertDialogCancel, AlertDialogContent,
  AlertDialogDescription, AlertDialogFooter, AlertDialogHeader,
  AlertDialogTitle, AlertDialogTrigger
} from '@/components/ui/alert-dialog'

// ===== Types =====

interface League {
  id: string
  name: string
  nameEn: string | null
  country: string | null
  logo: string | null
  type: string
  season: string | null
  isActive: boolean
  teamCount: number
}

interface Team {
  id: string
  name: string
  nameEn: string | null
  shortName: string | null
  logo: string | null
  color: string | null
}

interface Player {
  id: string
  name: string
  nameEn: string | null
  photo: string | null
  position: string | null
  number: number | null
  nationality: string | null
  team?: {
    id: string
    name: string
    color: string | null
  }
}

interface TopScorer {
  id: string
  leagueId: string
  playerId: string
  teamId: string
  goals: number
  assists: number
  penaltyGoals: number
  player: {
    id: string
    name: string
    nameEn: string | null
    photo: string | null
    position: string | null
    nationality: string | null
  }
  team: {
    id: string
    name: string
    nameEn: string | null
    shortName: string | null
    logo: string | null
  }
  league: {
    id: string
    name: string
  }
}

// ===== Constants =====

const POSITIONS: Record<string, string> = {
  GK: 'حارس مرمى',
  CB: 'قلب دفاع',
  RB: 'ظهير أيمن',
  LB: 'ظهير أيسر',
  CDM: 'محور دفاعي',
  CM: 'وسط مركزي',
  CAM: 'وسط هجومي',
  RW: 'جناح أيمن',
  LW: 'جناح أيسر',
  CF: 'مهاجم',
  ST: 'رأس حربة',
  DEF: 'مدافع',
  MID: 'وسط',
  FWD: 'مهاجم',
}

const POSITION_COLORS: Record<string, string> = {
  GK: 'bg-amber-100 text-amber-700 dark:bg-amber-900 dark:text-amber-300',
  CB: 'bg-blue-100 text-blue-700 dark:bg-blue-900 dark:text-blue-300',
  RB: 'bg-blue-100 text-blue-700 dark:bg-blue-900 dark:text-blue-300',
  LB: 'bg-blue-100 text-blue-700 dark:bg-blue-900 dark:text-blue-300',
  CDM: 'bg-teal-100 text-teal-700 dark:bg-teal-900 dark:text-teal-300',
  CM: 'bg-green-100 text-green-700 dark:bg-green-900 dark:text-green-300',
  CAM: 'bg-green-100 text-green-700 dark:bg-green-900 dark:text-green-300',
  RW: 'bg-rose-100 text-rose-700 dark:bg-rose-900 dark:text-rose-300',
  LW: 'bg-rose-100 text-rose-700 dark:bg-rose-900 dark:text-rose-300',
  CF: 'bg-red-100 text-red-700 dark:bg-red-900 dark:text-red-300',
  ST: 'bg-red-100 text-red-700 dark:bg-red-900 dark:text-red-300',
  DEF: 'bg-blue-100 text-blue-700 dark:bg-blue-900 dark:text-blue-300',
  MID: 'bg-green-100 text-green-700 dark:bg-green-900 dark:text-green-300',
  FWD: 'bg-red-100 text-red-700 dark:bg-red-900 dark:text-red-300',
}

const RANK_STYLES: Record<number, { badge: string; row: string; icon: string }> = {
  1: {
    badge: 'bg-gradient-to-r from-yellow-400 to-amber-500 text-white shadow-md shadow-amber-200 dark:shadow-amber-900/30',
    row: 'bg-amber-50/50 dark:bg-amber-950/20',
    icon: '🥇',
  },
  2: {
    badge: 'bg-gradient-to-r from-gray-300 to-slate-400 text-white shadow-md shadow-slate-200 dark:shadow-slate-800/30',
    row: 'bg-slate-50/50 dark:bg-slate-950/20',
    icon: '🥈',
  },
  3: {
    badge: 'bg-gradient-to-r from-orange-400 to-amber-600 text-white shadow-md shadow-orange-200 dark:shadow-orange-900/30',
    row: 'bg-orange-50/50 dark:bg-orange-950/20',
    icon: '🥉',
  },
}

// ===== Helpers =====

function positionLabel(pos: string | null): string {
  if (!pos) return '-'
  return POSITIONS[pos] || pos
}

function positionColor(pos: string | null): string {
  if (!pos) return 'bg-gray-100 text-gray-700 dark:bg-gray-800 dark:text-gray-300'
  return POSITION_COLORS[pos] || 'bg-gray-100 text-gray-700 dark:bg-gray-800 dark:text-gray-300'
}

function getInitials(name: string): string {
  const parts = name.trim().split(/\s+/)
  if (parts.length >= 2) return parts[0][0] + parts[1][0]
  return name.substring(0, 2)
}

// ===== Component =====

export default function AdminTopScorersPage() {
  // Data state
  const [leagues, setLeagues] = useState<League[]>([])
  const [topScorers, setTopScorers] = useState<TopScorer[]>([])
  const [teams, setTeams] = useState<Team[]>([])
  const [players, setPlayers] = useState<Player[]>([])
  const [loading, setLoading] = useState(true)

  // Tab state
  const [activeLeagueId, setActiveLeagueId] = useState<string>('')

  // Add dialog state
  const [addDialogOpen, setAddDialogOpen] = useState(false)
  const [addSubmitting, setAddSubmitting] = useState(false)
  const [addLeagueId, setAddLeagueId] = useState('')
  const [addTeamId, setAddTeamId] = useState('')
  const [addPlayerId, setAddPlayerId] = useState('')
  const [addGoals, setAddGoals] = useState('0')
  const [addAssists, setAddAssists] = useState('0')
  const [addPenaltyGoals, setAddPenaltyGoals] = useState('0')

  // Edit dialog state
  const [editDialogOpen, setEditDialogOpen] = useState(false)
  const [editSubmitting, setEditSubmitting] = useState(false)
  const [editId, setEditId] = useState<string | null>(null)
  const [editPlayerName, setEditPlayerName] = useState('')
  const [editGoals, setEditGoals] = useState('')
  const [editAssists, setEditAssists] = useState('')
  const [editPenaltyGoals, setEditPenaltyGoals] = useState('')

  // Delete state
  const [deleteId, setDeleteId] = useState<string | null>(null)
  const [deletePlayerName, setDeletePlayerName] = useState('')
  const [deleteSubmitting, setDeleteSubmitting] = useState(false)

  // ===== Data Fetching =====

  const fetchLeagues = useCallback(async () => {
    try {
      const res = await fetch('/api/leagues')
      const data = await res.json()
      const leagueList = data.leagues || []
      setLeagues(leagueList)
      if (leagueList.length > 0 && !activeLeagueId) {
        setActiveLeagueId(leagueList[0].id)
      }
    } catch {
      // silently fail
    }
  }, [activeLeagueId])

  const fetchTopScorers = useCallback(async () => {
    try {
      setLoading(true)
      const url = activeLeagueId
        ? `/api/admin/top-scorers?leagueId=${activeLeagueId}`
        : '/api/admin/top-scorers'
      const res = await fetch(url)
      const data = await res.json()
      setTopScorers(data.topScorers || [])
    } catch {
      // silently fail
    } finally {
      setLoading(false)
    }
  }, [activeLeagueId])

  const fetchTeams = useCallback(async (leagueId: string) => {
    try {
      const res = await fetch(`/api/teams?leagueId=${leagueId}`)
      const data = await res.json()
      setTeams(data.teams || [])
    } catch {
      setTeams([])
    }
  }, [])

  const fetchPlayers = useCallback(async (teamId: string) => {
    try {
      const res = await fetch(`/api/players?teamId=${teamId}`)
      const data = await res.json()
      setPlayers(data.players || [])
    } catch {
      setPlayers([])
    }
  }, [])

  useEffect(() => { fetchLeagues() }, [fetchLeagues])

  useEffect(() => {
    if (activeLeagueId) {
      fetchTopScorers()
    }
  }, [activeLeagueId, fetchTopScorers])

  // Cascade: when addLeagueId changes, reset team & player, fetch teams
  useEffect(() => {
    if (addLeagueId) {
      fetchTeams(addLeagueId)
      setAddTeamId('')
      setAddPlayerId('')
      setPlayers([])
    } else {
      setTeams([])
      setPlayers([])
    }
  }, [addLeagueId, fetchTeams])

  // Cascade: when addTeamId changes, reset player, fetch players
  useEffect(() => {
    if (addTeamId) {
      fetchPlayers(addTeamId)
      setAddPlayerId('')
    } else {
      setPlayers([])
      setAddPlayerId('')
    }
  }, [addTeamId, fetchPlayers])

  // ===== Computed =====

  const filteredScorers = useMemo(() => {
    return [...topScorers]
      .filter(s => !activeLeagueId || s.leagueId === activeLeagueId)
      .sort((a, b) => {
        if (b.goals !== a.goals) return b.goals - a.goals
        return b.assists - a.assists
      })
  }, [topScorers, activeLeagueId])

  const stats = useMemo(() => {
    const totalPlayers = filteredScorers.length
    const totalGoals = filteredScorers.reduce((sum, s) => sum + s.goals, 0)
    const totalAssists = filteredScorers.reduce((sum, s) => sum + s.assists, 0)
    const totalPenaltyGoals = filteredScorers.reduce((sum, s) => sum + s.penaltyGoals, 0)

    // Top league by goals
    const leagueGoals: Record<string, { name: string; goals: number }> = {}
    for (const s of topScorers) {
      if (!leagueGoals[s.leagueId]) {
        leagueGoals[s.leagueId] = { name: s.league.name, goals: 0 }
      }
      leagueGoals[s.leagueId].goals += s.goals
    }
    const topLeague = Object.values(leagueGoals).sort((a, b) => b.goals - a.goals)[0]

    return { totalPlayers, totalGoals, totalAssists, totalPenaltyGoals, topLeague }
  }, [filteredScorers, topScorers])

  // ===== Handlers =====

  const resetAddForm = () => {
    setAddLeagueId('')
    setAddTeamId('')
    setAddPlayerId('')
    setAddGoals('0')
    setAddAssists('0')
    setAddPenaltyGoals('0')
    setTeams([])
    setPlayers([])
  }

  const openAddDialog = () => {
    resetAddForm()
    setAddDialogOpen(true)
  }

  const handleAdd = async () => {
    if (!addLeagueId || !addPlayerId || !addTeamId) return
    setAddSubmitting(true)
    try {
      const res = await fetch('/api/admin/top-scorers', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          leagueId: addLeagueId,
          playerId: addPlayerId,
          teamId: addTeamId,
          goals: parseInt(addGoals) || 0,
          assists: parseInt(addAssists) || 0,
          penaltyGoals: parseInt(addPenaltyGoals) || 0,
        }),
      })
      if (res.ok) {
        setAddDialogOpen(false)
        resetAddForm()
        fetchTopScorers()
      }
    } catch {
      // silently fail
    } finally {
      setAddSubmitting(false)
    }
  }

  const openEditDialog = (scorer: TopScorer) => {
    setEditId(scorer.id)
    setEditPlayerName(scorer.player.name)
    setEditGoals(scorer.goals.toString())
    setEditAssists(scorer.assists.toString())
    setEditPenaltyGoals(scorer.penaltyGoals.toString())
    setEditDialogOpen(true)
  }

  const handleEdit = async () => {
    if (!editId) return
    setEditSubmitting(true)
    try {
      const res = await fetch('/api/admin/top-scorers', {
        method: 'PUT',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          id: editId,
          goals: parseInt(editGoals) || 0,
          assists: parseInt(editAssists) || 0,
          penaltyGoals: parseInt(editPenaltyGoals) || 0,
        }),
      })
      if (res.ok) {
        setEditDialogOpen(false)
        setEditId(null)
        fetchTopScorers()
      }
    } catch {
      // silently fail
    } finally {
      setEditSubmitting(false)
    }
  }

  const openDeleteDialog = (scorer: TopScorer) => {
    setDeleteId(scorer.id)
    setDeletePlayerName(scorer.player.name)
  }

  const handleDelete = async () => {
    if (!deleteId) return
    setDeleteSubmitting(true)
    try {
      await fetch(`/api/admin/top-scorers?id=${deleteId}`, {
        method: 'DELETE',
      })
      setDeleteId(null)
      setDeletePlayerName('')
      fetchTopScorers()
    } catch {
      // silently fail
    } finally {
      setDeleteSubmitting(false)
    }
  }

  // ===== Loading State =====

  if (loading && topScorers.length === 0) {
    return (
      <div className="space-y-6">
        <div className="flex items-center justify-between">
          <Skeleton className="h-8 w-48" />
          <Skeleton className="h-10 w-36" />
        </div>
        <div className="grid grid-cols-1 sm:grid-cols-3 gap-4">
          {Array.from({ length: 3 }).map((_, i) => (
            <Skeleton key={i} className="h-28 w-full rounded-xl" />
          ))}
        </div>
        <Skeleton className="h-10 w-full max-w-2xl" />
        {Array.from({ length: 6 }).map((_, i) => (
          <Skeleton key={i} className="h-14 w-full" />
        ))}
      </div>
    )
  }

  // ===== Render =====

  return (
    <div className="space-y-6">
      {/* Page Header */}
      <div className="flex items-center justify-between">
        <div className="flex items-center gap-3">
          <div className="size-10 rounded-xl bg-emerald-100 dark:bg-emerald-900/30 flex items-center justify-center">
            <Trophy className="size-5 text-emerald-600 dark:text-emerald-400" />
          </div>
          <div>
            <h2 className="text-xl font-bold text-gray-800 dark:text-gray-100">إدارة الهدافين</h2>
            <p className="text-sm text-gray-500 dark:text-gray-400">إدارة قوائم هدافي البطولات</p>
          </div>
        </div>

        {/* Add Button with Dialog */}
        <Dialog open={addDialogOpen} onOpenChange={setAddDialogOpen}>
          <DialogTrigger asChild>
            <Button className="bg-emerald-600 hover:bg-emerald-700" onClick={openAddDialog}>
              <Plus className="size-4 ml-1" />
              إضافة هداف
            </Button>
          </DialogTrigger>
          <DialogContent className="max-w-lg max-h-[90vh] overflow-y-auto" dir="rtl">
            <DialogHeader>
              <DialogTitle>إضافة هداف جديد</DialogTitle>
              <DialogDescription>اختر البطولة والفريق واللاعب ثم أدخل الإحصائيات</DialogDescription>
            </DialogHeader>
            <div className="space-y-4">
              {/* League Select */}
              <div className="space-y-2">
                <Label>البطولة *</Label>
                <Select value={addLeagueId} onValueChange={setAddLeagueId}>
                  <SelectTrigger className="w-full">
                    <SelectValue placeholder="اختر البطولة" />
                  </SelectTrigger>
                  <SelectContent>
                    {leagues.map(l => (
                      <SelectItem key={l.id} value={l.id}>{l.name}</SelectItem>
                    ))}
                  </SelectContent>
                </Select>
              </div>

              {/* Team Select (filtered by league) */}
              <div className="space-y-2">
                <Label>الفريق *</Label>
                <Select value={addTeamId} onValueChange={setAddTeamId} disabled={!addLeagueId}>
                  <SelectTrigger className="w-full">
                    <SelectValue placeholder={addLeagueId ? 'اختر الفريق' : 'اختر البطولة أولاً'} />
                  </SelectTrigger>
                  <SelectContent>
                    {teams.map(t => (
                      <SelectItem key={t.id} value={t.id}>{t.name}</SelectItem>
                    ))}
                  </SelectContent>
                </Select>
              </div>

              {/* Player Select (filtered by team) */}
              <div className="space-y-2">
                <Label>اللاعب *</Label>
                <Select value={addPlayerId} onValueChange={setAddPlayerId} disabled={!addTeamId}>
                  <SelectTrigger className="w-full">
                    <SelectValue placeholder={addTeamId ? 'اختر اللاعب' : 'اختر الفريق أولاً'} />
                  </SelectTrigger>
                  <SelectContent>
                    {players.map(p => (
                      <SelectItem key={p.id} value={p.id}>
                        {p.name} {p.position ? `(${positionLabel(p.position)})` : ''}
                      </SelectItem>
                    ))}
                  </SelectContent>
                </Select>
              </div>

              {/* Stats */}
              <div className="grid grid-cols-3 gap-4">
                <div className="space-y-2">
                  <Label>الأهداف</Label>
                  <Input
                    type="number"
                    min="0"
                    value={addGoals}
                    onChange={(e) => setAddGoals(e.target.value)}
                    placeholder="0"
                  />
                </div>
                <div className="space-y-2">
                  <Label>التمريرات</Label>
                  <Input
                    type="number"
                    min="0"
                    value={addAssists}
                    onChange={(e) => setAddAssists(e.target.value)}
                    placeholder="0"
                  />
                </div>
                <div className="space-y-2">
                  <Label>أهداف جزاء</Label>
                  <Input
                    type="number"
                    min="0"
                    value={addPenaltyGoals}
                    onChange={(e) => setAddPenaltyGoals(e.target.value)}
                    placeholder="0"
                  />
                </div>
              </div>
            </div>
            <DialogFooter>
              <Button variant="outline" onClick={() => setAddDialogOpen(false)}>إلغاء</Button>
              <Button
                className="bg-emerald-600 hover:bg-emerald-700"
                onClick={handleAdd}
                disabled={addSubmitting || !addLeagueId || !addPlayerId || !addTeamId}
              >
                {addSubmitting && <Loader2 className="size-4 ml-1 animate-spin" />}
                إضافة
              </Button>
            </DialogFooter>
          </DialogContent>
        </Dialog>
      </div>

      {/* Stats Summary Cards */}
      <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-4">
        <Card className="border-0 shadow-sm">
          <CardContent className="p-5">
            <div className="flex items-center gap-4">
              <div className="size-12 rounded-xl bg-emerald-100 dark:bg-emerald-900/30 flex items-center justify-center shrink-0">
                <Users className="size-6 text-emerald-600 dark:text-emerald-400" />
              </div>
              <div>
                <p className="text-sm text-gray-500 dark:text-gray-400">إجمالي اللاعبين</p>
                <p className="text-2xl font-bold text-gray-800 dark:text-gray-100">{stats.totalPlayers}</p>
              </div>
            </div>
          </CardContent>
        </Card>

        <Card className="border-0 shadow-sm">
          <CardContent className="p-5">
            <div className="flex items-center gap-4">
              <div className="size-12 rounded-xl bg-rose-100 dark:bg-rose-900/30 flex items-center justify-center shrink-0">
                <Target className="size-6 text-rose-600 dark:text-rose-400" />
              </div>
              <div>
                <p className="text-sm text-gray-500 dark:text-gray-400">إجمالي الأهداف</p>
                <p className="text-2xl font-bold text-gray-800 dark:text-gray-100">{stats.totalGoals}</p>
              </div>
            </div>
          </CardContent>
        </Card>

        <Card className="border-0 shadow-sm">
          <CardContent className="p-5">
            <div className="flex items-center gap-4">
              <div className="size-12 rounded-xl bg-blue-100 dark:bg-blue-900/30 flex items-center justify-center shrink-0">
                <TrendingUp className="size-6 text-blue-600 dark:text-blue-400" />
              </div>
              <div>
                <p className="text-sm text-gray-500 dark:text-gray-400">إجمالي التمريرات</p>
                <p className="text-2xl font-bold text-gray-800 dark:text-gray-100">{stats.totalAssists}</p>
              </div>
            </div>
          </CardContent>
        </Card>

        <Card className="border-0 shadow-sm">
          <CardContent className="p-5">
            <div className="flex items-center gap-4">
              <div className="size-12 rounded-xl bg-amber-100 dark:bg-amber-900/30 flex items-center justify-center shrink-0">
                <Medal className="size-6 text-amber-600 dark:text-amber-400" />
              </div>
              <div>
                <p className="text-sm text-gray-500 dark:text-gray-400">أكثر بطولة أهدافاً</p>
                <p className="text-lg font-bold text-gray-800 dark:text-gray-100 truncate">
                  {stats.topLeague ? stats.topLeague.name : '-'}
                </p>
                {stats.topLeague && (
                  <p className="text-xs text-gray-400">{stats.topLeague.goals} هدف</p>
                )}
              </div>
            </div>
          </CardContent>
        </Card>
      </div>

      {/* League Tabs + Table */}
      <Card className="border-0 shadow-sm">
        <CardHeader className="pb-3">
          <CardTitle className="text-base font-semibold">قائمة الهدافين</CardTitle>
        </CardHeader>
        <CardContent className="p-0">
          <Tabs
            dir="rtl"
            value={activeLeagueId}
            onValueChange={setActiveLeagueId}
          >
            {/* League Tabs */}
            <div className="px-6 pb-4 overflow-x-auto">
              <TabsList className="h-auto flex-wrap gap-1 bg-gray-100 dark:bg-gray-800 p-1.5">
                <TabsTrigger
                  value=""
                  className="data-[state=active]:bg-white dark:data-[state=active]:bg-gray-700 data-[state=active]:shadow-sm text-xs sm:text-sm px-3 py-1.5"
                >
                  الكل
                </TabsTrigger>
                {leagues.map(league => (
                  <TabsTrigger
                    key={league.id}
                    value={league.id}
                    className="data-[state=active]:bg-white dark:data-[state=active]:bg-gray-700 data-[state=active]:shadow-sm text-xs sm:text-sm px-3 py-1.5"
                  >
                    {league.name}
                  </TabsTrigger>
                ))}
              </TabsList>
            </div>

            {/* Table (shared across tabs) */}
            <div className="overflow-x-auto">
              <Table>
                <TableHeader>
                  <TableRow className="bg-gray-50/80 dark:bg-gray-800/50">
                    <TableHead className="text-right w-16">#</TableHead>
                    <TableHead className="text-right">اللاعب</TableHead>
                    <TableHead className="text-right">الفريق</TableHead>
                    <TableHead className="text-right">المركز</TableHead>
                    <TableHead className="text-center">الأهداف</TableHead>
                    <TableHead className="text-center">التمريرات</TableHead>
                    <TableHead className="text-center">جزاء</TableHead>
                    <TableHead className="text-center">المساهمات</TableHead>
                    <TableHead className="text-right">إجراءات</TableHead>
                  </TableRow>
                </TableHeader>
                <TableBody>
                  {filteredScorers.length === 0 ? (
                    <TableRow>
                      <TableCell colSpan={9} className="text-center py-12 text-muted-foreground">
                        <Trophy className="size-12 mx-auto mb-3 opacity-20" />
                        <p className="text-base font-medium">لا يوجد هدافين</p>
                        <p className="text-sm mt-1">أضف هدافاً جديداً للبدء</p>
                      </TableCell>
                    </TableRow>
                  ) : (
                    filteredScorers.map((scorer, index) => {
                      const rank = index + 1
                      const rankStyle = RANK_STYLES[rank]
                      const totalContributions = scorer.goals + scorer.assists

                      return (
                        <TableRow
                          key={scorer.id}
                          className={`transition-colors ${rankStyle ? rankStyle.row : 'hover:bg-gray-50 dark:hover:bg-gray-800/50'}`}
                        >
                          {/* Rank */}
                          <TableCell className="text-center">
                            {rankStyle ? (
                              <span className={`inline-flex items-center justify-center size-8 rounded-full text-sm font-bold ${rankStyle.badge}`}>
                                {rankStyle.icon}
                              </span>
                            ) : (
                              <span className="inline-flex items-center justify-center size-8 rounded-full bg-gray-100 dark:bg-gray-800 text-gray-600 dark:text-gray-300 text-sm font-medium">
                                {rank}
                              </span>
                            )}
                          </TableCell>

                          {/* Player */}
                          <TableCell>
                            <div className="flex items-center gap-3">
                              {/* Player Photo / Initials */}
                              {scorer.player.photo ? (
                                <div className="size-9 rounded-full overflow-hidden border-2 border-gray-100 dark:border-gray-700 shrink-0">
                                  <img
                                    src={scorer.player.photo}
                                    alt={scorer.player.name}
                                    className="size-full object-cover"
                                  />
                                </div>
                              ) : (
                                <div className="size-9 rounded-full bg-emerald-100 dark:bg-emerald-900/40 flex items-center justify-center text-emerald-700 dark:text-emerald-300 text-xs font-bold shrink-0 border-2 border-emerald-200 dark:border-emerald-800">
                                  {getInitials(scorer.player.name)}
                                </div>
                              )}
                              <div className="min-w-0">
                                <p className="font-semibold text-sm text-gray-800 dark:text-gray-100 truncate">
                                  {scorer.player.name}
                                </p>
                                {scorer.player.nameEn && (
                                  <p className="text-[11px] text-gray-400 truncate">{scorer.player.nameEn}</p>
                                )}
                              </div>
                            </div>
                          </TableCell>

                          {/* Team */}
                          <TableCell>
                            <div className="flex items-center gap-2">
                              <div
                                className="size-6 rounded-full shrink-0 border border-white dark:border-gray-700 shadow-sm"
                                style={{ backgroundColor: '#6b7280' }}
                              />
                              <span className="text-sm text-gray-700 dark:text-gray-300 truncate max-w-[100px]">
                                {scorer.team.shortName || scorer.team.name}
                              </span>
                            </div>
                          </TableCell>

                          {/* Position */}
                          <TableCell>
                            <Badge
                              variant="secondary"
                              className={`text-[10px] font-medium px-2 py-0.5 ${positionColor(scorer.player.position)}`}
                            >
                              {positionLabel(scorer.player.position)}
                            </Badge>
                          </TableCell>

                          {/* Goals */}
                          <TableCell className="text-center">
                            <span className="inline-flex items-center justify-center min-w-[32px] px-2 py-0.5 rounded-md bg-rose-50 dark:bg-rose-900/20 text-rose-700 dark:text-rose-300 font-bold text-sm">
                              {scorer.goals}
                            </span>
                          </TableCell>

                          {/* Assists */}
                          <TableCell className="text-center">
                            <span className="text-sm font-medium text-gray-700 dark:text-gray-300">
                              {scorer.assists}
                            </span>
                          </TableCell>

                          {/* Penalty Goals */}
                          <TableCell className="text-center">
                            <span className="text-sm text-gray-500 dark:text-gray-400">
                              {scorer.penaltyGoals}
                            </span>
                          </TableCell>

                          {/* Total Contributions */}
                          <TableCell className="text-center">
                            <Badge
                              variant="secondary"
                              className="bg-emerald-50 dark:bg-emerald-900/20 text-emerald-700 dark:text-emerald-300 font-semibold text-xs"
                            >
                              {totalContributions}
                            </Badge>
                          </TableCell>

                          {/* Actions */}
                          <TableCell>
                            <div className="flex items-center gap-1">
                              <Button
                                variant="ghost"
                                size="icon"
                                className="size-8"
                                onClick={() => openEditDialog(scorer)}
                              >
                                <Pencil className="size-4" />
                              </Button>

                              {/* Delete with AlertDialog */}
                              <AlertDialog
                                open={deleteId === scorer.id}
                                onOpenChange={(open) => {
                                  if (!open) {
                                    setDeleteId(null)
                                    setDeletePlayerName('')
                                  }
                                }}
                              >
                                <AlertDialogTrigger asChild>
                                  <Button
                                    variant="ghost"
                                    size="icon"
                                    className="size-8 text-red-500 hover:text-red-600"
                                    onClick={() => openDeleteDialog(scorer)}
                                  >
                                    <Trash2 className="size-4" />
                                  </Button>
                                </AlertDialogTrigger>
                                <AlertDialogContent dir="rtl">
                                  <AlertDialogHeader>
                                    <AlertDialogTitle className="flex items-center gap-2">
                                      <AlertTriangle className="size-5 text-red-500" />
                                      تأكيد الحذف
                                    </AlertDialogTitle>
                                    <AlertDialogDescription>
                                      هل أنت متأكد من حذف اللاعب <strong>{deletePlayerName}</strong> من قائمة الهدافين؟ لا يمكن التراجع عن هذا الإجراء.
                                    </AlertDialogDescription>
                                  </AlertDialogHeader>
                                  <AlertDialogFooter>
                                    <AlertDialogCancel>إلغاء</AlertDialogCancel>
                                    <AlertDialogAction
                                      onClick={handleDelete}
                                      disabled={deleteSubmitting}
                                      className="bg-red-600 hover:bg-red-700 text-white"
                                    >
                                      {deleteSubmitting && <Loader2 className="size-4 ml-1 animate-spin" />}
                                      حذف
                                    </AlertDialogAction>
                                  </AlertDialogFooter>
                                </AlertDialogContent>
                              </AlertDialog>
                            </div>
                          </TableCell>
                        </TableRow>
                      )
                    })
                  )}
                </TableBody>
              </Table>
            </div>

            {/* Hidden TabsContent for each league (required by Tabs) */}
            {leagues.map(league => (
              <TabsContent key={league.id} value={league.id} className="hidden" />
            ))}
            <TabsContent value="" className="hidden" />
          </Tabs>
        </CardContent>
      </Card>

      {/* Edit Dialog */}
      <Dialog open={editDialogOpen} onOpenChange={setEditDialogOpen}>
        <DialogContent className="max-w-md" dir="rtl">
          <DialogHeader>
            <DialogTitle>تعديل إحصائيات الهداف</DialogTitle>
            <DialogDescription>
              تعديل أهداف وتمريرات اللاعب: <strong>{editPlayerName}</strong>
            </DialogDescription>
          </DialogHeader>
          <div className="space-y-4">
            <div className="grid grid-cols-3 gap-4">
              <div className="space-y-2">
                <Label>الأهداف</Label>
                <Input
                  type="number"
                  min="0"
                  value={editGoals}
                  onChange={(e) => setEditGoals(e.target.value)}
                />
              </div>
              <div className="space-y-2">
                <Label>التمريرات</Label>
                <Input
                  type="number"
                  min="0"
                  value={editAssists}
                  onChange={(e) => setEditAssists(e.target.value)}
                />
              </div>
              <div className="space-y-2">
                <Label>أهداف جزاء</Label>
                <Input
                  type="number"
                  min="0"
                  value={editPenaltyGoals}
                  onChange={(e) => setEditPenaltyGoals(e.target.value)}
                />
              </div>
            </div>
          </div>
          <DialogFooter>
            <Button variant="outline" onClick={() => setEditDialogOpen(false)}>إلغاء</Button>
            <Button
              className="bg-emerald-600 hover:bg-emerald-700"
              onClick={handleEdit}
              disabled={editSubmitting}
            >
              {editSubmitting && <Loader2 className="size-4 ml-1 animate-spin" />}
              تحديث
            </Button>
          </DialogFooter>
        </DialogContent>
      </Dialog>
    </div>
  )
}
