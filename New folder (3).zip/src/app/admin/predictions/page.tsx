'use client'

import { useEffect, useState, useCallback, useMemo } from 'react'
import {
  TrendingUp, CheckCircle2, XCircle, Trash2, Loader2,
  AlertTriangle, Target, BarChart3, Users, Trophy, ArrowRightLeft,
  Filter, Search, Zap
} from 'lucide-react'
import { Card, CardContent } from '@/components/ui/card'
import { Badge } from '@/components/ui/badge'
import { Button } from '@/components/ui/button'
import { Input } from '@/components/ui/input'
import { Skeleton } from '@/components/ui/skeleton'
import { Avatar, AvatarFallback, AvatarImage } from '@/components/ui/avatar'
import {
  Table, TableBody, TableCell, TableHead, TableHeader, TableRow
} from '@/components/ui/table'
import {
  Select, SelectContent, SelectItem, SelectTrigger, SelectValue
} from '@/components/ui/select'
import {
  AlertDialog, AlertDialogAction, AlertDialogCancel, AlertDialogContent,
  AlertDialogDescription, AlertDialogFooter, AlertDialogHeader, AlertDialogTitle
} from '@/components/ui/alert-dialog'
import { timeAgo } from '@/lib/sports-utils'

// ===== Types =====
interface PredictionUser {
  id: string
  name: string
  avatar: string | null
  email: string
}

interface MatchTeam {
  id: string
  name: string
  shortName: string | null
  color: string | null
}

interface PredictionMatch {
  id: string
  homeScore: number | null
  awayScore: number | null
  status: string
  matchDate: string
  homeTeam: MatchTeam
  awayTeam: MatchTeam
}

interface Prediction {
  id: string
  userId: string
  matchId: string
  homeScore: number
  awayScore: number
  points: number
  isCorrect: boolean
  user: PredictionUser
  match: PredictionMatch
}

// ===== Helpers =====
function getUserInitials(name: string) {
  return name.charAt(0)
}

function getTeamDisplayName(team: MatchTeam) {
  return team.shortName || team.name
}

function getTeamColor(team: MatchTeam) {
  return team.color || '#6b7280'
}

function formatDate(dateStr: string) {
  const date = new Date(dateStr)
  return date.toLocaleDateString('ar-EG', {
    day: 'numeric',
    month: 'short',
  })
}

function isMatchFinished(status: string) {
  return status === 'finished'
}

// ===== Component =====
export default function AdminPredictionsPage() {
  const [predictions, setPredictions] = useState<Prediction[]>([])
  const [loading, setLoading] = useState(true)
  const [searchQuery, setSearchQuery] = useState('')
  const [matchFilter, setMatchFilter] = useState('all')
  const [correctFilter, setCorrectFilter] = useState('all')
  const [deleteTarget, setDeleteTarget] = useState<Prediction | null>(null)
  const [deleting, setDeleting] = useState(false)

  const fetchPredictions = useCallback(async () => {
    try {
      setLoading(true)
      const params = new URLSearchParams()
      if (matchFilter !== 'all') {
        params.set('matchId', matchFilter)
      }
      const res = await fetch(`/api/admin/predictions?${params.toString()}`)
      const data = await res.json()
      setPredictions(data.predictions || [])
    } catch {
      // silently fail
    } finally {
      setLoading(false)
    }
  }, [matchFilter])

  useEffect(() => {
    fetchPredictions()
  }, [fetchPredictions])

  // ===== Derived Data =====
  const matchOptions = useMemo(() => {
    const matchMap = new Map<string, { id: string; label: string; count: number }>()
    predictions.forEach((p) => {
      const existing = matchMap.get(p.matchId)
      if (existing) {
        existing.count++
      } else {
        matchMap.set(p.matchId, {
          id: p.matchId,
          label: `${getTeamDisplayName(p.match.homeTeam)} ضد ${getTeamDisplayName(p.match.awayTeam)}`,
          count: 1,
        })
      }
    })
    return Array.from(matchMap.values()).sort((a, b) => b.count - a.count)
  }, [predictions])

  // Filter by search and correct/incorrect
  const filteredPredictions = useMemo(() => {
    return predictions.filter((p) => {
      // Search filter
      if (searchQuery.trim()) {
        const q = searchQuery.trim().toLowerCase()
        const userName = p.user?.name?.toLowerCase() || ''
        const userEmail = p.user?.email?.toLowerCase() || ''
        const homeTeam = p.match.homeTeam?.name?.toLowerCase() || ''
        const awayTeam = p.match.awayTeam?.name?.toLowerCase() || ''
        if (
          !userName.includes(q) &&
          !userEmail.includes(q) &&
          !homeTeam.includes(q) &&
          !awayTeam.includes(q)
        ) {
          return false
        }
      }

      // Correct/incorrect filter
      if (correctFilter === 'correct' && !p.isCorrect) return false
      if (correctFilter === 'incorrect' && p.isCorrect) return false

      return true
    })
  }, [predictions, searchQuery, correctFilter])

  // Stats
  const totalPredictions = predictions.length
  const correctPredictions = predictions.filter((p) => p.isCorrect).length
  const averagePoints =
    totalPredictions > 0
      ? (predictions.reduce((sum, p) => sum + p.points, 0) / totalPredictions).toFixed(1)
      : '0'
  const mostPredictedMatch = matchOptions.length > 0 ? matchOptions[0] : null
  const accuracyRate =
    totalPredictions > 0
      ? ((correctPredictions / totalPredictions) * 100).toFixed(1)
      : '0'

  // ===== Handlers =====
  const handleDelete = async () => {
    if (!deleteTarget) return
    setDeleting(true)
    try {
      const res = await fetch(`/api/admin/predictions?id=${deleteTarget.id}`, {
        method: 'DELETE',
      })
      if (res.ok) {
        setPredictions((prev) => prev.filter((p) => p.id !== deleteTarget.id))
      }
    } catch {
      // silently fail
    } finally {
      setDeleting(false)
      setDeleteTarget(null)
    }
  }

  // ===== Loading Skeleton =====
  if (loading) {
    return (
      <div className="space-y-5">
        <div className="flex items-center gap-2">
          <Skeleton className="size-5 rounded" />
          <Skeleton className="h-6 w-40" />
        </div>
        <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-4">
          {Array.from({ length: 4 }).map((_, i) => (
            <Card key={i} className="border-0 shadow-sm">
              <CardContent className="p-5">
                <div className="flex items-center gap-3">
                  <Skeleton className="size-10 rounded-xl" />
                  <div className="space-y-2">
                    <Skeleton className="h-3 w-20" />
                    <Skeleton className="h-6 w-12" />
                  </div>
                </div>
              </CardContent>
            </Card>
          ))}
        </div>
        <div className="flex items-center gap-3">
          <Skeleton className="h-9 w-48" />
          <Skeleton className="h-9 w-36" />
          <Skeleton className="h-9 w-36" />
        </div>
        <Card className="border-0 shadow-sm">
          <CardContent className="p-0">
            <div className="p-4 space-y-3">
              {Array.from({ length: 8 }).map((_, i) => (
                <Skeleton key={i} className="h-14 w-full rounded-lg" />
              ))}
            </div>
          </CardContent>
        </Card>
      </div>
    )
  }

  return (
    <div className="space-y-5">
      {/* Header */}
      <div className="flex items-center justify-between flex-wrap gap-3">
        <div className="flex items-center gap-2">
          <Target className="size-5 text-emerald-500" />
          <h2 className="text-xl font-bold text-gray-800">إدارة التوقعات</h2>
        </div>
        <Badge
          variant="secondary"
          className="bg-emerald-50 text-emerald-600 border-0 text-xs font-medium px-3"
        >
          <Zap className="size-3 ml-1" />
          {totalPredictions} توقع
        </Badge>
      </div>

      {/* Stats Cards */}
      <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-4">
        {/* Total Predictions */}
        <Card className="border-0 shadow-sm">
          <CardContent className="p-5">
            <div className="flex items-center gap-3">
              <div className="size-10 rounded-xl bg-gray-100 flex items-center justify-center">
                <Users className="size-5 text-gray-500" />
              </div>
              <div>
                <p className="text-xs text-gray-400 font-medium">إجمالي التوقعات</p>
                <p className="text-2xl font-bold text-gray-800">{totalPredictions}</p>
              </div>
            </div>
          </CardContent>
        </Card>

        {/* Correct Predictions */}
        <Card className="border-0 shadow-sm">
          <CardContent className="p-5">
            <div className="flex items-center gap-3">
              <div className="size-10 rounded-xl bg-emerald-50 flex items-center justify-center">
                <CheckCircle2 className="size-5 text-emerald-500" />
              </div>
              <div>
                <p className="text-xs text-gray-400 font-medium">توقعات صحيحة</p>
                <div className="flex items-baseline gap-2">
                  <p className="text-2xl font-bold text-emerald-600">{correctPredictions}</p>
                  <span className="text-xs text-gray-400">({accuracyRate}%)</span>
                </div>
              </div>
            </div>
          </CardContent>
        </Card>

        {/* Average Points */}
        <Card className="border-0 shadow-sm">
          <CardContent className="p-5">
            <div className="flex items-center gap-3">
              <div className="size-10 rounded-xl bg-amber-50 flex items-center justify-center">
                <BarChart3 className="size-5 text-amber-500" />
              </div>
              <div>
                <p className="text-xs text-gray-400 font-medium">متوسط النقاط</p>
                <p className="text-2xl font-bold text-amber-600">{averagePoints}</p>
              </div>
            </div>
          </CardContent>
        </Card>

        {/* Most Predicted Match */}
        <Card className="border-0 shadow-sm">
          <CardContent className="p-5">
            <div className="flex items-center gap-3">
              <div className="size-10 rounded-xl bg-purple-50 flex items-center justify-center">
                <Trophy className="size-5 text-purple-500" />
              </div>
              <div className="min-w-0">
                <p className="text-xs text-gray-400 font-medium">الأكثر توقعاً</p>
                {mostPredictedMatch ? (
                  <div className="flex items-baseline gap-1">
                    <p className="text-sm font-bold text-purple-600 truncate" title={mostPredictedMatch.label}>
                      {mostPredictedMatch.label.length > 20
                        ? mostPredictedMatch.label.substring(0, 20) + '...'
                        : mostPredictedMatch.label}
                    </p>
                    <span className="text-[10px] text-gray-400">({mostPredictedMatch.count})</span>
                  </div>
                ) : (
                  <p className="text-sm text-gray-400">-</p>
                )}
              </div>
            </div>
          </CardContent>
        </Card>
      </div>

      {/* Search & Filter Bar */}
      <div className="flex items-center gap-3 flex-wrap">
        <div className="relative flex-1 max-w-xs">
          <Search className="absolute right-3 top-1/2 -translate-y-1/2 size-4 text-gray-300" />
          <Input
            placeholder="بحث بالاسم أو الفريق..."
            value={searchQuery}
            onChange={(e) => setSearchQuery(e.target.value)}
            className="bg-white border-gray-200 pr-9 h-9 text-sm"
          />
        </div>

        {/* Match Filter */}
        <Select value={matchFilter} onValueChange={setMatchFilter}>
          <SelectTrigger className="w-56 h-9 bg-white border-gray-200 text-sm">
            <Filter className="size-3.5 ml-1 text-gray-400" />
            <SelectValue placeholder="تصفية بالمباراة" />
          </SelectTrigger>
          <SelectContent>
            <SelectItem value="all">جميع المباريات</SelectItem>
            {matchOptions.map((m) => (
              <SelectItem key={m.id} value={m.id}>
                {m.label} ({m.count})
              </SelectItem>
            ))}
          </SelectContent>
        </Select>

        {/* Correct/Incorrect Filter */}
        <Select value={correctFilter} onValueChange={setCorrectFilter}>
          <SelectTrigger className="w-36 h-9 bg-white border-gray-200 text-sm">
            <SelectValue placeholder="الحالة" />
          </SelectTrigger>
          <SelectContent>
            <SelectItem value="all">الكل</SelectItem>
            <SelectItem value="correct">صحيح</SelectItem>
            <SelectItem value="incorrect">خاطئ</SelectItem>
          </SelectContent>
        </Select>

        <span className="text-xs text-gray-400">
          {filteredPredictions.length} توقع
        </span>
      </div>

      {/* Predictions Table */}
      <Card className="border-0 shadow-sm overflow-hidden">
        <CardContent className="p-0">
          <div className="overflow-x-auto">
            <Table>
              <TableHeader>
                <TableRow className="bg-gray-50/80">
                  <TableHead className="text-right text-xs font-semibold text-gray-500">المستخدم</TableHead>
                  <TableHead className="text-right text-xs font-semibold text-gray-500">المباراة</TableHead>
                  <TableHead className="text-center text-xs font-semibold text-gray-500">النتيجة المتوقعة</TableHead>
                  <TableHead className="text-center text-xs font-semibold text-gray-500">النتيجة الفعلية</TableHead>
                  <TableHead className="text-center text-xs font-semibold text-gray-500">المقارنة</TableHead>
                  <TableHead className="text-center text-xs font-semibold text-gray-500">النقاط</TableHead>
                  <TableHead className="text-center text-xs font-semibold text-gray-500">الحالة</TableHead>
                  <TableHead className="text-right text-xs font-semibold text-gray-500">التاريخ</TableHead>
                  <TableHead className="text-center text-xs font-semibold text-gray-500">إجراءات</TableHead>
                </TableRow>
              </TableHeader>
              <TableBody>
                {filteredPredictions.length === 0 ? (
                  <TableRow>
                    <TableCell colSpan={9} className="text-center py-16">
                      <div className="flex flex-col items-center gap-2">
                        <Target className="size-10 text-gray-200" />
                        <p className="text-gray-400 text-sm">لا توجد توقعات</p>
                        {matchFilter !== 'all' && (
                          <Button
                            variant="ghost"
                            size="sm"
                            className="text-emerald-500 hover:text-emerald-600 text-xs"
                            onClick={() => setMatchFilter('all')}
                          >
                            عرض جميع المباريات
                          </Button>
                        )}
                      </div>
                    </TableCell>
                  </TableRow>
                ) : (
                  filteredPredictions.map((prediction) => {
                    const matchFinished = isMatchFinished(prediction.match.status)
                    const actualHome = prediction.match.homeScore
                    const actualAway = prediction.match.awayScore
                    const homeTeamColor = getTeamColor(prediction.match.homeTeam)
                    const awayTeamColor = getTeamColor(prediction.match.awayTeam)

                    // Determine row highlight
                    const rowClass = matchFinished
                      ? prediction.isCorrect
                        ? 'bg-emerald-50/40 hover:bg-emerald-50/60'
                        : 'bg-red-50/30 hover:bg-red-50/50'
                      : 'hover:bg-gray-50/50'

                    return (
                      <TableRow
                        key={prediction.id}
                        className={`transition-colors ${rowClass}`}
                      >
                        {/* User */}
                        <TableCell>
                          <div className="flex items-center gap-2">
                            <Avatar className="size-8 border border-gray-100">
                              {prediction.user?.avatar ? (
                                <AvatarImage src={prediction.user.avatar} alt={prediction.user.name} />
                              ) : null}
                              <AvatarFallback className="bg-emerald-100 text-emerald-700 text-xs font-bold">
                                {prediction.user?.name ? getUserInitials(prediction.user.name) : '?'}
                              </AvatarFallback>
                            </Avatar>
                            <div className="min-w-0">
                              <p className="text-sm font-medium text-gray-700 truncate max-w-[100px]">
                                {prediction.user?.name || 'مجهول'}
                              </p>
                              <p className="text-[10px] text-gray-400 truncate max-w-[100px]">
                                {prediction.user?.email || ''}
                              </p>
                            </div>
                          </div>
                        </TableCell>

                        {/* Match */}
                        <TableCell>
                          <div className="flex items-center gap-2 text-sm">
                            <div className="flex items-center gap-1.5">
                              <span
                                className="size-2.5 rounded-full shrink-0"
                                style={{ backgroundColor: homeTeamColor }}
                              />
                              <span className="font-medium text-gray-700 text-xs">
                                {getTeamDisplayName(prediction.match.homeTeam)}
                              </span>
                            </div>
                            <span className="text-gray-300 text-[10px]">ضد</span>
                            <div className="flex items-center gap-1.5">
                              <span
                                className="size-2.5 rounded-full shrink-0"
                                style={{ backgroundColor: awayTeamColor }}
                              />
                              <span className="font-medium text-gray-700 text-xs">
                                {getTeamDisplayName(prediction.match.awayTeam)}
                              </span>
                            </div>
                          </div>
                        </TableCell>

                        {/* Predicted Score */}
                        <TableCell className="text-center">
                          <div className="inline-flex items-center gap-1.5 bg-gray-100 rounded-lg px-3 py-1.5">
                            <span className="text-sm font-bold text-gray-700 min-w-[20px]">
                              {prediction.homeScore}
                            </span>
                            <span className="text-gray-300 text-xs">-</span>
                            <span className="text-sm font-bold text-gray-700 min-w-[20px]">
                              {prediction.awayScore}
                            </span>
                          </div>
                        </TableCell>

                        {/* Actual Score */}
                        <TableCell className="text-center">
                          {matchFinished && actualHome !== null && actualAway !== null ? (
                            <div className="inline-flex items-center gap-1.5 bg-gray-800 rounded-lg px-3 py-1.5">
                              <span className="text-sm font-bold text-white min-w-[20px]">
                                {actualHome}
                              </span>
                              <span className="text-gray-400 text-xs">-</span>
                              <span className="text-sm font-bold text-white min-w-[20px]">
                                {actualAway}
                              </span>
                            </div>
                          ) : (
                            <Badge
                              variant="secondary"
                              className="text-[9px] bg-gray-100 text-gray-400 border-0"
                            >
                              لم تبدأ
                            </Badge>
                          )}
                        </TableCell>

                        {/* Comparison */}
                        <TableCell className="text-center">
                          {matchFinished && actualHome !== null && actualAway !== null ? (
                            <div className="flex items-center justify-center gap-1">
                              {/* Predicted */}
                              <div className={`inline-flex items-center gap-0.5 rounded px-1.5 py-0.5 text-xs font-bold ${
                                prediction.homeScore === actualHome
                                  ? 'bg-emerald-100 text-emerald-700'
                                  : 'bg-red-100 text-red-700'
                              }`}>
                                {prediction.homeScore}
                              </div>
                              <ArrowRightLeft className="size-3 text-gray-300" />
                              <div className={`inline-flex items-center gap-0.5 rounded px-1.5 py-0.5 text-xs font-bold ${
                                prediction.awayScore === actualAway
                                  ? 'bg-emerald-100 text-emerald-700'
                                  : 'bg-red-100 text-red-700'
                              }`}>
                                {prediction.awayScore}
                              </div>
                            </div>
                          ) : (
                            <span className="text-[10px] text-gray-300">-</span>
                          )}
                        </TableCell>

                        {/* Points */}
                        <TableCell className="text-center">
                          <div className="flex items-center justify-center gap-1">
                            <TrendingUp className="size-3 text-amber-500" />
                            <span className="text-sm font-bold text-gray-700">
                              {prediction.points}
                            </span>
                          </div>
                        </TableCell>

                        {/* Status */}
                        <TableCell className="text-center">
                          {prediction.isCorrect ? (
                            <Badge
                              variant="secondary"
                              className="text-[9px] border-0 bg-emerald-50 text-emerald-600"
                            >
                              <CheckCircle2 className="size-3 ml-0.5" />
                              صحيح
                            </Badge>
                          ) : (
                            <Badge
                              variant="secondary"
                              className="text-[9px] border-0 bg-red-50 text-red-600"
                            >
                              <XCircle className="size-3 ml-0.5" />
                              خاطئ
                            </Badge>
                          )}
                        </TableCell>

                        {/* Date */}
                        <TableCell>
                          <span className="text-[11px] text-gray-400">
                            {formatDate(prediction.match.matchDate)}
                          </span>
                        </TableCell>

                        {/* Actions */}
                        <TableCell className="text-center">
                          <Button
                            variant="ghost"
                            size="icon"
                            className="size-7 text-gray-400 hover:text-red-500 hover:bg-red-50"
                            onClick={() => setDeleteTarget(prediction)}
                            title="حذف التوقع"
                          >
                            <Trash2 className="size-3.5" />
                          </Button>
                        </TableCell>
                      </TableRow>
                    )
                  })
                )}
              </TableBody>
            </Table>
          </div>
        </CardContent>
      </Card>

      {/* Delete Confirmation Dialog */}
      <AlertDialog
        open={!!deleteTarget}
        onOpenChange={(open) => {
          if (!open) setDeleteTarget(null)
        }}
      >
        <AlertDialogContent dir="rtl">
          <AlertDialogHeader>
            <AlertDialogTitle className="flex items-center gap-2 text-right">
              <AlertTriangle className="size-5 text-red-500" />
              تأكيد حذف التوقع
            </AlertDialogTitle>
            <AlertDialogDescription className="text-right">
              هل أنت متأكد من حذف هذا التوقع؟ لا يمكن التراجع عن هذا الإجراء.
            </AlertDialogDescription>
            {deleteTarget && (
              <div className="mt-3 p-3 rounded-lg bg-gray-50 border border-gray-100 space-y-2">
                <div className="flex items-center gap-2">
                  <Users className="size-3.5 text-gray-400" />
                  <span className="text-xs font-medium text-gray-600">
                    {deleteTarget.user?.name || 'مجهول'}
                  </span>
                </div>
                <div className="flex items-center gap-2">
                  <Trophy className="size-3.5 text-gray-400" />
                  <span className="text-xs text-gray-600">
                    {getTeamDisplayName(deleteTarget.match.homeTeam)} ضد{' '}
                    {getTeamDisplayName(deleteTarget.match.awayTeam)}
                  </span>
                </div>
                <div className="flex items-center gap-2">
                  <Target className="size-3.5 text-gray-400" />
                  <span className="text-xs font-medium text-gray-700">
                    التوقع: {deleteTarget.homeScore} - {deleteTarget.awayScore}
                  </span>
                  {deleteTarget.points > 0 && (
                    <Badge
                      variant="secondary"
                      className="text-[9px] border-0 bg-amber-50 text-amber-600 mr-2"
                    >
                      {deleteTarget.points} نقطة
                    </Badge>
                  )}
                </div>
              </div>
            )}
          </AlertDialogHeader>
          <AlertDialogFooter className="flex-row gap-2 justify-end">
            <AlertDialogCancel className="h-9">إلغاء</AlertDialogCancel>
            <AlertDialogAction
              onClick={handleDelete}
              disabled={deleting}
              className="bg-red-500 hover:bg-red-600 text-white h-9 gap-1.5"
            >
              {deleting && <Loader2 className="size-4 animate-spin" />}
              حذف التوقع
            </AlertDialogAction>
          </AlertDialogFooter>
        </AlertDialogContent>
      </AlertDialog>
    </div>
  )
}
