'use client'

import { useEffect, useState, useCallback } from 'react'
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card'
import { Button } from '@/components/ui/button'
import { Badge } from '@/components/ui/badge'
import { Input } from '@/components/ui/input'
import { Skeleton } from '@/components/ui/skeleton'
import { Textarea } from '@/components/ui/textarea'
import {
  BookOpen, Plus, Pencil, Eye, EyeOff, Save, X, ArrowLeft, Globe, FileText, Trash2,
  Heading2, Heading3, List, Bold, Italic, Link as LinkIcon, Image, Minus,
  RotateCcw, Maximize2, Minimize2, Type
} from 'lucide-react'
import Link from 'next/link'

interface SitePageData {
  id: string
  slug: string
  title: string
  content: string
  metaDescription: string | null
  isPublished: boolean
  createdAt: string
  updatedAt: string
}

const PAGE_ICONS: Record<string, string> = {
  about: '🏠',
  privacy: '🔒',
  terms: '📋',
  contact: '📞',
}

const PAGE_COLORS: Record<string, string> = {
  about: 'bg-emerald-50 text-emerald-700 border-emerald-200',
  privacy: 'bg-blue-50 text-blue-700 border-blue-200',
  terms: 'bg-amber-50 text-amber-700 border-amber-200',
  contact: 'bg-purple-50 text-purple-700 border-purple-200',
}

const slugLabelMap: Record<string, string> = {
  about: 'من نحن',
  privacy: 'سياسة الخصوصية',
  terms: 'شروط الاستخدام',
  contact: 'اتصل بنا',
}

// Rich Text Toolbar for formatting help
function EditorToolbar({ onInsert }: { onInsert: (text: string) => void }) {
  const tools = [
    { icon: <Heading2 className="size-4" />, label: 'عنوان رئيسي', insert: '## عنوان رئيسي\n' },
    { icon: <Heading3 className="size-4" />, label: 'عنوان فرعي', insert: '### عنوان فرعي\n' },
    { icon: <Bold className="size-4" />, label: 'نص عريض', insert: '**نص عريض**' },
    { icon: <Italic className="size-4" />, label: 'نص مائل', insert: '*نص مائل*' },
    { icon: <List className="size-4" />, label: 'عنصر قائمة', insert: '- عنصر قائمة\n' },
    { icon: <LinkIcon className="size-4" />, label: 'رابط', insert: '[نص الرابط](https://example.com)' },
    { icon: <Minus className="size-4" />, label: 'فاصل', insert: '\n---\n' },
  ]

  return (
    <div className="flex items-center gap-1 px-3 py-2 bg-gray-50 border-b flex-wrap">
      <span className="text-xs text-gray-400 ml-2">تنسيق:</span>
      {tools.map((tool) => (
        <Button
          key={tool.label}
          variant="ghost"
          size="sm"
          className="h-8 gap-1.5 text-xs text-gray-500 hover:text-gray-700 hover:bg-gray-100"
          onClick={() => onInsert(tool.insert)}
          title={tool.label}
        >
          {tool.icon}
          <span className="hidden sm:inline">{tool.label}</span>
        </Button>
      ))}
    </div>
  )
}

function PageEditor({ page, onSave, onCancel }: { page: SitePageData; onSave: (data: Partial<SitePageData>) => void; onCancel: () => void }) {
  const [title, setTitle] = useState(page.title)
  const [content, setContent] = useState(page.content)
  const [metaDescription, setMetaDescription] = useState(page.metaDescription || '')
  const [isPublished, setIsPublished] = useState(page.isPublished)
  const [saving, setSaving] = useState(false)
  const [activeTab, setActiveTab] = useState<'edit' | 'preview'>('edit')
  const [isFullscreen, setIsFullscreen] = useState(false)
  const [wordCount, setWordCount] = useState(0)
  const [charCount, setCharCount] = useState(0)

  useEffect(() => {
    const words = content.trim().split(/\s+/).filter(Boolean).length
    const chars = content.length
    setWordCount(words)
    setCharCount(chars)
  }, [content])

  const handleInsert = (text: string) => {
    setContent(prev => prev + text)
  }

  const handleSave = async () => {
    setSaving(true)
    await onSave({ title, content, metaDescription, isPublished })
    setSaving(false)
  }

  return (
    <div className={`space-y-4 ${isFullscreen ? 'fixed inset-0 z-50 bg-white overflow-auto' : ''}`}>
      {/* Editor Header */}
      <div className="flex items-center justify-between flex-wrap gap-3">
        <div className="flex items-center gap-3">
          <Button variant="ghost" size="icon" onClick={onCancel} className="text-gray-400 hover:text-gray-600">
            <ArrowLeft className="size-5" />
          </Button>
          <div>
            <h2 className="text-lg font-bold text-gray-800">تعديل: {page.title}</h2>
            <p className="text-xs text-gray-400">الرابط: /page/{page.slug}</p>
          </div>
        </div>
        <div className="flex items-center gap-2">
          {/* Stats */}
          <div className="hidden sm:flex items-center gap-3 text-xs text-gray-400 px-3">
            <span>{charCount} حرف</span>
            <span className="text-gray-200">|</span>
            <span>{wordCount} كلمة</span>
          </div>

          <Button
            variant="ghost"
            size="icon"
            onClick={() => setIsFullscreen(!isFullscreen)}
            className="text-gray-400 hover:text-gray-600"
            title={isFullscreen ? 'خروج من الشاشة الكاملة' : 'شاشة كاملة'}
          >
            {isFullscreen ? <Minimize2 className="size-4" /> : <Maximize2 className="size-4" />}
          </Button>

          <Button
            variant="outline"
            size="sm"
            onClick={() => setIsPublished(!isPublished)}
            className={`gap-1.5 ${isPublished ? 'text-emerald-600 border-emerald-200 bg-emerald-50' : 'text-amber-600 border-amber-200 bg-amber-50'}`}
          >
            {isPublished ? <Eye className="size-4" /> : <EyeOff className="size-4" />}
            {isPublished ? 'منشورة' : 'مسودة'}
          </Button>
          <Button
            onClick={handleSave}
            disabled={saving}
            className="gap-1.5 bg-emerald-600 hover:bg-emerald-700 text-white"
          >
            <Save className="size-4" />
            {saving ? 'جاري الحفظ...' : 'حفظ التغييرات'}
          </Button>
        </div>
      </div>

      {/* Title */}
      <div>
        <label className="block text-sm font-medium text-gray-700 mb-1.5">عنوان الصفحة</label>
        <Input
          value={title}
          onChange={(e) => setTitle(e.target.value)}
          className="text-lg font-bold"
          placeholder="عنوان الصفحة"
        />
      </div>

      {/* Meta Description */}
      <div>
        <label className="block text-sm font-medium text-gray-700 mb-1.5">
          وصف الصفحة (SEO)
          <span className="text-xs text-gray-400 font-normal mr-2">({metaDescription.length}/160 حرف)</span>
        </label>
        <Input
          value={metaDescription}
          onChange={(e) => setMetaDescription(e.target.value.slice(0, 160))}
          placeholder="وصف مختصر للصفحة يظهر في محركات البحث"
          className={`text-sm ${metaDescription.length > 140 ? 'border-amber-300' : ''}`}
        />
        {metaDescription.length > 140 && (
          <p className="text-xs text-amber-500 mt-1">يُنصح ألا يتجاوز الوصف 160 حرف</p>
        )}
      </div>

      {/* Content Editor with Tabs */}
      <Card className="border-gray-200 overflow-hidden">
        {/* Tab Bar */}
        <div className="flex items-center border-b bg-gray-50">
          <button
            onClick={() => setActiveTab('edit')}
            className={`flex items-center gap-2 px-5 py-2.5 text-sm font-medium transition-colors ${
              activeTab === 'edit'
                ? 'text-emerald-600 border-b-2 border-emerald-500 bg-white'
                : 'text-gray-500 hover:text-gray-700'
            }`}
          >
            <Pencil className="size-4" />
            تحرير
          </button>
          <button
            onClick={() => setActiveTab('preview')}
            className={`flex items-center gap-2 px-5 py-2.5 text-sm font-medium transition-colors ${
              activeTab === 'preview'
                ? 'text-emerald-600 border-b-2 border-emerald-500 bg-white'
                : 'text-gray-500 hover:text-gray-700'
            }`}
          >
            <Eye className="size-4" />
            معاينة
          </button>

          {activeTab === 'edit' && (
            <div className="mr-auto flex items-center gap-2 px-4">
              <Button
                variant="ghost"
                size="sm"
                className="h-7 text-xs text-gray-400 hover:text-gray-600 gap-1"
                onClick={() => setContent(page.content)}
              >
                <RotateCcw className="size-3" />
                استعادة
              </Button>
            </div>
          )}
        </div>

        {/* Editor */}
        {activeTab === 'edit' && (
          <>
            <EditorToolbar onInsert={handleInsert} />
            <Textarea
              value={content}
              onChange={(e) => setContent(e.target.value)}
              className="w-full min-h-[500px] p-5 text-base leading-8 border-0 focus-visible:ring-0 resize-y font-mono"
              dir="rtl"
              placeholder="اكتب محتوى الصفحة هنا..."
            />
          </>
        )}

        {/* Preview */}
        {activeTab === 'preview' && (
          <div className="p-6 md:p-8 max-w-none">
            {/* Preview Header */}
            <div className="mb-6 pb-4 border-b">
              <h1 className="text-2xl md:text-3xl font-bold text-gray-900 mb-2">{title || 'بدون عنوان'}</h1>
              {metaDescription && (
                <p className="text-gray-500 text-sm">{metaDescription}</p>
              )}
            </div>

            {/* Rendered Content */}
            <div className="prose prose-lg max-w-none">
              {content.split('\n').map((line, i) => {
                const trimmed = line.trim()
                if (!trimmed) return <br key={i} />
                if (trimmed.startsWith('## ')) return <h2 key={i} className="text-2xl font-bold mt-8 mb-3 flex items-center gap-3"><div className="w-1.5 h-7 bg-emerald-500 rounded-full" />{trimmed.slice(3)}</h2>
                if (trimmed.startsWith('### ')) return <h3 key={i} className="text-xl font-bold mt-6 mb-2">{trimmed.slice(4)}</h3>
                if (trimmed.startsWith('- ')) return <li key={i} className="mr-4 list-disc text-gray-700">{renderInlinePreview(trimmed.slice(2))}</li>
                if (trimmed === '---') return <hr key={i} className="my-6 border-gray-200" />
                return <p key={i} className="mb-3 text-gray-700 leading-8">{renderInlinePreview(trimmed)}</p>
              })}
            </div>

            {/* Preview Footer */}
            <div className="mt-8 pt-4 border-t flex items-center gap-4 text-xs text-gray-400">
              <Badge variant="outline" className="text-xs">
                {isPublished ? 'منشورة' : 'مسودة'}
              </Badge>
              <span>{charCount} حرف</span>
              <span>{wordCount} كلمة</span>
            </div>
          </div>
        )}
      </Card>
    </div>
  )
}

function renderInlinePreview(text: string): React.ReactNode[] {
  const parts: React.ReactNode[] = []
  let key = 0
  const boldRegex = /\*\*(.+?)\*\*/g
  let lastIndex = 0
  let match

  while ((match = boldRegex.exec(text)) !== null) {
    if (match.index > lastIndex) {
      parts.push(text.slice(lastIndex, match.index))
    }
    parts.push(<strong key={key++} className="font-bold">{match[1]}</strong>)
    lastIndex = match.index + match[0].length
  }

  if (lastIndex < text.length) {
    parts.push(text.slice(lastIndex))
  }

  return parts.length > 0 ? parts : [text]
}

export default function AdminPages() {
  const [pages, setPages] = useState<SitePageData[]>([])
  const [loading, setLoading] = useState(true)
  const [editingPage, setEditingPage] = useState<SitePageData | null>(null)
  const [showNewForm, setShowNewForm] = useState(false)
  const [newPageSlug, setNewPageSlug] = useState('')
  const [newPageTitle, setNewPageTitle] = useState('')

  const fetchPages = useCallback(async () => {
    try {
      setLoading(true)
      const res = await fetch('/api/admin/pages')
      if (!res.ok) throw new Error('فشل في جلب الصفحات')
      const data = await res.json()
      setPages(data.pages || [])
    } catch (err) {
      console.error(err)
    } finally {
      setLoading(false)
    }
  }, [])

  useEffect(() => {
    fetchPages()
  }, [fetchPages])

  const handleSave = async (data: Partial<SitePageData>) => {
    if (!editingPage) return
    try {
      const res = await fetch(`/api/admin/pages/${editingPage.slug}`, {
        method: 'PUT',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify(data),
      })
      if (!res.ok) throw new Error('فشل في الحفظ')
      await fetchPages()
      setEditingPage(null)
    } catch (err) {
      console.error(err)
    }
  }

  const handleCreate = async () => {
    if (!newPageSlug || !newPageTitle) return
    try {
      const res = await fetch('/api/admin/pages', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          slug: newPageSlug,
          title: newPageTitle,
          content: `## ${newPageTitle}\n\nاكتب محتوى الصفحة هنا...`,
          isPublished: false,
        }),
      })
      if (!res.ok) throw new Error('فشل في الإنشاء')
      setShowNewForm(false)
      setNewPageSlug('')
      setNewPageTitle('')
      await fetchPages()
    } catch (err) {
      console.error(err)
    }
  }

  const handleDelete = async (slug: string) => {
    if (!confirm('هل أنت متأكد من حذف هذه الصفحة؟')) return
    try {
      await fetch(`/api/admin/pages/${slug}`, { method: 'DELETE' })
      await fetchPages()
    } catch (err) {
      console.error(err)
    }
  }

  const handleTogglePublish = async (page: SitePageData) => {
    try {
      await fetch(`/api/admin/pages/${page.slug}`, {
        method: 'PUT',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ isPublished: !page.isPublished }),
      })
      await fetchPages()
    } catch (err) {
      console.error(err)
    }
  }

  // Editor mode
  if (editingPage) {
    return (
      <PageEditor
        page={editingPage}
        onSave={handleSave}
        onCancel={() => setEditingPage(null)}
      />
    )
  }

  return (
    <div className="space-y-6">
      {/* Header */}
      <div className="flex items-center justify-between">
        <div className="flex items-center gap-2">
          <BookOpen className="size-5 text-emerald-600" />
          <h2 className="text-lg font-bold text-gray-800">إدارة الصفحات</h2>
          <Badge variant="secondary" className="text-xs">{pages.length} صفحة</Badge>
        </div>
        <Button
          onClick={() => setShowNewForm(true)}
          className="gap-1.5 bg-emerald-600 hover:bg-emerald-700 text-white"
        >
          <Plus className="size-4" />
          صفحة جديدة
        </Button>
      </div>

      {/* Quick Stats */}
      <div className="grid grid-cols-2 md:grid-cols-4 gap-3">
        {[
          { label: 'إجمالي الصفحات', value: pages.length, color: 'bg-gray-50 text-gray-700' },
          { label: 'منشورة', value: pages.filter(p => p.isPublished).length, color: 'bg-emerald-50 text-emerald-700' },
          { label: 'مسودات', value: pages.filter(p => !p.isPublished).length, color: 'bg-amber-50 text-amber-700' },
          { label: 'إجمالي المحتوى', value: `${Math.round(pages.reduce((acc, p) => acc + p.content.length, 0) / 1024)}KB`, color: 'bg-blue-50 text-blue-700' },
        ].map((stat) => (
          <Card key={stat.label} className="border-0 shadow-sm">
            <CardContent className={`p-4 ${stat.color} rounded-xl`}>
              <p className="text-2xl font-bold">{stat.value}</p>
              <p className="text-xs mt-0.5 opacity-70">{stat.label}</p>
            </CardContent>
          </Card>
        ))}
      </div>

      {/* New Page Form */}
      {showNewForm && (
        <Card className="border-emerald-200 bg-emerald-50/50">
          <CardContent className="p-4">
            <h3 className="font-bold text-sm text-gray-700 mb-3">إنشاء صفحة جديدة</h3>
            <div className="flex flex-col sm:flex-row gap-3">
              <div className="flex-1">
                <label className="block text-xs text-gray-500 mb-1">عنوان الصفحة</label>
                <Input
                  value={newPageTitle}
                  onChange={(e) => setNewPageTitle(e.target.value)}
                  placeholder="مثال: من نحن"
                />
              </div>
              <div className="flex-1">
                <label className="block text-xs text-gray-500 mb-1">الرابط (slug)</label>
                <Input
                  value={newPageSlug}
                  onChange={(e) => setNewPageSlug(e.target.value.replace(/[^a-z0-9-]/g, ''))}
                  placeholder="مثال: about"
                  dir="ltr"
                />
              </div>
              <div className="flex items-end gap-2">
                <Button onClick={handleCreate} className="bg-emerald-600 hover:bg-emerald-700 text-white gap-1">
                  <Plus className="size-4" />
                  إنشاء
                </Button>
                <Button variant="outline" onClick={() => { setShowNewForm(false); setNewPageSlug(''); setNewPageTitle('') }}>
                  إلغاء
                </Button>
              </div>
            </div>
          </CardContent>
        </Card>
      )}

      {/* Loading */}
      {loading && (
        <div className="space-y-3">
          {Array.from({ length: 4 }).map((_, i) => (
            <Skeleton key={i} className="h-24 w-full rounded-xl" />
          ))}
        </div>
      )}

      {/* Pages List */}
      {!loading && (
        <div className="space-y-3">
          {pages.map((page) => {
            const colorClass = PAGE_COLORS[page.slug] || 'bg-gray-50 text-gray-700 border-gray-200'
            const wordCount = page.content.trim().split(/\s+/).filter(Boolean).length

            return (
              <Card key={page.id} className="hover:shadow-md transition-shadow border-0 shadow-sm">
                <CardContent className="p-5">
                  <div className="flex items-center justify-between">
                    <div className="flex items-center gap-4">
                      <div className={`size-12 rounded-xl flex items-center justify-center text-2xl border ${colorClass}`}>
                        {PAGE_ICONS[page.slug] || '📄'}
                      </div>
                      <div>
                        <div className="flex items-center gap-2 mb-1">
                          <h3 className="font-bold text-gray-800">{page.title}</h3>
                          <Badge
                            className={`text-[10px] px-2 ${
                              page.isPublished
                                ? 'bg-emerald-50 text-emerald-600 border-emerald-200'
                                : 'bg-amber-50 text-amber-600 border-amber-200'
                            }`}
                            variant="outline"
                          >
                            {page.isPublished ? 'منشورة' : 'مسودة'}
                          </Badge>
                        </div>
                        <div className="flex items-center gap-3 text-xs text-gray-400">
                          <span className="flex items-center gap-1">
                            <Globe className="size-3" />
                            /page/{page.slug}
                          </span>
                          <span className="flex items-center gap-1">
                            <FileText className="size-3" />
                            {page.content.length} حرف
                          </span>
                          <span className="flex items-center gap-1">
                            <Type className="size-3" />
                            {wordCount} كلمة
                          </span>
                        </div>
                      </div>
                    </div>

                    <div className="flex items-center gap-1.5">
                      <Link href={`/page/${page.slug}`} target="_blank">
                        <Button variant="ghost" size="icon" className="text-gray-400 hover:text-emerald-600 h-9 w-9" title="معاينة">
                          <Eye className="size-4" />
                        </Button>
                      </Link>
                      <Button
                        variant="ghost"
                        size="icon"
                        onClick={() => handleTogglePublish(page)}
                        className={`h-9 w-9 ${page.isPublished ? 'text-emerald-500 hover:text-emerald-700' : 'text-amber-500 hover:text-amber-700'}`}
                        title={page.isPublished ? 'إلغاء النشر' : 'نشر'}
                      >
                        {page.isPublished ? <Eye className="size-4" /> : <EyeOff className="size-4" />}
                      </Button>
                      <Button
                        variant="ghost"
                        size="icon"
                        onClick={() => setEditingPage(page)}
                        className="text-gray-400 hover:text-blue-600 h-9 w-9"
                        title="تعديل"
                      >
                        <Pencil className="size-4" />
                      </Button>
                      {!['about', 'privacy', 'terms', 'contact'].includes(page.slug) && (
                        <Button
                          variant="ghost"
                          size="icon"
                          onClick={() => handleDelete(page.slug)}
                          className="text-gray-400 hover:text-red-600 h-9 w-9"
                          title="حذف"
                        >
                          <Trash2 className="size-4" />
                        </Button>
                      )}
                    </div>
                  </div>
                </CardContent>
              </Card>
            )
          })}

          {pages.length === 0 && (
            <Card>
              <CardContent className="text-center py-12 text-gray-400">
                <BookOpen className="size-12 mx-auto mb-3 text-gray-300" />
                <p className="font-medium">لا توجد صفحات بعد</p>
                <p className="text-sm mt-1">أنشئ صفحة جديدة لتبدأ</p>
              </CardContent>
            </Card>
          )}
        </div>
      )}
    </div>
  )
}
