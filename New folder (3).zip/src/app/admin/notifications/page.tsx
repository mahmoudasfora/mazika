'use client'

import { useEffect, useState, useCallback, useMemo } from 'react'
import {
  Bell, Plus, Trash2, Loader2, Send, Eye, RefreshCw,
  BellRing, Zap, CircleDot, Trophy, Info, Search,
  Clock, X, AlertTriangle
} from 'lucide-react'
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card'
import { Badge } from '@/components/ui/badge'
import { Button } from '@/components/ui/button'
import { Input } from '@/components/ui/input'
import { Skeleton } from '@/components/ui/skeleton'
import { Label } from '@/components/ui/label'
import { Textarea } from '@/components/ui/textarea'
import {
  Table, TableBody, TableCell, TableHead, TableHeader, TableRow
} from '@/components/ui/table'
import {
  Dialog, DialogContent, DialogDescription, DialogFooter,
  DialogHeader, DialogTitle
} from '@/components/ui/dialog'
import {
  Select, SelectContent, SelectItem, SelectTrigger, SelectValue
} from '@/components/ui/select'

// ============ TYPES ============
interface NotificationData {
  id: string
  key: string
  title: string
  message: string
  type: 'match_start' | 'goal' | 'breaking_news' | 'general'
  matchId?: string
  createdAt: string
}

interface MatchTeam {
  id: string
  name: string
  nameEn: string | null
  shortName: string | null
  logo: string | null
  color?: string | null
}

interface MatchLeague {
  id: string
  name: string
  nameEn: string | null
  logo: string | null
}

interface Match {
  id: string
  homeTeamId: string
  awayTeamId: string
  leagueId: string
  homeScore: number | null
  awayScore: number | null
  status: string
  matchDate: string
  homeTeam: MatchTeam
  awayTeam: MatchTeam
  league: MatchLeague
}

// ============ CONSTANTS ============
const NOTIFICATION_TYPES = [
  {
    value: 'match_start' as const,
    label: 'بدء مباراة',
    icon: Trophy,
    color: 'bg-green-100 text-green-700 border-green-200',
    dotColor: 'bg-green-500',
    previewBg: 'from-green-500 to-green-600',
  },
  {
    value: 'goal' as const,
    label: 'هدف',
    icon: CircleDot,
    color: 'bg-emerald-100 text-emerald-700 border-emerald-200',
    dotColor: 'bg-emerald-500',
    previewBg: 'from-emerald-500 to-emerald-600',
  },
  {
    value: 'breaking_news' as const,
    label: 'خبر عاجل',
    icon: Zap,
    color: 'bg-red-100 text-red-700 border-red-200',
    dotColor: 'bg-red-500',
    previewBg: 'from-red-500 to-red-600',
  },
  {
    value: 'general' as const,
    label: 'عام',
    icon: Info,
    color: 'bg-blue-100 text-blue-700 border-blue-200',
    dotColor: 'bg-blue-500',
    previewBg: 'from-blue-500 to-blue-600',
  },
]

const QUICK_NOTIFICATIONS = [
  {
    type: 'match_start' as const,
    label: 'إشعار بدء مباراة',
    icon: Trophy,
    titleTemplate: 'بدء المباراة!',
    messageTemplate: 'المباراة على وشك أن تبدأ! تابع الآن مباشرة.',
    color: 'bg-green-50 hover:bg-green-100 text-green-700 border-green-200',
  },
  {
    type: 'goal' as const,
    label: 'إشعار هدف',
    icon: CircleDot,
    titleTemplate: 'هدف!',
    messageTemplate: 'تم تسجيل هدف! تابع التفاصيل.',
    color: 'bg-emerald-50 hover:bg-emerald-100 text-emerald-700 border-emerald-200',
  },
  {
    type: 'breaking_news' as const,
    label: 'خبر عاجل',
    icon: Zap,
    titleTemplate: 'خبر عاجل!',
    messageTemplate: '',
    color: 'bg-red-50 hover:bg-red-100 text-red-700 border-red-200',
  },
]

// ============ MAIN COMPONENT ============
export default function AdminNotificationsPage() {
  // Data state
  const [notifications, setNotifications] = useState<NotificationData[]>([])
  const [matches, setMatches] = useState<Match[]>([])
  const [loading, setLoading] = useState(true)
  const [submitting, setSubmitting] = useState(false)

  // Dialog state
  const [createDialogOpen, setCreateDialogOpen] = useState(false)
  const [deleteDialogOpen, setDeleteDialogOpen] = useState(false)
  const [notificationToDelete, setNotificationToDelete] = useState<NotificationData | null>(null)

  // Preview state
  const [showPreview, setShowPreview] = useState(false)

  // Filter state
  const [typeFilter, setTypeFilter] = useState('all')
  const [searchQuery, setSearchQuery] = useState('')

  // Form state
  const [form, setForm] = useState({
    title: '',
    message: '',
    type: 'general' as 'match_start' | 'goal' | 'breaking_news' | 'general',
    matchId: '',
  })

  // ============ FETCH DATA ============
  const fetchNotifications = useCallback(async () => {
    try {
      setLoading(true)
      const res = await fetch('/api/admin/notifications?limit=100')
      const data = await res.json()
      setNotifications(data.notifications || [])
    } catch (error) {
      console.error('Error fetching notifications:', error)
    } finally {
      setLoading(false)
    }
  }, [])

  const fetchMatches = useCallback(async () => {
    try {
      const res = await fetch('/api/matches?all=1')
      const data = await res.json()
      setMatches(data.matches || [])
    } catch (error) {
      console.error('Error fetching matches:', error)
    }
  }, [])

  useEffect(() => {
    fetchNotifications()
    fetchMatches()
  }, [fetchNotifications, fetchMatches])

  // ============ COMPUTED VALUES ============
  const stats = useMemo(() => {
    const todayStart = new Date()
    todayStart.setHours(0, 0, 0, 0)
    const total = notifications.length
    const today = notifications.filter(n => new Date(n.createdAt) >= todayStart).length
    const byType = {
      match_start: notifications.filter(n => n.type === 'match_start').length,
      goal: notifications.filter(n => n.type === 'goal').length,
      breaking_news: notifications.filter(n => n.type === 'breaking_news').length,
      general: notifications.filter(n => n.type === 'general').length,
    }
    return { total, today, byType }
  }, [notifications])

  const filteredNotifications = useMemo(() => {
    let result = notifications
    if (typeFilter !== 'all') {
      result = result.filter(n => n.type === typeFilter)
    }
    if (searchQuery.trim()) {
      const q = searchQuery.trim().toLowerCase()
      result = result.filter(n =>
        n.title.toLowerCase().includes(q) ||
        n.message.toLowerCase().includes(q)
      )
    }
    return result
  }, [notifications, typeFilter, searchQuery])

  // Match lookup for linked matches
  const matchMap = useMemo(() => {
    const map = new Map<string, Match>()
    matches.forEach(m => map.set(m.id, m))
    return map
  }, [matches])

  // Should show match selector?
  const showMatchSelector = form.type === 'match_start' || form.type === 'goal'

  // ============ HANDLERS ============
  const resetForm = () => {
    setForm({
      title: '',
      message: '',
      type: 'general',
      matchId: '',
    })
    setShowPreview(false)
  }

  const handleQuickNotification = (quick: typeof QUICK_NOTIFICATIONS[number]) => {
    setForm({
      title: quick.titleTemplate,
      message: quick.messageTemplate,
      type: quick.type,
      matchId: '',
    })
    setCreateDialogOpen(true)
  }

  const handleOpenCreateDialog = () => {
    resetForm()
    setCreateDialogOpen(true)
  }

  const handleCreate = async () => {
    if (!form.title.trim() || !form.message.trim()) return
    setSubmitting(true)
    try {
      const res = await fetch('/api/admin/notifications', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          title: form.title.trim(),
          message: form.message.trim(),
          type: form.type,
          matchId: form.matchId || undefined,
        }),
      })
      if (res.ok) {
        setCreateDialogOpen(false)
        resetForm()
        fetchNotifications()
      }
    } catch (error) {
      console.error('Error creating notification:', error)
    } finally {
      setSubmitting(false)
    }
  }

  const handleDelete = async () => {
    if (!notificationToDelete) return
    setSubmitting(true)
    try {
      await fetch(`/api/admin/notifications?key=${encodeURIComponent(notificationToDelete.key)}`, {
        method: 'DELETE',
      })
      setDeleteDialogOpen(false)
      setNotificationToDelete(null)
      fetchNotifications()
    } catch (error) {
      console.error('Error deleting notification:', error)
    } finally {
      setSubmitting(false)
    }
  }

  const getTypeConfig = (type: string) => {
    return NOTIFICATION_TYPES.find(t => t.value === type) || NOTIFICATION_TYPES[3]
  }

  const formatDate = (dateStr: string) => {
    const date = new Date(dateStr)
    const now = new Date()
    const diffMs = now.getTime() - date.getTime()
    const diffMins = Math.floor(diffMs / 60000)
    const diffHours = Math.floor(diffMs / 3600000)
    const diffDays = Math.floor(diffMs / 86400000)

    if (diffMins < 1) return 'الآن'
    if (diffMins < 60) return `منذ ${diffMins} دقيقة`
    if (diffHours < 24) return `منذ ${diffHours} ساعة`
    if (diffDays < 7) return `منذ ${diffDays} يوم`

    return date.toLocaleDateString('ar-SA', {
      year: 'numeric',
      month: 'short',
      day: 'numeric',
    })
  }

  const truncateText = (text: string, maxLen: number) => {
    if (text.length <= maxLen) return text
    return text.slice(0, maxLen) + '...'
  }

  // ============ RENDER ============
  if (loading) {
    return (
      <div className="space-y-6">
        <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-4">
          {Array.from({ length: 4 }).map((_, i) => (
            <Skeleton key={i} className="h-28 rounded-xl" />
          ))}
        </div>
        <div className="flex gap-3">
          {Array.from({ length: 3 }).map((_, i) => (
            <Skeleton key={i} className="h-10 w-44 rounded-lg" />
          ))}
        </div>
        <Skeleton className="h-96 rounded-xl" />
      </div>
    )
  }

  return (
    <div className="space-y-6">
      {/* Header */}
      <div className="flex items-center justify-between flex-wrap gap-3">
        <div>
          <h2 className="text-xl font-bold text-gray-800 flex items-center gap-2">
            <Bell className="size-5 text-emerald-500" />
            إدارة الإشعارات
          </h2>
          <p className="text-sm text-gray-500 mt-0.5">إنشاء وإدارة إشعارات الدفع للمستخدمين</p>
        </div>
        <div className="flex items-center gap-2">
          <Button variant="outline" size="sm" onClick={fetchNotifications} className="gap-1.5">
            <RefreshCw className="size-3.5" />
            تحديث
          </Button>
          <Button
            className="bg-emerald-500 hover:bg-emerald-600 shadow-sm shadow-emerald-500/25 gap-1.5"
            onClick={handleOpenCreateDialog}
          >
            <Plus className="size-4" />
            إنشاء إشعار
          </Button>
        </div>
      </div>

      {/* Stats Cards */}
      <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-4">
        {/* Total */}
        <Card className="border-0 shadow-sm overflow-hidden">
          <CardContent className="p-4">
            <div className="flex items-center justify-between">
              <div>
                <p className="text-xs font-medium text-gray-500 mb-1">إجمالي الإشعارات</p>
                <p className="text-2xl font-bold text-gray-800">{stats.total}</p>
              </div>
              <div className="size-11 rounded-xl bg-gray-100 flex items-center justify-center">
                <Bell className="size-5 text-gray-500" />
              </div>
            </div>
          </CardContent>
        </Card>

        {/* Today */}
        <Card className="border-0 shadow-sm overflow-hidden">
          <CardContent className="p-4">
            <div className="flex items-center justify-between">
              <div>
                <p className="text-xs font-medium text-gray-500 mb-1">إشعارات اليوم</p>
                <p className="text-2xl font-bold text-emerald-600">{stats.today}</p>
              </div>
              <div className="size-11 rounded-xl bg-emerald-50 flex items-center justify-center">
                <Clock className="size-5 text-emerald-500" />
              </div>
            </div>
          </CardContent>
        </Card>

        {/* Match Start & Goal */}
        <Card className="border-0 shadow-sm overflow-hidden">
          <CardContent className="p-4">
            <div className="flex items-center justify-between">
              <div>
                <p className="text-xs font-medium text-gray-500 mb-1">بدء مباراة / هدف</p>
                <p className="text-2xl font-bold text-green-600">
                  {stats.byType.match_start + stats.byType.goal}
                </p>
                <div className="flex items-center gap-2 mt-1">
                  <span className="text-[10px] text-green-600 bg-green-50 px-1.5 py-0.5 rounded">
                    بدء: {stats.byType.match_start}
                  </span>
                  <span className="text-[10px] text-emerald-600 bg-emerald-50 px-1.5 py-0.5 rounded">
                    هدف: {stats.byType.goal}
                  </span>
                </div>
              </div>
              <div className="size-11 rounded-xl bg-green-50 flex items-center justify-center">
                <Trophy className="size-5 text-green-500" />
              </div>
            </div>
          </CardContent>
        </Card>

        {/* Breaking & General */}
        <Card className="border-0 shadow-sm overflow-hidden">
          <CardContent className="p-4">
            <div className="flex items-center justify-between">
              <div>
                <p className="text-xs font-medium text-gray-500 mb-1">عاجل / عام</p>
                <p className="text-2xl font-bold text-red-600">
                  {stats.byType.breaking_news + stats.byType.general}
                </p>
                <div className="flex items-center gap-2 mt-1">
                  <span className="text-[10px] text-red-600 bg-red-50 px-1.5 py-0.5 rounded">
                    عاجل: {stats.byType.breaking_news}
                  </span>
                  <span className="text-[10px] text-blue-600 bg-blue-50 px-1.5 py-0.5 rounded">
                    عام: {stats.byType.general}
                  </span>
                </div>
              </div>
              <div className="size-11 rounded-xl bg-red-50 flex items-center justify-center">
                <Zap className="size-5 text-red-500" />
              </div>
            </div>
          </CardContent>
        </Card>
      </div>

      {/* Quick Notification Buttons */}
      <Card className="border-0 shadow-sm">
        <CardHeader className="pb-3 pt-4 px-4">
          <CardTitle className="text-sm font-semibold text-gray-700 flex items-center gap-2">
            <Zap className="size-4 text-amber-500" />
            إشعارات سريعة
          </CardTitle>
        </CardHeader>
        <CardContent className="px-4 pb-4">
          <div className="flex flex-wrap gap-3">
            {QUICK_NOTIFICATIONS.map((quick) => {
              const Icon = quick.icon
              return (
                <Button
                  key={quick.type}
                  variant="outline"
                  className={`gap-2 border ${quick.color} transition-all`}
                  onClick={() => handleQuickNotification(quick)}
                >
                  <Icon className="size-4" />
                  {quick.label}
                </Button>
              )
            })}
          </div>
        </CardContent>
      </Card>

      {/* Filters */}
      <div className="flex items-center gap-3 flex-wrap">
        <div className="relative flex-1 min-w-[200px] max-w-sm">
          <Search className="absolute right-3 top-1/2 -translate-y-1/2 size-4 text-gray-400" />
          <Input
            placeholder="بحث في الإشعارات..."
            value={searchQuery}
            onChange={e => setSearchQuery(e.target.value)}
            className="pr-9 h-9 bg-white border-gray-200"
          />
        </div>
        <Select value={typeFilter} onValueChange={setTypeFilter}>
          <SelectTrigger className="w-40 h-9 bg-white border-gray-200 text-sm">
            <SelectValue placeholder="تصفية بالنوع" />
          </SelectTrigger>
          <SelectContent>
            <SelectItem value="all">جميع الأنواع</SelectItem>
            {NOTIFICATION_TYPES.map(t => (
              <SelectItem key={t.value} value={t.value}>{t.label}</SelectItem>
            ))}
          </SelectContent>
        </Select>
        <Badge variant="outline" className="h-9 px-3 text-xs">
          {filteredNotifications.length} إشعار
        </Badge>
      </div>

      {/* Notifications Table */}
      <Card className="border-0 shadow-sm overflow-hidden">
        <CardContent className="p-0">
          <Table>
            <TableHeader>
              <TableRow className="bg-gray-50/80">
                <TableHead className="text-right text-xs font-semibold text-gray-500 w-8">#</TableHead>
                <TableHead className="text-right text-xs font-semibold text-gray-500">العنوان</TableHead>
                <TableHead className="text-right text-xs font-semibold text-gray-500">الرسالة</TableHead>
                <TableHead className="text-center text-xs font-semibold text-gray-500">النوع</TableHead>
                <TableHead className="text-right text-xs font-semibold text-gray-500">المباراة</TableHead>
                <TableHead className="text-right text-xs font-semibold text-gray-500">التاريخ</TableHead>
                <TableHead className="text-center text-xs font-semibold text-gray-500">إجراءات</TableHead>
              </TableRow>
            </TableHeader>
            <TableBody>
              {filteredNotifications.length === 0 ? (
                <TableRow>
                  <TableCell colSpan={7} className="text-center py-12 text-gray-400">
                    <div className="flex flex-col items-center gap-2">
                      <BellRing className="size-10 text-gray-300" />
                      <p>لا توجد إشعارات</p>
                      <p className="text-xs">اضغط على &quot;إنشاء إشعار&quot; لإضافة إشعار جديد</p>
                    </div>
                  </TableCell>
                </TableRow>
              ) : (
                filteredNotifications.map((notification, idx) => {
                  const typeConfig = getTypeConfig(notification.type)
                  const TypeIcon = typeConfig.icon
                  const linkedMatch = notification.matchId ? matchMap.get(notification.matchId) : null

                  return (
                    <TableRow
                      key={notification.key}
                      className="hover:bg-gray-50/50 transition-colors"
                    >
                      <TableCell className="text-xs text-gray-400">{idx + 1}</TableCell>
                      <TableCell>
                        <div className="flex items-center gap-2">
                          <div className={`size-7 rounded-lg flex items-center justify-center shrink-0 ${typeConfig.color}`}>
                            <TypeIcon className="size-3.5" />
                          </div>
                          <span className="text-sm font-medium text-gray-700 truncate max-w-[180px]">
                            {notification.title}
                          </span>
                        </div>
                      </TableCell>
                      <TableCell>
                        <span className="text-sm text-gray-500 truncate max-w-[250px] block">
                          {truncateText(notification.message, 60)}
                        </span>
                      </TableCell>
                      <TableCell className="text-center">
                        <Badge className={`text-[10px] border ${typeConfig.color}`}>
                          {typeConfig.label}
                        </Badge>
                      </TableCell>
                      <TableCell>
                        {linkedMatch ? (
                          <div className="flex items-center gap-1.5">
                            <span className="text-xs text-gray-600 truncate max-w-[140px]">
                              {linkedMatch.homeTeam.name} ضد {linkedMatch.awayTeam.name}
                            </span>
                          </div>
                        ) : (
                          <span className="text-xs text-gray-300">—</span>
                        )}
                      </TableCell>
                      <TableCell>
                        <span className="text-[11px] text-gray-400 whitespace-nowrap">
                          {formatDate(notification.createdAt)}
                        </span>
                      </TableCell>
                      <TableCell>
                        <div className="flex items-center justify-center gap-1">
                          <Button
                            variant="ghost"
                            size="icon"
                            className="size-7 text-red-400 hover:text-red-600 hover:bg-red-50"
                            onClick={() => {
                              setNotificationToDelete(notification)
                              setDeleteDialogOpen(true)
                            }}
                          >
                            <Trash2 className="size-3.5" />
                          </Button>
                        </div>
                      </TableCell>
                    </TableRow>
                  )
                })
              )}
            </TableBody>
          </Table>
        </CardContent>
      </Card>

      {/* ============ CREATE NOTIFICATION DIALOG ============ */}
      <Dialog open={createDialogOpen} onOpenChange={setCreateDialogOpen}>
        <DialogContent className="max-w-2xl max-h-[90vh] overflow-y-auto" dir="rtl">
          <DialogHeader>
            <DialogTitle className="flex items-center gap-2">
              <Bell className="size-5 text-emerald-500" />
              إنشاء إشعار جديد
            </DialogTitle>
            <DialogDescription>أدخل بيانات الإشعار لإرساله للمستخدمين</DialogDescription>
          </DialogHeader>

          <div className="space-y-5 py-2">
            {/* Title */}
            <div className="space-y-2">
              <Label className="text-sm font-semibold">عنوان الإشعار *</Label>
              <Input
                value={form.title}
                onChange={e => setForm(prev => ({ ...prev, title: e.target.value }))}
                placeholder="مثال: بدء مباراة الأهلي والزمالك"
                className="bg-white"
              />
            </div>

            {/* Message */}
            <div className="space-y-2">
              <Label className="text-sm font-semibold">نص الإشعار *</Label>
              <Textarea
                value={form.message}
                onChange={e => setForm(prev => ({ ...prev, message: e.target.value }))}
                placeholder="اكتب نص الإشعار هنا..."
                rows={3}
                className="bg-white resize-none"
              />
            </div>

            {/* Type Selector */}
            <div className="space-y-2">
              <Label className="text-sm font-semibold">نوع الإشعار *</Label>
              <Select
                value={form.type}
                onValueChange={(value: 'match_start' | 'goal' | 'breaking_news' | 'general') =>
                  setForm(prev => ({ ...prev, type: value, matchId: value !== 'match_start' && value !== 'goal' ? '' : prev.matchId }))
                }
              >
                <SelectTrigger className="w-full bg-white">
                  <SelectValue placeholder="اختر نوع الإشعار" />
                </SelectTrigger>
                <SelectContent>
                  {NOTIFICATION_TYPES.map(t => {
                    const Icon = t.icon
                    return (
                      <SelectItem key={t.value} value={t.value}>
                        <div className="flex items-center gap-2">
                          <Icon className="size-3.5" />
                          {t.label}
                        </div>
                      </SelectItem>
                    )
                  })}
                </SelectContent>
              </Select>

              {/* Type Visual Indicator */}
              <div className="flex items-center gap-2 mt-1.5">
                {NOTIFICATION_TYPES.map(t => {
                  const Icon = t.icon
                  const isActive = form.type === t.value
                  return (
                    <button
                      key={t.value}
                      type="button"
                      onClick={() => setForm(prev => ({ ...prev, type: t.value, matchId: t.value !== 'match_start' && t.value !== 'goal' ? '' : prev.matchId }))}
                      className={`flex items-center gap-1.5 px-3 py-1.5 rounded-lg text-xs font-medium transition-all border ${
                        isActive
                          ? t.color + ' shadow-sm'
                          : 'bg-gray-50 text-gray-400 border-gray-100 hover:bg-gray-100'
                      }`}
                    >
                      <Icon className="size-3" />
                      {t.label}
                    </button>
                  )
                })}
              </div>
            </div>

            {/* Match Selector - Only for match_start and goal */}
            {showMatchSelector && (
              <div className="space-y-2">
                <Label className="text-sm font-semibold flex items-center gap-1.5">
                  <Trophy className="size-3.5 text-amber-500" />
                  ربط بمباراة (اختياري)
                </Label>
                <Select
                  value={form.matchId}
                  onValueChange={value => setForm(prev => ({ ...prev, matchId: value }))}
                >
                  <SelectTrigger className="w-full bg-white">
                    <SelectValue placeholder="اختر المباراة" />
                  </SelectTrigger>
                  <SelectContent>
                    <SelectItem value="">بدون ربط</SelectItem>
                    {matches.map(m => (
                      <SelectItem key={m.id} value={m.id}>
                        <div className="flex items-center gap-2">
                          <span>{m.homeTeam.name}</span>
                          <span className="text-gray-400">ضد</span>
                          <span>{m.awayTeam.name}</span>
                          <span className="text-[10px] text-gray-400">({m.league.name})</span>
                        </div>
                      </SelectItem>
                    ))}
                  </SelectContent>
                </Select>
                {form.matchId && matchMap.get(form.matchId) && (
                  <div className="bg-gray-50 rounded-lg p-3 flex items-center gap-3">
                    <div className="flex items-center gap-2">
                      <div
                        className="size-7 rounded-full flex items-center justify-center text-white text-[9px] font-bold shrink-0"
                        style={{ backgroundColor: matchMap.get(form.matchId)!.homeTeam.color || '#10b981' }}
                      >
                        {(matchMap.get(form.matchId)!.homeTeam.shortName || matchMap.get(form.matchId)!.homeTeam.name).charAt(0)}
                      </div>
                      <span className="text-sm font-medium text-gray-700">
                        {matchMap.get(form.matchId)!.homeTeam.name}
                      </span>
                    </div>
                    <span className="text-sm font-bold text-gray-400">ضد</span>
                    <div className="flex items-center gap-2">
                      <div
                        className="size-7 rounded-full flex items-center justify-center text-white text-[9px] font-bold shrink-0"
                        style={{ backgroundColor: matchMap.get(form.matchId)!.awayTeam.color || '#6366f1' }}
                      >
                        {(matchMap.get(form.matchId)!.awayTeam.shortName || matchMap.get(form.matchId)!.awayTeam.name).charAt(0)}
                      </div>
                      <span className="text-sm font-medium text-gray-700">
                        {matchMap.get(form.matchId)!.awayTeam.name}
                      </span>
                    </div>
                    <Badge variant="outline" className="text-[9px] mr-auto">
                      {matchMap.get(form.matchId)!.league.name}
                    </Badge>
                  </div>
                )}
              </div>
            )}

            {/* Live Preview Toggle */}
            <div className="flex items-center justify-between">
              <Label className="text-sm font-semibold flex items-center gap-1.5">
                <Eye className="size-3.5 text-gray-500" />
                معاينة مباشرة
              </Label>
              <Button
                variant="outline"
                size="sm"
                className="gap-1.5 text-xs"
                onClick={() => setShowPreview(!showPreview)}
              >
                {showPreview ? <X className="size-3" /> : <Eye className="size-3" />}
                {showPreview ? 'إخفاء المعاينة' : 'عرض المعاينة'}
              </Button>
            </div>

            {/* Live Preview */}
            {showPreview && (
              <div className="space-y-3">
                {/* Desktop-style notification preview */}
                <div className="bg-gray-100 rounded-xl p-4">
                  <p className="text-[10px] text-gray-400 mb-2 font-medium">معاينة الإشعار (سطح المكتب)</p>
                  <div className="bg-white rounded-lg shadow-lg p-3 max-w-sm border">
                    <div className="flex items-start gap-3">
                      <div className={`size-10 rounded-lg bg-gradient-to-br ${getTypeConfig(form.type).previewBg} flex items-center justify-center text-white shrink-0 shadow-sm`}>
                        <Bell className="size-5" />
                      </div>
                      <div className="flex-1 min-w-0">
                        <div className="flex items-center gap-2 mb-0.5">
                          <span className="text-xs font-bold text-gray-800 truncate">
                            {form.title || 'عنوان الإشعار'}
                          </span>
                          <Badge className={`text-[8px] border-0 px-1 py-0 ${getTypeConfig(form.type).color}`}>
                            {getTypeConfig(form.type).label}
                          </Badge>
                        </div>
                        <p className="text-[11px] text-gray-500 line-clamp-2">
                          {form.message || 'نص الإشعار سيظهر هنا...'}
                        </p>
                      </div>
                      <button className="text-gray-300 hover:text-gray-500 shrink-0">
                        <X className="size-3" />
                      </button>
                    </div>
                  </div>
                </div>

                {/* Mobile-style notification preview */}
                <div className="bg-gray-900 rounded-xl p-4">
                  <p className="text-[10px] text-gray-500 mb-2 font-medium">معاينة الإشعار (جوال)</p>
                  <div className="bg-gray-800 rounded-xl p-3 max-w-sm border border-gray-700">
                    <div className="flex items-start gap-2.5">
                      <div className={`size-9 rounded-xl bg-gradient-to-br ${getTypeConfig(form.type).previewBg} flex items-center justify-center text-white shrink-0`}>
                        <Bell className="size-4" />
                      </div>
                      <div className="flex-1 min-w-0">
                        <div className="flex items-center gap-1.5 mb-0.5">
                          <span className="text-[11px] font-bold text-white truncate">
                            سبورت بلس
                          </span>
                          <span className="text-[9px] text-gray-500">الآن</span>
                        </div>
                        <p className="text-[11px] font-medium text-gray-200 truncate">
                          {form.title || 'عنوان الإشعار'}
                        </p>
                        <p className="text-[10px] text-gray-400 line-clamp-2">
                          {form.message || 'نص الإشعار سيظهر هنا...'}
                        </p>
                      </div>
                    </div>
                  </div>
                </div>
              </div>
            )}
          </div>

          <DialogFooter className="gap-2">
            <Button variant="outline" onClick={() => setCreateDialogOpen(false)}>
              إلغاء
            </Button>
            <Button
              className="bg-emerald-500 hover:bg-emerald-600 gap-1.5"
              onClick={handleCreate}
              disabled={submitting || !form.title.trim() || !form.message.trim()}
            >
              {submitting ? (
                <Loader2 className="size-4 animate-spin" />
              ) : (
                <Send className="size-4" />
              )}
              إرسال الإشعار
            </Button>
          </DialogFooter>
        </DialogContent>
      </Dialog>

      {/* ============ DELETE CONFIRMATION DIALOG ============ */}
      <Dialog open={deleteDialogOpen} onOpenChange={setDeleteDialogOpen}>
        <DialogContent className="max-w-md" dir="rtl">
          <DialogHeader>
            <DialogTitle className="flex items-center gap-2 text-red-600">
              <AlertTriangle className="size-5" />
              تأكيد حذف الإشعار
            </DialogTitle>
            <DialogDescription>
              هل أنت متأكد من حذف هذا الإشعار؟ لا يمكن التراجع عن هذا الإجراء.
            </DialogDescription>
          </DialogHeader>

          {notificationToDelete && (
            <div className="bg-red-50 rounded-lg p-3 border border-red-100">
              <div className="flex items-center gap-2 mb-1">
                <Badge className={`text-[10px] border ${getTypeConfig(notificationToDelete.type).color}`}>
                  {getTypeConfig(notificationToDelete.type).label}
                </Badge>
                <span className="text-sm font-medium text-gray-800">{notificationToDelete.title}</span>
              </div>
              <p className="text-xs text-gray-500">{notificationToDelete.message}</p>
            </div>
          )}

          <DialogFooter className="gap-2">
            <Button variant="outline" onClick={() => setDeleteDialogOpen(false)}>
              إلغاء
            </Button>
            <Button
              variant="destructive"
              className="gap-1.5"
              onClick={handleDelete}
              disabled={submitting}
            >
              {submitting ? (
                <Loader2 className="size-4 animate-spin" />
              ) : (
                <Trash2 className="size-4" />
              )}
              حذف الإشعار
            </Button>
          </DialogFooter>
        </DialogContent>
      </Dialog>
    </div>
  )
}
