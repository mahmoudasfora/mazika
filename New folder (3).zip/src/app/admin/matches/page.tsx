'use client'

import { useEffect, useState, useCallback, useMemo } from 'react'
import {
  Plus, Pencil, Trash2, Loader2, Search, Filter, X, Trophy,
  Clock, MapPin, User, Tv, Play, Pause, Square, ChevronDown,
  Shirt, ArrowRightLeft, CircleDot, Flag, Video, BarChart3,
  Users, Eye, Settings, Zap, AlertTriangle, CheckCircle2,
  ChevronLeft, ChevronRight, RotateCcw, Save, RefreshCw
} from 'lucide-react'
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card'
import { Badge } from '@/components/ui/badge'
import { Button } from '@/components/ui/button'
import { Input } from '@/components/ui/input'
import { Skeleton } from '@/components/ui/skeleton'
import { Label } from '@/components/ui/label'
import { Textarea } from '@/components/ui/textarea'
import { Switch } from '@/components/ui/switch'
import { Tabs, TabsContent, TabsList, TabsTrigger } from '@/components/ui/tabs'
import {
  Table, TableBody, TableCell, TableHead, TableHeader, TableRow
} from '@/components/ui/table'
import {
  Dialog, DialogContent, DialogDescription, DialogFooter,
  DialogHeader, DialogTitle
} from '@/components/ui/dialog'
import {
  Select, SelectContent, SelectItem, SelectTrigger, SelectValue
} from '@/components/ui/select'
import {
  Tooltip, TooltipContent, TooltipProvider, TooltipTrigger
} from '@/components/ui/tooltip'
import { getStatusLabel, getStatusColor, formatFullDate, getEventIcon } from '@/lib/sports-utils'

// ============ TYPES ============
interface MatchTeam {
  id: string; name: string; nameEn: string | null; shortName: string | null
  logo: string | null; color?: string | null; stadium?: string | null
}
interface MatchLeague { id: string; name: string; nameEn: string | null; logo: string | null }
interface Player { id: string; name: string; nameEn: string | null; photo: string | null; position: string | null; number: number | null; team?: { id: string; name: string; color: string | null } }
interface MatchEvent {
  id: string; matchId: string; type: string; minute: number; team: string
  playerId: string | null; assistPlayerId: string | null; detail: string | null
  player?: { id: string; name: string; nameEn: string | null; photo: string | null; position: string | null; number: number | null } | null
  assistPlayer?: { id: string; name: string; nameEn: string | null } | null
}
interface MatchLineup {
  id: string; matchId: string; teamId: string; playerId: string
  position: string | null; isStarter: boolean; shirtNumber: number | null
  player: { id: string; name: string; nameEn: string | null; photo: string | null; position: string | null; number: number | null }
}
interface Match {
  id: string; homeTeamId: string; awayTeamId: string; leagueId: string
  homeScore: number | null; awayScore: number | null; status: string
  matchDate: string; stadium: string | null; referee: string | null
  round: string | null; matchday: number | null; broadcastChannels: string | null
  streamUrl: string | null; matchReport: string | null
  homePossession: number | null; awayPossession: number | null
  homeShots: number | null; awayShots: number | null
  homeShotsOnTarget: number | null; awayShotsOnTarget: number | null
  homeCorners: number | null; awayCorners: number | null
  homeFouls: number | null; awayFouls: number | null
  homeYellowCards: number | null; awayYellowCards: number | null
  homeRedCards: number | null; awayRedCards: number | null
  createdAt: string
  homeTeam: MatchTeam; awayTeam: MatchTeam; league: MatchLeague
  events?: MatchEvent[]; lineups?: MatchLineup[]
}
interface Team {
  id: string; name: string; nameEn: string | null; shortName: string | null
  country: string | null; city: string | null; stadium: string | null
  founded: number | null; color: string | null; playerCount: number
}
interface League { id: string; name: string; nameEn: string | null; country: string | null; type: string; season: string | null; isActive: boolean; teamCount: number }

// ============ CONSTANTS ============
const MATCH_STATUSES = [
  { value: 'upcoming', label: 'لم تبدأ', color: 'bg-gray-100 text-gray-700', icon: Clock },
  { value: 'live', label: 'مباشر', color: 'bg-red-500 text-white animate-pulse', icon: Play },
  { value: 'halftime', label: 'استراحة', color: 'bg-yellow-500 text-white', icon: Pause },
  { value: 'finished', label: 'انتهت', color: 'bg-green-100 text-green-700', icon: Square },
  { value: 'postponed', label: 'مؤجلة', color: 'bg-orange-100 text-orange-700', icon: AlertTriangle },
  { value: 'cancelled', label: 'ملغاة', color: 'bg-red-100 text-red-700', icon: X },
]

const EVENT_TYPES = [
  { value: 'goal', label: 'هدف', icon: '⚽', category: 'goal' },
  { value: 'penalty', label: 'ركلة جزاء', icon: '⚽🎯', category: 'goal' },
  { value: 'own_goal', label: 'هدف عكسي', icon: '😟', category: 'goal' },
  { value: 'yellow_card', label: 'بطاقة صفراء', icon: '🟨', category: 'card' },
  { value: 'red_card', label: 'بطاقة حمراء', icon: '🟥', category: 'card' },
  { value: 'substitution', label: 'تبديل', icon: '🔄', category: 'sub' },
  { value: 'var', label: 'VAR', icon: '📺', category: 'var' },
  { value: 'halftime', label: 'نهاية الشوط الأول', icon: '⏸️', category: 'period' },
  { value: 'fulltime', label: 'نهاية المباراة', icon: '🏁', category: 'period' },
]

const STAT_FIELDS = [
  { key: 'Possession', label: 'الاستحواذ', suffix: '%' },
  { key: 'Shots', label: 'التسديدات', suffix: '' },
  { key: 'ShotsOnTarget', label: 'على المرمى', suffix: '' },
  { key: 'Corners', label: 'الركنيات', suffix: '' },
  { key: 'Fouls', label: 'الأخطاء', suffix: '' },
  { key: 'YellowCards', label: 'بطاقات صفراء', suffix: '' },
  { key: 'RedCards', label: 'بطقات حمراء', suffix: '' },
]

const POSITIONS = [
  { value: 'GK', label: 'حارس مرمى' },
  { value: 'DEF', label: 'مدافع' },
  { value: 'MID', label: 'وسط' },
  { value: 'FWD', label: 'مهاجم' },
]

// ============ MAIN COMPONENT ============
export default function AdminMatchesPage() {
  // List state
  const [matches, setMatches] = useState<Match[]>([])
  const [teams, setTeams] = useState<Team[]>([])
  const [leagues, setLeagues] = useState<League[]>([])
  const [loading, setLoading] = useState(true)
  const [statusFilter, setStatusFilter] = useState('all')
  const [searchQuery, setSearchQuery] = useState('')

  // Dialogs
  const [createDialogOpen, setCreateDialogOpen] = useState(false)
  const [detailDialogOpen, setDetailDialogOpen] = useState(false)
  const [deleteDialogOpen, setDeleteDialogOpen] = useState(false)
  const [submitting, setSubmitting] = useState(false)

  // Selected match for detail editing
  const [selectedMatch, setSelectedMatch] = useState<Match | null>(null)
  const [matchToDelete, setMatchToDelete] = useState<Match | null>(null)

  // Detail tab
  const [detailTab, setDetailTab] = useState('info')

  // Create form
  const [createForm, setCreateForm] = useState({
    homeTeamId: '', awayTeamId: '', leagueId: '', matchDate: '',
    stadium: '', referee: '', round: '', matchday: '',
    broadcastChannels: '', streamUrl: '',
  })

  // Edit info form
  const [editForm, setEditForm] = useState({
    homeTeamId: '', awayTeamId: '', leagueId: '', matchDate: '',
    stadium: '', referee: '', round: '', matchday: '',
    broadcastChannels: '', streamUrl: '', matchReport: '',
    homeScore: 0, awayScore: 0, status: 'upcoming',
  })

  // Stats form
  const [statsForm, setStatsForm] = useState<Record<string, { home: number; away: number }>>({})

  // Events state
  const [events, setEvents] = useState<MatchEvent[]>([])
  const [eventForm, setEventForm] = useState({
    type: 'goal', minute: '', team: 'home', playerId: '', assistPlayerId: '', detail: '',
  })

  // Lineups state
  const [lineups, setLineups] = useState<MatchLineup[]>([])
  const [lineupForm, setLineupForm] = useState({
    teamId: '', playerId: '', position: '', isStarter: true, shirtNumber: '',
  })

  // Players by team
  const [homePlayers, setHomePlayers] = useState<Player[]>([])
  const [awayPlayers, setAwayPlayers] = useState<Player[]>([])

  // ============ FETCH DATA ============
  const fetchData = useCallback(async () => {
    try {
      setLoading(true)
      const [matchesRes, teamsRes, leaguesRes] = await Promise.all([
        fetch(`/api/matches?all=1`),
        fetch('/api/teams'),
        fetch('/api/leagues'),
      ])
      const matchesData = await matchesRes.json()
      const teamsData = await teamsRes.json()
      const leaguesData = await leaguesRes.json()
      setMatches(matchesData.matches || [])
      setTeams(teamsData.teams || [])
      setLeagues(leaguesData.leagues || [])
    } catch { /* */ } finally { setLoading(false) }
  }, [])

  useEffect(() => { fetchData() }, [fetchData])

  // Fetch match detail with events & lineups
  const fetchMatchDetail = useCallback(async (matchId: string) => {
    try {
      const res = await fetch(`/api/matches/${matchId}`)
      const data = await res.json()
      if (data.match) {
        const m = data.match as Match
        setSelectedMatch(m)
        setEvents(m.events || [])
        setLineups(m.lineups || [])

        // Fill edit form
        setEditForm({
          homeTeamId: m.homeTeamId, awayTeamId: m.awayTeamId, leagueId: m.leagueId,
          matchDate: new Date(m.matchDate).toISOString().slice(0, 16),
          stadium: m.stadium || '', referee: m.referee || '',
          round: m.round || '', matchday: m.matchday?.toString() || '',
          broadcastChannels: m.broadcastChannels || '', streamUrl: m.streamUrl || '',
          matchReport: m.matchReport || '',
          homeScore: m.homeScore || 0, awayScore: m.awayScore || 0, status: m.status,
        })

        // Fill stats form
        const stats: Record<string, { home: number; away: number }> = {}
        STAT_FIELDS.forEach(f => {
          const homeKey = `home${f.key}` as keyof Match
          const awayKey = `away${f.key}` as keyof Match
          stats[f.key] = {
            home: (m[homeKey] as number) || 0,
            away: (m[awayKey] as number) || 0,
          }
        })
        setStatsForm(stats)

        // Fetch players for each team
        const [homeRes, awayRes] = await Promise.all([
          fetch(`/api/players?teamId=${m.homeTeamId}`),
          fetch(`/api/players?teamId=${m.awayTeamId}`),
        ])
        const homeData = await homeRes.json()
        const awayData = await awayRes.json()
        setHomePlayers(homeData.players || [])
        setAwayPlayers(awayData.players || [])

        setLineupForm(prev => ({
          ...prev, teamId: m.homeTeamId,
        }))
      }
    } catch (e) {
      console.error('Error fetching match detail:', e)
    }
  }, [])

  // ============ HANDLERS ============
  const resetCreateForm = () => {
    setCreateForm({
      homeTeamId: '', awayTeamId: '', leagueId: '', matchDate: '',
      stadium: '', referee: '', round: '', matchday: '',
      broadcastChannels: '', streamUrl: '',
    })
  }

  const handleCreate = async () => {
    if (!createForm.homeTeamId || !createForm.awayTeamId || !createForm.leagueId || !createForm.matchDate) return
    setSubmitting(true)
    try {
      await fetch('/api/admin/matches', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          ...createForm,
          matchday: createForm.matchday ? parseInt(createForm.matchday) : undefined,
        }),
      })
      setCreateDialogOpen(false)
      resetCreateForm()
      fetchData()
    } catch { /* */ } finally { setSubmitting(false) }
  }

  const openDetailDialog = async (match: Match) => {
    setDetailTab('info')
    await fetchMatchDetail(match.id)
    setDetailDialogOpen(true)
  }

  const handleUpdateMatch = async () => {
    if (!selectedMatch) return
    setSubmitting(true)
    try {
      await fetch('/api/admin/matches', {
        method: 'PUT',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          id: selectedMatch.id,
          ...editForm,
          matchday: editForm.matchday ? parseInt(editForm.matchday) : undefined,
        }),
      })
      await fetchMatchDetail(selectedMatch.id)
      fetchData()
    } catch { /* */ } finally { setSubmitting(false) }
  }

  const handleSaveStats = async () => {
    if (!selectedMatch) return
    setSubmitting(true)
    try {
      const data: Record<string, number> = {}
      STAT_FIELDS.forEach(f => {
        data[`home${f.key}`] = statsForm[f.key]?.home || 0
        data[`away${f.key}`] = statsForm[f.key]?.away || 0
      })
      await fetch('/api/admin/matches', {
        method: 'PUT',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ id: selectedMatch.id, ...data }),
      })
      await fetchMatchDetail(selectedMatch.id)
    } catch { /* */ } finally { setSubmitting(false) }
  }

  const handleDelete = async () => {
    if (!matchToDelete) return
    setSubmitting(true)
    try {
      await fetch(`/api/admin/matches/${matchToDelete.id}`, { method: 'DELETE' })
      setDeleteDialogOpen(false)
      setMatchToDelete(null)
      fetchData()
    } catch { /* */ } finally { setSubmitting(false) }
  }

  // Quick status change
  const handleQuickStatus = async (matchId: string, status: string) => {
    try {
      await fetch('/api/admin/matches', {
        method: 'PUT',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ id: matchId, status }),
      })
      fetchData()
    } catch { /* */ }
  }

  // ============ EVENT HANDLERS ============
  const handleAddEvent = async () => {
    if (!selectedMatch || !eventForm.minute) return
    setSubmitting(true)
    try {
      const res = await fetch('/api/admin/match-events', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          matchId: selectedMatch.id,
          type: eventForm.type,
          minute: parseInt(eventForm.minute),
          team: eventForm.team,
          playerId: eventForm.playerId || null,
          assistPlayerId: eventForm.assistPlayerId || null,
          detail: eventForm.detail || null,
        }),
      })
      const data = await res.json()
      if (data.event) {
        setEvents(prev => [...prev, data.event].sort((a, b) => a.minute - b.minute))
      }
      // Refresh match detail to get updated scores
      await fetchMatchDetail(selectedMatch.id)
      setEventForm({ type: 'goal', minute: '', team: 'home', playerId: '', assistPlayerId: '', detail: '' })
    } catch { /* */ } finally { setSubmitting(false) }
  }

  const handleDeleteEvent = async (eventId: string) => {
    if (!selectedMatch) return
    try {
      await fetch(`/api/admin/match-events?id=${eventId}`, { method: 'DELETE' })
      setEvents(prev => prev.filter(e => e.id !== eventId))
      await fetchMatchDetail(selectedMatch.id)
    } catch { /* */ }
  }

  // ============ LINEUP HANDLERS ============
  const handleAddLineup = async () => {
    if (!selectedMatch || !lineupForm.playerId) return
    setSubmitting(true)
    try {
      const res = await fetch('/api/admin/match-lineups', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          matchId: selectedMatch.id,
          teamId: lineupForm.teamId,
          playerId: lineupForm.playerId,
          position: lineupForm.position || null,
          isStarter: lineupForm.isStarter,
          shirtNumber: lineupForm.shirtNumber ? parseInt(lineupForm.shirtNumber) : null,
        }),
      })
      const data = await res.json()
      if (data.lineup) {
        setLineups(prev => [...prev, data.lineup])
      }
      setLineupForm(prev => ({ ...prev, playerId: '', position: '', shirtNumber: '' }))
    } catch { /* */ } finally { setSubmitting(false) }
  }

  const handleToggleStarter = async (lineupId: string, isStarter: boolean) => {
    try {
      await fetch('/api/admin/match-lineups', {
        method: 'PUT',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ id: lineupId, isStarter: !isStarter }),
      })
      setLineups(prev => prev.map(l => l.id === lineupId ? { ...l, isStarter: !isStarter } : l))
    } catch { /* */ }
  }

  const handleDeleteLineup = async (lineupId: string) => {
    try {
      await fetch(`/api/admin/match-lineups?id=${lineupId}`, { method: 'DELETE' })
      setLineups(prev => prev.filter(l => l.id !== lineupId))
    } catch { /* */ }
  }

  // Bulk lineup: add all players of a team as starters
  const handleBulkAddLineup = async (teamId: string, isStarter: boolean) => {
    if (!selectedMatch) return
    setSubmitting(true)
    try {
      const playersList = teamId === selectedMatch.homeTeamId ? homePlayers : awayPlayers
      const existingPlayerIds = new Set(lineups.filter(l => l.teamId === teamId).map(l => l.playerId))
      const playersToAdd = playersList.filter(p => !existingPlayerIds.has(p.id))

      for (const player of playersToAdd) {
        await fetch('/api/admin/match-lineups', {
          method: 'POST',
          headers: { 'Content-Type': 'application/json' },
          body: JSON.stringify({
            matchId: selectedMatch.id,
            teamId,
            playerId: player.id,
            position: player.position || null,
            isStarter,
            shirtNumber: player.number || null,
          }),
        })
      }
      // Refresh lineups
      await fetchMatchDetail(selectedMatch.id)
    } catch { /* */ } finally { setSubmitting(false) }
  }

  // ============ FILTERED MATCHES ============
  const filteredMatches = useMemo(() => {
    let result = matches
    if (statusFilter !== 'all') {
      result = result.filter(m => m.status === statusFilter)
    }
    if (searchQuery.trim()) {
      const q = searchQuery.trim().toLowerCase()
      result = result.filter(m =>
        m.homeTeam.name.toLowerCase().includes(q) ||
        m.awayTeam.name.toLowerCase().includes(q) ||
        m.league.name.toLowerCase().includes(q) ||
        (m.homeTeam.nameEn?.toLowerCase().includes(q)) ||
        (m.awayTeam.nameEn?.toLowerCase().includes(q))
      )
    }
    return result
  }, [matches, statusFilter, searchQuery])

  // Group lineups by team and starter/sub
  const homeStarters = useMemo(() => lineups.filter(l => l.teamId === selectedMatch?.homeTeamId && l.isStarter), [lineups, selectedMatch])
  const homeSubs = useMemo(() => lineups.filter(l => l.teamId === selectedMatch?.homeTeamId && !l.isStarter), [lineups, selectedMatch])
  const awayStarters = useMemo(() => lineups.filter(l => l.teamId === selectedMatch?.awayTeamId && l.isStarter), [lineups, selectedMatch])
  const awaySubs = useMemo(() => lineups.filter(l => l.teamId === selectedMatch?.awayTeamId && !l.isStarter), [lineups, selectedMatch])

  // Current players list based on lineup team selection
  const currentTeamPlayers = useMemo(() => {
    if (!selectedMatch) return []
    return lineupForm.teamId === selectedMatch.homeTeamId ? homePlayers : awayPlayers
  }, [lineupForm.teamId, selectedMatch, homePlayers, awayPlayers])

  // Available players (not already in lineup)
  const availablePlayers = useMemo(() => {
    const usedIds = new Set(lineups.map(l => l.playerId))
    return currentTeamPlayers.filter(p => !usedIds.has(p.id))
  }, [currentTeamPlayers, lineups])

  // ============ RENDER ============
  if (loading) {
    return (
      <div className="space-y-4">
        {Array.from({ length: 5 }).map((_, i) => (
          <Skeleton key={i} className="h-14 w-full rounded-xl" />
        ))}
      </div>
    )
  }

  return (
    <div className="space-y-5">
      {/* Header */}
      <div className="flex items-center justify-between flex-wrap gap-3">
        <div>
          <h2 className="text-xl font-bold text-gray-800">إدارة المباريات</h2>
          <p className="text-sm text-gray-500 mt-0.5">إدارة شاملة للمباريات - إنشاء، تعديل، تتبع مباشر</p>
        </div>
        <div className="flex items-center gap-2">
          <Button variant="outline" size="sm" onClick={fetchData} className="gap-1.5">
            <RefreshCw className="size-3.5" />تحديث
          </Button>
          <Button
            className="bg-emerald-500 hover:bg-emerald-600 shadow-sm shadow-emerald-500/25 gap-1.5"
            onClick={() => { resetCreateForm(); setCreateDialogOpen(true) }}
          >
            <Plus className="size-4" />مباراة جديدة
          </Button>
        </div>
      </div>

      {/* Filters & Search */}
      <div className="flex items-center gap-3 flex-wrap">
        <div className="relative flex-1 min-w-[200px] max-w-sm">
          <Search className="absolute right-3 top-1/2 -translate-y-1/2 size-4 text-gray-400" />
          <Input
            placeholder="بحث بالفريق أو الدوري..."
            value={searchQuery}
            onChange={e => setSearchQuery(e.target.value)}
            className="pr-9 h-9 bg-white border-gray-200"
          />
        </div>
        <Select value={statusFilter} onValueChange={setStatusFilter}>
          <SelectTrigger className="w-40 h-9 bg-white border-gray-200 text-sm">
            <Filter className="size-3.5 ml-1 text-gray-400" />
            <SelectValue placeholder="تصفية بالحالة" />
          </SelectTrigger>
          <SelectContent>
            <SelectItem value="all">الكل</SelectItem>
            {MATCH_STATUSES.map(s => (
              <SelectItem key={s.value} value={s.value}>{s.label}</SelectItem>
            ))}
          </SelectContent>
        </Select>
        <Badge variant="outline" className="h-9 px-3 text-xs">
          {filteredMatches.length} مباراة
        </Badge>
      </div>

      {/* Live Matches Quick Bar */}
      {matches.filter(m => m.status === 'live').length > 0 && (
        <div className="bg-red-50 border border-red-200 rounded-xl p-3">
          <div className="flex items-center gap-2 mb-2">
            <span className="relative flex size-2.5">
              <span className="animate-ping absolute inline-flex h-full w-full rounded-full bg-red-400 opacity-75"></span>
              <span className="relative inline-flex rounded-full size-2.5 bg-red-500"></span>
            </span>
            <span className="text-sm font-bold text-red-700">مباريات مباشرة الآن</span>
          </div>
          <div className="flex gap-3 overflow-x-auto pb-1">
            {matches.filter(m => m.status === 'live').map(m => (
              <button
                key={m.id}
                onClick={() => openDetailDialog(m)}
                className="flex items-center gap-3 bg-white rounded-lg px-3 py-2 border border-red-200 hover:border-red-400 transition min-w-fit"
              >
                <span className="text-xs font-medium text-gray-700">{m.homeTeam.name}</span>
                <span className="text-sm font-bold text-red-600">{m.homeScore ?? 0} - {m.awayScore ?? 0}</span>
                <span className="text-xs font-medium text-gray-700">{m.awayTeam.name}</span>
              </button>
            ))}
          </div>
        </div>
      )}

      {/* Matches Table */}
      <Card className="border-0 shadow-sm overflow-hidden">
        <CardContent className="p-0">
          <Table>
            <TableHeader>
              <TableRow className="bg-gray-50/80">
                <TableHead className="text-right text-xs font-semibold text-gray-500 w-8">#</TableHead>
                <TableHead className="text-right text-xs font-semibold text-gray-500">المضيف</TableHead>
                <TableHead className="text-center text-xs font-semibold text-gray-500">النتيجة</TableHead>
                <TableHead className="text-right text-xs font-semibold text-gray-500">الضيف</TableHead>
                <TableHead className="text-right text-xs font-semibold text-gray-500">الدوري</TableHead>
                <TableHead className="text-center text-xs font-semibold text-gray-500">الحالة</TableHead>
                <TableHead className="text-right text-xs font-semibold text-gray-500">التاريخ</TableHead>
                <TableHead className="text-center text-xs font-semibold text-gray-500">إجراءات</TableHead>
              </TableRow>
            </TableHeader>
            <TableBody>
              {filteredMatches.length === 0 ? (
                <TableRow>
                  <TableCell colSpan={8} className="text-center py-12 text-gray-400">
                    <div className="flex flex-col items-center gap-2">
                      <Trophy className="size-10 text-gray-300" />
                      <p>لا توجد مباريات</p>
                    </div>
                  </TableCell>
                </TableRow>
              ) : (
                filteredMatches.map((match, idx) => (
                  <TableRow
                    key={match.id}
                    className={`hover:bg-gray-50/50 transition-colors cursor-pointer ${match.status === 'live' ? 'bg-red-50/30' : ''}`}
                    onClick={() => openDetailDialog(match)}
                  >
                    <TableCell className="text-xs text-gray-400">{idx + 1}</TableCell>
                    <TableCell>
                      <div className="flex items-center gap-2">
                        <div
                          className="size-7 rounded-full flex items-center justify-center text-white text-[9px] font-bold shrink-0"
                          style={{ backgroundColor: match.homeTeam.color || '#10b981' }}
                        >
                          {(match.homeTeam.shortName || match.homeTeam.name).charAt(0)}
                        </div>
                        <span className="text-sm font-medium text-gray-700 truncate max-w-[120px]">
                          {match.homeTeam.name}
                        </span>
                      </div>
                    </TableCell>
                    <TableCell className="text-center">
                      <div className="inline-flex items-center gap-1.5 bg-gray-100 rounded-lg px-2.5 py-1">
                        <span className="text-sm font-bold text-gray-800">{match.homeScore ?? '-'}</span>
                        <span className="text-xs text-gray-400">-</span>
                        <span className="text-sm font-bold text-gray-800">{match.awayScore ?? '-'}</span>
                      </div>
                    </TableCell>
                    <TableCell>
                      <div className="flex items-center gap-2">
                        <div
                          className="size-7 rounded-full flex items-center justify-center text-white text-[9px] font-bold shrink-0"
                          style={{ backgroundColor: match.awayTeam.color || '#6366f1' }}
                        >
                          {(match.awayTeam.shortName || match.awayTeam.name).charAt(0)}
                        </div>
                        <span className="text-sm font-medium text-gray-700 truncate max-w-[120px]">
                          {match.awayTeam.name}
                        </span>
                      </div>
                    </TableCell>
                    <TableCell className="text-xs text-gray-400">{match.league.name}</TableCell>
                    <TableCell className="text-center">
                      <Badge className={`text-[9px] border-0 ${getStatusColor(match.status)}`}>
                        {getStatusLabel(match.status)}
                      </Badge>
                    </TableCell>
                    <TableCell className="text-[11px] text-gray-400 whitespace-nowrap">
                      {formatFullDate(match.matchDate)}
                    </TableCell>
                    <TableCell>
                      <div className="flex items-center justify-center gap-1" onClick={e => e.stopPropagation()}>
                        <TooltipProvider>
                          <Tooltip>
                            <TooltipTrigger asChild>
                              <Button variant="ghost" size="icon" className="size-7 text-blue-500 hover:text-blue-700 hover:bg-blue-50" onClick={() => openDetailDialog(match)}>
                                <Pencil className="size-3.5" />
                              </Button>
                            </TooltipTrigger>
                            <TooltipContent>تعديل</TooltipContent>
                          </Tooltip>
                        </TooltipProvider>
                        {match.status === 'upcoming' && (
                          <TooltipProvider>
                            <Tooltip>
                              <TooltipTrigger asChild>
                                <Button variant="ghost" size="icon" className="size-7 text-green-500 hover:text-green-700 hover:bg-green-50" onClick={() => handleQuickStatus(match.id, 'live')}>
                                  <Play className="size-3.5" />
                                </Button>
                              </TooltipTrigger>
                              <TooltipContent>بدء المباراة</TooltipContent>
                            </Tooltip>
                          </TooltipProvider>
                        )}
                        {match.status === 'live' && (
                          <TooltipProvider>
                            <Tooltip>
                              <TooltipTrigger asChild>
                                <Button variant="ghost" size="icon" className="size-7 text-yellow-500 hover:text-yellow-700 hover:bg-yellow-50" onClick={() => handleQuickStatus(match.id, 'halftime')}>
                                  <Pause className="size-3.5" />
                                </Button>
                              </TooltipTrigger>
                              <TooltipContent>استراحة</TooltipContent>
                            </Tooltip>
                          </TooltipProvider>
                        )}
                        {match.status === 'halftime' && (
                          <TooltipProvider>
                            <Tooltip>
                              <TooltipTrigger asChild>
                                <Button variant="ghost" size="icon" className="size-7 text-green-500 hover:text-green-700 hover:bg-green-50" onClick={() => handleQuickStatus(match.id, 'live')}>
                                  <Play className="size-3.5" />
                                </Button>
                              </TooltipTrigger>
                              <TooltipContent>استئناف</TooltipContent>
                            </Tooltip>
                          </TooltipProvider>
                        )}
                        <TooltipProvider>
                          <Tooltip>
                            <TooltipTrigger asChild>
                              <Button variant="ghost" size="icon" className="size-7 text-red-400 hover:text-red-600 hover:bg-red-50" onClick={() => { setMatchToDelete(match); setDeleteDialogOpen(true) }}>
                                <Trash2 className="size-3.5" />
                              </Button>
                            </TooltipTrigger>
                            <TooltipContent>حذف</TooltipContent>
                          </Tooltip>
                        </TooltipProvider>
                      </div>
                    </TableCell>
                  </TableRow>
                ))
              )}
            </TableBody>
          </Table>
        </CardContent>
      </Card>

      {/* ============ CREATE MATCH DIALOG ============ */}
      <Dialog open={createDialogOpen} onOpenChange={setCreateDialogOpen}>
        <DialogContent className="max-w-2xl max-h-[90vh] overflow-y-auto" dir="rtl">
          <DialogHeader>
            <DialogTitle className="flex items-center gap-2">
              <Plus className="size-5 text-emerald-500" />مباراة جديدة
            </DialogTitle>
            <DialogDescription>أدخل بيانات المباراة الجديدة</DialogDescription>
          </DialogHeader>

          <div className="space-y-5 py-2">
            {/* League */}
            <div className="space-y-2">
              <Label className="text-sm font-semibold flex items-center gap-1.5"><Trophy className="size-3.5 text-amber-500" />الدوري *</Label>
              <Select value={createForm.leagueId} onValueChange={v => setCreateForm(p => ({ ...p, leagueId: v }))}>
                <SelectTrigger className="w-full"><SelectValue placeholder="اختر الدوري" /></SelectTrigger>
                <SelectContent>{leagues.map(l => (<SelectItem key={l.id} value={l.id}>{l.name}</SelectItem>))}</SelectContent>
              </Select>
            </div>

            {/* Teams */}
            <div className="grid grid-cols-2 gap-4">
              <div className="space-y-2">
                <Label className="text-sm font-semibold flex items-center gap-1.5"><Shirt className="size-3.5 text-emerald-500" />الفريق المضيف *</Label>
                <Select value={createForm.homeTeamId} onValueChange={v => setCreateForm(p => ({ ...p, homeTeamId: v }))}>
                  <SelectTrigger className="w-full"><SelectValue placeholder="اختر الفريق" /></SelectTrigger>
                  <SelectContent>{teams.map(t => (<SelectItem key={t.id} value={t.id}>{t.name}</SelectItem>))}</SelectContent>
                </Select>
              </div>
              <div className="space-y-2">
                <Label className="text-sm font-semibold flex items-center gap-1.5"><Shirt className="size-3.5 text-blue-500" />الفريق الضيف *</Label>
                <Select value={createForm.awayTeamId} onValueChange={v => setCreateForm(p => ({ ...p, awayTeamId: v }))}>
                  <SelectTrigger className="w-full"><SelectValue placeholder="اختر الفريق" /></SelectTrigger>
                  <SelectContent>{teams.map(t => (<SelectItem key={t.id} value={t.id}>{t.name}</SelectItem>))}</SelectContent>
                </Select>
              </div>
            </div>

            {/* Date & Round */}
            <div className="grid grid-cols-2 gap-4">
              <div className="space-y-2">
                <Label className="text-sm font-semibold flex items-center gap-1.5"><Clock className="size-3.5 text-gray-500" />تاريخ المباراة *</Label>
                <Input type="datetime-local" value={createForm.matchDate} onChange={e => setCreateForm(p => ({ ...p, matchDate: e.target.value }))} />
              </div>
              <div className="space-y-2">
                <Label className="text-sm font-semibold">الجولة</Label>
                <Input value={createForm.round} onChange={e => setCreateForm(p => ({ ...p, round: e.target.value }))} placeholder="مثال: 15" />
              </div>
            </div>

            {/* Stadium & Referee */}
            <div className="grid grid-cols-2 gap-4">
              <div className="space-y-2">
                <Label className="text-sm font-semibold flex items-center gap-1.5"><MapPin className="size-3.5 text-gray-500" />الملعب</Label>
                <Input value={createForm.stadium} onChange={e => setCreateForm(p => ({ ...p, stadium: e.target.value }))} placeholder="اسم الملعب" />
              </div>
              <div className="space-y-2">
                <Label className="text-sm font-semibold flex items-center gap-1.5"><User className="size-3.5 text-gray-500" />الحكم</Label>
                <Input value={createForm.referee} onChange={e => setCreateForm(p => ({ ...p, referee: e.target.value }))} placeholder="اسم الحكم" />
              </div>
            </div>

            {/* Broadcast */}
            <div className="grid grid-cols-2 gap-4">
              <div className="space-y-2">
                <Label className="text-sm font-semibold flex items-center gap-1.5"><Tv className="size-3.5 text-purple-500" />قنوات البث</Label>
                <Input value={createForm.broadcastChannels} onChange={e => setCreateForm(p => ({ ...p, broadcastChannels: e.target.value }))} placeholder="beIN Sports, SSC" />
              </div>
              <div className="space-y-2">
                <Label className="text-sm font-semibold flex items-center gap-1.5"><Video className="size-3.5 text-red-500" />رابط البث</Label>
                <Input value={createForm.streamUrl} onChange={e => setCreateForm(p => ({ ...p, streamUrl: e.target.value }))} placeholder="رابط البث المباشر" dir="ltr" />
              </div>
            </div>
          </div>

          <DialogFooter className="gap-2">
            <Button variant="outline" onClick={() => setCreateDialogOpen(false)}>إلغاء</Button>
            <Button className="bg-emerald-500 hover:bg-emerald-600 gap-1.5" onClick={handleCreate} disabled={submitting || !createForm.homeTeamId || !createForm.awayTeamId || !createForm.leagueId || !createForm.matchDate}>
              {submitting && <Loader2 className="size-4 animate-spin" />}إنشاء المباراة
            </Button>
          </DialogFooter>
        </DialogContent>
      </Dialog>

      {/* ============ MATCH DETAIL / EDIT DIALOG ============ */}
      <Dialog open={detailDialogOpen} onOpenChange={setDetailDialogOpen}>
        <DialogContent className="max-w-5xl max-h-[92vh] overflow-hidden flex flex-col" dir="rtl">
          <DialogHeader className="shrink-0">
            {selectedMatch && (
              <div className="flex items-center justify-between">
                <div>
                  <DialogTitle className="flex items-center gap-2">
                    <Badge className={`text-[10px] border-0 ${getStatusColor(selectedMatch.status)}`}>
                      {getStatusLabel(selectedMatch.status)}
                    </Badge>
                    {selectedMatch.homeTeam.name} ضد {selectedMatch.awayTeam.name}
                  </DialogTitle>
                  <DialogDescription>{selectedMatch.league.name} - {formatFullDate(selectedMatch.matchDate)}</DialogDescription>
                </div>
                {/* Quick Status Controls */}
                <div className="flex items-center gap-1.5">
                  {selectedMatch.status === 'upcoming' && (
                    <Button size="sm" className="bg-green-500 hover:bg-green-600 gap-1 h-8" onClick={() => { handleQuickStatus(selectedMatch.id, 'live').then(() => fetchMatchDetail(selectedMatch.id)) }}>
                      <Play className="size-3" />بدء المباراة
                    </Button>
                  )}
                  {selectedMatch.status === 'live' && (
                    <>
                      <Button size="sm" variant="outline" className="border-yellow-400 text-yellow-600 gap-1 h-8" onClick={() => { handleQuickStatus(selectedMatch.id, 'halftime').then(() => fetchMatchDetail(selectedMatch.id)) }}>
                        <Pause className="size-3" />استراحة
                      </Button>
                      <Button size="sm" variant="outline" className="border-red-400 text-red-600 gap-1 h-8" onClick={() => { handleQuickStatus(selectedMatch.id, 'finished').then(() => fetchMatchDetail(selectedMatch.id)) }}>
                        <Square className="size-3" />نهاية
                      </Button>
                    </>
                  )}
                  {selectedMatch.status === 'halftime' && (
                    <Button size="sm" className="bg-green-500 hover:bg-green-600 gap-1 h-8" onClick={() => { handleQuickStatus(selectedMatch.id, 'live').then(() => fetchMatchDetail(selectedMatch.id)) }}>
                      <Play className="size-3" />استئناف
                    </Button>
                  )}
                </div>
              </div>
            )}
          </DialogHeader>

          {/* Score Bar */}
          {selectedMatch && (
            <div className="shrink-0 bg-gradient-to-l from-blue-600 via-gray-800 to-emerald-600 rounded-xl p-4 text-white">
              <div className="flex items-center justify-center gap-6">
                <div className="text-center flex-1">
                  <div className="size-12 mx-auto rounded-full bg-white/20 flex items-center justify-center text-lg font-bold mb-1">
                    {(selectedMatch.homeTeam.shortName || selectedMatch.homeTeam.name).charAt(0)}
                  </div>
                  <p className="font-bold text-sm">{selectedMatch.homeTeam.name}</p>
                </div>
                <div className="text-center">
                  <div className="flex items-center gap-3">
                    <span className="text-3xl font-black">{selectedMatch.homeScore ?? 0}</span>
                    <span className="text-xl text-white/50">-</span>
                    <span className="text-3xl font-black">{selectedMatch.awayScore ?? 0}</span>
                  </div>
                  {selectedMatch.status === 'live' && (
                    <span className="text-[10px] bg-red-500 px-2 py-0.5 rounded-full animate-pulse mt-1 inline-block">مباشر</span>
                  )}
                </div>
                <div className="text-center flex-1">
                  <div className="size-12 mx-auto rounded-full bg-white/20 flex items-center justify-center text-lg font-bold mb-1">
                    {(selectedMatch.awayTeam.shortName || selectedMatch.awayTeam.name).charAt(0)}
                  </div>
                  <p className="font-bold text-sm">{selectedMatch.awayTeam.name}</p>
                </div>
              </div>
            </div>
          )}

          {/* Tabs */}
          <Tabs value={detailTab} onValueChange={setDetailTab} className="flex-1 min-h-0 flex flex-col">
            <TabsList className="shrink-0 w-full grid grid-cols-5 h-9 bg-gray-100 p-0.5 rounded-lg">
              <TabsTrigger value="info" className="text-[11px] gap-1 h-8 data-[state=active]:bg-white data-[state=active]:shadow-sm rounded-md">
                <Settings className="size-3" />بيانات
              </TabsTrigger>
              <TabsTrigger value="lineup" className="text-[11px] gap-1 h-8 data-[state=active]:bg-white data-[state=active]:shadow-sm rounded-md">
                <Users className="size-3" />تشكيل
              </TabsTrigger>
              <TabsTrigger value="events" className="text-[11px] gap-1 h-8 data-[state=active]:bg-white data-[state=active]:shadow-sm rounded-md">
                <Zap className="size-3" />أحداث
                {events.length > 0 && (
                  <span className="bg-red-500 text-white text-[8px] rounded-full size-4 inline-flex items-center justify-center">{events.length}</span>
                )}
              </TabsTrigger>
              <TabsTrigger value="stats" className="text-[11px] gap-1 h-8 data-[state=active]:bg-white data-[state=active]:shadow-sm rounded-md">
                <BarChart3 className="size-3" />إحصائيات
              </TabsTrigger>
              <TabsTrigger value="broadcast" className="text-[11px] gap-1 h-8 data-[state=active]:bg-white data-[state=active]:shadow-sm rounded-md">
                <Video className="size-3" />بث
              </TabsTrigger>
            </TabsList>

            {/* TAB: Basic Info */}
            <TabsContent value="info" className="flex-1 overflow-y-auto mt-3 pr-1">
              <div className="space-y-4">
                {/* Status & Score */}
                <Card className="border border-gray-100">
                  <CardHeader className="py-2.5 px-4">
                    <CardTitle className="text-sm font-semibold flex items-center gap-1.5">
                      <Play className="size-3.5 text-green-500" />الحالة والنتيجة
                    </CardTitle>
                  </CardHeader>
                  <CardContent className="px-4 pb-4">
                    <div className="grid grid-cols-3 gap-4">
                      <div className="space-y-1.5">
                        <Label className="text-xs font-medium">حالة المباراة</Label>
                        <Select value={editForm.status} onValueChange={v => setEditForm(p => ({ ...p, status: v }))}>
                          <SelectTrigger className="h-8 text-xs"><SelectValue /></SelectTrigger>
                          <SelectContent>
                            {MATCH_STATUSES.map(s => (<SelectItem key={s.value} value={s.value}>{s.label}</SelectItem>))}
                          </SelectContent>
                        </Select>
                      </div>
                      <div className="space-y-1.5">
                        <Label className="text-xs font-medium">أهداف المضيف</Label>
                        <Input type="number" value={editForm.homeScore} onChange={e => setEditForm(p => ({ ...p, homeScore: parseInt(e.target.value) || 0 }))} className="h-8 text-center text-lg font-bold" />
                      </div>
                      <div className="space-y-1.5">
                        <Label className="text-xs font-medium">أهداف الضيف</Label>
                        <Input type="number" value={editForm.awayScore} onChange={e => setEditForm(p => ({ ...p, awayScore: parseInt(e.target.value) || 0 }))} className="h-8 text-center text-lg font-bold" />
                      </div>
                    </div>
                  </CardContent>
                </Card>

                {/* Teams & League */}
                <Card className="border border-gray-100">
                  <CardHeader className="py-2.5 px-4">
                    <CardTitle className="text-sm font-semibold flex items-center gap-1.5">
                      <Shirt className="size-3.5 text-emerald-500" />الفرق والدوري
                    </CardTitle>
                  </CardHeader>
                  <CardContent className="px-4 pb-4 space-y-3">
                    <div className="grid grid-cols-3 gap-3">
                      <div className="space-y-1.5">
                        <Label className="text-xs font-medium">الدوري</Label>
                        <Select value={editForm.leagueId} onValueChange={v => setEditForm(p => ({ ...p, leagueId: v }))}>
                          <SelectTrigger className="h-8 text-xs"><SelectValue /></SelectTrigger>
                          <SelectContent>{leagues.map(l => (<SelectItem key={l.id} value={l.id}>{l.name}</SelectItem>))}</SelectContent>
                        </Select>
                      </div>
                      <div className="space-y-1.5">
                        <Label className="text-xs font-medium">الفريق المضيف</Label>
                        <Select value={editForm.homeTeamId} onValueChange={v => setEditForm(p => ({ ...p, homeTeamId: v }))}>
                          <SelectTrigger className="h-8 text-xs"><SelectValue /></SelectTrigger>
                          <SelectContent>{teams.map(t => (<SelectItem key={t.id} value={t.id}>{t.name}</SelectItem>))}</SelectContent>
                        </Select>
                      </div>
                      <div className="space-y-1.5">
                        <Label className="text-xs font-medium">الفريق الضيف</Label>
                        <Select value={editForm.awayTeamId} onValueChange={v => setEditForm(p => ({ ...p, awayTeamId: v }))}>
                          <SelectTrigger className="h-8 text-xs"><SelectValue /></SelectTrigger>
                          <SelectContent>{teams.map(t => (<SelectItem key={t.id} value={t.id}>{t.name}</SelectItem>))}</SelectContent>
                        </Select>
                      </div>
                    </div>
                  </CardContent>
                </Card>

                {/* Match Details */}
                <Card className="border border-gray-100">
                  <CardHeader className="py-2.5 px-4">
                    <CardTitle className="text-sm font-semibold flex items-center gap-1.5">
                      <MapPin className="size-3.5 text-gray-500" />تفاصيل المباراة
                    </CardTitle>
                  </CardHeader>
                  <CardContent className="px-4 pb-4 space-y-3">
                    <div className="grid grid-cols-2 gap-3">
                      <div className="space-y-1.5">
                        <Label className="text-xs font-medium">تاريخ المباراة</Label>
                        <Input type="datetime-local" value={editForm.matchDate} onChange={e => setEditForm(p => ({ ...p, matchDate: e.target.value }))} className="h-8 text-xs" />
                      </div>
                      <div className="space-y-1.5">
                        <Label className="text-xs font-medium">الجولة</Label>
                        <Input value={editForm.round} onChange={e => setEditForm(p => ({ ...p, round: e.target.value }))} className="h-8 text-xs" placeholder="مثال: 15" />
                      </div>
                      <div className="space-y-1.5">
                        <Label className="text-xs font-medium">الملعب</Label>
                        <Input value={editForm.stadium} onChange={e => setEditForm(p => ({ ...p, stadium: e.target.value }))} className="h-8 text-xs" placeholder="اسم الملعب" />
                      </div>
                      <div className="space-y-1.5">
                        <Label className="text-xs font-medium">الحكم</Label>
                        <Input value={editForm.referee} onChange={e => setEditForm(p => ({ ...p, referee: e.target.value }))} className="h-8 text-xs" placeholder="اسم الحكم" />
                      </div>
                    </div>
                    <div className="space-y-1.5">
                      <Label className="text-xs font-medium">قنوات البث</Label>
                      <Input value={editForm.broadcastChannels} onChange={e => setEditForm(p => ({ ...p, broadcastChannels: e.target.value }))} className="h-8 text-xs" placeholder="beIN Sports, SSC" />
                    </div>
                    <div className="space-y-1.5">
                      <Label className="text-xs font-medium">تقرير المباراة</Label>
                      <Textarea value={editForm.matchReport} onChange={e => setEditForm(p => ({ ...p, matchReport: e.target.value }))} className="min-h-[80px] text-xs" placeholder="اكتب تقريراً عن المباراة..." />
                    </div>
                  </CardContent>
                </Card>

                <div className="flex justify-end gap-2 sticky bottom-0 bg-white py-2">
                  <Button variant="outline" onClick={() => setDetailDialogOpen(false)}>إلغاء</Button>
                  <Button className="bg-emerald-500 hover:bg-emerald-600 gap-1.5" onClick={handleUpdateMatch} disabled={submitting}>
                    {submitting && <Loader2 className="size-4 animate-spin" />}<Save className="size-3.5" />حفظ التعديلات
                  </Button>
                </div>
              </div>
            </TabsContent>

            {/* TAB: Lineups */}
            <TabsContent value="lineup" className="flex-1 overflow-y-auto mt-3 pr-1">
              <div className="space-y-4">
                {/* Add Player */}
                <Card className="border border-dashed border-emerald-300 bg-emerald-50/50">
                  <CardHeader className="py-2.5 px-4">
                    <CardTitle className="text-sm font-semibold flex items-center gap-1.5">
                      <Plus className="size-3.5 text-emerald-500" />إضافة لاعب للتشكيل
                    </CardTitle>
                  </CardHeader>
                  <CardContent className="px-4 pb-4">
                    <div className="grid grid-cols-6 gap-3 items-end">
                      <div className="space-y-1.5">
                        <Label className="text-xs font-medium">الفريق</Label>
                        <Select value={lineupForm.teamId} onValueChange={v => setLineupForm(p => ({ ...p, teamId: v, playerId: '' }))}>
                          <SelectTrigger className="h-8 text-xs"><SelectValue /></SelectTrigger>
                          <SelectContent>
                            {selectedMatch && (
                              <>
                                <SelectItem value={selectedMatch.homeTeamId}>{selectedMatch.homeTeam.name}</SelectItem>
                                <SelectItem value={selectedMatch.awayTeamId}>{selectedMatch.awayTeam.name}</SelectItem>
                              </>
                            )}
                          </SelectContent>
                        </Select>
                      </div>
                      <div className="col-span-2 space-y-1.5">
                        <Label className="text-xs font-medium">اللاعب</Label>
                        <Select value={lineupForm.playerId} onValueChange={v => setLineupForm(p => ({ ...p, playerId: v }))}>
                          <SelectTrigger className="h-8 text-xs"><SelectValue placeholder="اختر اللاعب" /></SelectTrigger>
                          <SelectContent>
                            {availablePlayers.map(p => (
                              <SelectItem key={p.id} value={p.id}>
                                {p.name} {p.number ? `#${p.number}` : ''} {p.position ? `(${p.position})` : ''}
                              </SelectItem>
                            ))}
                          </SelectContent>
                        </Select>
                      </div>
                      <div className="space-y-1.5">
                        <Label className="text-xs font-medium">المركز</Label>
                        <Select value={lineupForm.position || undefined} onValueChange={v => setLineupForm(p => ({ ...p, position: v === 'none' ? '' : v }))}>
                          <SelectTrigger className="h-8 text-xs"><SelectValue placeholder="المركز" /></SelectTrigger>
                          <SelectContent>
                            <SelectItem value="none">بدون</SelectItem>
                            {POSITIONS.map(pos => (<SelectItem key={pos.value} value={pos.value}>{pos.label}</SelectItem>))}
                          </SelectContent>
                        </Select>
                      </div>
                      <div className="space-y-1.5">
                        <Label className="text-xs font-medium">رقم القميص</Label>
                        <Input type="number" value={lineupForm.shirtNumber} onChange={e => setLineupForm(p => ({ ...p, shirtNumber: e.target.value }))} className="h-8 text-xs text-center" placeholder="#" />
                      </div>
                      <div className="space-y-2">
                        <div className="flex items-center gap-2">
                          <Switch checked={lineupForm.isStarter} onCheckedChange={v => setLineupForm(p => ({ ...p, isStarter: v }))} />
                          <Label className="text-xs">{lineupForm.isStarter ? 'أساسي' : 'احتياطي'}</Label>
                        </div>
                        <Button size="sm" className="w-full bg-emerald-500 hover:bg-emerald-600 h-7 text-[11px] gap-1" onClick={handleAddLineup} disabled={submitting || !lineupForm.playerId}>
                          <Plus className="size-3" />إضافة
                        </Button>
                      </div>
                    </div>
                    {/* Bulk add buttons */}
                    {selectedMatch && (
                      <div className="flex gap-2 mt-3 pt-3 border-t border-emerald-200">
                        <Button variant="outline" size="sm" className="text-[10px] h-7 gap-1 border-emerald-300 text-emerald-600" onClick={() => handleBulkAddLineup(selectedMatch.homeTeamId, true)}>
                          <Users className="size-3" />إضافة كل لاعبي {selectedMatch.homeTeam.name} كأساسيين
                        </Button>
                        <Button variant="outline" size="sm" className="text-[10px] h-7 gap-1 border-blue-300 text-blue-600" onClick={() => handleBulkAddLineup(selectedMatch.awayTeamId, true)}>
                          <Users className="size-3" />إضافة كل لاعبي {selectedMatch.awayTeam.name} كأساسيين
                        </Button>
                      </div>
                    )}
                  </CardContent>
                </Card>

                {/* Two-Team Lineup View */}
                {selectedMatch && (
                  <div className="grid grid-cols-2 gap-4">
                    {/* Home Team */}
                    <Card className="border border-gray-100">
                      <CardHeader className="py-2.5 px-4 bg-emerald-50/50">
                        <CardTitle className="text-sm font-semibold text-emerald-700 flex items-center gap-1.5">
                          <div className="size-5 rounded-full flex items-center justify-center text-white text-[8px] font-bold" style={{ backgroundColor: selectedMatch.homeTeam.color || '#10b981' }}>
                            {(selectedMatch.homeTeam.shortName || selectedMatch.homeTeam.name).charAt(0)}
                          </div>
                          {selectedMatch.homeTeam.name}
                        </CardTitle>
                      </CardHeader>
                      <CardContent className="px-3 pb-3">
                        {/* Starters */}
                        <div className="mb-3">
                          <p className="text-[10px] font-bold text-gray-400 mb-1.5 flex items-center gap-1">
                            <CheckCircle2 className="size-3" />التشكيل الأساسي ({homeStarters.length})
                          </p>
                          {homeStarters.length === 0 ? (
                            <p className="text-[10px] text-gray-300 py-2 text-center">لا يوجد لاعبون أساسيون</p>
                          ) : (
                            <div className="space-y-1">
                              {homeStarters.map(l => (
                                <div key={l.id} className="flex items-center justify-between bg-white rounded-lg px-2 py-1.5 border border-gray-50 hover:border-gray-200 transition text-xs">
                                  <div className="flex items-center gap-2">
                                    <span className="size-5 rounded-full bg-emerald-100 text-emerald-700 flex items-center justify-center text-[9px] font-bold">{l.shirtNumber || l.player.number || '-'}</span>
                                    <span className="font-medium text-gray-700">{l.player.name}</span>
                                    {l.position && <Badge className="text-[8px] h-4 bg-gray-100 text-gray-500 border-0">{l.position}</Badge>}
                                  </div>
                                  <div className="flex items-center gap-1">
                                    <Button variant="ghost" size="icon" className="size-5 text-gray-300 hover:text-yellow-500" onClick={() => handleToggleStarter(l.id, l.isStarter)}>
                                      <ArrowRightLeft className="size-2.5" />
                                    </Button>
                                    <Button variant="ghost" size="icon" className="size-5 text-gray-300 hover:text-red-500" onClick={() => handleDeleteLineup(l.id)}>
                                      <X className="size-2.5" />
                                    </Button>
                                  </div>
                                </div>
                              ))}
                            </div>
                          )}
                        </div>
                        {/* Subs */}
                        <div>
                          <p className="text-[10px] font-bold text-gray-400 mb-1.5 flex items-center gap-1">
                            <ArrowRightLeft className="size-3" />الاحتياط ({homeSubs.length})
                          </p>
                          {homeSubs.length === 0 ? (
                            <p className="text-[10px] text-gray-300 py-2 text-center">لا يوجد احتياط</p>
                          ) : (
                            <div className="space-y-1">
                              {homeSubs.map(l => (
                                <div key={l.id} className="flex items-center justify-between bg-yellow-50/50 rounded-lg px-2 py-1.5 border border-yellow-100 text-xs">
                                  <div className="flex items-center gap-2">
                                    <span className="size-5 rounded-full bg-yellow-100 text-yellow-700 flex items-center justify-center text-[9px] font-bold">{l.shirtNumber || l.player.number || '-'}</span>
                                    <span className="font-medium text-gray-700">{l.player.name}</span>
                                    {l.position && <Badge className="text-[8px] h-4 bg-gray-100 text-gray-500 border-0">{l.position}</Badge>}
                                  </div>
                                  <div className="flex items-center gap-1">
                                    <Button variant="ghost" size="icon" className="size-5 text-gray-300 hover:text-green-500" onClick={() => handleToggleStarter(l.id, l.isStarter)}>
                                      <CheckCircle2 className="size-2.5" />
                                    </Button>
                                    <Button variant="ghost" size="icon" className="size-5 text-gray-300 hover:text-red-500" onClick={() => handleDeleteLineup(l.id)}>
                                      <X className="size-2.5" />
                                    </Button>
                                  </div>
                                </div>
                              ))}
                            </div>
                          )}
                        </div>
                      </CardContent>
                    </Card>

                    {/* Away Team */}
                    <Card className="border border-gray-100">
                      <CardHeader className="py-2.5 px-4 bg-blue-50/50">
                        <CardTitle className="text-sm font-semibold text-blue-700 flex items-center gap-1.5">
                          <div className="size-5 rounded-full flex items-center justify-center text-white text-[8px] font-bold" style={{ backgroundColor: selectedMatch.awayTeam.color || '#6366f1' }}>
                            {(selectedMatch.awayTeam.shortName || selectedMatch.awayTeam.name).charAt(0)}
                          </div>
                          {selectedMatch.awayTeam.name}
                        </CardTitle>
                      </CardHeader>
                      <CardContent className="px-3 pb-3">
                        <div className="mb-3">
                          <p className="text-[10px] font-bold text-gray-400 mb-1.5 flex items-center gap-1">
                            <CheckCircle2 className="size-3" />التشكيل الأساسي ({awayStarters.length})
                          </p>
                          {awayStarters.length === 0 ? (
                            <p className="text-[10px] text-gray-300 py-2 text-center">لا يوجد لاعبون أساسيون</p>
                          ) : (
                            <div className="space-y-1">
                              {awayStarters.map(l => (
                                <div key={l.id} className="flex items-center justify-between bg-white rounded-lg px-2 py-1.5 border border-gray-50 hover:border-gray-200 transition text-xs">
                                  <div className="flex items-center gap-2">
                                    <span className="size-5 rounded-full bg-blue-100 text-blue-700 flex items-center justify-center text-[9px] font-bold">{l.shirtNumber || l.player.number || '-'}</span>
                                    <span className="font-medium text-gray-700">{l.player.name}</span>
                                    {l.position && <Badge className="text-[8px] h-4 bg-gray-100 text-gray-500 border-0">{l.position}</Badge>}
                                  </div>
                                  <div className="flex items-center gap-1">
                                    <Button variant="ghost" size="icon" className="size-5 text-gray-300 hover:text-yellow-500" onClick={() => handleToggleStarter(l.id, l.isStarter)}>
                                      <ArrowRightLeft className="size-2.5" />
                                    </Button>
                                    <Button variant="ghost" size="icon" className="size-5 text-gray-300 hover:text-red-500" onClick={() => handleDeleteLineup(l.id)}>
                                      <X className="size-2.5" />
                                    </Button>
                                  </div>
                                </div>
                              ))}
                            </div>
                          )}
                        </div>
                        <div>
                          <p className="text-[10px] font-bold text-gray-400 mb-1.5 flex items-center gap-1">
                            <ArrowRightLeft className="size-3" />الاحتياط ({awaySubs.length})
                          </p>
                          {awaySubs.length === 0 ? (
                            <p className="text-[10px] text-gray-300 py-2 text-center">لا يوجد احتياط</p>
                          ) : (
                            <div className="space-y-1">
                              {awaySubs.map(l => (
                                <div key={l.id} className="flex items-center justify-between bg-yellow-50/50 rounded-lg px-2 py-1.5 border border-yellow-100 text-xs">
                                  <div className="flex items-center gap-2">
                                    <span className="size-5 rounded-full bg-yellow-100 text-yellow-700 flex items-center justify-center text-[9px] font-bold">{l.shirtNumber || l.player.number || '-'}</span>
                                    <span className="font-medium text-gray-700">{l.player.name}</span>
                                    {l.position && <Badge className="text-[8px] h-4 bg-gray-100 text-gray-500 border-0">{l.position}</Badge>}
                                  </div>
                                  <div className="flex items-center gap-1">
                                    <Button variant="ghost" size="icon" className="size-5 text-gray-300 hover:text-green-500" onClick={() => handleToggleStarter(l.id, l.isStarter)}>
                                      <CheckCircle2 className="size-2.5" />
                                    </Button>
                                    <Button variant="ghost" size="icon" className="size-5 text-gray-300 hover:text-red-500" onClick={() => handleDeleteLineup(l.id)}>
                                      <X className="size-2.5" />
                                    </Button>
                                  </div>
                                </div>
                              ))}
                            </div>
                          )}
                        </div>
                      </CardContent>
                    </Card>
                  </div>
                )}
              </div>
            </TabsContent>

            {/* TAB: Events */}
            <TabsContent value="events" className="flex-1 overflow-y-auto mt-3 pr-1">
              <div className="space-y-4">
                {/* Add Event */}
                <Card className="border border-dashed border-red-300 bg-red-50/50">
                  <CardHeader className="py-2.5 px-4">
                    <CardTitle className="text-sm font-semibold flex items-center gap-1.5">
                      <Zap className="size-3.5 text-red-500" />إضافة حدث جديد
                    </CardTitle>
                  </CardHeader>
                  <CardContent className="px-4 pb-4">
                    <div className="grid grid-cols-6 gap-3 items-end">
                      <div className="space-y-1.5">
                        <Label className="text-xs font-medium">نوع الحدث</Label>
                        <Select value={eventForm.type} onValueChange={v => setEventForm(p => ({ ...p, type: v }))}>
                          <SelectTrigger className="h-8 text-xs"><SelectValue /></SelectTrigger>
                          <SelectContent>
                            {EVENT_TYPES.map(et => (
                              <SelectItem key={et.value} value={et.value}>{et.icon} {et.label}</SelectItem>
                            ))}
                          </SelectContent>
                        </Select>
                      </div>
                      <div className="space-y-1.5">
                        <Label className="text-xs font-medium">الدقيقة *</Label>
                        <Input type="number" value={eventForm.minute} onChange={e => setEventForm(p => ({ ...p, minute: e.target.value }))} className="h-8 text-xs text-center" placeholder="45" min="0" max="120" />
                      </div>
                      <div className="space-y-1.5">
                        <Label className="text-xs font-medium">الفريق</Label>
                        <Select value={eventForm.team} onValueChange={v => setEventForm(p => ({ ...p, team: v, playerId: '', assistPlayerId: '' }))}>
                          <SelectTrigger className="h-8 text-xs"><SelectValue /></SelectTrigger>
                          <SelectContent>
                            {selectedMatch && (
                              <>
                                <SelectItem value="home">{selectedMatch.homeTeam.name}</SelectItem>
                                <SelectItem value="away">{selectedMatch.awayTeam.name}</SelectItem>
                              </>
                            )}
                          </SelectContent>
                        </Select>
                      </div>
                      <div className="space-y-1.5">
                        <Label className="text-xs font-medium">اللاعب</Label>
                        <Select value={eventForm.playerId} onValueChange={v => setEventForm(p => ({ ...p, playerId: v }))}>
                          <SelectTrigger className="h-8 text-xs"><SelectValue placeholder="اختر اللاعب" /></SelectTrigger>
                          <SelectContent>
                            {(eventForm.team === 'home' ? homePlayers : awayPlayers).map(p => (
                              <SelectItem key={p.id} value={p.id}>{p.name} {p.number ? `#${p.number}` : ''}</SelectItem>
                            ))}
                          </SelectContent>
                        </Select>
                      </div>
                      <div className="space-y-1.5">
                        <Label className="text-xs font-medium">صانع الهدف</Label>
                        <Select value={eventForm.assistPlayerId} onValueChange={v => setEventForm(p => ({ ...p, assistPlayerId: v }))}>
                          <SelectTrigger className="h-8 text-xs"><SelectValue placeholder="اختر" /></SelectTrigger>
                          <SelectContent>
                            {(eventForm.team === 'home' ? homePlayers : awayPlayers).filter(p => p.id !== eventForm.playerId).map(p => (
                              <SelectItem key={p.id} value={p.id}>{p.name}</SelectItem>
                            ))}
                          </SelectContent>
                        </Select>
                      </div>
                      <Button size="sm" className="bg-red-500 hover:bg-red-600 h-8 gap-1 text-xs" onClick={handleAddEvent} disabled={submitting || !eventForm.minute}>
                        {submitting ? <Loader2 className="size-3.5 animate-spin" /> : <Plus className="size-3.5" />}إضافة
                      </Button>
                    </div>
                    {eventForm.type && (
                      <div className="mt-2">
                        <Input value={eventForm.detail} onChange={e => setEventForm(p => ({ ...p, detail: e.target.value }))} className="h-8 text-xs" placeholder="تفاصيل إضافية (مثل: ركلة جزاء مثيرة للجدل...)" />
                      </div>
                    )}
                    {/* Quick event buttons for live matches */}
                    {selectedMatch?.status === 'live' && (
                      <div className="mt-3 pt-3 border-t border-red-200 flex flex-wrap gap-2">
                        <span className="text-[10px] text-red-400 font-bold self-center">إضافة سريعة:</span>
                        <Button variant="outline" size="sm" className="text-[10px] h-6 gap-1 border-green-300 text-green-600" onClick={() => setEventForm(p => ({ ...p, type: 'goal' }))}>
                          ⚽ هدف
                        </Button>
                        <Button variant="outline" size="sm" className="text-[10px] h-6 gap-1 border-yellow-300 text-yellow-600" onClick={() => setEventForm(p => ({ ...p, type: 'yellow_card' }))}>
                          🟨 بطاقة صفراء
                        </Button>
                        <Button variant="outline" size="sm" className="text-[10px] h-6 gap-1 border-red-300 text-red-600" onClick={() => setEventForm(p => ({ ...p, type: 'red_card' }))}>
                          🟥 بطاقة حمراء
                        </Button>
                        <Button variant="outline" size="sm" className="text-[10px] h-6 gap-1 border-blue-300 text-blue-600" onClick={() => setEventForm(p => ({ ...p, type: 'substitution' }))}>
                          🔄 تبديل
                        </Button>
                        <Button variant="outline" size="sm" className="text-[10px] h-6 gap-1 border-gray-300 text-gray-600" onClick={() => { setEventForm(p => ({ ...p, type: 'halftime', minute: '45', team: 'home' })); }}>
                          ⏸️ نهاية الشوط
                        </Button>
                        <Button variant="outline" size="sm" className="text-[10px] h-6 gap-1 border-gray-300 text-gray-600" onClick={() => { setEventForm(p => ({ ...p, type: 'fulltime', minute: '90', team: 'home' })); }}>
                          🏁 نهاية المباراة
                        </Button>
                      </div>
                    )}
                  </CardContent>
                </Card>

                {/* Events Timeline */}
                <Card className="border border-gray-100">
                  <CardHeader className="py-2.5 px-4">
                    <CardTitle className="text-sm font-semibold flex items-center gap-1.5">
                      <Flag className="size-3.5 text-gray-500" />أحداث المباراة ({events.length})
                    </CardTitle>
                  </CardHeader>
                  <CardContent className="px-4 pb-4">
                    {events.length === 0 ? (
                      <div className="text-center py-8">
                        <Zap className="size-8 text-gray-300 mx-auto mb-2" />
                        <p className="text-sm text-gray-400">لا توجد أحداث بعد</p>
                        <p className="text-[10px] text-gray-300">أضف أحداث المباراة مثل الأهداف والبطاقات والتبديلات</p>
                      </div>
                    ) : (
                      <div className="space-y-2">
                        {events.map(event => {
                          const isHome = event.team === 'home'
                          return (
                            <div key={event.id} className={`flex items-center gap-3 rounded-lg px-3 py-2 border transition hover:shadow-sm ${isHome ? 'bg-emerald-50/50 border-emerald-100' : 'bg-blue-50/50 border-blue-100'}`}>
                              <span className="text-lg shrink-0">{getEventIcon(event.type)}</span>
                              <span className="text-xs font-bold text-gray-600 shrink-0 w-8 text-center">{event.minute}&apos;</span>
                              <div className="flex-1 min-w-0">
                                <div className="flex items-center gap-1.5">
                                  <span className="text-xs font-semibold text-gray-800 truncate">
                                    {event.player?.name || EVENT_TYPES.find(et => et.value === event.type)?.label || event.type}
                                  </span>
                                  {event.assistPlayer && (
                                    <span className="text-[10px] text-gray-400 truncate">
                                      (صانع: {event.assistPlayer.name})
                                    </span>
                                  )}
                                </div>
                                {event.detail && <p className="text-[10px] text-gray-400 truncate">{event.detail}</p>}
                              </div>
                              <Badge className={`text-[8px] border-0 shrink-0 ${isHome ? 'bg-emerald-100 text-emerald-700' : 'bg-blue-100 text-blue-700'}`}>
                                {isHome ? selectedMatch?.homeTeam.name : selectedMatch?.awayTeam.name}
                              </Badge>
                              <Button variant="ghost" size="icon" className="size-6 text-gray-300 hover:text-red-500 shrink-0" onClick={() => handleDeleteEvent(event.id)}>
                                <Trash2 className="size-3" />
                              </Button>
                            </div>
                          )
                        })}
                      </div>
                    )}
                  </CardContent>
                </Card>
              </div>
            </TabsContent>

            {/* TAB: Statistics */}
            <TabsContent value="stats" className="flex-1 overflow-y-auto mt-3 pr-1">
              <div className="space-y-4">
                <Card className="border border-gray-100">
                  <CardHeader className="py-2.5 px-4">
                    <CardTitle className="text-sm font-semibold flex items-center gap-1.5">
                      <BarChart3 className="size-3.5 text-blue-500" />إحصائيات المباراة
                    </CardTitle>
                  </CardHeader>
                  <CardContent className="px-4 pb-4 space-y-3">
                    {STAT_FIELDS.map(field => {
                      const home = statsForm[field.key]?.home || 0
                      const away = statsForm[field.key]?.away || 0
                      const total = home + away || 1
                      const homePercent = (home / total) * 100
                      const awayPercent = (away / total) * 100
                      return (
                        <div key={field.key} className="space-y-1.5">
                          <div className="flex items-center justify-between">
                            <Input
                              type="number"
                              value={home}
                              onChange={e => setStatsForm(p => ({ ...p, [field.key]: { home: parseInt(e.target.value) || 0, away: p[field.key]?.away || 0 } }))}
                              className="w-16 h-7 text-center text-xs font-bold border-gray-200"
                            />
                            <Label className="text-xs font-semibold text-gray-500">{field.label}</Label>
                            <Input
                              type="number"
                              value={away}
                              onChange={e => setStatsForm(p => ({ ...p, [field.key]: { home: p[field.key]?.home || 0, away: parseInt(e.target.value) || 0 } }))}
                              className="w-16 h-7 text-center text-xs font-bold border-gray-200"
                            />
                          </div>
                          <div className="flex h-2 rounded-full overflow-hidden bg-gray-100">
                            <div className="bg-emerald-500 transition-all duration-300" style={{ width: `${homePercent}%` }} />
                            <div className="bg-blue-500 transition-all duration-300" style={{ width: `${awayPercent}%` }} />
                          </div>
                        </div>
                      )
                    })}
                    <div className="flex justify-end pt-2">
                      <Button className="bg-emerald-500 hover:bg-emerald-600 gap-1.5 h-8" onClick={handleSaveStats} disabled={submitting}>
                        {submitting && <Loader2 className="size-3.5 animate-spin" />}<Save className="size-3.5" />حفظ الإحصائيات
                      </Button>
                    </div>
                  </CardContent>
                </Card>
              </div>
            </TabsContent>

            {/* TAB: Broadcast & Stream */}
            <TabsContent value="broadcast" className="flex-1 overflow-y-auto mt-3 pr-1">
              <div className="space-y-4">
                <Card className="border border-gray-100">
                  <CardHeader className="py-2.5 px-4">
                    <CardTitle className="text-sm font-semibold flex items-center gap-1.5">
                      <Tv className="size-3.5 text-purple-500" />قنوات البث
                    </CardTitle>
                  </CardHeader>
                  <CardContent className="px-4 pb-4 space-y-3">
                    <div className="space-y-1.5">
                      <Label className="text-xs font-medium">قنوات البث</Label>
                      <Input value={editForm.broadcastChannels} onChange={e => setEditForm(p => ({ ...p, broadcastChannels: e.target.value }))} className="h-8 text-xs" placeholder="beIN Sports 1, SSC Sport" />
                      <p className="text-[10px] text-gray-400">افصل بين القنوات بفاصلة</p>
                    </div>
                  </CardContent>
                </Card>

                <Card className="border border-gray-100">
                  <CardHeader className="py-2.5 px-4">
                    <CardTitle className="text-sm font-semibold flex items-center gap-1.5">
                      <Video className="size-3.5 text-red-500" />رابط البث المباشر
                    </CardTitle>
                  </CardHeader>
                  <CardContent className="px-4 pb-4 space-y-3">
                    <div className="space-y-1.5">
                      <Label className="text-xs font-medium">رابط البث</Label>
                      <Input value={editForm.streamUrl} onChange={e => setEditForm(p => ({ ...p, streamUrl: e.target.value }))} className="h-8 text-xs" placeholder="https://..." dir="ltr" />
                    </div>
                  </CardContent>
                </Card>

                <Card className="border border-gray-100">
                  <CardHeader className="py-2.5 px-4">
                    <CardTitle className="text-sm font-semibold flex items-center gap-1.5">
                      <Eye className="size-3.5 text-indigo-500" />تقرير المباراة
                    </CardTitle>
                  </CardHeader>
                  <CardContent className="px-4 pb-4 space-y-3">
                    <div className="space-y-1.5">
                      <Label className="text-xs font-medium">محتوى التقرير</Label>
                      <Textarea value={editForm.matchReport} onChange={e => setEditForm(p => ({ ...p, matchReport: e.target.value }))} className="min-h-[150px] text-xs" placeholder="اكتب تقريراً مفصلاً عن المباراة..." />
                    </div>
                  </CardContent>
                </Card>

                <div className="flex justify-end gap-2">
                  <Button className="bg-emerald-500 hover:bg-emerald-600 gap-1.5 h-8" onClick={handleUpdateMatch} disabled={submitting}>
                    {submitting && <Loader2 className="size-3.5 animate-spin" />}<Save className="size-3.5" />حفظ
                  </Button>
                </div>
              </div>
            </TabsContent>
          </Tabs>
        </DialogContent>
      </Dialog>

      {/* ============ DELETE CONFIRMATION ============ */}
      <Dialog open={deleteDialogOpen} onOpenChange={setDeleteDialogOpen}>
        <DialogContent className="max-w-sm" dir="rtl">
          <DialogHeader>
            <DialogTitle className="flex items-center gap-2 text-red-600">
              <AlertTriangle className="size-5" />تأكيد الحذف
            </DialogTitle>
            <DialogDescription>
              هل أنت متأكد من حذف مباراة {matchToDelete?.homeTeam.name} ضد {matchToDelete?.awayTeam.name}؟
              لا يمكن التراجع عن هذا الإجراء.
            </DialogDescription>
          </DialogHeader>
          <DialogFooter className="gap-2">
            <Button variant="outline" onClick={() => setDeleteDialogOpen(false)}>إلغاء</Button>
            <Button variant="destructive" onClick={handleDelete} disabled={submitting} className="gap-1.5">
              {submitting && <Loader2 className="size-4 animate-spin" />}حذف نهائي
            </Button>
          </DialogFooter>
        </DialogContent>
      </Dialog>
    </div>
  )
}
