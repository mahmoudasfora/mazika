'use client'

import { useEffect, useState, useCallback } from 'react'
import { Plus, Pencil, Trash2, Loader2 } from 'lucide-react'
import { Card, CardContent } from '@/components/ui/card'
import { Button } from '@/components/ui/button'
import { Input } from '@/components/ui/input'
import { Skeleton } from '@/components/ui/skeleton'
import { Label } from '@/components/ui/label'
import {
  Table, TableBody, TableCell, TableHead, TableHeader, TableRow
} from '@/components/ui/table'
import {
  Dialog, DialogContent, DialogDescription, DialogFooter,
  DialogHeader, DialogTitle, DialogTrigger
} from '@/components/ui/dialog'

interface Team {
  id: string
  name: string
  nameEn: string | null
  shortName: string | null
  country: string | null
  city: string | null
  stadium: string | null
  founded: number | null
  color: string | null
  playerCount: number
}

export default function AdminTeamsPage() {
  const [teams, setTeams] = useState<Team[]>([])
  const [loading, setLoading] = useState(true)
  const [dialogOpen, setDialogOpen] = useState(false)
  const [submitting, setSubmitting] = useState(false)
  const [editId, setEditId] = useState<string | null>(null)

  const [formName, setFormName] = useState('')
  const [formNameEn, setFormNameEn] = useState('')
  const [formShortName, setFormShortName] = useState('')
  const [formCountry, setFormCountry] = useState('')
  const [formCity, setFormCity] = useState('')
  const [formStadium, setFormStadium] = useState('')
  const [formFounded, setFormFounded] = useState('')
  const [formColor, setFormColor] = useState('#10b981')

  const fetchTeams = useCallback(async () => {
    try {
      setLoading(true)
      const res = await fetch('/api/teams')
      const data = await res.json()
      setTeams(data.teams || [])
    } catch {
      // silently fail
    } finally {
      setLoading(false)
    }
  }, [])

  useEffect(() => { fetchTeams() }, [fetchTeams])

  const resetForm = () => {
    setFormName(''); setFormNameEn(''); setFormShortName('')
    setFormCountry(''); setFormCity(''); setFormStadium('')
    setFormFounded(''); setFormColor('#10b981'); setEditId(null)
  }

  const openCreate = () => { resetForm(); setDialogOpen(true) }

  const openEdit = (team: Team) => {
    setEditId(team.id)
    setFormName(team.name)
    setFormNameEn(team.nameEn || '')
    setFormShortName(team.shortName || '')
    setFormCountry(team.country || '')
    setFormCity(team.city || '')
    setFormStadium(team.stadium || '')
    setFormFounded(team.founded?.toString() || '')
    setFormColor(team.color || '#10b981')
    setDialogOpen(true)
  }

  const handleSubmit = async () => {
    if (!formName) return
    setSubmitting(true)
    try {
      if (editId) {
        await fetch('/api/admin/teams', {
          method: 'PUT',
          headers: { 'Content-Type': 'application/json' },
          body: JSON.stringify({
            id: editId, name: formName, nameEn: formNameEn,
            shortName: formShortName, country: formCountry,
            city: formCity, stadium: formStadium,
            founded: formFounded ? parseInt(formFounded) : undefined,
            color: formColor,
          }),
        })
      } else {
        await fetch('/api/admin/teams', {
          method: 'POST',
          headers: { 'Content-Type': 'application/json' },
          body: JSON.stringify({
            name: formName, nameEn: formNameEn, shortName: formShortName,
            country: formCountry, city: formCity, stadium: formStadium,
            founded: formFounded ? parseInt(formFounded) : undefined,
            color: formColor,
          }),
        })
      }
      setDialogOpen(false)
      resetForm()
      fetchTeams()
    } catch {
      // silently fail
    } finally {
      setSubmitting(false)
    }
  }

  const handleDelete = async (id: string) => {
    if (!confirm('هل أنت متأكد من حذف هذا الفريق؟')) return
    try {
      await fetch('/api/admin/teams', {
        method: 'DELETE',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ id }),
      })
      fetchTeams()
    } catch {
      // silently fail
    }
  }

  if (loading) {
    return (
      <div className="space-y-4">
        {Array.from({ length: 5 }).map((_, i) => (
          <Skeleton key={i} className="h-14 w-full" />
        ))}
      </div>
    )
  }

  return (
    <div className="space-y-4">
      <div className="flex items-center justify-between">
        <h2 className="text-xl font-bold">إدارة الفرق</h2>
        <Dialog open={dialogOpen} onOpenChange={setDialogOpen}>
          <DialogTrigger asChild>
            <Button className="bg-emerald-600 hover:bg-emerald-700" onClick={openCreate}>
              <Plus className="size-4 ml-1" />
              فريق جديد
            </Button>
          </DialogTrigger>
          <DialogContent className="max-w-lg max-h-[90vh] overflow-y-auto" dir="rtl">
            <DialogHeader>
              <DialogTitle>{editId ? 'تعديل الفريق' : 'فريق جديد'}</DialogTitle>
              <DialogDescription>{editId ? 'قم بتعديل بيانات الفريق' : 'أدخل بيانات الفريق الجديد'}</DialogDescription>
            </DialogHeader>
            <div className="space-y-4">
              <div className="grid grid-cols-2 gap-4">
                <div className="space-y-2">
                  <Label>الاسم (عربي) *</Label>
                  <Input value={formName} onChange={(e) => setFormName(e.target.value)} placeholder="الأهلي" />
                </div>
                <div className="space-y-2">
                  <Label>الاسم (إنجليزي)</Label>
                  <Input value={formNameEn} onChange={(e) => setFormNameEn(e.target.value)} placeholder="Al Ahly" />
                </div>
              </div>
              <div className="grid grid-cols-2 gap-4">
                <div className="space-y-2">
                  <Label>الاسم المختصر</Label>
                  <Input value={formShortName} onChange={(e) => setFormShortName(e.target.value)} placeholder="AHL" />
                </div>
                <div className="space-y-2">
                  <Label>الدولة</Label>
                  <Input value={formCountry} onChange={(e) => setFormCountry(e.target.value)} placeholder="مصر" />
                </div>
              </div>
              <div className="grid grid-cols-2 gap-4">
                <div className="space-y-2">
                  <Label>المدينة</Label>
                  <Input value={formCity} onChange={(e) => setFormCity(e.target.value)} placeholder="القاهرة" />
                </div>
                <div className="space-y-2">
                  <Label>الملعب</Label>
                  <Input value={formStadium} onChange={(e) => setFormStadium(e.target.value)} placeholder="ستاد القاهرة" />
                </div>
              </div>
              <div className="grid grid-cols-2 gap-4">
                <div className="space-y-2">
                  <Label>سنة التأسيس</Label>
                  <Input type="number" value={formFounded} onChange={(e) => setFormFounded(e.target.value)} placeholder="1907" />
                </div>
                <div className="space-y-2">
                  <Label>اللون الأساسي</Label>
                  <div className="flex items-center gap-2">
                    <input type="color" value={formColor} onChange={(e) => setFormColor(e.target.value)} className="size-9 rounded cursor-pointer" />
                    <Input value={formColor} onChange={(e) => setFormColor(e.target.value)} className="flex-1" />
                  </div>
                </div>
              </div>
            </div>
            <DialogFooter>
              <Button variant="outline" onClick={() => setDialogOpen(false)}>إلغاء</Button>
              <Button className="bg-emerald-600 hover:bg-emerald-700" onClick={handleSubmit} disabled={submitting || !formName}>
                {submitting && <Loader2 className="size-4 ml-1 animate-spin" />}
                {editId ? 'تحديث' : 'إنشاء'}
              </Button>
            </DialogFooter>
          </DialogContent>
        </Dialog>
      </div>

      <Card>
        <CardContent className="p-0">
          <Table>
            <TableHeader>
              <TableRow>
                <TableHead className="text-right">الفريق</TableHead>
                <TableHead className="text-right">الدولة</TableHead>
                <TableHead className="text-right">المدينة</TableHead>
                <TableHead className="text-right">الملعب</TableHead>
                <TableHead className="text-right">التأسيس</TableHead>
                <TableHead className="text-right">عدد اللاعبين</TableHead>
                <TableHead className="text-right">إجراءات</TableHead>
              </TableRow>
            </TableHeader>
            <TableBody>
              {teams.length === 0 ? (
                <TableRow>
                  <TableCell colSpan={7} className="text-center py-8 text-muted-foreground">لا توجد فرق</TableCell>
                </TableRow>
              ) : (
                teams.map((team) => (
                  <TableRow key={team.id}>
                    <TableCell>
                      <div className="flex items-center gap-2">
                        <div
                          className="size-8 rounded-full flex items-center justify-center text-white text-xs font-bold shrink-0"
                          style={{ backgroundColor: team.color || '#10b981' }}
                        >
                          {(team.shortName || team.name).charAt(0)}
                        </div>
                        <div>
                          <p className="font-medium">{team.name}</p>
                          {team.nameEn && <p className="text-xs text-muted-foreground">{team.nameEn}</p>}
                        </div>
                      </div>
                    </TableCell>
                    <TableCell className="text-sm">{team.country || '-'}</TableCell>
                    <TableCell className="text-sm">{team.city || '-'}</TableCell>
                    <TableCell className="text-sm">{team.stadium || '-'}</TableCell>
                    <TableCell className="text-sm">{team.founded || '-'}</TableCell>
                    <TableCell className="text-sm">{team.playerCount}</TableCell>
                    <TableCell>
                      <div className="flex items-center gap-1">
                        <Button variant="ghost" size="icon" className="size-8" onClick={() => openEdit(team)}>
                          <Pencil className="size-4" />
                        </Button>
                        <Button variant="ghost" size="icon" className="size-8 text-red-500 hover:text-red-600" onClick={() => handleDelete(team.id)}>
                          <Trash2 className="size-4" />
                        </Button>
                      </div>
                    </TableCell>
                  </TableRow>
                ))
              )}
            </TableBody>
          </Table>
        </CardContent>
      </Card>
    </div>
  )
}
