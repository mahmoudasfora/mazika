'use client'

import { useEffect, useState } from 'react'
import Link from 'next/link'
import {
  FileText, Trophy, Users, Plus, BarChart3, Eye,
  TrendingUp, TrendingDown, Radio, Clock, ArrowUpRight,
  Newspaper, Calendar, Play
} from 'lucide-react'
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card'
import { Badge } from '@/components/ui/badge'
import { Button } from '@/components/ui/button'
import { Skeleton } from '@/components/ui/skeleton'
import { getCategoryLabel, getCategoryColor, getStatusLabel, getStatusColor, formatFullDate, timeAgo } from '@/lib/sports-utils'
import { BarChart, Bar, LineChart, Line, XAxis, YAxis, CartesianGrid, Tooltip, ResponsiveContainer, PieChart, Pie, Cell } from 'recharts'

interface Stats {
  totalArticles: number
  totalMatches: number
  totalUsers: number
  liveMatches: number
  todaysMatches: number
  breakingNews: number
}

interface ArticleAuthor {
  id: string
  name: string
  avatar: string | null
  role: string
}

interface Article {
  id: string
  title: string
  slug: string
  summary: string | null
  content: string
  image: string | null
  category: string
  isBreaking: boolean
  isFeatured: boolean
  status: string
  authorId: string
  publishedAt: string | null
  views: number
  createdAt: string
  updatedAt: string
  author: ArticleAuthor
}

interface MatchTeam {
  id: string
  name: string
  nameEn: string | null
  shortName: string | null
  logo: string | null
  color?: string | null
}

interface MatchLeague {
  id: string
  name: string
  nameEn: string | null
  logo: string | null
}

interface Match {
  id: string
  homeTeamId: string
  awayTeamId: string
  leagueId: string
  homeScore: number | null
  awayScore: number | null
  status: string
  matchDate: string
  stadium: string | null
  referee: string | null
  broadcastChannels: string | null
  createdAt: string
  homeTeam: MatchTeam
  awayTeam: MatchTeam
  league: MatchLeague
}

const PIE_DATA = [
  { name: 'كرة قدم', value: 45, color: '#10b981' },
  { name: 'كرة سلة', value: 20, color: '#6366f1' },
  { name: 'تنس', value: 15, color: '#f59e0b' },
  { name: 'أخرى', value: 20, color: '#3b82f6' },
]

const WEEKLY_DATA = [
  { day: 'السبت', views: 1200, articles: 8 },
  { day: 'الأحد', views: 1800, articles: 12 },
  { day: 'الاثنين', views: 1500, articles: 10 },
  { day: 'الثلاثاء', views: 2200, articles: 15 },
  { day: 'الأربعاء', views: 1900, articles: 11 },
  { day: 'الخميس', views: 2500, articles: 18 },
  { day: 'الجمعة', views: 2100, articles: 14 },
]

export default function AdminDashboardPage() {
  const [stats, setStats] = useState<Stats | null>(null)
  const [loading, setLoading] = useState(true)
  const [recentArticles, setRecentArticles] = useState<Article[]>([])
  const [recentMatches, setRecentMatches] = useState<Match[]>([])
  const [liveMatches, setLiveMatches] = useState<Match[]>([])

  useEffect(() => {
    async function fetchData() {
      try {
        const [statsRes, articlesRes, matchesRes, liveRes] = await Promise.all([
          fetch('/api/stats'),
          fetch('/api/articles?status=published&limit=5'),
          fetch('/api/matches?status=finished'),
          fetch('/api/matches?status=live'),
        ])
        const statsData = await statsRes.json()
        const articlesData = await articlesRes.json()
        const matchesData = await matchesRes.json()
        const liveData = await liveRes.json()

        setStats(statsData.stats || null)
        setRecentArticles((articlesData.articles || []).slice(0, 5))
        setRecentMatches((matchesData.matches || []).slice(0, 5))
        setLiveMatches((liveData.matches || []).slice(0, 3))
      } catch {
        // silently fail
      } finally {
        setLoading(false)
      }
    }
    fetchData()
  }, [])

  const statsCards = stats ? [
    {
      title: 'إجمالي المستخدمين',
      value: stats.totalUsers,
      change: '+12%',
      trend: 'up' as const,
      icon: Users,
      color: 'from-purple-500 to-purple-600',
      bgLight: 'bg-purple-50',
      textColor: 'text-purple-600',
      href: '/admin/users'
    },
    {
      title: 'المقالات المنشورة',
      value: stats.totalArticles,
      change: '+8%',
      trend: 'up' as const,
      icon: FileText,
      color: 'from-emerald-500 to-emerald-600',
      bgLight: 'bg-emerald-50',
      textColor: 'text-emerald-600',
      href: '/admin/articles'
    },
    {
      title: 'المباريات اليوم',
      value: stats.todaysMatches,
      change: '+3',
      trend: 'up' as const,
      icon: Trophy,
      color: 'from-blue-500 to-blue-600',
      bgLight: 'bg-blue-50',
      textColor: 'text-blue-600',
      href: '/admin/matches'
    },
    {
      title: 'الأخبار العاجلة',
      value: stats.breakingNews,
      change: '-2%',
      trend: 'down' as const,
      icon: Radio,
      color: 'from-orange-500 to-orange-600',
      bgLight: 'bg-orange-50',
      textColor: 'text-orange-600',
      href: '/admin/articles'
    },
  ] : []

  if (loading) {
    return (
      <div className="space-y-6">
        <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-5">
          {Array.from({ length: 4 }).map((_, i) => (
            <Card key={i} className="border-0 shadow-sm">
              <CardContent className="p-5">
                <div className="flex items-center gap-4">
                  <Skeleton className="size-12 rounded-xl" />
                  <div className="space-y-2 flex-1">
                    <Skeleton className="h-3 w-20" />
                    <Skeleton className="h-6 w-16" />
                  </div>
                </div>
              </CardContent>
            </Card>
          ))}
        </div>
      </div>
    )
  }

  return (
    <div className="space-y-6">
      {/* Stats Cards */}
      <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-5">
        {statsCards.map((card) => {
          const Icon = card.icon
          return (
            <Link key={card.title} href={card.href}>
              <Card className="border-0 shadow-sm hover:shadow-md transition-all duration-300 cursor-pointer group">
                <CardContent className="p-5">
                  <div className="flex items-start justify-between">
                    <div className="flex items-center gap-4">
                      <div className={`size-12 rounded-xl ${card.bgLight} flex items-center justify-center`}>
                        <Icon className={`size-6 ${card.textColor}`} />
                      </div>
                      <div>
                        <p className="text-xs text-gray-400 font-medium">{card.title}</p>
                        <p className="text-2xl font-bold text-gray-800 mt-0.5">{card.value}</p>
                      </div>
                    </div>
                  </div>
                  <div className="flex items-center gap-1 mt-3">
                    {card.trend === 'up' ? (
                      <TrendingUp className="size-3.5 text-emerald-500" />
                    ) : (
                      <TrendingDown className="size-3.5 text-red-500" />
                    )}
                    <span className={`text-xs font-medium ${card.trend === 'up' ? 'text-emerald-500' : 'text-red-500'}`}>
                      {card.change}
                    </span>
                    <span className="text-[10px] text-gray-300 mr-1">من الأسبوع الماضي</span>
                  </div>
                </CardContent>
              </Card>
            </Link>
          )
        })}
      </div>

      {/* Live Matches Section */}
      {liveMatches.length > 0 && (
        <Card className="border-0 shadow-sm overflow-hidden">
          <CardHeader className="bg-gradient-to-l from-red-50 to-white pb-3">
            <div className="flex items-center justify-between">
              <CardTitle className="text-sm font-bold flex items-center gap-2">
                <span className="size-2 rounded-full bg-red-500 animate-pulse" />
                مباريات مباشرة
              </CardTitle>
              <Link href="/admin/matches" className="text-xs text-emerald-600 hover:text-emerald-700 font-medium">
                عرض الكل ←
              </Link>
            </div>
          </CardHeader>
          <CardContent className="p-4">
            <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
              {liveMatches.map((match) => (
                <div key={match.id} className="bg-gray-50 rounded-xl p-4 hover:bg-gray-100 transition-colors">
                  <div className="flex items-center justify-between mb-3">
                    <Badge className="bg-red-500 text-white text-[9px] px-1.5 py-0 animate-pulse">
                      LIVE
                    </Badge>
                    <span className="text-[10px] text-gray-400">{match.league.name}</span>
                  </div>
                  <div className="flex items-center justify-between">
                    <div className="text-center flex-1">
                      <div
                        className="size-10 rounded-full mx-auto mb-1.5 flex items-center justify-center text-white text-xs font-bold"
                        style={{ backgroundColor: match.homeTeam.color || '#10b981' }}
                      >
                        {(match.homeTeam.shortName || match.homeTeam.name).charAt(0)}
                      </div>
                      <p className="text-xs font-medium text-gray-700 truncate">{match.homeTeam.name}</p>
                    </div>
                    <div className="px-4 text-center">
                      <div className="flex items-center gap-2">
                        <span className="text-xl font-bold text-gray-800">{match.homeScore ?? 0}</span>
                        <span className="text-gray-300">-</span>
                        <span className="text-xl font-bold text-gray-800">{match.awayScore ?? 0}</span>
                      </div>
                    </div>
                    <div className="text-center flex-1">
                      <div
                        className="size-10 rounded-full mx-auto mb-1.5 flex items-center justify-center text-white text-xs font-bold"
                        style={{ backgroundColor: match.awayTeam.color || '#6366f1' }}
                      >
                        {(match.awayTeam.shortName || match.awayTeam.name).charAt(0)}
                      </div>
                      <p className="text-xs font-medium text-gray-700 truncate">{match.awayTeam.name}</p>
                    </div>
                  </div>
                </div>
              ))}
            </div>
          </CardContent>
        </Card>
      )}

      {/* Charts Row */}
      <div className="grid grid-cols-1 lg:grid-cols-3 gap-5">
        {/* Line Chart - Weekly Views */}
        <Card className="border-0 shadow-sm lg:col-span-2">
          <CardHeader className="pb-2">
            <div className="flex items-center justify-between">
              <CardTitle className="text-sm font-bold text-gray-700 flex items-center gap-2">
                <BarChart3 className="size-4 text-emerald-500" />
                المشاهدات الأسبوعية
              </CardTitle>
              <Badge variant="secondary" className="text-[10px] bg-emerald-50 text-emerald-600">
                آخر 7 أيام
              </Badge>
            </div>
          </CardHeader>
          <CardContent>
            <div className="h-64">
              <ResponsiveContainer width="100%" height="100%">
                <LineChart data={WEEKLY_DATA}>
                  <CartesianGrid strokeDasharray="3 3" vertical={false} stroke="#f0f0f0" />
                  <XAxis dataKey="day" tick={{ fontSize: 11 }} tickLine={false} axisLine={false} />
                  <YAxis tick={{ fontSize: 11 }} tickLine={false} axisLine={false} />
                  <Tooltip
                    contentStyle={{
                      borderRadius: '12px',
                      border: 'none',
                      boxShadow: '0 4px 12px rgba(0,0,0,0.1)',
                      fontSize: '12px',
                    }}
                  />
                  <Line
                    type="monotone"
                    dataKey="views"
                    stroke="#10b981"
                    strokeWidth={2.5}
                    dot={{ fill: '#10b981', strokeWidth: 0, r: 4 }}
                    activeDot={{ r: 6, fill: '#10b981' }}
                    name="المشاهدات"
                  />
                </LineChart>
              </ResponsiveContainer>
            </div>
          </CardContent>
        </Card>

        {/* Pie Chart - Content Distribution */}
        <Card className="border-0 shadow-sm">
          <CardHeader className="pb-2">
            <CardTitle className="text-sm font-bold text-gray-700 flex items-center gap-2">
              <Trophy className="size-4 text-emerald-500" />
              توزيع المحتوى
            </CardTitle>
          </CardHeader>
          <CardContent>
            <div className="h-52">
              <ResponsiveContainer width="100%" height="100%">
                <PieChart>
                  <Pie
                    data={PIE_DATA}
                    cx="50%"
                    cy="50%"
                    innerRadius={50}
                    outerRadius={80}
                    paddingAngle={3}
                    dataKey="value"
                  >
                    {PIE_DATA.map((entry, index) => (
                      <Cell key={`cell-${index}`} fill={entry.color} />
                    ))}
                  </Pie>
                  <Tooltip
                    contentStyle={{
                      borderRadius: '12px',
                      border: 'none',
                      boxShadow: '0 4px 12px rgba(0,0,0,0.1)',
                      fontSize: '12px',
                    }}
                  />
                </PieChart>
              </ResponsiveContainer>
            </div>
            <div className="grid grid-cols-2 gap-2 mt-2">
              {PIE_DATA.map((item) => (
                <div key={item.name} className="flex items-center gap-2">
                  <span className="size-2.5 rounded-full" style={{ backgroundColor: item.color }} />
                  <span className="text-[11px] text-gray-500">{item.name}</span>
                  <span className="text-[11px] font-bold text-gray-700 mr-auto">{item.value}%</span>
                </div>
              ))}
            </div>
          </CardContent>
        </Card>
      </div>

      {/* Bottom Row - News + Upcoming */}
      <div className="grid grid-cols-1 lg:grid-cols-2 gap-5">
        {/* Recent News */}
        <Card className="border-0 shadow-sm">
          <CardHeader className="pb-2">
            <div className="flex items-center justify-between">
              <CardTitle className="text-sm font-bold text-gray-700 flex items-center gap-2">
                <Newspaper className="size-4 text-emerald-500" />
                آخر الأخبار
              </CardTitle>
              <Link href="/admin/articles" className="text-xs text-emerald-600 hover:text-emerald-700 font-medium">
                عرض الكل ←
              </Link>
            </div>
          </CardHeader>
          <CardContent>
            {recentArticles.length === 0 ? (
              <p className="text-sm text-gray-400 text-center py-8">لا توجد مقالات</p>
            ) : (
              <div className="space-y-3">
                {recentArticles.map((article) => (
                  <div
                    key={article.id}
                    className="flex items-start gap-3 p-2.5 rounded-xl hover:bg-gray-50 transition-colors cursor-pointer"
                  >
                    <div className="size-14 rounded-lg bg-gray-100 flex items-center justify-center shrink-0 overflow-hidden">
                      {article.image ? (
                        <img src={article.image} alt="" className="size-full object-cover" />
                      ) : (
                        <Newspaper className="size-5 text-gray-300" />
                      )}
                    </div>
                    <div className="flex-1 min-w-0">
                      <p className="text-sm font-medium text-gray-700 line-clamp-2 leading-snug">{article.title}</p>
                      <div className="flex items-center gap-2 mt-1.5">
                        <Badge variant="secondary" className={`text-[9px] px-1.5 py-0 ${getCategoryColor(article.category)}`}>
                          {getCategoryLabel(article.category)}
                        </Badge>
                        <span className="text-[10px] text-gray-400">{article.author.name}</span>
                        <span className="text-[10px] text-gray-300 flex items-center gap-0.5">
                          <Eye className="size-2.5" />
                          {article.views}
                        </span>
                      </div>
                    </div>
                  </div>
                ))}
              </div>
            )}
          </CardContent>
        </Card>

        {/* Recent Matches */}
        <Card className="border-0 shadow-sm">
          <CardHeader className="pb-2">
            <div className="flex items-center justify-between">
              <CardTitle className="text-sm font-bold text-gray-700 flex items-center gap-2">
                <Calendar className="size-4 text-emerald-500" />
                آخر المباريات
              </CardTitle>
              <Link href="/admin/matches" className="text-xs text-emerald-600 hover:text-emerald-700 font-medium">
                عرض الكل ←
              </Link>
            </div>
          </CardHeader>
          <CardContent>
            {recentMatches.length === 0 ? (
              <p className="text-sm text-gray-400 text-center py-8">لا توجد مباريات</p>
            ) : (
              <div className="space-y-2.5">
                {recentMatches.map((match) => (
                  <div
                    key={match.id}
                    className="flex items-center justify-between p-3 rounded-xl bg-gray-50 hover:bg-gray-100 transition-colors"
                  >
                    <div className="flex items-center gap-3 flex-1 min-w-0">
                      <div
                        className="size-8 rounded-full flex items-center justify-center text-white text-[10px] font-bold shrink-0"
                        style={{ backgroundColor: match.homeTeam.color || '#10b981' }}
                      >
                        {(match.homeTeam.shortName || match.homeTeam.name).charAt(0)}
                      </div>
                      <div className="text-center">
                        <div className="flex items-center gap-2">
                          <span className="text-sm font-bold text-gray-800">{match.homeScore ?? '-'}</span>
                          <span className="text-[10px] text-gray-300">-</span>
                          <span className="text-sm font-bold text-gray-800">{match.awayScore ?? '-'}</span>
                        </div>
                      </div>
                      <div
                        className="size-8 rounded-full flex items-center justify-center text-white text-[10px] font-bold shrink-0"
                        style={{ backgroundColor: match.awayTeam.color || '#6366f1' }}
                      >
                        {(match.awayTeam.shortName || match.awayTeam.name).charAt(0)}
                      </div>
                    </div>
                    <div className="flex flex-col items-end gap-1">
                      <Badge className={`text-[9px] px-1.5 py-0 ${getStatusColor(match.status)}`}>
                        {getStatusLabel(match.status)}
                      </Badge>
                      <span className="text-[10px] text-gray-400">{formatFullDate(match.matchDate)}</span>
                    </div>
                  </div>
                ))}
              </div>
            )}
          </CardContent>
        </Card>
      </div>

      {/* Quick Actions */}
      <div className="flex flex-wrap gap-3">
        <Link href="/admin/articles">
          <Button className="bg-emerald-500 hover:bg-emerald-600 shadow-sm shadow-emerald-500/25 gap-1.5 text-sm">
            <Plus className="size-4" />
            مقال جديد
          </Button>
        </Link>
        <Link href="/admin/matches">
          <Button className="bg-blue-500 hover:bg-blue-600 shadow-sm shadow-blue-500/25 gap-1.5 text-sm">
            <Plus className="size-4" />
            مباراة جديدة
          </Button>
        </Link>
        <Link href="/admin/leagues">
          <Button className="bg-purple-500 hover:bg-purple-600 shadow-sm shadow-purple-500/25 gap-1.5 text-sm">
            <Plus className="size-4" />
            بطولة جديدة
          </Button>
        </Link>
        <Link href="/admin/teams">
          <Button variant="outline" className="gap-1.5 text-sm border-gray-200">
            <Plus className="size-4" />
            فريق جديد
          </Button>
        </Link>
      </div>
    </div>
  )
}
