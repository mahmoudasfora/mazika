'use client'

import { useEffect, useState, useCallback } from 'react'
import { Plus, Pencil, Trash2, Loader2, UserCircle } from 'lucide-react'
import { Card, CardContent } from '@/components/ui/card'
import { Badge } from '@/components/ui/badge'
import { Button } from '@/components/ui/button'
import { Input } from '@/components/ui/input'
import { Skeleton } from '@/components/ui/skeleton'
import { Label } from '@/components/ui/label'
import {
  Table, TableBody, TableCell, TableHead, TableHeader, TableRow
} from '@/components/ui/table'
import {
  Dialog, DialogContent, DialogDescription, DialogFooter,
  DialogHeader, DialogTitle, DialogTrigger
} from '@/components/ui/dialog'
import {
  Select, SelectContent, SelectItem, SelectTrigger, SelectValue
} from '@/components/ui/select'

interface Player {
  id: string
  name: string
  nameEn: string | null
  position: string
  number: number | null
  goals: number
  assists: number
  teamId: string
  team?: {
    id: string
    name: string
    color: string | null
  }
}

interface Team {
  id: string
  name: string
  nameEn: string | null
  shortName: string | null
  color: string | null
}

const POSITIONS = [
  { value: 'GK', label: 'حارس مرمى' },
  { value: 'CB', label: 'قلب دفاع' },
  { value: 'RB', label: 'ظهير أيمن' },
  { value: 'LB', label: 'ظهير أيسر' },
  { value: 'CDM', label: 'محور دفاعي' },
  { value: 'CM', label: 'وسط مركزي' },
  { value: 'CAM', label: 'وسط هجومي' },
  { value: 'RW', label: 'جناح أيمن' },
  { value: 'LW', label: 'جناح أيسر' },
  { value: 'CF', label: 'مهاجم' },
  { value: 'ST', label: 'رأس حربة' },
]

const positionLabel = (pos: string) => POSITIONS.find(p => p.value === pos)?.label || pos

export default function AdminPlayersPage() {
  const [players, setPlayers] = useState<Player[]>([])
  const [teams, setTeams] = useState<Team[]>([])
  const [loading, setLoading] = useState(true)
  const [dialogOpen, setDialogOpen] = useState(false)
  const [submitting, setSubmitting] = useState(false)
  const [editId, setEditId] = useState<string | null>(null)

  const [formName, setFormName] = useState('')
  const [formNameEn, setFormNameEn] = useState('')
  const [formPosition, setFormPosition] = useState('ST')
  const [formNumber, setFormNumber] = useState('')
  const [formGoals, setFormGoals] = useState('0')
  const [formAssists, setFormAssists] = useState('0')
  const [formTeamId, setFormTeamId] = useState('')

  const fetchData = useCallback(async () => {
    try {
      setLoading(true)
      const [playersRes, teamsRes] = await Promise.all([
        fetch('/api/players'),
        fetch('/api/teams'),
      ])
      const playersData = await playersRes.json()
      const teamsData = await teamsRes.json()
      setPlayers(playersData.players || [])
      setTeams(teamsData.teams || [])
    } catch {
      // silently fail
    } finally {
      setLoading(false)
    }
  }, [])

  useEffect(() => { fetchData() }, [fetchData])

  const resetForm = () => {
    setFormName(''); setFormNameEn(''); setFormPosition('ST')
    setFormNumber(''); setFormGoals('0'); setFormAssists('0')
    setFormTeamId(''); setEditId(null)
  }

  const openCreate = () => { resetForm(); setDialogOpen(true) }

  const openEdit = (player: Player) => {
    setEditId(player.id)
    setFormName(player.name)
    setFormNameEn(player.nameEn || '')
    setFormPosition(player.position)
    setFormNumber(player.number?.toString() || '')
    setFormGoals(player.goals.toString())
    setFormAssists(player.assists.toString())
    setFormTeamId(player.teamId)
    setDialogOpen(true)
  }

  const handleSubmit = async () => {
    if (!formName || !formTeamId) return
    setSubmitting(true)
    try {
      if (editId) {
        await fetch('/api/admin/players', {
          method: 'PUT',
          headers: { 'Content-Type': 'application/json' },
          body: JSON.stringify({
            id: editId, name: formName, nameEn: formNameEn,
            position: formPosition, number: formNumber ? parseInt(formNumber) : null,
            goals: parseInt(formGoals) || 0, assists: parseInt(formAssists) || 0,
            teamId: formTeamId,
          }),
        })
      } else {
        await fetch('/api/admin/players', {
          method: 'POST',
          headers: { 'Content-Type': 'application/json' },
          body: JSON.stringify({
            name: formName, nameEn: formNameEn,
            position: formPosition, number: formNumber ? parseInt(formNumber) : null,
            goals: parseInt(formGoals) || 0, assists: parseInt(formAssists) || 0,
            teamId: formTeamId,
          }),
        })
      }
      setDialogOpen(false)
      resetForm()
      fetchData()
    } catch {
      // silently fail
    } finally {
      setSubmitting(false)
    }
  }

  const handleDelete = async (id: string) => {
    if (!confirm('هل أنت متأكد من حذف هذا اللاعب؟')) return
    try {
      await fetch('/api/admin/players', {
        method: 'DELETE',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ id }),
      })
      fetchData()
    } catch {
      // silently fail
    }
  }

  if (loading) {
    return (
      <div className="space-y-4">
        {Array.from({ length: 5 }).map((_, i) => (
          <Skeleton key={i} className="h-14 w-full" />
        ))}
      </div>
    )
  }

  return (
    <div className="space-y-4">
      <div className="flex items-center justify-between">
        <h2 className="text-xl font-bold">إدارة اللاعبين</h2>
        <Dialog open={dialogOpen} onOpenChange={setDialogOpen}>
          <DialogTrigger asChild>
            <Button className="bg-emerald-600 hover:bg-emerald-700" onClick={openCreate}>
              <Plus className="size-4 ml-1" />
              لاعب جديد
            </Button>
          </DialogTrigger>
          <DialogContent className="max-w-lg max-h-[90vh] overflow-y-auto" dir="rtl">
            <DialogHeader>
              <DialogTitle>{editId ? 'تعديل اللاعب' : 'لاعب جديد'}</DialogTitle>
              <DialogDescription>{editId ? 'قم بتعديل بيانات اللاعب' : 'أدخل بيانات اللاعب الجديد'}</DialogDescription>
            </DialogHeader>
            <div className="space-y-4">
              <div className="grid grid-cols-2 gap-4">
                <div className="space-y-2">
                  <Label>الاسم (عربي) *</Label>
                  <Input value={formName} onChange={(e) => setFormName(e.target.value)} placeholder="محمد صلاح" />
                </div>
                <div className="space-y-2">
                  <Label>الاسم (إنجليزي)</Label>
                  <Input value={formNameEn} onChange={(e) => setFormNameEn(e.target.value)} placeholder="Mohamed Salah" />
                </div>
              </div>
              <div className="grid grid-cols-2 gap-4">
                <div className="space-y-2">
                  <Label>المركز *</Label>
                  <Select value={formPosition} onValueChange={setFormPosition}>
                    <SelectTrigger className="w-full"><SelectValue /></SelectTrigger>
                    <SelectContent>
                      {POSITIONS.map(p => (
                        <SelectItem key={p.value} value={p.value}>{p.label}</SelectItem>
                      ))}
                    </SelectContent>
                  </Select>
                </div>
                <div className="space-y-2">
                  <Label>رقم القميص</Label>
                  <Input type="number" value={formNumber} onChange={(e) => setFormNumber(e.target.value)} placeholder="10" />
                </div>
              </div>
              <div className="grid grid-cols-2 gap-4">
                <div className="space-y-2">
                  <Label>الأهداف</Label>
                  <Input type="number" value={formGoals} onChange={(e) => setFormGoals(e.target.value)} placeholder="0" />
                </div>
                <div className="space-y-2">
                  <Label>التمريرات</Label>
                  <Input type="number" value={formAssists} onChange={(e) => setFormAssists(e.target.value)} placeholder="0" />
                </div>
              </div>
              <div className="space-y-2">
                <Label>الفريق *</Label>
                <Select value={formTeamId} onValueChange={setFormTeamId}>
                  <SelectTrigger className="w-full"><SelectValue placeholder="اختر الفريق" /></SelectTrigger>
                  <SelectContent>
                    {teams.map(t => (
                      <SelectItem key={t.id} value={t.id}>{t.name}</SelectItem>
                    ))}
                  </SelectContent>
                </Select>
              </div>
            </div>
            <DialogFooter>
              <Button variant="outline" onClick={() => setDialogOpen(false)}>إلغاء</Button>
              <Button className="bg-emerald-600 hover:bg-emerald-700" onClick={handleSubmit} disabled={submitting || !formName || !formTeamId}>
                {submitting && <Loader2 className="size-4 ml-1 animate-spin" />}
                {editId ? 'تحديث' : 'إنشاء'}
              </Button>
            </DialogFooter>
          </DialogContent>
        </Dialog>
      </div>

      <Card>
        <CardContent className="p-0">
          <Table>
            <TableHeader>
              <TableRow>
                <TableHead className="text-right">اللاعب</TableHead>
                <TableHead className="text-right">الفريق</TableHead>
                <TableHead className="text-right">المركز</TableHead>
                <TableHead className="text-right">الرقم</TableHead>
                <TableHead className="text-right">أهداف</TableHead>
                <TableHead className="text-right">تمريرات</TableHead>
                <TableHead className="text-right">إجراءات</TableHead>
              </TableRow>
            </TableHeader>
            <TableBody>
              {players.length === 0 ? (
                <TableRow>
                  <TableCell colSpan={7} className="text-center py-8 text-muted-foreground">
                    <UserCircle className="size-12 mx-auto mb-2 opacity-30" />
                    لا يوجد لاعبين
                  </TableCell>
                </TableRow>
              ) : (
                players.map((player) => (
                  <TableRow key={player.id}>
                    <TableCell>
                      <div>
                        <p className="font-medium">{player.name}</p>
                        {player.nameEn && <p className="text-xs text-muted-foreground">{player.nameEn}</p>}
                      </div>
                    </TableCell>
                    <TableCell>
                      <Badge variant="secondary" className="text-[10px]">
                        {player.team?.name || '-'}
                      </Badge>
                    </TableCell>
                    <TableCell className="text-sm">{positionLabel(player.position)}</TableCell>
                    <TableCell className="text-sm">{player.number || '-'}</TableCell>
                    <TableCell className="text-sm font-medium">{player.goals}</TableCell>
                    <TableCell className="text-sm">{player.assists}</TableCell>
                    <TableCell>
                      <div className="flex items-center gap-1">
                        <Button variant="ghost" size="icon" className="size-8" onClick={() => openEdit(player)}>
                          <Pencil className="size-4" />
                        </Button>
                        <Button variant="ghost" size="icon" className="size-8 text-red-500 hover:text-red-600" onClick={() => handleDelete(player.id)}>
                          <Trash2 className="size-4" />
                        </Button>
                      </div>
                    </TableCell>
                  </TableRow>
                ))
              )}
            </TableBody>
          </Table>
        </CardContent>
      </Card>
    </div>
  )
}
