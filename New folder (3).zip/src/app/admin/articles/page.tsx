'use client'

import { useEffect, useState, useCallback } from 'react'
import { Plus, Pencil, Trash2, Loader2, Search, Filter } from 'lucide-react'
import { Card, CardContent } from '@/components/ui/card'
import { Badge } from '@/components/ui/badge'
import { Button } from '@/components/ui/button'
import { Input } from '@/components/ui/input'
import { Textarea } from '@/components/ui/textarea'
import { Switch } from '@/components/ui/switch'
import { Skeleton } from '@/components/ui/skeleton'
import { Label } from '@/components/ui/label'
import {
  Table, TableBody, TableCell, TableHead, TableHeader, TableRow
} from '@/components/ui/table'
import {
  Dialog, DialogContent, DialogDescription, DialogFooter,
  DialogHeader, DialogTitle, DialogTrigger
} from '@/components/ui/dialog'
import {
  Select, SelectContent, SelectItem, SelectTrigger, SelectValue
} from '@/components/ui/select'
import { getCategoryLabel, getCategoryColor, formatFullDate } from '@/lib/sports-utils'

interface ArticleAuthor {
  id: string
  name: string
  avatar: string | null
  role: string
}

interface Article {
  id: string
  title: string
  slug: string
  summary: string | null
  content: string
  image: string | null
  category: string
  isBreaking: boolean
  isFeatured: boolean
  status: string
  authorId: string
  publishedAt: string | null
  views: number
  createdAt: string
  updatedAt: string
  author: ArticleAuthor
}

const ARTICLE_CATEGORIES = [
  { value: 'general', label: 'أخبار عامة' },
  { value: 'transfer', label: 'انتقالات' },
  { value: 'analysis', label: 'تحليلات' },
  { value: 'interview', label: 'مقابلات' },
  { value: 'report', label: 'تقارير' },
]

const ARTICLE_STATUS_BADGE: Record<string, string> = {
  draft: 'bg-gray-100 text-gray-600 dark:bg-gray-800 dark:text-gray-300',
  review: 'bg-amber-50 text-amber-600 dark:bg-amber-900 dark:text-amber-300',
  published: 'bg-emerald-50 text-emerald-600 dark:bg-emerald-900 dark:text-emerald-300',
}

const ARTICLE_STATUS_LABEL: Record<string, string> = {
  draft: 'مسودة',
  review: 'قيد المراجعة',
  published: 'منشور',
}

function toSlug(text: string): string {
  return text.trim().replace(/\s+/g, '-').replace(/[^\u0621-\u064Aa-zA-Z0-9-]/g, '').replace(/-+/g, '-').toLowerCase()
}

export default function AdminArticlesPage() {
  const [articles, setArticles] = useState<Article[]>([])
  const [loading, setLoading] = useState(true)
  const [dialogOpen, setDialogOpen] = useState(false)
  const [submitting, setSubmitting] = useState(false)
  const [editId, setEditId] = useState<string | null>(null)
  const [searchQuery, setSearchQuery] = useState('')
  const [categoryFilter, setCategoryFilter] = useState('all')

  const [formTitle, setFormTitle] = useState('')
  const [formSlug, setFormSlug] = useState('')
  const [formSummary, setFormSummary] = useState('')
  const [formContent, setFormContent] = useState('')
  const [formCategory, setFormCategory] = useState('general')
  const [formIsBreaking, setFormIsBreaking] = useState(false)
  const [formIsFeatured, setFormIsFeatured] = useState(false)
  const [formTags, setFormTags] = useState('')
  const [formImage, setFormImage] = useState('')
  const [formStatus, setFormStatus] = useState('draft')

  const fetchArticles = useCallback(async () => {
    try {
      setLoading(true)
      const res = await fetch('/api/articles?status=&limit=50')
      const data = await res.json()
      setArticles(data.articles || [])
    } catch {
      // silently fail
    } finally {
      setLoading(false)
    }
  }, [])

  useEffect(() => { fetchArticles() }, [fetchArticles])

  const resetForm = () => {
    setFormTitle(''); setFormSlug(''); setFormSummary(''); setFormContent('')
    setFormCategory('general'); setFormIsBreaking(false); setFormIsFeatured(false)
    setFormTags(''); setFormImage(''); setEditId(null); setFormStatus('draft')
  }

  const openCreateDialog = () => { resetForm(); setDialogOpen(true) }

  const openEditDialog = (article: Article) => {
    setEditId(article.id); setFormTitle(article.title); setFormSlug(article.slug)
    setFormSummary(article.summary || ''); setFormContent(article.content)
    setFormCategory(article.category); setFormIsBreaking(article.isBreaking)
    setFormIsFeatured(article.isFeatured); setFormStatus(article.status)
    setFormTags(''); setFormImage(article.image || ''); setDialogOpen(true)
  }

  const handleSubmit = async () => {
    if (!formTitle || !formContent) return
    setSubmitting(true)
    try {
      const tags = formTags.split(',').map(t => t.trim()).filter(Boolean)
      if (editId) {
        await fetch(`/api/articles/${editId}`, {
          method: 'PUT',
          headers: { 'Content-Type': 'application/json' },
          body: JSON.stringify({
            title: formTitle, slug: formSlug || toSlug(formTitle),
            summary: formSummary, content: formContent, category: formCategory,
            isBreaking: formIsBreaking, isFeatured: formIsFeatured, status: formStatus,
            image: formImage || null,
          }),
        })
      } else {
        await fetch('/api/admin/articles', {
          method: 'POST',
          headers: { 'Content-Type': 'application/json' },
          body: JSON.stringify({
            title: formTitle, slug: formSlug || toSlug(formTitle),
            summary: formSummary, content: formContent, category: formCategory,
            isBreaking: formIsBreaking, isFeatured: formIsFeatured, status: formStatus,
            authorId: 'admin', tags, image: formImage || null,
          }),
        })
      }
      setDialogOpen(false); resetForm(); fetchArticles()
    } catch { /* */ } finally { setSubmitting(false) }
  }

  const handleDelete = async (id: string) => {
    if (!confirm('هل أنت متأكد من حذف هذا المقال؟')) return
    try { await fetch(`/api/articles/${id}`, { method: 'DELETE' }); fetchArticles() } catch { /* */ }
  }

  const filteredArticles = articles.filter(a => {
    const matchesSearch = !searchQuery || a.title.includes(searchQuery)
    const matchesCategory = categoryFilter === 'all' || a.category === categoryFilter
    return matchesSearch && matchesCategory
  })

  if (loading) {
    return (
      <div className="space-y-4">
        {Array.from({ length: 5 }).map((_, i) => (<Skeleton key={i} className="h-14 w-full rounded-xl" />))}
      </div>
    )
  }

  return (
    <div className="space-y-5">
      {/* Header */}
      <div className="flex items-center justify-between flex-wrap gap-3">
        <h2 className="text-xl font-bold text-gray-800">إدارة المقالات</h2>
        <Dialog open={dialogOpen} onOpenChange={setDialogOpen}>
          <DialogTrigger asChild>
            <Button className="bg-emerald-500 hover:bg-emerald-600 shadow-sm shadow-emerald-500/25 gap-1.5" onClick={openCreateDialog}>
              <Plus className="size-4" />مقال جديد
            </Button>
          </DialogTrigger>
          <DialogContent className="max-w-2xl max-h-[90vh] overflow-y-auto" dir="rtl">
            <DialogHeader>
              <DialogTitle>{editId ? 'تعديل المقال' : 'مقال جديد'}</DialogTitle>
              <DialogDescription>{editId ? 'قم بتعديل بيانات المقال' : 'أدخل بيانات المقال الجديد'}</DialogDescription>
            </DialogHeader>
            <div className="space-y-4">
              <div className="space-y-2">
                <Label>العنوان *</Label>
                <Input value={formTitle} onChange={(e) => { setFormTitle(e.target.value); if (!editId) setFormSlug(toSlug(e.target.value)) }} placeholder="عنوان المقال" />
              </div>
              <div className="space-y-2">
                <Label>الرابط (Slug)</Label>
                <Input value={formSlug} onChange={(e) => setFormSlug(e.target.value)} placeholder="رابط-المقال" />
              </div>
              <div className="space-y-2">
                <Label>الملخص</Label>
                <Textarea value={formSummary} onChange={(e) => setFormSummary(e.target.value)} placeholder="ملخص المقال" rows={2} />
              </div>
              <div className="space-y-2">
                <Label>المحتوى *</Label>
                <Textarea value={formContent} onChange={(e) => setFormContent(e.target.value)} placeholder="محتوى المقال" rows={6} />
              </div>
              <div className="grid grid-cols-2 gap-4">
                <div className="space-y-2">
                  <Label>التصنيف</Label>
                  <Select value={formCategory} onValueChange={setFormCategory}>
                    <SelectTrigger className="w-full"><SelectValue /></SelectTrigger>
                    <SelectContent>
                      {ARTICLE_CATEGORIES.map(cat => (<SelectItem key={cat.value} value={cat.value}>{cat.label}</SelectItem>))}
                    </SelectContent>
                  </Select>
                </div>
                <div className="space-y-2">
                  <Label>الحالة</Label>
                  <Select value={formStatus} onValueChange={setFormStatus}>
                    <SelectTrigger className="w-full"><SelectValue /></SelectTrigger>
                    <SelectContent>
                      <SelectItem value="draft">مسودة</SelectItem>
                      <SelectItem value="review">قيد المراجعة</SelectItem>
                      <SelectItem value="published">منشور</SelectItem>
                    </SelectContent>
                  </Select>
                </div>
              </div>
              <div className="space-y-2">
                <Label>رابط الصورة</Label>
                <Input value={formImage} onChange={(e) => setFormImage(e.target.value)} placeholder="https://..." />
              </div>
              <div className="flex items-center gap-6">
                <div className="flex items-center gap-2"><Switch checked={formIsBreaking} onCheckedChange={setFormIsBreaking} /><Label>خبر عاجل</Label></div>
                <div className="flex items-center gap-2"><Switch checked={formIsFeatured} onCheckedChange={setFormIsFeatured} /><Label>مقال مميز</Label></div>
              </div>
              <div className="space-y-2">
                <Label>الوسوم (مفصولة بفواصل)</Label>
                <Input value={formTags} onChange={(e) => setFormTags(e.target.value)} placeholder="كرة قدم، دوري، أهلي" />
              </div>
            </div>
            <DialogFooter>
              <Button variant="outline" onClick={() => setDialogOpen(false)}>إلغاء</Button>
              <Button className="bg-emerald-500 hover:bg-emerald-600" onClick={handleSubmit} disabled={submitting || !formTitle || !formContent}>
                {submitting && <Loader2 className="size-4 ml-1 animate-spin" />}
                {editId ? 'تحديث' : 'إنشاء'}
              </Button>
            </DialogFooter>
          </DialogContent>
        </Dialog>
      </div>

      {/* Search & Filter Bar */}
      <div className="flex items-center gap-3 flex-wrap">
        <div className="relative flex-1 max-w-xs">
          <Search className="absolute right-3 top-1/2 -translate-y-1/2 size-4 text-gray-300" />
          <Input
            placeholder="بحث في المقالات..."
            value={searchQuery}
            onChange={(e) => setSearchQuery(e.target.value)}
            className="bg-white border-gray-200 pr-9 h-9 text-sm"
          />
        </div>
        <Select value={categoryFilter} onValueChange={setCategoryFilter}>
          <SelectTrigger className="w-36 h-9 bg-white border-gray-200 text-sm">
            <Filter className="size-3.5 ml-1 text-gray-400" />
            <SelectValue placeholder="التصنيف" />
          </SelectTrigger>
          <SelectContent>
            <SelectItem value="all">الكل</SelectItem>
            {ARTICLE_CATEGORIES.map(cat => (<SelectItem key={cat.value} value={cat.value}>{cat.label}</SelectItem>))}
          </SelectContent>
        </Select>
        <span className="text-xs text-gray-400">{filteredArticles.length} مقال</span>
      </div>

      {/* Articles Table */}
      <Card className="border-0 shadow-sm overflow-hidden">
        <CardContent className="p-0">
          <Table>
            <TableHeader>
              <TableRow className="bg-gray-50/80">
                <TableHead className="text-right text-xs font-semibold text-gray-500">العنوان</TableHead>
                <TableHead className="text-right text-xs font-semibold text-gray-500">التصنيف</TableHead>
                <TableHead className="text-right text-xs font-semibold text-gray-500">الحالة</TableHead>
                <TableHead className="text-right text-xs font-semibold text-gray-500">الكاتب</TableHead>
                <TableHead className="text-right text-xs font-semibold text-gray-500">المشاهدات</TableHead>
                <TableHead className="text-right text-xs font-semibold text-gray-500">التاريخ</TableHead>
                <TableHead className="text-right text-xs font-semibold text-gray-500">إجراءات</TableHead>
              </TableRow>
            </TableHeader>
            <TableBody>
              {filteredArticles.length === 0 ? (
                <TableRow>
                  <TableCell colSpan={7} className="text-center py-12 text-gray-400">لا توجد مقالات</TableCell>
                </TableRow>
              ) : (
                filteredArticles.map((article) => (
                  <TableRow key={article.id} className="hover:bg-gray-50/50 transition-colors">
                    <TableCell className="max-w-[200px]">
                      <p className="truncate font-medium text-gray-700">{article.title}</p>
                      {article.isBreaking && (<Badge className="bg-red-50 text-red-600 text-[9px] mt-0.5 border-0">عاجل</Badge>)}
                    </TableCell>
                    <TableCell>
                      <Badge variant="secondary" className={`text-[9px] border-0 ${getCategoryColor(article.category)}`}>
                        {getCategoryLabel(article.category)}
                      </Badge>
                    </TableCell>
                    <TableCell>
                      <Badge variant="secondary" className={`text-[9px] border-0 ${ARTICLE_STATUS_BADGE[article.status] || ''}`}>
                        {ARTICLE_STATUS_LABEL[article.status] || article.status}
                      </Badge>
                    </TableCell>
                    <TableCell className="text-xs text-gray-400">{article.author?.name || '-'}</TableCell>
                    <TableCell className="text-xs text-gray-500">{article.views}</TableCell>
                    <TableCell className="text-[11px] text-gray-400">{article.createdAt ? formatFullDate(article.createdAt) : '-'}</TableCell>
                    <TableCell>
                      <div className="flex items-center gap-0.5">
                        <Button variant="ghost" size="icon" className="size-7 text-gray-400 hover:text-emerald-600" onClick={() => openEditDialog(article)}>
                          <Pencil className="size-3.5" />
                        </Button>
                        <Button variant="ghost" size="icon" className="size-7 text-gray-400 hover:text-red-500" onClick={() => handleDelete(article.id)}>
                          <Trash2 className="size-3.5" />
                        </Button>
                      </div>
                    </TableCell>
                  </TableRow>
                ))
              )}
            </TableBody>
          </Table>
        </CardContent>
      </Card>
    </div>
  )
}
