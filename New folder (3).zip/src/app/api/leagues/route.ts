import { db } from '@/lib/db'
import { NextResponse } from 'next/server'

export async function GET() {
  try {
    const leagues = await db.league.findMany({
      where: { isActive: true },
      include: {
        _count: {
          select: { teams: true },
        },
      },
      orderBy: { order: 'asc' },
    })

    const leaguesWithTeamCount = leagues.map((league) => ({
      id: league.id,
      name: league.name,
      nameEn: league.nameEn,
      country: league.country,
      logo: league.logo,
      type: league.type,
      season: league.season,
      isActive: league.isActive,
      order: league.order,
      teamCount: league._count.teams,
    }))

    return NextResponse.json({ leagues: leaguesWithTeamCount })
  } catch (error) {
    console.error('Error fetching leagues:', error)
    return NextResponse.json(
      { error: 'فشل في جلب البطولات' },
      { status: 500 }
    )
  }
}
