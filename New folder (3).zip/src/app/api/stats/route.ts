import { db } from '@/lib/db'
import { NextResponse } from 'next/server'

export async function GET() {
  try {
    // Get total counts
    const [
      totalArticles,
      totalMatches,
      totalUsers,
      liveMatches,
      todaysMatches,
      breakingNews,
    ] = await Promise.all([
      db.article.count(),
      db.match.count(),
      db.user.count(),
      db.match.count({
        where: {
          OR: [
            { status: 'live' },
            { status: 'halftime' },
          ],
        },
      }),
      db.match.count({
        where: {
          matchDate: {
            gte: new Date(new Date().setHours(0, 0, 0, 0)),
            lt: new Date(new Date().setHours(23, 59, 59, 999)),
          },
        },
      }),
      db.article.count({
        where: { isBreaking: true, status: 'published' },
      }),
    ])

    return NextResponse.json({
      stats: {
        totalArticles,
        totalMatches,
        totalUsers,
        liveMatches,
        todaysMatches,
        breakingNews,
      },
    })
  } catch (error) {
    console.error('Error fetching stats:', error)
    return NextResponse.json(
      { error: 'فشل في جلب الإحصائيات' },
      { status: 500 }
    )
  }
}
