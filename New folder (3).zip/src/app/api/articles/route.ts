import { db } from '@/lib/db'
import { NextRequest, NextResponse } from 'next/server'

export async function GET(request: NextRequest) {
  try {
    const { searchParams } = new URL(request.url)
    const category = searchParams.get('category')
    const status = searchParams.get('status') || 'published'
    const search = searchParams.get('search')
    const page = parseInt(searchParams.get('page') || '1')
    const limit = parseInt(searchParams.get('limit') || '10')
    const isBreaking = searchParams.get('isBreaking')
    const isFeatured = searchParams.get('isFeatured')

    const skip = (page - 1) * limit

    const where: Record<string, unknown> = {}

    // Filter by status - default to published only unless explicitly provided
    if (status) {
      where.status = status
    }

    // Filter by category
    if (category) {
      where.category = category
    }

    // Filter by breaking news
    if (isBreaking === 'true') {
      where.isBreaking = true
    }

    // Filter by featured
    if (isFeatured === 'true') {
      where.isFeatured = true
    }

    // Search by title or summary
    if (search) {
      where.OR = [
        { title: { contains: search } },
        { summary: { contains: search } },
        { content: { contains: search } },
      ]
    }

    const [articles, total] = await Promise.all([
      db.article.findMany({
        where,
        include: {
          author: {
            select: {
              id: true,
              name: true,
              avatar: true,
              role: true,
            },
          },
          tags: {
            select: {
              id: true,
              tag: true,
            },
          },
          teams: {
            include: {
              team: {
                select: {
                  id: true,
                  name: true,
                  nameEn: true,
                  shortName: true,
                  logo: true,
                },
              },
            },
          },
        },
        orderBy: { publishedAt: 'desc' },
        skip,
        take: limit,
      }),
      db.article.count({ where }),
    ])

    return NextResponse.json({
      articles,
      pagination: {
        page,
        limit,
        total,
        totalPages: Math.ceil(total / limit),
      },
    })
  } catch (error) {
    console.error('Error fetching articles:', error)
    return NextResponse.json(
      { error: 'فشل في جلب المقالات' },
      { status: 500 }
    )
  }
}
