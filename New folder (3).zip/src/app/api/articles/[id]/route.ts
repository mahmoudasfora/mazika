import { db } from '@/lib/db'
import { NextRequest, NextResponse } from 'next/server'

export async function GET(
  request: NextRequest,
  { params }: { params: Promise<{ id: string }> }
) {
  try {
    const { id } = await params

    const article = await db.article.findUnique({
      where: { id },
      include: {
        author: {
          select: {
            id: true,
            name: true,
            avatar: true,
            role: true,
            bio: true,
          },
        },
        tags: {
          select: {
            id: true,
            tag: true,
          },
        },
        teams: {
          include: {
            team: {
              select: {
                id: true,
                name: true,
                nameEn: true,
                shortName: true,
                logo: true,
                color: true,
              },
            },
          },
        },
        comments: {
          include: {
            user: {
              select: {
                id: true,
                name: true,
                avatar: true,
              },
            },
          },
          orderBy: { createdAt: 'desc' },
        },
      },
    })

    if (!article) {
      return NextResponse.json(
        { error: 'المقال غير موجود' },
        { status: 404 }
      )
    }

    // Increment views
    await db.article.update({
      where: { id },
      data: { views: { increment: 1 } },
    })

    return NextResponse.json({ article: { ...article, views: article.views + 1 } })
  } catch (error) {
    console.error('Error fetching article:', error)
    return NextResponse.json(
      { error: 'فشل في جلب المقال' },
      { status: 500 }
    )
  }
}

export async function PUT(
  request: NextRequest,
  { params }: { params: Promise<{ id: string }> }
) {
  try {
    const { id } = await params
    const body = await request.json()

    const {
      title,
      slug,
      summary,
      content,
      image,
      category,
      isBreaking,
      isFeatured,
      status,
      tags,
      teamIds,
    } = body

    // Check if article exists
    const existing = await db.article.findUnique({ where: { id } })
    if (!existing) {
      return NextResponse.json(
        { error: 'المقال غير موجود' },
        { status: 404 }
      )
    }

    // Update article
    const article = await db.article.update({
      where: { id },
      data: {
        ...(title !== undefined && { title }),
        ...(slug !== undefined && { slug }),
        ...(summary !== undefined && { summary }),
        ...(content !== undefined && { content }),
        ...(image !== undefined && { image }),
        ...(category !== undefined && { category }),
        ...(isBreaking !== undefined && { isBreaking }),
        ...(isFeatured !== undefined && { isFeatured }),
        ...(status !== undefined && {
          status,
          publishedAt: status === 'published' && !existing.publishedAt ? new Date() : existing.publishedAt,
        }),
      },
    })

    // Update tags if provided
    if (tags !== undefined) {
      await db.articleTag.deleteMany({ where: { articleId: id } })
      if (tags.length > 0) {
        await db.articleTag.createMany({
          data: tags.map((tag: string) => ({
            articleId: id,
            tag,
          })),
        })
      }
    }

    // Update teams if provided
    if (teamIds !== undefined) {
      await db.articleTeam.deleteMany({ where: { articleId: id } })
      if (teamIds.length > 0) {
        await db.articleTeam.createMany({
          data: teamIds.map((teamId: string) => ({
            articleId: id,
            teamId,
          })),
        })
      }
    }

    // Fetch updated article with relations
    const updatedArticle = await db.article.findUnique({
      where: { id },
      include: {
        author: {
          select: { id: true, name: true, avatar: true, role: true },
        },
        tags: { select: { id: true, tag: true } },
        teams: {
          include: {
            team: {
              select: { id: true, name: true, nameEn: true, logo: true },
            },
          },
        },
      },
    })

    return NextResponse.json({ article: updatedArticle })
  } catch (error) {
    console.error('Error updating article:', error)
    return NextResponse.json(
      { error: 'فشل في تحديث المقال' },
      { status: 500 }
    )
  }
}
