import { db } from '@/lib/db'
import { NextResponse } from 'next/server'

export async function GET() {
  try {
    const pages = await db.sitePage.findMany({
      orderBy: { createdAt: 'asc' },
    })
    return NextResponse.json({ pages })
  } catch (error) {
    return NextResponse.json({ error: 'فشل في جلب الصفحات' }, { status: 500 })
  }
}
