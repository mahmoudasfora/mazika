import { db } from '@/lib/db'
import { NextResponse } from 'next/server'

export async function GET(
  _request: Request,
  { params }: { params: Promise<{ slug: string }> }
) {
  try {
    const { slug } = await params
    const page = await db.sitePage.findUnique({
      where: { slug },
    })

    if (!page || !page.isPublished) {
      return NextResponse.json({ error: 'الصفحة غير موجودة' }, { status: 404 })
    }

    return NextResponse.json({ page })
  } catch (error) {
    return NextResponse.json({ error: 'فشل في جلب الصفحة' }, { status: 500 })
  }
}
