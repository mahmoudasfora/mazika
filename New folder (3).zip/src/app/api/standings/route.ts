import { db } from '@/lib/db'
import { NextRequest, NextResponse } from 'next/server'

export async function GET(request: NextRequest) {
  try {
    const { searchParams } = new URL(request.url)
    const leagueId = searchParams.get('leagueId')

    if (!leagueId) {
      return NextResponse.json(
        { error: 'معرّف البطولة مطلوب' },
        { status: 400 }
      )
    }

    const standings = await db.standing.findMany({
      where: { leagueId },
      include: {
        team: {
          select: {
            id: true,
            name: true,
            nameEn: true,
            shortName: true,
            logo: true,
            color: true,
          },
        },
        league: {
          select: {
            id: true,
            name: true,
            nameEn: true,
            season: true,
          },
        },
      },
      orderBy: { position: 'asc' },
    })

    return NextResponse.json({ standings })
  } catch (error) {
    console.error('Error fetching standings:', error)
    return NextResponse.json(
      { error: 'فشل في جلب الترتيب' },
      { status: 500 }
    )
  }
}
