import { NextRequest, NextResponse } from 'next/server'
import { db } from '@/lib/db'

// POST /api/ads/[id]/track - تتبع المشاهدات والنقرات
export async function POST(
  request: NextRequest,
  { params }: { params: Promise<{ id: string }> }
) {
  try {
    const { id } = await params
    const body = await request.json()
    const { type } = body // impression أو click

    if (!type || !['impression', 'click'].includes(type)) {
      return NextResponse.json({ error: 'نوع التتبع غير صالح' }, { status: 400 })
    }

    const ad = await db.adSlot.findUnique({ where: { id } })
    if (!ad) {
      return NextResponse.json({ error: 'الإعلان غير موجود' }, { status: 404 })
    }

    if (type === 'impression') {
      await db.adSlot.update({
        where: { id },
        data: { impressions: { increment: 1 } },
      })
    } else if (type === 'click') {
      await db.adSlot.update({
        where: { id },
        data: { clicks: { increment: 1 } },
      })
    }

    return NextResponse.json({ success: true })
  } catch (error) {
    console.error('Error tracking ad:', error)
    return NextResponse.json({ success: false }, { status: 500 })
  }
}
