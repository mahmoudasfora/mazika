import { NextRequest, NextResponse } from 'next/server'
import { db } from '@/lib/db'

// GET /api/ads - جلب الإعلانات النشطة للعرض العام
export async function GET(request: NextRequest) {
  try {
    const { searchParams } = new URL(request.url)
    const position = searchParams.get('position')
    const page = searchParams.get('page') || 'all' // home, news, article, matches, match_detail, all

    if (!position) {
      return NextResponse.json({ ads: [] })
    }

    const now = new Date()

    // استخدام AND لدمج شروط التاريخ بشكل صحيح
    const ads = await db.adSlot.findMany({
      where: {
        position,
        isActive: true,
        AND: [
          {
            OR: [
              { startDate: null },
              { startDate: { lte: now } },
            ],
          },
          {
            OR: [
              { endDate: null },
              { endDate: { gte: now } },
            ],
          },
        ],
      },
      orderBy: [
        { priority: 'desc' },
        { createdAt: 'desc' },
      ],
      take: 5, // أقصى 5 إعلانات لكل موضع
    })

    // فلترة حسب الصفحة المستهدفة
    const filteredAds = ads.filter(ad => {
      if (!ad.targetPages || ad.targetPages === 'all') return true
      const targetPagesList = ad.targetPages.split(',').map(p => p.trim())
      return targetPagesList.includes(page) || targetPagesList.includes('all')
    })

    return NextResponse.json({ ads: filteredAds })
  } catch (error) {
    console.error('Error fetching public ads:', error)
    return NextResponse.json({ ads: [] })
  }
}
