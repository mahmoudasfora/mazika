import { db } from '@/lib/db'
import { NextRequest, NextResponse } from 'next/server'

export async function GET(
  request: NextRequest,
  { params }: { params: Promise<{ id: string }> }
) {
  try {
    const { id } = await params

    const match = await db.match.findUnique({
      where: { id },
      include: {
        homeTeam: {
          select: {
            id: true,
            name: true,
            nameEn: true,
            shortName: true,
            logo: true,
            color: true,
            stadium: true,
          },
        },
        awayTeam: {
          select: {
            id: true,
            name: true,
            nameEn: true,
            shortName: true,
            logo: true,
            color: true,
          },
        },
        league: {
          select: {
            id: true,
            name: true,
            nameEn: true,
            logo: true,
            type: true,
            season: true,
          },
        },
        events: {
          include: {
            player: {
              select: {
                id: true,
                name: true,
                nameEn: true,
                photo: true,
                position: true,
                number: true,
              },
            },
            assistPlayer: {
              select: {
                id: true,
                name: true,
                nameEn: true,
              },
            },
          },
          orderBy: { minute: 'asc' },
        },
        lineups: {
          include: {
            player: {
              select: {
                id: true,
                name: true,
                nameEn: true,
                photo: true,
                position: true,
                number: true,
              },
            },
          },
          orderBy: [{ isStarter: 'desc' }, { shirtNumber: 'asc' }],
        },
      },
    })

    if (!match) {
      return NextResponse.json(
        { error: 'المباراة غير موجودة' },
        { status: 404 }
      )
    }

    return NextResponse.json({ match })
  } catch (error) {
    console.error('Error fetching match:', error)
    return NextResponse.json(
      { error: 'فشل في جلب المباراة' },
      { status: 500 }
    )
  }
}

export async function PUT(
  request: NextRequest,
  { params }: { params: Promise<{ id: string }> }
) {
  try {
    const { id } = await params
    const body = await request.json()

    // Check if match exists
    const existing = await db.match.findUnique({ where: { id } })
    if (!existing) {
      return NextResponse.json(
        { error: 'المباراة غير موجودة' },
        { status: 404 }
      )
    }

    const {
      homeScore,
      awayScore,
      status,
      homePossession,
      awayPossession,
      homeShots,
      awayShots,
      homeShotsOnTarget,
      awayShotsOnTarget,
      homeCorners,
      awayCorners,
      homeFouls,
      awayFouls,
      homeYellowCards,
      awayYellowCards,
      homeRedCards,
      awayRedCards,
      stadium,
      referee,
      broadcastChannels,
      matchReport,
    } = body

    const match = await db.match.update({
      where: { id },
      data: {
        ...(homeScore !== undefined && { homeScore }),
        ...(awayScore !== undefined && { awayScore }),
        ...(status !== undefined && { status }),
        ...(homePossession !== undefined && { homePossession }),
        ...(awayPossession !== undefined && { awayPossession }),
        ...(homeShots !== undefined && { homeShots }),
        ...(awayShots !== undefined && { awayShots }),
        ...(homeShotsOnTarget !== undefined && { homeShotsOnTarget }),
        ...(awayShotsOnTarget !== undefined && { awayShotsOnTarget }),
        ...(homeCorners !== undefined && { homeCorners }),
        ...(awayCorners !== undefined && { awayCorners }),
        ...(homeFouls !== undefined && { homeFouls }),
        ...(awayFouls !== undefined && { awayFouls }),
        ...(homeYellowCards !== undefined && { homeYellowCards }),
        ...(awayYellowCards !== undefined && { awayYellowCards }),
        ...(homeRedCards !== undefined && { homeRedCards }),
        ...(awayRedCards !== undefined && { awayRedCards }),
        ...(stadium !== undefined && { stadium }),
        ...(referee !== undefined && { referee }),
        ...(broadcastChannels !== undefined && { broadcastChannels }),
        ...(matchReport !== undefined && { matchReport }),
      },
      include: {
        homeTeam: {
          select: { id: true, name: true, nameEn: true, logo: true },
        },
        awayTeam: {
          select: { id: true, name: true, nameEn: true, logo: true },
        },
        league: {
          select: { id: true, name: true, nameEn: true, logo: true },
        },
      },
    })

    return NextResponse.json({ match })
  } catch (error) {
    console.error('Error updating match:', error)
    return NextResponse.json(
      { error: 'فشل في تحديث المباراة' },
      { status: 500 }
    )
  }
}
