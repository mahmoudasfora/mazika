import { db } from '@/lib/db'
import { NextRequest, NextResponse } from 'next/server'

export async function GET(request: NextRequest) {
  try {
    const { searchParams } = new URL(request.url)
    const status = searchParams.get('status')
    const leagueId = searchParams.get('leagueId')
    const date = searchParams.get('date') // YYYY-MM-DD format
    const teamId = searchParams.get('teamId')
    const includeEvents = searchParams.get('includeEvents') === '1'

    const where: Record<string, unknown> = {}

    if (status) {
      where.status = status
    }

    if (leagueId) {
      where.leagueId = leagueId
    }

    // Date filtering using string comparison (SQLite stores dates as strings)
    if (date) {
      const nextDay = new Date(date)
      nextDay.setDate(nextDay.getDate() + 1)
      const nextDayStr = nextDay.toISOString().split('T')[0]
      where.matchDate = {
        gte: new Date(date + 'T00:00:00.000Z'),
        lt: new Date(nextDayStr + 'T00:00:00.000Z'),
      }
    }

    // Default: today's matches if no filters provided (unless 'all' param is set)
    const allParam = searchParams.get('all')
    if (!status && !leagueId && !date && !teamId && allParam !== '1') {
      const today = new Date()
      const todayStr = today.toISOString().split('T')[0]
      const tomorrow = new Date(today)
      tomorrow.setDate(tomorrow.getDate() + 1)
      const tomorrowStr = tomorrow.toISOString().split('T')[0]
      where.matchDate = {
        gte: new Date(todayStr + 'T00:00:00.000Z'),
        lt: new Date(tomorrowStr + 'T00:00:00.000Z'),
      }
    }

    // Filter by team (home or away)
    if (teamId) {
      where.OR = [
        { homeTeamId: teamId },
        { awayTeamId: teamId },
      ]
    }

    // Determine ordering based on status
    const orderBy: Record<string, string> =
      status === 'finished'
        ? { matchDate: 'desc' }
        : { matchDate: 'asc' }

    // Build include object - only include events when explicitly requested
    const includeObj: Record<string, unknown> = {
      homeTeam: {
        select: {
          id: true,
          name: true,
          nameEn: true,
          shortName: true,
          logo: true,
          color: true,
        },
      },
      awayTeam: {
        select: {
          id: true,
          name: true,
          nameEn: true,
          shortName: true,
          logo: true,
          color: true,
        },
      },
      league: {
        select: {
          id: true,
          name: true,
          nameEn: true,
          logo: true,
          type: true,
        },
      },
    }

    if (includeEvents) {
      includeObj.events = {
        include: {
          player: {
            select: {
              id: true,
              name: true,
              nameEn: true,
              photo: true,
            },
          },
          assistPlayer: {
            select: {
              id: true,
              name: true,
              nameEn: true,
            },
          },
        },
        orderBy: { minute: 'asc' },
      }
    }

    const matches = await db.match.findMany({
      where,
      include: includeObj,
      orderBy,
    })

    return NextResponse.json({ matches })
  } catch (error) {
    console.error('Error fetching matches:', error)
    return NextResponse.json(
      { error: 'فشل في جلب المباريات' },
      { status: 500 }
    )
  }
}
