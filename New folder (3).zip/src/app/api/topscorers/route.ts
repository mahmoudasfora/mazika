import { db } from '@/lib/db'
import { NextRequest, NextResponse } from 'next/server'

export async function GET(request: NextRequest) {
  try {
    const { searchParams } = new URL(request.url)
    const leagueId = searchParams.get('leagueId')

    if (!leagueId) {
      return NextResponse.json(
        { error: 'معرّف البطولة مطلوب' },
        { status: 400 }
      )
    }

    const topScorers = await db.topScorer.findMany({
      where: { leagueId },
      include: {
        player: {
          select: {
            id: true,
            name: true,
            nameEn: true,
            photo: true,
            position: true,
            number: true,
            nationality: true,
          },
        },
        team: {
          select: {
            id: true,
            name: true,
            nameEn: true,
            shortName: true,
            logo: true,
          },
        },
        league: {
          select: {
            id: true,
            name: true,
            nameEn: true,
          },
        },
      },
      orderBy: { goals: 'desc' },
    })

    return NextResponse.json({ topScorers })
  } catch (error) {
    console.error('Error fetching top scorers:', error)
    return NextResponse.json(
      { error: 'فشل في جلب الهدافين' },
      { status: 500 }
    )
  }
}
