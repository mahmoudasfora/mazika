import { NextResponse } from 'next/server'
import { db } from '@/lib/db'

export async function GET(request: Request) {
  try {
    const { searchParams } = new URL(request.url)
    const teamId = searchParams.get('teamId')
    const limit = parseInt(searchParams.get('limit') || '100')

    const where = teamId ? { teamId } : {}

    const players = await db.player.findMany({
      where,
      include: {
        team: {
          select: { id: true, name: true, color: true }
        }
      },
      orderBy: [
        { goals: 'desc' },
        { name: 'asc' }
      ],
      take: limit,
    })

    return NextResponse.json({ players })
  } catch (error) {
    console.error('Error fetching players:', error)
    return NextResponse.json({ error: 'Failed to fetch players' }, { status: 500 })
  }
}
