import { db } from '@/lib/db'
import { NextRequest, NextResponse } from 'next/server'

export async function GET(request: NextRequest) {
  try {
    const { searchParams } = new URL(request.url)
    const leagueId = searchParams.get('leagueId')

    const where: Record<string, unknown> = {}

    if (leagueId) {
      where.leagueTeams = {
        some: { leagueId },
      }
    }

    const teams = await db.team.findMany({
      where,
      include: {
        _count: {
          select: { players: true },
        },
        ...(leagueId
          ? {
              leagueTeams: {
                where: { leagueId },
                select: { leagueId: true },
              },
            }
          : {}),
      },
      orderBy: { name: 'asc' },
    })

    const teamsWithPlayerCount = teams.map((team) => ({
      id: team.id,
      name: team.name,
      nameEn: team.nameEn,
      shortName: team.shortName,
      logo: team.logo,
      country: team.country,
      city: team.city,
      stadium: team.stadium,
      founded: team.founded,
      color: team.color,
      playerCount: team._count.players,
    }))

    return NextResponse.json({ teams: teamsWithPlayerCount })
  } catch (error) {
    console.error('Error fetching teams:', error)
    return NextResponse.json(
      { error: 'فشل في جلب الفرق' },
      { status: 500 }
    )
  }
}
