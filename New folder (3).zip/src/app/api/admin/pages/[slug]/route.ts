import { db } from '@/lib/db'
import { NextResponse } from 'next/server'

export async function PUT(
  request: Request,
  { params }: { params: Promise<{ slug: string }> }
) {
  try {
    const { slug } = await params
    const body = await request.json()
    const { title, content, metaDescription, isPublished } = body

    const page = await db.sitePage.update({
      where: { slug },
      data: {
        ...(title !== undefined && { title }),
        ...(content !== undefined && { content }),
        ...(metaDescription !== undefined && { metaDescription }),
        ...(isPublished !== undefined && { isPublished }),
      },
    })

    return NextResponse.json({ page })
  } catch (error: any) {
    if (error.code === 'P2025') {
      return NextResponse.json({ error: 'الصفحة غير موجودة' }, { status: 404 })
    }
    return NextResponse.json({ error: 'فشل في تحديث الصفحة' }, { status: 500 })
  }
}

export async function DELETE(
  _request: Request,
  { params }: { params: Promise<{ slug: string }> }
) {
  try {
    const { slug } = await params
    await db.sitePage.delete({ where: { slug } })
    return NextResponse.json({ success: true })
  } catch (error: any) {
    if (error.code === 'P2025') {
      return NextResponse.json({ error: 'الصفحة غير موجودة' }, { status: 404 })
    }
    return NextResponse.json({ error: 'فشل في حذف الصفحة' }, { status: 500 })
  }
}
