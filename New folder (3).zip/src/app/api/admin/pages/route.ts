import { db } from '@/lib/db'
import { NextResponse } from 'next/server'

export async function GET() {
  try {
    const pages = await db.sitePage.findMany({
      orderBy: { createdAt: 'asc' },
    })
    return NextResponse.json({ pages })
  } catch (error) {
    return NextResponse.json({ error: 'فشل في جلب الصفحات' }, { status: 500 })
  }
}

export async function POST(request: Request) {
  try {
    const body = await request.json()
    const { slug, title, content, metaDescription, isPublished } = body

    if (!slug || !title || !content) {
      return NextResponse.json({ error: 'البيانات مطلوبة' }, { status: 400 })
    }

    const page = await db.sitePage.create({
      data: { slug, title, content, metaDescription, isPublished: isPublished ?? true },
    })

    return NextResponse.json({ page }, { status: 201 })
  } catch (error: any) {
    if (error.code === 'P2002') {
      return NextResponse.json({ error: 'هذا الرابط مستخدم بالفعل' }, { status: 409 })
    }
    return NextResponse.json({ error: 'فشل في إنشاء الصفحة' }, { status: 500 })
  }
}
