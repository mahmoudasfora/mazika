import { NextRequest, NextResponse } from 'next/server'
import { db } from '@/lib/db'

// GET /api/admin/ads - جلب جميع الإعلانات
export async function GET(request: NextRequest) {
  try {
    const { searchParams } = new URL(request.url)
    const position = searchParams.get('position')
    const isActive = searchParams.get('isActive')

    const where: any = {}
    if (position) where.position = position
    if (isActive !== null && isActive !== undefined) {
      where.isActive = isActive === 'true'
    }

    const ads = await db.adSlot.findMany({
      where,
      orderBy: [
        { priority: 'desc' },
        { createdAt: 'desc' },
      ],
    })

    // حساب الإحصائيات
    const stats = {
      totalAds: ads.length,
      activeAds: ads.filter(a => a.isActive).length,
      totalImpressions: ads.reduce((sum, a) => sum + a.impressions, 0),
      totalClicks: ads.reduce((sum, a) => sum + a.clicks, 0),
      avgCtr: ads.length > 0
        ? (ads.reduce((sum, a) => sum + (a.impressions > 0 ? (a.clicks / a.impressions) * 100 : 0), 0) / ads.length).toFixed(2)
        : '0.00',
    }

    return NextResponse.json({ ads, stats })
  } catch (error) {
    console.error('Error fetching ads:', error)
    return NextResponse.json({ error: 'فشل في جلب الإعلانات' }, { status: 500 })
  }
}

// POST /api/admin/ads - إنشاء إعلان جديد
export async function POST(request: NextRequest) {
  try {
    const body = await request.json()
    const {
      title,
      position,
      type = 'image',
      advertiser,
      imageUrl,
      linkUrl,
      content,
      isActive = true,
      priority = 0,
      targetPages = 'all',
      width,
      height,
      startDate,
      endDate,
    } = body

    if (!title || !position) {
      return NextResponse.json(
        { error: 'عنوان الإعلان والموضع مطلوبان' },
        { status: 400 }
      )
    }

    const ad = await db.adSlot.create({
      data: {
        title,
        position,
        type,
        advertiser: advertiser || null,
        imageUrl: imageUrl || null,
        linkUrl: linkUrl || null,
        content: content || null,
        isActive,
        priority: Number(priority),
        targetPages: targetPages || 'all',
        width: width || null,
        height: height || null,
        startDate: startDate ? new Date(startDate) : null,
        endDate: endDate ? new Date(endDate) : null,
      },
    })

    return NextResponse.json({ ad }, { status: 201 })
  } catch (error) {
    console.error('Error creating ad:', error)
    return NextResponse.json({ error: 'فشل في إنشاء الإعلان' }, { status: 500 })
  }
}
