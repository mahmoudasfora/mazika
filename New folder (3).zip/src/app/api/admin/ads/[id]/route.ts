import { NextRequest, NextResponse } from 'next/server'
import { db } from '@/lib/db'

// GET /api/admin/ads/[id] - جلب إعلان واحد
export async function GET(
  request: NextRequest,
  { params }: { params: Promise<{ id: string }> }
) {
  try {
    const { id } = await params
    const ad = await db.adSlot.findUnique({ where: { id } })

    if (!ad) {
      return NextResponse.json({ error: 'الإعلان غير موجود' }, { status: 404 })
    }

    return NextResponse.json({ ad })
  } catch (error) {
    console.error('Error fetching ad:', error)
    return NextResponse.json({ error: 'فشل في جلب الإعلان' }, { status: 500 })
  }
}

// PATCH /api/admin/ads/[id] - تحديث إعلان
export async function PATCH(
  request: NextRequest,
  { params }: { params: Promise<{ id: string }> }
) {
  try {
    const { id } = await params
    const body = await request.json()

    const existingAd = await db.adSlot.findUnique({ where: { id } })
    if (!existingAd) {
      return NextResponse.json({ error: 'الإعلان غير موجود' }, { status: 404 })
    }

    const updateData: any = {}
    const allowedFields = [
      'title', 'position', 'type', 'advertiser', 'imageUrl',
      'linkUrl', 'content', 'isActive', 'priority', 'targetPages',
      'width', 'height',
    ]

    for (const field of allowedFields) {
      if (body[field] !== undefined) {
        if (field === 'priority') {
          updateData[field] = Number(body[field])
        } else {
          updateData[field] = body[field]
        }
      }
    }

    if (body.startDate !== undefined) {
      updateData.startDate = body.startDate ? new Date(body.startDate) : null
    }
    if (body.endDate !== undefined) {
      updateData.endDate = body.endDate ? new Date(body.endDate) : null
    }

    const ad = await db.adSlot.update({
      where: { id },
      data: updateData,
    })

    return NextResponse.json({ ad })
  } catch (error) {
    console.error('Error updating ad:', error)
    return NextResponse.json({ error: 'فشل في تحديث الإعلان' }, { status: 500 })
  }
}

// DELETE /api/admin/ads/[id] - حذف إعلان
export async function DELETE(
  request: NextRequest,
  { params }: { params: Promise<{ id: string }> }
) {
  try {
    const { id } = await params

    const existingAd = await db.adSlot.findUnique({ where: { id } })
    if (!existingAd) {
      return NextResponse.json({ error: 'الإعلان غير موجود' }, { status: 404 })
    }

    await db.adSlot.delete({ where: { id } })

    return NextResponse.json({ success: true })
  } catch (error) {
    console.error('Error deleting ad:', error)
    return NextResponse.json({ error: 'فشل في حذف الإعلان' }, { status: 500 })
  }
}
