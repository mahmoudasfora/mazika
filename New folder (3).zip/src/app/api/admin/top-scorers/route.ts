import { db } from '@/lib/db'
import { NextRequest, NextResponse } from 'next/server'

// GET: جلب جميع الهدافين
export async function GET(request: NextRequest) {
  try {
    const { searchParams } = new URL(request.url)
    const leagueId = searchParams.get('leagueId')
    const page = parseInt(searchParams.get('page') || '1')
    const limit = parseInt(searchParams.get('limit') || '50')
    const skip = (page - 1) * limit

    // بناء شروط البحث
    const where: Record<string, unknown> = {}
    if (leagueId) {
      where.leagueId = leagueId
    }

    const [topScorers, total] = await Promise.all([
      db.topScorer.findMany({
        where,
        include: {
          player: {
            select: {
              id: true,
              name: true,
              nameEn: true,
              photo: true,
              position: true,
              nationality: true,
            },
          },
          team: {
            select: {
              id: true,
              name: true,
              nameEn: true,
              shortName: true,
              logo: true,
            },
          },
          league: {
            select: {
              id: true,
              name: true,
              nameEn: true,
              logo: true,
              country: true,
            },
          },
        },
        orderBy: [{ leagueId: 'asc' }, { goals: 'desc' }],
        skip,
        take: limit,
      }),
      db.topScorer.count({ where }),
    ])

    return NextResponse.json({
      topScorers,
      pagination: {
        page,
        limit,
        total,
        totalPages: Math.ceil(total / limit),
      },
    })
  } catch (error) {
    console.error('Error fetching top scorers:', error)
    return NextResponse.json(
      { error: 'فشل في جلب قائمة الهدافين' },
      { status: 500 }
    )
  }
}

// POST: إنشاء سجل هداف جديد
export async function POST(request: NextRequest) {
  try {
    const body = await request.json()
    const { leagueId, playerId, teamId, goals, assists, penaltyGoals } = body

    // التحقق من الحقول المطلوبة
    if (!leagueId) {
      return NextResponse.json(
        { error: 'معرّف الدوري مطلوب' },
        { status: 400 }
      )
    }
    if (!playerId) {
      return NextResponse.json(
        { error: 'معرّف اللاعب مطلوب' },
        { status: 400 }
      )
    }
    if (!teamId) {
      return NextResponse.json(
        { error: 'معرّف الفريق مطلوب' },
        { status: 400 }
      )
    }

    // التحقق من وجود الدوري
    const league = await db.league.findUnique({ where: { id: leagueId } })
    if (!league) {
      return NextResponse.json(
        { error: 'الدوري غير موجود' },
        { status: 404 }
      )
    }

    // التحقق من وجود اللاعب
    const player = await db.player.findUnique({ where: { id: playerId } })
    if (!player) {
      return NextResponse.json(
        { error: 'اللاعب غير موجود' },
        { status: 404 }
      )
    }

    // التحقق من وجود الفريق
    const team = await db.team.findUnique({ where: { id: teamId } })
    if (!team) {
      return NextResponse.json(
        { error: 'الفريق غير موجود' },
        { status: 404 }
      )
    }

    // التحقق من عدم وجود سجل مكرر (نفس الدوري واللاعب)
    const existingScorer = await db.topScorer.findUnique({
      where: {
        leagueId_playerId: {
          leagueId,
          playerId,
        },
      },
    })
    if (existingScorer) {
      return NextResponse.json(
        { error: 'يوجد سجل هداف لهذا اللاعب في هذا الدوري بالفعل' },
        { status: 409 }
      )
    }

    const topScorer = await db.topScorer.create({
      data: {
        leagueId,
        playerId,
        teamId,
        goals: goals ? parseInt(String(goals)) : 0,
        assists: assists ? parseInt(String(assists)) : 0,
        penaltyGoals: penaltyGoals ? parseInt(String(penaltyGoals)) : 0,
      },
      include: {
        player: {
          select: {
            id: true,
            name: true,
            nameEn: true,
            photo: true,
            position: true,
            nationality: true,
          },
        },
        team: {
          select: {
            id: true,
            name: true,
            nameEn: true,
            shortName: true,
            logo: true,
          },
        },
        league: {
          select: {
            id: true,
            name: true,
            nameEn: true,
            logo: true,
            country: true,
          },
        },
      },
    })

    return NextResponse.json({ topScorer }, { status: 201 })
  } catch (error) {
    console.error('Error creating top scorer:', error)
    return NextResponse.json(
      { error: 'فشل في إنشاء سجل الهداف' },
      { status: 500 }
    )
  }
}

// PUT: تحديث سجل هداف
export async function PUT(request: NextRequest) {
  try {
    const body = await request.json()
    const { id, goals, assists, penaltyGoals } = body

    if (!id) {
      return NextResponse.json(
        { error: 'معرّف سجل الهداف مطلوب' },
        { status: 400 }
      )
    }

    // التحقق من وجود السجل
    const existing = await db.topScorer.findUnique({ where: { id } })
    if (!existing) {
      return NextResponse.json(
        { error: 'سجل الهداف غير موجود' },
        { status: 404 }
      )
    }

    // بناء بيانات التحديث
    const updateData: Record<string, unknown> = {}
    if (goals !== undefined) {
      updateData.goals = parseInt(String(goals))
    }
    if (assists !== undefined) {
      updateData.assists = parseInt(String(assists))
    }
    if (penaltyGoals !== undefined) {
      updateData.penaltyGoals = parseInt(String(penaltyGoals))
    }

    if (Object.keys(updateData).length === 0) {
      return NextResponse.json(
        { error: 'لم يتم توفير أي بيانات للتحديث' },
        { status: 400 }
      )
    }

    const topScorer = await db.topScorer.update({
      where: { id },
      data: updateData,
      include: {
        player: {
          select: {
            id: true,
            name: true,
            nameEn: true,
            photo: true,
            position: true,
            nationality: true,
          },
        },
        team: {
          select: {
            id: true,
            name: true,
            nameEn: true,
            shortName: true,
            logo: true,
          },
        },
        league: {
          select: {
            id: true,
            name: true,
            nameEn: true,
            logo: true,
            country: true,
          },
        },
      },
    })

    return NextResponse.json({ topScorer })
  } catch (error) {
    console.error('Error updating top scorer:', error)
    return NextResponse.json(
      { error: 'فشل في تحديث سجل الهداف' },
      { status: 500 }
    )
  }
}

// DELETE: حذف سجل هداف
export async function DELETE(request: NextRequest) {
  try {
    const { searchParams } = new URL(request.url)
    const id = searchParams.get('id')

    if (!id) {
      return NextResponse.json(
        { error: 'معرّف سجل الهداف مطلوب' },
        { status: 400 }
      )
    }

    // التحقق من وجود السجل
    const existing = await db.topScorer.findUnique({ where: { id } })
    if (!existing) {
      return NextResponse.json(
        { error: 'سجل الهداف غير موجود' },
        { status: 404 }
      )
    }

    await db.topScorer.delete({ where: { id } })

    return NextResponse.json({ success: true, message: 'تم حذف سجل الهداف بنجاح' })
  } catch (error) {
    console.error('Error deleting top scorer:', error)
    return NextResponse.json(
      { error: 'فشل في حذف سجل الهداف' },
      { status: 500 }
    )
  }
}
