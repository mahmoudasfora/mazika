import { db } from '@/lib/db'
import { NextRequest, NextResponse } from 'next/server'

export async function DELETE(
  request: NextRequest,
  { params }: { params: Promise<{ id: string }> }
) {
  try {
    const { id } = await params

    const existing = await db.match.findUnique({ where: { id } })
    if (!existing) {
      return NextResponse.json({ error: 'المباراة غير موجودة' }, { status: 404 })
    }

    // Delete related records first (cascade should handle this, but be safe)
    await db.matchEvent.deleteMany({ where: { matchId: id } })
    await db.matchLineup.deleteMany({ where: { matchId: id } })
    await db.prediction.deleteMany({ where: { matchId: id } })
    await db.userFavorite.deleteMany({ where: { matchId: id } })

    await db.match.delete({ where: { id } })

    return NextResponse.json({ success: true })
  } catch (error) {
    console.error('Error deleting match:', error)
    return NextResponse.json({ error: 'فشل في حذف المباراة' }, { status: 500 })
  }
}
