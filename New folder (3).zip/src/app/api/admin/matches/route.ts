import { db } from '@/lib/db'
import { NextRequest, NextResponse } from 'next/server'

export async function POST(request: NextRequest) {
  try {
    const body = await request.json()

    const {
      homeTeamId,
      awayTeamId,
      leagueId,
      matchDate,
      stadium,
      referee,
      round,
      matchday,
      broadcastChannels,
      streamUrl,
    } = body

    // Validate required fields
    if (!homeTeamId || !awayTeamId || !leagueId || !matchDate) {
      return NextResponse.json(
        { error: 'معرّف الفريق المضيف والضيف والبطولة وتاريخ المباراة حقول مطلوبة' },
        { status: 400 }
      )
    }

    // Verify teams and league exist
    const [homeTeam, awayTeam, league] = await Promise.all([
      db.team.findUnique({ where: { id: homeTeamId } }),
      db.team.findUnique({ where: { id: awayTeamId } }),
      db.league.findUnique({ where: { id: leagueId } }),
    ])

    if (!homeTeam) {
      return NextResponse.json(
        { error: 'الفريق المضيف غير موجود' },
        { status: 404 }
      )
    }
    if (!awayTeam) {
      return NextResponse.json(
        { error: 'الفريق الضيف غير موجود' },
        { status: 404 }
      )
    }
    if (!league) {
      return NextResponse.json(
        { error: 'البطولة غير موجودة' },
        { status: 404 }
      )
    }

    const match = await db.match.create({
      data: {
        homeTeamId,
        awayTeamId,
        leagueId,
        matchDate: new Date(matchDate),
        stadium,
        referee,
        round,
        matchday,
        broadcastChannels,
        streamUrl,
      },
      include: {
        homeTeam: {
          select: { id: true, name: true, nameEn: true, logo: true },
        },
        awayTeam: {
          select: { id: true, name: true, nameEn: true, logo: true },
        },
        league: {
          select: { id: true, name: true, nameEn: true, logo: true },
        },
      },
    })

    return NextResponse.json({ match }, { status: 201 })
  } catch (error) {
    console.error('Error creating match:', error)
    return NextResponse.json(
      { error: 'فشل في إنشاء المباراة' },
      { status: 500 }
    )
  }
}

export async function PUT(request: NextRequest) {
  try {
    const body = await request.json()

    const {
      id,
      homeTeamId,
      awayTeamId,
      leagueId,
      matchDate,
      homeScore,
      awayScore,
      status,
      stadium,
      referee,
      round,
      matchday,
      homePossession,
      awayPossession,
      homeShots,
      awayShots,
      homeShotsOnTarget,
      awayShotsOnTarget,
      homeCorners,
      awayCorners,
      homeFouls,
      awayFouls,
      homeYellowCards,
      awayYellowCards,
      homeRedCards,
      awayRedCards,
      broadcastChannels,
      streamUrl,
      matchReport,
    } = body

    if (!id) {
      return NextResponse.json(
        { error: 'معرّف المباراة مطلوب' },
        { status: 400 }
      )
    }

    // Check if match exists
    const existing = await db.match.findUnique({ where: { id } })
    if (!existing) {
      return NextResponse.json(
        { error: 'المباراة غير موجودة' },
        { status: 404 }
      )
    }

    const match = await db.match.update({
      where: { id },
      data: {
        ...(homeTeamId !== undefined && { homeTeamId }),
        ...(awayTeamId !== undefined && { awayTeamId }),
        ...(leagueId !== undefined && { leagueId }),
        ...(matchDate !== undefined && { matchDate: new Date(matchDate) }),
        ...(homeScore !== undefined && { homeScore }),
        ...(awayScore !== undefined && { awayScore }),
        ...(status !== undefined && { status }),
        ...(stadium !== undefined && { stadium }),
        ...(referee !== undefined && { referee }),
        ...(round !== undefined && { round }),
        ...(matchday !== undefined && { matchday }),
        ...(homePossession !== undefined && { homePossession }),
        ...(awayPossession !== undefined && { awayPossession }),
        ...(homeShots !== undefined && { homeShots }),
        ...(awayShots !== undefined && { awayShots }),
        ...(homeShotsOnTarget !== undefined && { homeShotsOnTarget }),
        ...(awayShotsOnTarget !== undefined && { awayShotsOnTarget }),
        ...(homeCorners !== undefined && { homeCorners }),
        ...(awayCorners !== undefined && { awayCorners }),
        ...(homeFouls !== undefined && { homeFouls }),
        ...(awayFouls !== undefined && { awayFouls }),
        ...(homeYellowCards !== undefined && { homeYellowCards }),
        ...(awayYellowCards !== undefined && { awayYellowCards }),
        ...(homeRedCards !== undefined && { homeRedCards }),
        ...(awayRedCards !== undefined && { awayRedCards }),
        ...(broadcastChannels !== undefined && { broadcastChannels }),
        ...(streamUrl !== undefined && { streamUrl }),
        ...(matchReport !== undefined && { matchReport }),
      },
      include: {
        homeTeam: {
          select: { id: true, name: true, nameEn: true, logo: true },
        },
        awayTeam: {
          select: { id: true, name: true, nameEn: true, logo: true },
        },
        league: {
          select: { id: true, name: true, nameEn: true, logo: true },
        },
      },
    })

    return NextResponse.json({ match })
  } catch (error) {
    console.error('Error updating match:', error)
    return NextResponse.json(
      { error: 'فشل في تحديث المباراة' },
      { status: 500 }
    )
  }
}
