import { db } from '@/lib/db'
import { NextRequest, NextResponse } from 'next/server'

// أنواع الإشعارات المسموحة
const VALID_NOTIFICATION_TYPES = ['match_start', 'goal', 'breaking_news', 'general'] as const
type NotificationType = (typeof VALID_NOTIFICATION_TYPES)[number]

// واجهة بيانات الإشعار
interface NotificationData {
  title: string
  message: string
  type: NotificationType
  matchId?: string
  createdAt: string
}

// GET: جلب قائمة الإشعارات المخزنة
export async function GET(request: NextRequest) {
  try {
    const { searchParams } = new URL(request.url)
    const type = searchParams.get('type')
    const page = parseInt(searchParams.get('page') || '1')
    const limit = parseInt(searchParams.get('limit') || '20')
    const skip = (page - 1) * limit

    // جلب جميع الإشعارات من SiteSetting
    const notificationSettings = await db.siteSetting.findMany({
      where: {
        key: {
          startsWith: 'notification_',
        },
      },
      orderBy: { id: 'desc' },
    })

    // تحليل بيانات الإشعارات
    let notifications: (NotificationData & { id: string; key: string })[] = []
    for (const setting of notificationSettings) {
      try {
        const data: NotificationData = JSON.parse(setting.value)
        // فلترة حسب النوع إذا تم تحديده
        if (type && data.type !== type) continue
        notifications.push({
          id: setting.id,
          key: setting.key,
          ...data,
        })
      } catch {
        // تخطي السجلات التالفة
        console.warn(`تنبيه: فشل تحليل بيانات الإشعار بالمفتاح ${setting.key}`)
      }
    }

    const total = notifications.length
    const paginatedNotifications = notifications.slice(skip, skip + limit)

    return NextResponse.json({
      notifications: paginatedNotifications,
      pagination: {
        page,
        limit,
        total,
        totalPages: Math.ceil(total / limit),
      },
    })
  } catch (error) {
    console.error('Error fetching notifications:', error)
    return NextResponse.json(
      { error: 'فشل في جلب الإشعارات' },
      { status: 500 }
    )
  }
}

// POST: إنشاء وإرسال إشعار جديد
export async function POST(request: NextRequest) {
  try {
    const body = await request.json()
    const { title, message, type, matchId } = body

    // التحقق من الحقول المطلوبة
    if (!title || typeof title !== 'string' || title.trim().length === 0) {
      return NextResponse.json(
        { error: 'عنوان الإشعار مطلوب' },
        { status: 400 }
      )
    }

    if (!message || typeof message !== 'string' || message.trim().length === 0) {
      return NextResponse.json(
        { error: 'نص الإشعار مطلوب' },
        { status: 400 }
      )
    }

    // التحقق من نوع الإشعار
    const notificationType: NotificationType = type || 'general'
    if (!VALID_NOTIFICATION_TYPES.includes(notificationType)) {
      return NextResponse.json(
        {
          error: `نوع الإشعار غير صالح. الأنواع المسموحة: ${VALID_NOTIFICATION_TYPES.join('، ')}`,
        },
        { status: 400 }
      )
    }

    // التحقق من وجود المباراة إذا تم تحديد matchId
    if (matchId) {
      const match = await db.match.findUnique({ where: { id: matchId } })
      if (!match) {
        return NextResponse.json(
          { error: 'المباراة المحددة غير موجودة' },
          { status: 404 }
        )
      }
    }

    // إنشاء مفتاح فريد للإشعار باستخدام الطابع الزمني
    const timestamp = Date.now()
    const key = `notification_${timestamp}`

    // بيانات الإشعار
    const notificationData: NotificationData = {
      title: title.trim(),
      message: message.trim(),
      type: notificationType,
      ...(matchId && { matchId }),
      createdAt: new Date().toISOString(),
    }

    // تخزين الإشعار في SiteSetting
    const setting = await db.siteSetting.create({
      data: {
        key,
        value: JSON.stringify(notificationData),
      },
    })

    return NextResponse.json(
      {
        notification: {
          id: setting.id,
          key: setting.key,
          ...notificationData,
        },
      },
      { status: 201 }
    )
  } catch (error) {
    console.error('Error creating notification:', error)
    return NextResponse.json(
      { error: 'فشل في إنشاء الإشعار' },
      { status: 500 }
    )
  }
}

// DELETE: حذف إشعار
export async function DELETE(request: NextRequest) {
  try {
    const { searchParams } = new URL(request.url)
    const key = searchParams.get('key')

    if (!key) {
      return NextResponse.json(
        { error: 'مفتاح الإشعار مطلوب' },
        { status: 400 }
      )
    }

    // حذف الإشعار من SiteSetting
    const deleted = await db.siteSetting.deleteMany({
      where: { key },
    })

    if (deleted.count === 0) {
      return NextResponse.json(
        { error: 'الإشعار غير موجود' },
        { status: 404 }
      )
    }

    return NextResponse.json({ success: true })
  } catch (error) {
    console.error('Error deleting notification:', error)
    return NextResponse.json(
      { error: 'فشل في حذف الإشعار' },
      { status: 500 }
    )
  }
}
