import { db } from '@/lib/db'
import { NextRequest, NextResponse } from 'next/server'

export async function GET(request: NextRequest) {
  try {
    const { searchParams } = new URL(request.url)
    const matchId = searchParams.get('matchId')

    const where: Record<string, unknown> = {}
    if (matchId) where.matchId = matchId

    const predictions = await db.prediction.findMany({
      where,
      include: {
        user: {
          select: {
            id: true,
            name: true,
            avatar: true,
            email: true,
          },
        },
        match: {
          include: {
            homeTeam: {
              select: {
                id: true,
                name: true,
                shortName: true,
                color: true,
              },
            },
            awayTeam: {
              select: {
                id: true,
                name: true,
                shortName: true,
                color: true,
              },
            },
          },
        },
      },
      orderBy: { id: 'desc' },
      take: 200,
    })

    return NextResponse.json({ predictions })
  } catch (error) {
    console.error('Error fetching predictions:', error)
    return NextResponse.json(
      { error: 'فشل في جلب التوقعات' },
      { status: 500 }
    )
  }
}

export async function DELETE(request: NextRequest) {
  try {
    const { searchParams } = new URL(request.url)
    const id = searchParams.get('id')

    if (!id) {
      return NextResponse.json(
        { error: 'معرّف التوقع مطلوب' },
        { status: 400 }
      )
    }

    const existing = await db.prediction.findUnique({ where: { id } })
    if (!existing) {
      return NextResponse.json(
        { error: 'التوقع غير موجود' },
        { status: 404 }
      )
    }

    await db.prediction.delete({ where: { id } })

    return NextResponse.json({ success: true, message: 'تم حذف التوقع بنجاح' })
  } catch (error) {
    console.error('Error deleting prediction:', error)
    return NextResponse.json(
      { error: 'فشل في حذف التوقع' },
      { status: 500 }
    )
  }
}
