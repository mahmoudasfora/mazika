import { db } from '@/lib/db'
import { NextRequest, NextResponse } from 'next/server'

export async function POST(request: NextRequest) {
  try {
    const body = await request.json()

    const {
      name,
      nameEn,
      country,
      logo,
      type,
      season,
      isActive,
      order,
    } = body

    if (!name) {
      return NextResponse.json(
        { error: 'اسم البطولة مطلوب' },
        { status: 400 }
      )
    }

    const league = await db.league.create({
      data: {
        name,
        nameEn,
        country,
        logo,
        type: type || 'league',
        season,
        isActive: isActive !== undefined ? isActive : true,
        order: order || 0,
      },
    })

    return NextResponse.json({ league }, { status: 201 })
  } catch (error) {
    console.error('Error creating league:', error)
    return NextResponse.json(
      { error: 'فشل في إنشاء البطولة' },
      { status: 500 }
    )
  }
}

export async function PUT(request: NextRequest) {
  try {
    const body = await request.json()

    const {
      id,
      name,
      nameEn,
      country,
      logo,
      type,
      season,
      isActive,
      order,
    } = body

    if (!id) {
      return NextResponse.json(
        { error: 'معرّف البطولة مطلوب' },
        { status: 400 }
      )
    }

    const existing = await db.league.findUnique({ where: { id } })
    if (!existing) {
      return NextResponse.json(
        { error: 'البطولة غير موجودة' },
        { status: 404 }
      )
    }

    const league = await db.league.update({
      where: { id },
      data: {
        ...(name !== undefined && { name }),
        ...(nameEn !== undefined && { nameEn }),
        ...(country !== undefined && { country }),
        ...(logo !== undefined && { logo }),
        ...(type !== undefined && { type }),
        ...(season !== undefined && { season }),
        ...(isActive !== undefined && { isActive }),
        ...(order !== undefined && { order }),
      },
    })

    return NextResponse.json({ league })
  } catch (error) {
    console.error('Error updating league:', error)
    return NextResponse.json(
      { error: 'فشل في تحديث البطولة' },
      { status: 500 }
    )
  }
}

export async function DELETE(request: NextRequest) {
  try {
    const body = await request.json()
    const { id } = body

    if (!id) {
      return NextResponse.json(
        { error: 'معرّف البطولة مطلوب' },
        { status: 400 }
      )
    }

    const existing = await db.league.findUnique({ where: { id } })
    if (!existing) {
      return NextResponse.json(
        { error: 'البطولة غير موجودة' },
        { status: 404 }
      )
    }

    await db.league.delete({ where: { id } })

    return NextResponse.json({ success: true })
  } catch (error) {
    console.error('Error deleting league:', error)
    return NextResponse.json(
      { error: 'فشل في حذف البطولة' },
      { status: 500 }
    )
  }
}
