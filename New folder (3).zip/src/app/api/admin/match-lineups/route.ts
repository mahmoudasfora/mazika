import { db } from '@/lib/db'
import { NextRequest, NextResponse } from 'next/server'

// POST - Add a player to match lineup (single player)
export async function POST(request: NextRequest) {
  try {
    const body = await request.json()
    const { matchId, teamId, playerId, position, isStarter, shirtNumber } = body

    if (!matchId || !teamId || !playerId) {
      return NextResponse.json(
        { error: 'معرّف المباراة والفريق واللاعب حقول مطلوبة' },
        { status: 400 }
      )
    }

    // Verify match exists
    const match = await db.match.findUnique({ where: { id: matchId } })
    if (!match) {
      return NextResponse.json({ error: 'المباراة غير موجودة' }, { status: 404 })
    }

    // Check for duplicate lineup entry
    const existing = await db.matchLineup.findFirst({
      where: { matchId, playerId },
    })
    if (existing) {
      return NextResponse.json({ error: 'اللاعب موجود بالفعل في التشكيل' }, { status: 400 })
    }

    const lineup = await db.matchLineup.create({
      data: {
        matchId,
        teamId,
        playerId,
        position: position || null,
        isStarter: isStarter !== undefined ? isStarter : true,
        shirtNumber: shirtNumber || null,
      },
      include: {
        player: {
          select: { id: true, name: true, nameEn: true, photo: true, position: true, number: true },
        },
      },
    })

    return NextResponse.json({ lineup }, { status: 201 })
  } catch (error) {
    console.error('Error creating lineup entry:', error)
    return NextResponse.json({ error: 'فشل في إضافة اللاعب للتشكيل' }, { status: 500 })
  }
}

// PUT - Update a lineup entry
export async function PUT(request: NextRequest) {
  try {
    const body = await request.json()
    const { id, position, isStarter, shirtNumber } = body

    if (!id) {
      return NextResponse.json({ error: 'معرّف التشكيل مطلوب' }, { status: 400 })
    }

    const existing = await db.matchLineup.findUnique({ where: { id } })
    if (!existing) {
      return NextResponse.json({ error: 'سجل التشكيل غير موجود' }, { status: 404 })
    }

    const lineup = await db.matchLineup.update({
      where: { id },
      data: {
        ...(position !== undefined && { position }),
        ...(isStarter !== undefined && { isStarter }),
        ...(shirtNumber !== undefined && { shirtNumber }),
      },
      include: {
        player: {
          select: { id: true, name: true, nameEn: true, photo: true, position: true, number: true },
        },
      },
    })

    return NextResponse.json({ lineup })
  } catch (error) {
    console.error('Error updating lineup entry:', error)
    return NextResponse.json({ error: 'فشل في تحديث التشكيل' }, { status: 500 })
  }
}

// DELETE - Remove a player from lineup
export async function DELETE(request: NextRequest) {
  try {
    const { searchParams } = new URL(request.url)
    const id = searchParams.get('id')

    if (!id) {
      return NextResponse.json({ error: 'معرّف التشكيل مطلوب' }, { status: 400 })
    }

    const existing = await db.matchLineup.findUnique({ where: { id } })
    if (!existing) {
      return NextResponse.json({ error: 'سجل التشكيل غير موجود' }, { status: 404 })
    }

    await db.matchLineup.delete({ where: { id } })

    return NextResponse.json({ success: true })
  } catch (error) {
    console.error('Error deleting lineup entry:', error)
    return NextResponse.json({ error: 'فشل في حذف اللاعب من التشكيل' }, { status: 500 })
  }
}
