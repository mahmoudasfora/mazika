import { db } from '@/lib/db'
import { NextRequest, NextResponse } from 'next/server'

// GET: جلب جميع الترتيبات مجمعة حسب الدوري
export async function GET(request: NextRequest) {
  try {
    const { searchParams } = new URL(request.url)
    const leagueId = searchParams.get('leagueId')
    const season = searchParams.get('season')

    // بناء شروط البحث
    const where: Record<string, unknown> = {}
    if (leagueId) {
      where.leagueId = leagueId
    }
    if (season) {
      where.season = season
    }

    const standings = await db.standing.findMany({
      where,
      include: {
        team: {
          select: {
            id: true,
            name: true,
            shortName: true,
            logo: true,
            color: true,
          },
        },
        league: {
          select: {
            id: true,
            name: true,
            nameEn: true,
            logo: true,
            country: true,
          },
        },
      },
      orderBy: [{ leagueId: 'asc' }, { position: 'asc' }],
    })

    // تجميع الترتيبات حسب الدوري
    const groupedByLeague = standings.reduce(
      (acc, standing) => {
        const leagueKey = standing.leagueId
        if (!acc[leagueKey]) {
          acc[leagueKey] = {
            league: standing.league,
            standings: [],
          }
        }
        acc[leagueKey].standings.push(standing)
        return acc
      },
      {} as Record<
        string,
        {
          league: {
            id: string
            name: string
            nameEn: string | null
            logo: string | null
            country: string | null
          }
          standings: typeof standings
        }
      >
    )

    // تحويل الكائن إلى مصفوفة
    const result = Object.values(groupedByLeague)

    return NextResponse.json({ standings: result, total: standings.length })
  } catch (error) {
    console.error('Error fetching standings:', error)
    return NextResponse.json(
      { error: 'فشل في جلب الترتيبات' },
      { status: 500 }
    )
  }
}

// POST: إنشاء سجل ترتيب جديد
export async function POST(request: NextRequest) {
  try {
    const body = await request.json()
    const {
      leagueId,
      teamId,
      season,
      position,
      played,
      won,
      drawn,
      lost,
      goalsFor,
      goalsAgainst,
      goalDifference,
      points,
      form,
    } = body

    // التحقق من الحقول المطلوبة
    if (!leagueId) {
      return NextResponse.json(
        { error: 'معرّف الدوري مطلوب' },
        { status: 400 }
      )
    }
    if (!teamId) {
      return NextResponse.json(
        { error: 'معرّف الفريق مطلوب' },
        { status: 400 }
      )
    }
    if (position === undefined || position === null) {
      return NextResponse.json(
        { error: 'الترتيب مطلوب' },
        { status: 400 }
      )
    }

    // التحقق من وجود الدوري
    const league = await db.league.findUnique({ where: { id: leagueId } })
    if (!league) {
      return NextResponse.json(
        { error: 'الدوري غير موجود' },
        { status: 404 }
      )
    }

    // التحقق من وجود الفريق
    const team = await db.team.findUnique({ where: { id: teamId } })
    if (!team) {
      return NextResponse.json(
        { error: 'الفريق غير موجود' },
        { status: 404 }
      )
    }

    // التحقق من عدم وجود سجل مكرر (نفس الدوري والفريق)
    const existingStanding = await db.standing.findUnique({
      where: {
        leagueId_teamId: {
          leagueId,
          teamId,
        },
      },
    })
    if (existingStanding) {
      return NextResponse.json(
        { error: 'يوجد سجل ترتيب لهذا الفريق في هذا الدوري بالفعل' },
        { status: 409 }
      )
    }

    const standing = await db.standing.create({
      data: {
        leagueId,
        teamId,
        season,
        position: parseInt(String(position)),
        played: played ? parseInt(String(played)) : 0,
        won: won ? parseInt(String(won)) : 0,
        drawn: drawn ? parseInt(String(drawn)) : 0,
        lost: lost ? parseInt(String(lost)) : 0,
        goalsFor: goalsFor ? parseInt(String(goalsFor)) : 0,
        goalsAgainst: goalsAgainst ? parseInt(String(goalsAgainst)) : 0,
        goalDifference: goalDifference ? parseInt(String(goalDifference)) : 0,
        points: points ? parseInt(String(points)) : 0,
        form,
      },
      include: {
        team: {
          select: {
            id: true,
            name: true,
            shortName: true,
            logo: true,
            color: true,
          },
        },
        league: {
          select: {
            id: true,
            name: true,
            nameEn: true,
            logo: true,
            country: true,
          },
        },
      },
    })

    return NextResponse.json({ standing }, { status: 201 })
  } catch (error) {
    console.error('Error creating standing:', error)
    return NextResponse.json(
      { error: 'فشل في إنشاء سجل الترتيب' },
      { status: 500 }
    )
  }
}

// PUT: تحديث سجل ترتيب
export async function PUT(request: NextRequest) {
  try {
    const body = await request.json()
    const {
      id,
      position,
      played,
      won,
      drawn,
      lost,
      goalsFor,
      goalsAgainst,
      goalDifference,
      points,
      form,
    } = body

    if (!id) {
      return NextResponse.json(
        { error: 'معرّف سجل الترتيب مطلوب' },
        { status: 400 }
      )
    }

    // التحقق من وجود السجل
    const existing = await db.standing.findUnique({ where: { id } })
    if (!existing) {
      return NextResponse.json(
        { error: 'سجل الترتيب غير موجود' },
        { status: 404 }
      )
    }

    // بناء بيانات التحديث
    const updateData: Record<string, unknown> = {}
    if (position !== undefined) {
      updateData.position = parseInt(String(position))
    }
    if (played !== undefined) {
      updateData.played = parseInt(String(played))
    }
    if (won !== undefined) {
      updateData.won = parseInt(String(won))
    }
    if (drawn !== undefined) {
      updateData.drawn = parseInt(String(drawn))
    }
    if (lost !== undefined) {
      updateData.lost = parseInt(String(lost))
    }
    if (goalsFor !== undefined) {
      updateData.goalsFor = parseInt(String(goalsFor))
    }
    if (goalsAgainst !== undefined) {
      updateData.goalsAgainst = parseInt(String(goalsAgainst))
    }
    if (goalDifference !== undefined) {
      updateData.goalDifference = parseInt(String(goalDifference))
    }
    if (points !== undefined) {
      updateData.points = parseInt(String(points))
    }
    if (form !== undefined) {
      updateData.form = form
    }

    if (Object.keys(updateData).length === 0) {
      return NextResponse.json(
        { error: 'لم يتم توفير أي بيانات للتحديث' },
        { status: 400 }
      )
    }

    const standing = await db.standing.update({
      where: { id },
      data: updateData,
      include: {
        team: {
          select: {
            id: true,
            name: true,
            shortName: true,
            logo: true,
            color: true,
          },
        },
        league: {
          select: {
            id: true,
            name: true,
            nameEn: true,
            logo: true,
            country: true,
          },
        },
      },
    })

    return NextResponse.json({ standing })
  } catch (error) {
    console.error('Error updating standing:', error)
    return NextResponse.json(
      { error: 'فشل في تحديث سجل الترتيب' },
      { status: 500 }
    )
  }
}

// DELETE: حذف سجل ترتيب
export async function DELETE(request: NextRequest) {
  try {
    const { searchParams } = new URL(request.url)
    const id = searchParams.get('id')

    if (!id) {
      return NextResponse.json(
        { error: 'معرّف سجل الترتيب مطلوب' },
        { status: 400 }
      )
    }

    // التحقق من وجود السجل
    const existing = await db.standing.findUnique({ where: { id } })
    if (!existing) {
      return NextResponse.json(
        { error: 'سجل الترتيب غير موجود' },
        { status: 404 }
      )
    }

    await db.standing.delete({ where: { id } })

    return NextResponse.json({ success: true, message: 'تم حذف سجل الترتيب بنجاح' })
  } catch (error) {
    console.error('Error deleting standing:', error)
    return NextResponse.json(
      { error: 'فشل في حذف سجل الترتيب' },
      { status: 500 }
    )
  }
}
