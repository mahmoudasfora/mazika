import { db } from '@/lib/db'
import { NextRequest, NextResponse } from 'next/server'

export async function POST(request: NextRequest) {
  try {
    const body = await request.json()

    const {
      name,
      nameEn,
      shortName,
      logo,
      country,
      city,
      stadium,
      founded,
      color,
    } = body

    if (!name) {
      return NextResponse.json(
        { error: 'اسم الفريق مطلوب' },
        { status: 400 }
      )
    }

    const team = await db.team.create({
      data: {
        name,
        nameEn,
        shortName,
        logo,
        country,
        city,
        stadium,
        founded,
        color,
      },
    })

    return NextResponse.json({ team }, { status: 201 })
  } catch (error) {
    console.error('Error creating team:', error)
    return NextResponse.json(
      { error: 'فشل في إنشاء الفريق' },
      { status: 500 }
    )
  }
}

export async function PUT(request: NextRequest) {
  try {
    const body = await request.json()

    const {
      id,
      name,
      nameEn,
      shortName,
      logo,
      country,
      city,
      stadium,
      founded,
      color,
    } = body

    if (!id) {
      return NextResponse.json(
        { error: 'معرّف الفريق مطلوب' },
        { status: 400 }
      )
    }

    const existing = await db.team.findUnique({ where: { id } })
    if (!existing) {
      return NextResponse.json(
        { error: 'الفريق غير موجود' },
        { status: 404 }
      )
    }

    const team = await db.team.update({
      where: { id },
      data: {
        ...(name !== undefined && { name }),
        ...(nameEn !== undefined && { nameEn }),
        ...(shortName !== undefined && { shortName }),
        ...(logo !== undefined && { logo }),
        ...(country !== undefined && { country }),
        ...(city !== undefined && { city }),
        ...(stadium !== undefined && { stadium }),
        ...(founded !== undefined && { founded }),
        ...(color !== undefined && { color }),
      },
    })

    return NextResponse.json({ team })
  } catch (error) {
    console.error('Error updating team:', error)
    return NextResponse.json(
      { error: 'فشل في تحديث الفريق' },
      { status: 500 }
    )
  }
}

export async function DELETE(request: NextRequest) {
  try {
    const body = await request.json()
    const { id } = body

    if (!id) {
      return NextResponse.json(
        { error: 'معرّف الفريق مطلوب' },
        { status: 400 }
      )
    }

    const existing = await db.team.findUnique({ where: { id } })
    if (!existing) {
      return NextResponse.json(
        { error: 'الفريق غير موجود' },
        { status: 404 }
      )
    }

    await db.team.delete({ where: { id } })

    return NextResponse.json({ success: true })
  } catch (error) {
    console.error('Error deleting team:', error)
    return NextResponse.json(
      { error: 'فشل في حذف الفريق' },
      { status: 500 }
    )
  }
}
