import { NextResponse } from 'next/server'
import { db } from '@/lib/db'

export async function POST(request: Request) {
  try {
    const body = await request.json()
    const { name, nameEn, position, number, goals, assists, teamId, age, nationality } = body

    if (!name || !teamId) {
      return NextResponse.json({ error: 'Name and teamId are required' }, { status: 400 })
    }

    const player = await db.player.create({
      data: {
        name,
        nameEn: nameEn || null,
        position: position || null,
        number: number || null,
        goals: goals || 0,
        assists: assists || 0,
        teamId,
        age: age || null,
        nationality: nationality || null,
      },
      include: {
        team: { select: { id: true, name: true, color: true } }
      }
    })

    return NextResponse.json({ player }, { status: 201 })
  } catch (error) {
    console.error('Error creating player:', error)
    return NextResponse.json({ error: 'Failed to create player' }, { status: 500 })
  }
}

export async function PUT(request: Request) {
  try {
    const body = await request.json()
    const { id, name, nameEn, position, number, goals, assists, teamId, age, nationality } = body

    if (!id) {
      return NextResponse.json({ error: 'Player ID is required' }, { status: 400 })
    }

    const player = await db.player.update({
      where: { id },
      data: {
        ...(name !== undefined && { name }),
        ...(nameEn !== undefined && { nameEn }),
        ...(position !== undefined && { position }),
        ...(number !== undefined && { number }),
        ...(goals !== undefined && { goals }),
        ...(assists !== undefined && { assists }),
        ...(teamId !== undefined && { teamId }),
        ...(age !== undefined && { age }),
        ...(nationality !== undefined && { nationality }),
      },
      include: {
        team: { select: { id: true, name: true, color: true } }
      }
    })

    return NextResponse.json({ player })
  } catch (error) {
    console.error('Error updating player:', error)
    return NextResponse.json({ error: 'Failed to update player' }, { status: 500 })
  }
}

export async function DELETE(request: Request) {
  try {
    const body = await request.json()
    const { id } = body

    if (!id) {
      return NextResponse.json({ error: 'Player ID is required' }, { status: 400 })
    }

    await db.player.delete({ where: { id } })

    return NextResponse.json({ success: true })
  } catch (error) {
    console.error('Error deleting player:', error)
    return NextResponse.json({ error: 'Failed to delete player' }, { status: 500 })
  }
}
