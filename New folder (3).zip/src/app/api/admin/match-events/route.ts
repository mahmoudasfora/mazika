import { db } from '@/lib/db'
import { NextRequest, NextResponse } from 'next/server'

// POST - Create a new match event
export async function POST(request: NextRequest) {
  try {
    const body = await request.json()
    const { matchId, type, minute, team, playerId, assistPlayerId, detail } = body

    if (!matchId || !type || minute === undefined || !team) {
      return NextResponse.json(
        { error: 'معرّف المباراة ونوع الحدث والدقيقة والفريق حقول مطلوبة' },
        { status: 400 }
      )
    }

    // Verify match exists
    const match = await db.match.findUnique({ where: { id: matchId } })
    if (!match) {
      return NextResponse.json({ error: 'المباراة غير موجودة' }, { status: 404 })
    }

    // If it's a goal, update the score
    if (type === 'goal' || type === 'penalty') {
      const updateData: Record<string, number> = {}
      if (team === 'home') {
        updateData.homeScore = (match.homeScore || 0) + 1
      } else {
        updateData.awayScore = (match.awayScore || 0) + 1
      }
      await db.match.update({ where: { id: matchId }, data: updateData })
    }

    // If it's an own_goal, update score for opposing team
    if (type === 'own_goal') {
      const updateData: Record<string, number> = {}
      if (team === 'home') {
        updateData.awayScore = (match.awayScore || 0) + 1
      } else {
        updateData.homeScore = (match.homeScore || 0) + 1
      }
      await db.match.update({ where: { id: matchId }, data: updateData })
    }

    // If halftime or fulltime event, update match status
    if (type === 'halftime') {
      await db.match.update({ where: { id: matchId }, data: { status: 'halftime' } })
    }
    if (type === 'fulltime') {
      await db.match.update({ where: { id: matchId }, data: { status: 'finished' } })
    }

    const event = await db.matchEvent.create({
      data: {
        matchId,
        type,
        minute: parseInt(minute),
        team,
        playerId: playerId || null,
        assistPlayerId: assistPlayerId || null,
        detail: detail || null,
      },
      include: {
        player: {
          select: { id: true, name: true, nameEn: true, photo: true, position: true, number: true },
        },
        assistPlayer: {
          select: { id: true, name: true, nameEn: true },
        },
      },
    })

    return NextResponse.json({ event }, { status: 201 })
  } catch (error) {
    console.error('Error creating match event:', error)
    return NextResponse.json({ error: 'فشل في إنشاء الحدث' }, { status: 500 })
  }
}

// PUT - Update a match event
export async function PUT(request: NextRequest) {
  try {
    const body = await request.json()
    const { id, type, minute, team, playerId, assistPlayerId, detail } = body

    if (!id) {
      return NextResponse.json({ error: 'معرّف الحدث مطلوب' }, { status: 400 })
    }

    const existing = await db.matchEvent.findUnique({ where: { id } })
    if (!existing) {
      return NextResponse.json({ error: 'الحدث غير موجود' }, { status: 404 })
    }

    const event = await db.matchEvent.update({
      where: { id },
      data: {
        ...(type !== undefined && { type }),
        ...(minute !== undefined && { minute: parseInt(minute) }),
        ...(team !== undefined && { team }),
        ...(playerId !== undefined && { playerId }),
        ...(assistPlayerId !== undefined && { assistPlayerId }),
        ...(detail !== undefined && { detail }),
      },
      include: {
        player: {
          select: { id: true, name: true, nameEn: true, photo: true, position: true, number: true },
        },
        assistPlayer: {
          select: { id: true, name: true, nameEn: true },
        },
      },
    })

    return NextResponse.json({ event })
  } catch (error) {
    console.error('Error updating match event:', error)
    return NextResponse.json({ error: 'فشل في تحديث الحدث' }, { status: 500 })
  }
}

// DELETE - Delete a match event
export async function DELETE(request: NextRequest) {
  try {
    const { searchParams } = new URL(request.url)
    const id = searchParams.get('id')

    if (!id) {
      return NextResponse.json({ error: 'معرّف الحدث مطلوب' }, { status: 400 })
    }

    const existing = await db.matchEvent.findUnique({ where: { id } })
    if (!existing) {
      return NextResponse.json({ error: 'الحدث غير موجود' }, { status: 404 })
    }

    // If deleting a goal, decrease the score
    if (existing.type === 'goal' || existing.type === 'penalty') {
      const match = await db.match.findUnique({ where: { id: existing.matchId } })
      if (match) {
        const updateData: Record<string, number> = {}
        if (existing.team === 'home') {
          updateData.homeScore = Math.max(0, (match.homeScore || 0) - 1)
        } else {
          updateData.awayScore = Math.max(0, (match.awayScore || 0) - 1)
        }
        await db.match.update({ where: { id: existing.matchId }, data: updateData })
      }
    }

    if (existing.type === 'own_goal') {
      const match = await db.match.findUnique({ where: { id: existing.matchId } })
      if (match) {
        const updateData: Record<string, number> = {}
        if (existing.team === 'home') {
          updateData.awayScore = Math.max(0, (match.awayScore || 0) - 1)
        } else {
          updateData.homeScore = Math.max(0, (match.homeScore || 0) - 1)
        }
        await db.match.update({ where: { id: existing.matchId }, data: updateData })
      }
    }

    await db.matchEvent.delete({ where: { id } })

    return NextResponse.json({ success: true })
  } catch (error) {
    console.error('Error deleting match event:', error)
    return NextResponse.json({ error: 'فشل في حذف الحدث' }, { status: 500 })
  }
}
