import { db } from '@/lib/db'
import { NextRequest, NextResponse } from 'next/server'

export async function POST(request: NextRequest) {
  try {
    const body = await request.json()

    const {
      title,
      slug,
      summary,
      content,
      image,
      category,
      isBreaking,
      isFeatured,
      status,
      authorId,
      tags = [],
      teamIds = [],
    } = body

    // Validate required fields
    if (!title || !slug || !content || !authorId) {
      return NextResponse.json(
        { error: 'العنوان والرابط والمحتوى ومعرّف الكاتب حقول مطلوبة' },
        { status: 400 }
      )
    }

    // Check for duplicate slug
    const existingSlug = await db.article.findUnique({ where: { slug } })
    if (existingSlug) {
      return NextResponse.json(
        { error: 'رابط المقال مستخدم بالفعل' },
        { status: 409 }
      )
    }

    // Create article
    const article = await db.article.create({
      data: {
        title,
        slug,
        summary,
        content,
        image,
        category: category || 'general',
        isBreaking: isBreaking || false,
        isFeatured: isFeatured || false,
        status: status || 'draft',
        authorId,
        publishedAt: status === 'published' ? new Date() : null,
        tags: {
          create: tags.map((tag: string) => ({ tag })),
        },
        teams: {
          create: teamIds.map((teamId: string) => ({ teamId })),
        },
      },
      include: {
        author: {
          select: { id: true, name: true, avatar: true, role: true },
        },
        tags: { select: { id: true, tag: true } },
        teams: {
          include: {
            team: {
              select: { id: true, name: true, nameEn: true, logo: true },
            },
          },
        },
      },
    })

    return NextResponse.json({ article }, { status: 201 })
  } catch (error) {
    console.error('Error creating article:', error)
    return NextResponse.json(
      { error: 'فشل في إنشاء المقال' },
      { status: 500 }
    )
  }
}
