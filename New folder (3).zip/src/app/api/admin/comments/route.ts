import { db } from '@/lib/db'
import { NextRequest, NextResponse } from 'next/server'

// GET: قائمة التعليقات مع فلاتر اختيارية
export async function GET(request: NextRequest) {
  try {
    const { searchParams } = new URL(request.url)
    const articleId = searchParams.get('articleId')
    const isApproved = searchParams.get('isApproved')
    const search = searchParams.get('search')
    const page = parseInt(searchParams.get('page') || '1')
    const limit = parseInt(searchParams.get('limit') || '20')
    const skip = (page - 1) * limit

    // بناء شروط البحث
    const where: Record<string, unknown> = {}

    if (articleId) {
      where.articleId = articleId
    }

    if (isApproved !== null && isApproved !== undefined && isApproved !== '') {
      where.isApproved = isApproved === 'true'
    }

    if (search) {
      where.content = {
        contains: search,
      }
    }

    const [comments, total] = await Promise.all([
      db.comment.findMany({
        where,
        include: {
          user: {
            select: {
              id: true,
              name: true,
              avatar: true,
            },
          },
          article: {
            select: {
              id: true,
              title: true,
            },
          },
        },
        orderBy: { createdAt: 'desc' },
        skip,
        take: limit,
      }),
      db.comment.count({ where }),
    ])

    return NextResponse.json({
      comments,
      pagination: {
        page,
        limit,
        total,
        totalPages: Math.ceil(total / limit),
      },
    })
  } catch (error) {
    console.error('Error fetching comments:', error)
    return NextResponse.json(
      { error: 'فشل في جلب التعليقات' },
      { status: 500 }
    )
  }
}

// PUT: تحديث تعليق (اعتماد/رفض أو تعديل المحتوى)
export async function PUT(request: NextRequest) {
  try {
    const body = await request.json()
    const { id, isApproved, content } = body

    if (!id) {
      return NextResponse.json(
        { error: 'معرّف التعليق مطلوب' },
        { status: 400 }
      )
    }

    // التحقق من وجود التعليق
    const existing = await db.comment.findUnique({ where: { id } })
    if (!existing) {
      return NextResponse.json(
        { error: 'التعليق غير موجود' },
        { status: 404 }
      )
    }

    // بناء بيانات التحديث
    const updateData: Record<string, unknown> = {}
    if (isApproved !== undefined) {
      updateData.isApproved = isApproved
    }
    if (content !== undefined) {
      if (typeof content !== 'string' || content.trim().length === 0) {
        return NextResponse.json(
          { error: 'محتوى التعليق لا يمكن أن يكون فارغاً' },
          { status: 400 }
        )
      }
      updateData.content = content.trim()
    }

    if (Object.keys(updateData).length === 0) {
      return NextResponse.json(
        { error: 'لم يتم توفير أي بيانات للتحديث' },
        { status: 400 }
      )
    }

    const comment = await db.comment.update({
      where: { id },
      data: updateData,
      include: {
        user: {
          select: {
            id: true,
            name: true,
            avatar: true,
          },
        },
        article: {
          select: {
            id: true,
            title: true,
          },
        },
      },
    })

    return NextResponse.json({ comment })
  } catch (error) {
    console.error('Error updating comment:', error)
    return NextResponse.json(
      { error: 'فشل في تحديث التعليق' },
      { status: 500 }
    )
  }
}

// DELETE: حذف تعليق
export async function DELETE(request: NextRequest) {
  try {
    const { searchParams } = new URL(request.url)
    const id = searchParams.get('id')

    if (!id) {
      return NextResponse.json(
        { error: 'معرّف التعليق مطلوب' },
        { status: 400 }
      )
    }

    // التحقق من وجود التعليق
    const existing = await db.comment.findUnique({ where: { id } })
    if (!existing) {
      return NextResponse.json(
        { error: 'التعليق غير موجود' },
        { status: 404 }
      )
    }

    await db.comment.delete({ where: { id } })

    return NextResponse.json({ success: true, message: 'تم حذف التعليق بنجاح' })
  } catch (error) {
    console.error('Error deleting comment:', error)
    return NextResponse.json(
      { error: 'فشل في حذف التعليق' },
      { status: 500 }
    )
  }
}
