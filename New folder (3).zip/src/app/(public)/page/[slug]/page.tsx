'use client'

import { useEffect, useState } from 'react'
import { use } from 'react'
import { useRouter } from 'next/navigation'
import Link from 'next/link'
import { Card, CardContent } from '@/components/ui/card'
import { Badge } from '@/components/ui/badge'
import { Skeleton } from '@/components/ui/skeleton'
import { Button } from '@/components/ui/button'
import {
  ArrowRight,
  FileText,
  Clock,
  Home,
  ChevronLeft,
  Users,
  Shield,
  ScrollText,
  Phone,
  Mail,
  MapPin,
  Globe,
  CheckCircle2,
} from 'lucide-react'

interface SitePageData {
  id: string
  slug: string
  title: string
  content: string
  metaDescription: string | null
  isPublished: boolean
  updatedAt: string
}

// Page-specific configuration
const pageConfig: Record<string, {
  icon: React.ReactNode
  color: string
  bgGradient: string
  description: string
}> = {
  about: {
    icon: <Users className="size-7" />,
    color: 'emerald',
    bgGradient: 'from-emerald-600 via-teal-600 to-emerald-700',
    description: 'تعرفوا على منصتنا وفريقنا ورؤيتنا لمستقبل الرياضة العربية',
  },
  privacy: {
    icon: <Shield className="size-7" />,
    color: 'blue',
    bgGradient: 'from-blue-600 via-indigo-600 to-blue-700',
    description: 'كيف نجمع ونستخدم ونحمي بياناتكم الشخصية',
  },
  terms: {
    icon: <ScrollText className="size-7" />,
    color: 'amber',
    bgGradient: 'from-amber-600 via-orange-600 to-amber-700',
    description: 'الشروط والأحكام المنظمة لاستخدام منصة سبورت بلس',
  },
  contact: {
    icon: <Phone className="size-7" />,
    color: 'purple',
    bgGradient: 'from-purple-600 via-violet-600 to-purple-700',
    description: 'نحن هنا لمساعدتكم - تواصلوا معنا في أي وقت',
  },
}

const slugTitles: Record<string, string> = {
  about: 'من نحن',
  privacy: 'سياسة الخصوصية',
  terms: 'شروط الاستخدام',
  contact: 'اتصل بنا',
}

// Enhanced markdown-like renderer
function renderContent(content: string, slug: string) {
  const lines = content.split('\n')
  const elements: React.ReactNode[] = []
  let key = 0
  let inList = false

  for (let i = 0; i < lines.length; i++) {
    const line = lines[i].trim()

    if (!line) {
      if (inList) {
        elements.push(<ul key={`ul-end-${key++}`} className="space-y-2 mb-4 mr-6 list-none">{}</ul>)
        inList = false
      }
      continue
    }

    // ## heading - main section
    if (line.startsWith('## ')) {
      if (inList) { inList = false }
      elements.push(
        <div key={key++} className="flex items-center gap-3 mt-10 mb-4 first:mt-0">
          <div className="w-1.5 h-8 bg-emerald-500 rounded-full" />
          <h2 className="text-2xl md:text-3xl font-bold text-foreground">
            {line.slice(3)}
          </h2>
        </div>
      )
      continue
    }

    // ### heading - sub section
    if (line.startsWith('### ')) {
      if (inList) { inList = false }
      elements.push(
        <h3 key={key++} className="text-xl md:text-2xl font-bold text-foreground/90 mt-8 mb-3 flex items-center gap-2">
          <CheckCircle2 className="size-5 text-emerald-500 shrink-0" />
          {line.slice(4)}
        </h3>
      )
      continue
    }

    // list item with ** support
    if (line.startsWith('- ')) {
      if (!inList) {
        inList = true
        // Collect all consecutive list items
        const listItems: React.ReactNode[] = []
        let j = i
        while (j < lines.length && lines[j].trim().startsWith('- ')) {
          const itemText = lines[j].trim().slice(2)
          listItems.push(
            <li key={`li-${key++}-${j}`} className="flex items-start gap-3 py-1.5">
              <div className="size-2 rounded-full bg-emerald-500 mt-2.5 shrink-0" />
              <span className="text-foreground/90 leading-7 text-base md:text-lg">
                {renderInline(itemText)}
              </span>
            </li>
          )
          j++
        }
        elements.push(
          <ul key={`ul-${key++}`} className="space-y-1 mb-4 mr-2 list-none">
            {listItems}
          </ul>
        )
        // Skip the items we already processed
        i = j - 1
        inList = false
        continue
      }
      continue
    }

    // paragraph with inline formatting
    if (inList) { inList = false }
    elements.push(
      <p key={key++} className="text-foreground/85 leading-8 text-base md:text-lg mb-3">
        {renderInline(line)}
      </p>
    )
  }

  return elements
}

function renderInline(text: string): React.ReactNode[] {
  const parts: React.ReactNode[] = []
  let key = 0
  let remaining = text

  const boldRegex = /\*\*(.+?)\*\*/g
  let lastIndex = 0
  let match

  while ((match = boldRegex.exec(remaining)) !== null) {
    if (match.index > lastIndex) {
      parts.push(remaining.slice(lastIndex, match.index))
    }
    parts.push(
      <strong key={key++} className="font-bold text-foreground">
        {match[1]}
      </strong>
    )
    lastIndex = match.index + match[0].length
  }

  if (lastIndex < remaining.length) {
    parts.push(remaining.slice(lastIndex))
  }

  return parts.length > 0 ? parts : [text]
}

// Quick links for sidebar
const quickLinks = [
  { slug: 'about', label: 'من نحن', icon: <Users className="size-4" /> },
  { slug: 'privacy', label: 'سياسة الخصوصية', icon: <Shield className="size-4" /> },
  { slug: 'terms', label: 'شروط الاستخدام', icon: <ScrollText className="size-4" /> },
  { slug: 'contact', label: 'اتصل بنا', icon: <Phone className="size-4" /> },
]

export default function SitePage({ params }: { params: Promise<{ slug: string }> }) {
  const { slug } = use(params)
  const [page, setPage] = useState<SitePageData | null>(null)
  const [loading, setLoading] = useState(true)
  const [error, setError] = useState<string | null>(null)
  const router = useRouter()
  const config = pageConfig[slug] || pageConfig.about

  useEffect(() => {
    async function fetchPage() {
      try {
        setLoading(true)
        const res = await fetch(`/api/pages/${slug}`)
        if (!res.ok) throw new Error('الصفحة غير موجودة')
        const data = await res.json()
        setPage(data.page)
      } catch {
        setError('الصفحة غير موجودة')
      } finally {
        setLoading(false)
      }
    }
    fetchPage()
  }, [slug])

  if (loading) {
    return (
      <div className="space-y-6" dir="rtl">
        <Skeleton className="h-48 w-full rounded-2xl" />
        <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
          <div className="lg:col-span-2 space-y-4">
            <Skeleton className="h-8 w-48" />
            <Skeleton className="h-6 w-full" />
            <Skeleton className="h-6 w-3/4" />
            <Skeleton className="h-6 w-full" />
            <Skeleton className="h-6 w-2/3" />
          </div>
          <Skeleton className="h-64 rounded-xl" />
        </div>
      </div>
    )
  }

  if (error || !page) {
    return (
      <div className="space-y-4 text-center py-20" dir="rtl">
        <div className="size-24 rounded-full bg-muted flex items-center justify-center mx-auto mb-4">
          <FileText className="size-10 text-muted-foreground/40" />
        </div>
        <h2 className="text-2xl font-bold text-foreground">الصفحة غير موجودة</h2>
        <p className="text-muted-foreground max-w-md mx-auto">الصفحة التي تبحث عنها غير متوفرة أو تم نقلها إلى عنوان آخر</p>
        <Button onClick={() => router.push('/')} className="gap-2 bg-emerald-600 hover:bg-emerald-700 text-white mt-4">
          <ArrowRight className="size-4" />
          العودة للرئيسية
        </Button>
      </div>
    )
  }

  return (
    <div className="space-y-0 -mx-4 -my-6" dir="rtl">
      {/* Hero Banner */}
      <div className={`relative bg-gradient-to-bl ${config.bgGradient} text-white overflow-hidden`}>
        {/* Decorative patterns */}
        <div className="absolute inset-0 opacity-10">
          <div className="absolute top-10 right-10 size-40 rounded-full border-4 border-white/30" />
          <div className="absolute bottom-10 left-20 size-60 rounded-full border-4 border-white/20" />
          <div className="absolute top-20 left-1/3 size-20 rounded-full bg-white/10" />
        </div>

        <div className="relative max-w-7xl mx-auto px-4 py-12 md:py-16">
          {/* Breadcrumb */}
          <div className="flex items-center gap-2 text-white/70 text-sm mb-6">
            <Link href="/" className="hover:text-white transition-colors flex items-center gap-1">
              <Home className="size-3.5" />
              الرئيسية
            </Link>
            <ChevronLeft className="size-3.5" />
            <span className="text-white font-medium">{page.title}</span>
          </div>

          <div className="flex items-center gap-4 mb-4">
            <div className="size-14 rounded-2xl bg-white/20 backdrop-blur-sm flex items-center justify-center">
              {config.icon}
            </div>
            <div>
              <h1 className="text-3xl md:text-4xl font-bold">{page.title}</h1>
              <p className="text-white/80 text-base md:text-lg mt-1">{config.description}</p>
            </div>
          </div>

          {page.metaDescription && (
            <p className="text-white/70 text-sm max-w-2xl">{page.metaDescription}</p>
          )}
        </div>
      </div>

      {/* Content Area */}
      <div className="max-w-7xl mx-auto px-4 py-8">
        <div className="grid grid-cols-1 lg:grid-cols-3 gap-8">
          {/* Main Content */}
          <div className="lg:col-span-2">
            <Card className="border-0 shadow-lg overflow-hidden">
              <CardContent className="p-6 md:p-10">
                <div className="prose prose-lg dark:prose-invert max-w-none">
                  {renderContent(page.content, slug)}
                </div>

                {/* Contact Form for contact page */}
                {slug === 'contact' && <ContactForm />}

                {/* Last Updated */}
                <div className="mt-10 pt-5 border-t flex items-center justify-between">
                  <div className="flex items-center gap-2 text-sm text-muted-foreground">
                    <Clock className="size-4" />
                    <span>آخر تحديث: {new Date(page.updatedAt).toLocaleDateString('ar-EG', { year: 'numeric', month: 'long', day: 'numeric' })}</span>
                  </div>
                  <Badge variant="outline" className="text-xs gap-1">
                    <Globe className="size-3" />
                    /page/{slug}
                  </Badge>
                </div>
              </CardContent>
            </Card>
          </div>

          {/* Sidebar */}
          <div className="space-y-6">
            {/* Quick Navigation */}
            <Card className="border-0 shadow-lg overflow-hidden">
              <div className="bg-gradient-to-bl from-gray-50 to-gray-100 dark:from-gray-900 dark:to-gray-800 p-4 border-b">
                <h3 className="font-bold text-foreground flex items-center gap-2">
                  <FileText className="size-4 text-emerald-500" />
                  صفحات الموقع
                </h3>
              </div>
              <CardContent className="p-2">
                <nav className="space-y-1">
                  {quickLinks.map((link) => (
                    <Link
                      key={link.slug}
                      href={`/page/${link.slug}`}
                      className={`flex items-center gap-3 px-3 py-2.5 rounded-lg text-sm transition-all ${
                        slug === link.slug
                          ? 'bg-emerald-50 dark:bg-emerald-950/30 text-emerald-700 dark:text-emerald-400 font-semibold'
                          : 'text-muted-foreground hover:bg-muted hover:text-foreground'
                      }`}
                    >
                      <span className={slug === link.slug ? 'text-emerald-500' : 'text-muted-foreground/60'}>
                        {link.icon}
                      </span>
                      {link.label}
                    </Link>
                  ))}
                </nav>
              </CardContent>
            </Card>

            {/* Contact Info Card (only for contact page) */}
            {slug === 'contact' && (
              <Card className="border-0 shadow-lg overflow-hidden">
                <div className="bg-gradient-to-bl from-purple-50 to-violet-50 dark:from-purple-950/20 dark:to-violet-950/20 p-4 border-b">
                  <h3 className="font-bold text-foreground flex items-center gap-2">
                    <Phone className="size-4 text-purple-500" />
                    معلومات سريعة
                  </h3>
                </div>
                <CardContent className="p-4 space-y-4">
                  <div className="flex items-center gap-3">
                    <div className="size-9 rounded-lg bg-purple-50 dark:bg-purple-950/30 flex items-center justify-center">
                      <Mail className="size-4 text-purple-500" />
                    </div>
                    <div>
                      <p className="text-xs text-muted-foreground">البريد الإلكتروني</p>
                      <p className="text-sm font-medium" dir="ltr">info@sportplus.com</p>
                    </div>
                  </div>
                  <div className="flex items-center gap-3">
                    <div className="size-9 rounded-lg bg-purple-50 dark:bg-purple-950/30 flex items-center justify-center">
                      <Phone className="size-4 text-purple-500" />
                    </div>
                    <div>
                      <p className="text-xs text-muted-foreground">الهاتف</p>
                      <p className="text-sm font-medium" dir="ltr">+20 123 456 7890</p>
                    </div>
                  </div>
                  <div className="flex items-center gap-3">
                    <div className="size-9 rounded-lg bg-purple-50 dark:bg-purple-950/30 flex items-center justify-center">
                      <MapPin className="size-4 text-purple-500" />
                    </div>
                    <div>
                      <p className="text-xs text-muted-foreground">المقر الرئيسي</p>
                      <p className="text-sm font-medium">القاهرة، مصر</p>
                    </div>
                  </div>
                  <div className="flex items-center gap-3">
                    <div className="size-9 rounded-lg bg-purple-50 dark:bg-purple-950/30 flex items-center justify-center">
                      <Clock className="size-4 text-purple-500" />
                    </div>
                    <div>
                      <p className="text-xs text-muted-foreground">ساعات العمل</p>
                      <p className="text-sm font-medium">السبت - الخميس: 9ص - 6م</p>
                    </div>
                  </div>
                </CardContent>
              </Card>
            )}

            {/* About highlights (only for about page) */}
            {slug === 'about' && (
              <Card className="border-0 shadow-lg overflow-hidden">
                <div className="bg-gradient-to-bl from-emerald-50 to-teal-50 dark:from-emerald-950/20 dark:to-teal-950/20 p-4 border-b">
                  <h3 className="font-bold text-foreground flex items-center gap-2">
                    <CheckCircle2 className="size-4 text-emerald-500" />
                    لماذا سبورت بلس؟
                  </h3>
                </div>
                <CardContent className="p-4 space-y-3">
                  {[
                    { num: '+50', label: 'بطولة ودوري' },
                    { num: '+100', label: 'مقال شهرياً' },
                    { num: '+1M', label: 'زائر شهرياً' },
                    { num: '24/7', label: 'متابعة لحظية' },
                  ].map((stat) => (
                    <div key={stat.label} className="flex items-center justify-between py-2 border-b last:border-0">
                      <span className="text-sm text-muted-foreground">{stat.label}</span>
                      <span className="text-lg font-bold text-emerald-600">{stat.num}</span>
                    </div>
                  ))}
                </CardContent>
              </Card>
            )}
          </div>
        </div>
      </div>
    </div>
  )
}

function ContactForm() {
  const [formData, setFormData] = useState({ name: '', email: '', subject: '', message: '' })
  const [submitted, setSubmitted] = useState(false)

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault()
    setSubmitted(true)
    setTimeout(() => setSubmitted(false), 4000)
    setFormData({ name: '', email: '', subject: '', message: '' })
  }

  return (
    <div className="mt-10 pt-8 border-t">
      <div className="flex items-center gap-3 mb-6">
        <div className="size-10 rounded-xl bg-purple-100 dark:bg-purple-950/30 flex items-center justify-center">
          <Mail className="size-5 text-purple-600" />
        </div>
        <div>
          <h3 className="text-xl font-bold text-foreground">أرسل لنا رسالة</h3>
          <p className="text-sm text-muted-foreground">سنرد عليكم خلال 24-48 ساعة عمل</p>
        </div>
      </div>

      {submitted && (
        <div className="mb-6 p-4 rounded-xl bg-emerald-50 dark:bg-emerald-950/30 text-emerald-700 dark:text-emerald-400 border border-emerald-200 dark:border-emerald-800 flex items-center gap-3">
          <CheckCircle2 className="size-5 shrink-0" />
          <div>
            <p className="font-semibold">تم إرسال رسالتك بنجاح!</p>
            <p className="text-sm mt-0.5">سنتواصل معك في أقرب وقت ممكن.</p>
          </div>
        </div>
      )}

      <form onSubmit={handleSubmit} className="space-y-5">
        <div className="grid grid-cols-1 md:grid-cols-2 gap-5">
          <div>
            <label className="block text-sm font-semibold text-foreground mb-2">الاسم الكامل</label>
            <input
              type="text"
              required
              value={formData.name}
              onChange={(e) => setFormData({ ...formData, name: e.target.value })}
              className="w-full px-4 py-3 rounded-xl border border-border bg-background text-foreground text-sm focus:outline-none focus:ring-2 focus:ring-purple-500/20 focus:border-purple-500 transition-all"
              placeholder="أدخل اسمك الكامل"
            />
          </div>
          <div>
            <label className="block text-sm font-semibold text-foreground mb-2">البريد الإلكتروني</label>
            <input
              type="email"
              required
              value={formData.email}
              onChange={(e) => setFormData({ ...formData, email: e.target.value })}
              className="w-full px-4 py-3 rounded-xl border border-border bg-background text-foreground text-sm focus:outline-none focus:ring-2 focus:ring-purple-500/20 focus:border-purple-500 transition-all"
              placeholder="example@email.com"
              dir="ltr"
            />
          </div>
        </div>
        <div>
          <label className="block text-sm font-semibold text-foreground mb-2">الموضوع</label>
          <input
            type="text"
            required
            value={formData.subject}
            onChange={(e) => setFormData({ ...formData, subject: e.target.value })}
            className="w-full px-4 py-3 rounded-xl border border-border bg-background text-foreground text-sm focus:outline-none focus:ring-2 focus:ring-purple-500/20 focus:border-purple-500 transition-all"
            placeholder="موضوع رسالتك"
          />
        </div>
        <div>
          <label className="block text-sm font-semibold text-foreground mb-2">الرسالة</label>
          <textarea
            required
            rows={5}
            value={formData.message}
            onChange={(e) => setFormData({ ...formData, message: e.target.value })}
            className="w-full px-4 py-3 rounded-xl border border-border bg-background text-foreground text-sm focus:outline-none focus:ring-2 focus:ring-purple-500/20 focus:border-purple-500 resize-none transition-all"
            placeholder="اكتب رسالتك هنا بالتفصيل..."
          />
        </div>
        <Button
          type="submit"
          className="bg-gradient-to-l from-purple-600 to-violet-600 hover:from-purple-700 hover:to-violet-700 text-white px-8 py-3 rounded-xl text-base font-semibold gap-2 shadow-lg shadow-purple-500/20"
        >
          <Mail className="size-4" />
          إرسال الرسالة
        </Button>
      </form>
    </div>
  )
}
