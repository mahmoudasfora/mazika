'use client'

import StandingsFull from '@/components/sports/StandingsFull'

export default function StandingsPage() {
  return <StandingsFull />
}
