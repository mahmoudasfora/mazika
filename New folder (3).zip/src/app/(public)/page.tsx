'use client'

import LiveMatches from '@/components/sports/LiveMatches'
import NewsSection from '@/components/sports/NewsSection'
import StandingsWidget from '@/components/sports/StandingsWidget'
import TopScorersWidget from '@/components/sports/TopScorersWidget'
import AdBanner from '@/components/sports/AdBanner'
import { Video, Target, Sparkles } from 'lucide-react'

export default function HomePage() {
  return (
    <div className="space-y-10" dir="rtl">
      {/* إعلان الهيدر */}
      <AdBanner position="header_banner" page="home" />

      {/* مباريات اليوم - مباشر */}
      <section>
        <LiveMatches />
      </section>

      {/* إعلان مميز بالرئيسية */}
      <AdBanner position="home_featured" page="home" />

      {/* الأخبار الرئيسية */}
      <section>
        <NewsSection />
      </section>

      {/* ترتيب + هدافون */}
      <section className="grid grid-cols-1 lg:grid-cols-2 gap-6">
        <StandingsWidget />
        <TopScorersWidget />
      </section>

      {/* إعلان الفوتر */}
      <AdBanner position="footer_banner" page="home" />

      {/* قسمين جنب بعض - فيديوهات وتوقعات */}
      <section className="grid grid-cols-1 md:grid-cols-2 gap-4">
        {/* مقاطع فيديو - قريباً */}
        <div className="relative bg-gradient-to-br from-emerald-600 via-emerald-700 to-teal-800 rounded-2xl p-6 text-center overflow-hidden group">
          <div className="absolute inset-0 bg-[radial-gradient(circle_at_30%_50%,rgba(255,255,255,0.1),transparent)]" />
          <div className="relative">
            <div className="flex items-center justify-center size-16 rounded-2xl bg-white/20 backdrop-blur-sm mx-auto mb-4 group-hover:scale-110 transition-transform duration-300">
              <Video className="size-8 text-white" />
            </div>
            <h3 className="text-xl font-bold text-white mb-2">قسم الفيديوهات</h3>
            <p className="text-emerald-100/80 text-sm leading-relaxed">
              ملخصات المباريات، الأهداف، واللحظات الحاسمة
            </p>
            <div className="inline-flex items-center gap-1.5 mt-4 bg-white/20 backdrop-blur-sm rounded-full px-4 py-1.5 text-xs font-semibold text-white">
              <Sparkles className="size-3.5" />
              قريباً
            </div>
          </div>
        </div>

        {/* توقعات - قريباً */}
        <div className="relative bg-gradient-to-br from-amber-500 via-amber-600 to-orange-700 rounded-2xl p-6 text-center overflow-hidden group">
          <div className="absolute inset-0 bg-[radial-gradient(circle_at_70%_50%,rgba(255,255,255,0.1),transparent)]" />
          <div className="relative">
            <div className="flex items-center justify-center size-16 rounded-2xl bg-white/20 backdrop-blur-sm mx-auto mb-4 group-hover:scale-110 transition-transform duration-300">
              <Target className="size-8 text-white" />
            </div>
            <h3 className="text-xl font-bold text-white mb-2">توقعات المباريات</h3>
            <p className="text-amber-100/80 text-sm leading-relaxed">
              تنبأ بنتائج المباريات وشارك في الترتيب العام
            </p>
            <div className="inline-flex items-center gap-1.5 mt-4 bg-white/20 backdrop-blur-sm rounded-full px-4 py-1.5 text-xs font-semibold text-white">
              <Sparkles className="size-3.5" />
              قريباً
            </div>
          </div>
        </div>
      </section>
    </div>
  )
}
