'use client'

import { use } from 'react'
import ArticleDetail from '@/components/sports/ArticleDetail'
import AdBanner from '@/components/sports/AdBanner'

export default function ArticlePage({ params }: { params: Promise<{ id: string }> }) {
  const { id } = use(params)
  return (
    <div className="space-y-8" dir="rtl">
      <AdBanner position="header_banner" page="article" />
      <ArticleDetail articleId={id} />
      <AdBanner position="footer_banner" page="article" />
    </div>
  )
}
