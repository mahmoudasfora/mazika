'use client'

import { Suspense } from 'react'
import NewsList from '@/components/sports/NewsList'
import AdBanner from '@/components/sports/AdBanner'
import { Skeleton } from '@/components/ui/skeleton'
import { Newspaper } from 'lucide-react'

function NewsPageFallback() {
  return (
    <div className="space-y-6" dir="rtl">
      <div className="flex items-center gap-2">
        <Newspaper className="size-6 text-emerald-500" />
        <h1 className="text-2xl font-bold text-foreground">الأخبار</h1>
      </div>
      <Skeleton className="h-10 w-full" />
      <Skeleton className="h-10 w-full" />
      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-4">
        {Array.from({ length: 6 }).map((_, i) => (
          <Skeleton key={i} className="h-64 w-full rounded-xl" />
        ))}
      </div>
    </div>
  )
}

export default function NewsPage() {
  return (
    <div className="space-y-8" dir="rtl">
      {/* إعلان أعلى صفحة الأخبار */}
      <AdBanner position="header_banner" page="news" />

      <Suspense fallback={<NewsPageFallback />}>
        <NewsList />
      </Suspense>

      {/* إعلان أسفل صفحة الأخبار */}
      <AdBanner position="footer_banner" page="news" />
    </div>
  )
}
