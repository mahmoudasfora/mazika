'use client'

import { use } from 'react'
import MatchDetail from '@/components/sports/MatchDetail'
import AdBanner from '@/components/sports/AdBanner'

export default function MatchPage({ params }: { params: Promise<{ id: string }> }) {
  const { id } = use(params)
  return (
    <div className="space-y-8" dir="rtl">
      <AdBanner position="header_banner" page="match_detail" />
      <MatchDetail matchId={id} />
      <AdBanner position="footer_banner" page="match_detail" />
    </div>
  )
}
