'use client'

import MatchesList from '@/components/sports/MatchesList'
import AdBanner from '@/components/sports/AdBanner'

export default function MatchesPage() {
  return (
    <div className="space-y-8" dir="rtl">
      <AdBanner position="header_banner" page="matches" />
      <MatchesList />
      <AdBanner position="footer_banner" page="matches" />
    </div>
  )
}
