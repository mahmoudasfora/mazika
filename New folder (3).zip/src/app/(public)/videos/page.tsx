'use client'

import { Video, Play, Clock, TrendingUp, Film } from 'lucide-react'
import { Card, CardContent } from '@/components/ui/card'
import { Badge } from '@/components/ui/badge'

const videoCategories = [
  { label: 'ملخصات المباريات', icon: <Play className="size-5" />, color: 'from-emerald-500 to-teal-500' },
  { label: 'الأهداف', icon: <Video className="size-5" />, color: 'from-red-500 to-rose-500' },
  { label: 'تحليلات', icon: <TrendingUp className="size-5" />, color: 'from-blue-500 to-indigo-500' },
  { label: 'مقابلات', icon: <Film className="size-5" />, color: 'from-purple-500 to-violet-500' },
]

const placeholderVideos = [
  { title: 'ملخص مباراة الأهلي والزمالك', category: 'ملخصات', duration: '12:30', views: '1.2M' },
  { title: 'أجمل أهداف الجولة', category: 'أهداف', duration: '8:45', views: '856K' },
  { title: 'تحليل أداء برشلونة', category: 'تحليلات', duration: '15:20', views: '432K' },
  { title: 'مقابلة حصرية مع محمد صلاح', category: 'مقابلات', duration: '22:10', views: '2.1M' },
  { title: 'ملخص مباراة ريال مدريد', category: 'ملخصات', duration: '11:55', views: '987K' },
  { title: 'أهداف دوري أبطال أفريقيا', category: 'أهداف', duration: '6:30', views: '543K' },
]

export default function VideosPage() {
  return (
    <div className="space-y-6" dir="rtl">
      {/* Header */}
      <div className="flex items-center gap-2">
        <Video className="size-6 text-emerald-500" />
        <h1 className="text-2xl font-bold text-foreground">الفيديوهات</h1>
      </div>

      {/* Categories */}
      <div className="grid grid-cols-2 md:grid-cols-4 gap-3">
        {videoCategories.map((cat) => (
          <div
            key={cat.label}
            className={`bg-gradient-to-br ${cat.color} rounded-xl p-4 text-white cursor-pointer hover:scale-[1.02] transition-transform`}
          >
            <div className="mb-2">{cat.icon}</div>
            <h3 className="font-bold text-sm">{cat.label}</h3>
          </div>
        ))}
      </div>

      {/* Coming Soon Banner */}
      <Card className="overflow-hidden border-emerald-200 dark:border-emerald-800">
        <div className="bg-gradient-to-l from-emerald-500/10 to-transparent p-6 flex items-center gap-4">
          <div className="flex items-center justify-center size-14 rounded-2xl bg-emerald-100 dark:bg-emerald-900">
            <Play className="size-7 text-emerald-600 dark:text-emerald-400" />
          </div>
          <div>
            <h2 className="text-lg font-bold text-emerald-700 dark:text-emerald-400">قريباً - قسم الفيديوهات</h2>
            <p className="text-sm text-muted-foreground">ملخصات المباريات، الأهداف، واللحظات الحاسمة قادمة قريباً</p>
          </div>
        </div>
      </Card>

      {/* Placeholder Videos Grid */}
      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-4">
        {placeholderVideos.map((video, index) => (
          <Card key={index} className="overflow-hidden py-0 gap-0 group cursor-pointer opacity-70 hover:opacity-100 transition-opacity">
            <div className={`bg-gradient-to-br ${videoCategories[index % 4].color} w-full h-44 flex items-center justify-center relative`}>
              <div className="size-14 rounded-full bg-white/20 backdrop-blur-sm flex items-center justify-center group-hover:scale-110 transition-transform">
                <Play className="size-7 text-white fill-white" />
              </div>
              <Badge className="absolute bottom-2 left-2 bg-black/60 text-white text-[11px]">
                <Clock className="size-3 ml-1" />
                {video.duration}
              </Badge>
            </div>
            <CardContent className="p-4 space-y-2">
              <h3 className="font-semibold text-sm line-clamp-2">{video.title}</h3>
              <div className="flex items-center justify-between text-xs text-muted-foreground">
                <Badge variant="secondary" className="text-[10px]">{video.category}</Badge>
                <span>{video.views} مشاهدة</span>
              </div>
            </CardContent>
          </Card>
        ))}
      </div>
    </div>
  )
}
