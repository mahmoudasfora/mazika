import type { Metadata } from "next";
import { Geist, Geist_Mono } from "next/font/google";
import "./globals.css";
import { Toaster } from "@/components/ui/toaster";
import { ThemeProvider } from "@/components/theme-provider";

const geistSans = Geist({
  variable: "--font-geist-sans",
  subsets: ["latin"],
});

const geistMono = Geist_Mono({
  variable: "--font-geist-mono",
  subsets: ["latin"],
});

export const metadata: Metadata = {
  title: "سبورت بلس - أخبار الرياضة أولاً",
  description: "منصتك الأولى للأخبار الرياضية. نغطي أهم الأحداث الرياضية في العالم العربي والعالم مع تحليلات معمقة وتقارير حصرية.",
  keywords: ["رياضة", "أخبار رياضية", "كرة القدم", "مباريات", "ترتيب", "سبورت بلس"],
  authors: [{ name: "سبورت بلس" }],
  icons: {
    icon: [
      { url: "/favicon.ico", sizes: "48x48" },
      { url: "/favicon.png", type: "image/png", sizes: "1024x1024" },
    ],
    apple: "/apple-icon.png",
  },
  openGraph: {
    title: "سبورت بلس - أخبار الرياضة أولاً",
    description: "منصتك الأولى للأخبار الرياضية. نغطي أهم الأحداث الرياضية في العالم العربي والعالم",
    siteName: "سبورت بلس",
    locale: "ar_AR",
    type: "website",
  },
};

export default function RootLayout({
  children,
}: Readonly<{
  children: React.ReactNode;
}>) {
  return (
    <html lang="ar" dir="rtl" suppressHydrationWarning>
      <body
        className={`${geistSans.variable} ${geistMono.variable} antialiased bg-background text-foreground`}
      >
        <ThemeProvider
          attribute="class"
          defaultTheme="light"
          enableSystem
          disableTransitionOnChange
        >
          {children}
          <Toaster />
        </ThemeProvider>
      </body>
    </html>
  );
}
