'use client'

import { useEffect, useState, useRef, useCallback } from 'react'
import { ExternalLink, X } from 'lucide-react'

interface AdData {
  id: string
  title: string
  position: string
  type: string
  imageUrl: string | null
  linkUrl: string | null
  content: string | null
  width: string | null
  height: string | null
}

interface AdBannerProps {
  position: string
  page?: string // home, news, article, matches, match_detail
  className?: string
}

export default function AdBanner({ position, page = 'all', className = '' }: AdBannerProps) {
  const [ads, setAds] = useState<AdData[]>([])
  const [currentAdIndex, setCurrentAdIndex] = useState(0)
  const [isDismissed, setIsDismissed] = useState(false)
  const [isLoading, setIsLoading] = useState(true)
  const impressionTracked = useRef<Set<string>>(new Set())
  const containerRef = useRef<HTMLDivElement>(null)

  const fetchAds = useCallback(async () => {
    try {
      setIsLoading(true)
      const res = await fetch(`/api/ads?position=${position}&page=${page}`)
      if (!res.ok) {
        setAds([])
        return
      }
      const data = await res.json()
      setAds(data.ads || [])
    } catch {
      // صامت - لا نريد أخطاء الإعلانات تؤثر على تجربة المستخدم
    } finally {
      setIsLoading(false)
    }
  }, [position, page])

  useEffect(() => {
    fetchAds()
  }, [fetchAds])

  // تتبع المشاهدة عند ظهور الإعلان
  useEffect(() => {
    if (ads.length === 0) return
    const ad = ads[currentAdIndex]
    if (!ad || impressionTracked.current.has(ad.id)) return

    const observer = new IntersectionObserver(
      (entries) => {
        entries.forEach((entry) => {
          if (entry.isIntersecting && !impressionTracked.current.has(ad.id)) {
            impressionTracked.current.add(ad.id)
            fetch(`/api/ads/${ad.id}`, {
              method: 'POST',
              headers: { 'Content-Type': 'application/json' },
              body: JSON.stringify({ type: 'impression' }),
            }).catch(() => {})
          }
        })
      },
      { threshold: 0.5 }
    )

    if (containerRef.current) {
      observer.observe(containerRef.current)
    }

    return () => observer.disconnect()
  }, [ads, currentAdIndex])

  // تتبع النقر
  const handleClick = async (ad: AdData) => {
    try {
      await fetch(`/api/ads/${ad.id}`, {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ type: 'click' }),
      })
    } catch {
      // صامت
    }
  }

  // تبديل بين الإعلانات كل 8 ثوانٍ إذا كان هناك أكثر من إعلان
  useEffect(() => {
    if (ads.length <= 1) return
    const interval = setInterval(() => {
      setCurrentAdIndex((prev) => (prev + 1) % ads.length)
    }, 8000)
    return () => clearInterval(interval)
  }, [ads.length])

  // لا نعرض شيء إذا كان مُغلق أو لا توجد إعلانات
  if (isLoading) {
    // لا نعرض مؤشر تحميل للإعلانات - أفضل تجربة مستخدم
    return null
  }

  if (ads.length === 0 || isDismissed) return null

  const ad = ads[currentAdIndex]

  // حساب الأبعاد
  const getStyle = (): React.CSSProperties => {
    const style: React.CSSProperties = {}
    if (ad.width === 'responsive') {
      style.width = '100%'
    } else if (ad.width) {
      style.width = ad.width
      style.maxWidth = '100%'
    }
    if (ad.height === 'auto') {
      style.height = 'auto'
    } else if (ad.height) {
      style.height = ad.height
      style.maxHeight = '400px'
    }
    return style
  }

  // تحديد نوع العرض حسب الموضع
  const isHeaderBanner = position === 'header_banner'
  const isFooterBanner = position === 'footer_banner'
  const isSidebar = position.startsWith('sidebar_')
  const isArticleMiddle = position === 'article_middle'
  const isMatchBanner = position === 'match_banner'

  const wrapperClasses = [
    'ad-banner-container group relative overflow-hidden transition-all duration-300',
    isHeaderBanner || isFooterBanner || isMatchBanner ? 'w-full rounded-xl' : 'rounded-xl',
    isSidebar ? 'w-full' : '',
    isArticleMiddle ? 'w-full' : '',
    className,
  ].filter(Boolean).join(' ')

  return (
    <div ref={containerRef} className={wrapperClasses}>
      {/* زر إغلاق الإعلان */}
      <button
        onClick={() => setIsDismissed(true)}
        className="absolute top-2 right-2 z-20 size-6 rounded-full bg-black/40 backdrop-blur-sm text-white/70 hover:text-white hover:bg-black/60 flex items-center justify-center opacity-0 group-hover:opacity-100 transition-all duration-200"
        title="إغلاق الإعلان"
      >
        <X className="size-3.5" />
      </button>

      {/* إعلان صورة مع رابط */}
      {ad.type === 'image' && ad.imageUrl && (
        <>
          {ad.linkUrl ? (
            <a
              href={ad.linkUrl}
              target="_blank"
              rel="noopener noreferrer sponsored"
              onClick={() => handleClick(ad)}
              className="block relative overflow-hidden rounded-xl"
              style={getStyle()}
            >
              <img
                src={ad.imageUrl}
                alt={ad.title}
                className="w-full h-full object-cover transition-transform duration-500 group-hover:scale-[1.02]"
              />
              {/* تأثير التحويم */}
              <div className="absolute inset-0 bg-gradient-to-t from-black/30 via-transparent to-transparent opacity-0 group-hover:opacity-100 transition-opacity duration-300" />
              {/* علامة إعلان */}
              <div className="absolute top-2 left-2 bg-black/50 backdrop-blur-sm text-white text-[10px] font-medium px-2 py-0.5 rounded-md opacity-0 group-hover:opacity-100 transition-opacity duration-200 flex items-center gap-1">
                <ExternalLink className="size-2.5" />
                إعلان
              </div>
            </a>
          ) : (
            <div className="relative overflow-hidden rounded-xl" style={getStyle()}>
              <img
                src={ad.imageUrl}
                alt={ad.title}
                className="w-full h-full object-cover"
              />
              <div className="absolute top-2 left-2 bg-black/50 backdrop-blur-sm text-white text-[10px] font-medium px-2 py-0.5 rounded-md opacity-0 group-hover:opacity-100 transition-opacity duration-200">
                إعلان
              </div>
            </div>
          )}
        </>
      )}

      {/* إعلان HTML مخصص */}
      {ad.type === 'html' && ad.content && (
        <div className="rounded-xl overflow-hidden" style={getStyle()}>
          <div dangerouslySetInnerHTML={{ __html: ad.content }} />
        </div>
      )}

      {/* إعلان Google AdSense */}
      {ad.type === 'adsense' && ad.content && (
        <div className="rounded-xl overflow-hidden" style={getStyle()}>
          <div dangerouslySetInnerHTML={{ __html: ad.content }} />
        </div>
      )}

      {/* مؤشر الإعلانات المتعددة */}
      {ads.length > 1 && (
        <div className="flex items-center justify-center gap-1.5 mt-2">
          {ads.map((_, idx) => (
            <button
              key={idx}
              onClick={() => setCurrentAdIndex(idx)}
              className={`h-1.5 rounded-full transition-all duration-300 ${
                idx === currentAdIndex
                  ? 'w-6 bg-emerald-500'
                  : 'w-1.5 bg-muted-foreground/20 hover:bg-muted-foreground/40'
              }`}
            />
          ))}
        </div>
      )}
    </div>
  )
}
