'use client'

import { useEffect, useState, useCallback } from 'react'
import { Badge } from '@/components/ui/badge'
import { Skeleton } from '@/components/ui/skeleton'
import { ScrollArea, ScrollBar } from '@/components/ui/scroll-area'
import { useRouter } from 'next/navigation'
import { formatTime, getStatusLabel, getStatusColor } from '@/lib/sports-utils'
import {
  Clock,
  Trophy,
  ChevronLeft,
  Radio,
  Zap,
  Play,
  ArrowLeft,
} from 'lucide-react'

interface TeamData {
  id: string
  name: string
  nameEn?: string
  shortName?: string
  logo?: string | null
  color?: string | null
}

interface LeagueData {
  id: string
  name: string
  nameEn?: string
  logo?: string | null
  type?: string
}

interface MatchData {
  id: string
  homeTeam: TeamData
  awayTeam: TeamData
  league: LeagueData
  homeScore: number | null
  awayScore: number | null
  status: string
  matchDate: string
  stadium?: string | null
}

function TeamCrest({ team, size = 'md' }: { team: TeamData; size?: 'sm' | 'md' | 'lg' }) {
  const sizeClasses = {
    sm: 'size-9 text-sm',
    md: 'size-11 text-base',
    lg: 'size-14 text-lg',
  }
  const color = team.color || '#10b981'
  const firstLetter = (team.shortName || team.name).charAt(0)

  return (
    <div className="relative">
      <div
        className={`${sizeClasses[size]} rounded-full flex items-center justify-center font-bold text-white shrink-0 shadow-lg ring-2 ring-white/20`}
        style={{ backgroundColor: color }}
        title={team.name}
      >
        {firstLetter}
      </div>
      <div
        className="absolute inset-0 rounded-full opacity-30"
        style={{
          background: `linear-gradient(135deg, rgba(255,255,255,0.3) 0%, transparent 50%)`,
        }}
      />
    </div>
  )
}

function MatchCard({ match, onClick, variant = 'default' }: { match: MatchData; onClick: () => void; variant?: 'default' | 'live' | 'compact' }) {
  const isLive = match.status === 'live' || match.status === 'halftime'
  const isFinished = match.status === 'finished'
  const isUpcoming = match.status === 'upcoming'

  if (variant === 'live') {
    return (
      <div
        className="relative bg-gradient-to-br from-emerald-600 via-emerald-700 to-teal-800 rounded-2xl p-4 cursor-pointer transition-all duration-300 hover:scale-[1.03] hover:shadow-2xl hover:shadow-emerald-500/20 active:scale-[0.98] min-w-[300px] max-w-[340px] overflow-hidden group"
        onClick={onClick}
      >
        {/* Live pulse background effect */}
        <div className="absolute inset-0 bg-gradient-to-r from-white/0 via-white/5 to-white/0 animate-pulse" />
        
        {/* Top row - League */}
        <div className="relative flex items-center justify-between mb-4">
          <div className="flex items-center gap-1.5">
            {match.league.logo ? (
              <img src={match.league.logo} alt="" className="w-4 h-4" />
            ) : (
              <Trophy className="w-3.5 h-3.5 text-emerald-200/80" />
            )}
            <span className="text-[11px] text-emerald-100/90 font-medium truncate max-w-[120px]">
              {match.league.name}
            </span>
          </div>
          <div className="flex items-center gap-1.5 bg-white/20 backdrop-blur-sm rounded-full px-2.5 py-1">
            <div className="w-2 h-2 rounded-full bg-red-400 animate-pulse" />
            <span className="text-[11px] font-bold text-white">{getStatusLabel(match.status)}</span>
          </div>
        </div>

        {/* Teams & Score */}
        <div className="relative flex items-center justify-between gap-2">
          {/* Home Team */}
          <div className="flex flex-col items-center gap-1.5 flex-1 min-w-0">
            <TeamCrest team={match.homeTeam} size="md" />
            <span className="text-xs font-semibold text-white text-center truncate w-full">{match.homeTeam.shortName || match.homeTeam.name}</span>
          </div>

          {/* Score */}
          <div className="flex flex-col items-center gap-1 px-3">
            <div className="flex items-center gap-2 bg-white/15 backdrop-blur-sm rounded-xl px-4 py-2">
              <span className="text-3xl font-black text-white tabular-nums">{match.homeScore ?? 0}</span>
              <span className="text-lg font-bold text-emerald-200/80">:</span>
              <span className="text-3xl font-black text-white tabular-nums">{match.awayScore ?? 0}</span>
            </div>
          </div>

          {/* Away Team */}
          <div className="flex flex-col items-center gap-1.5 flex-1 min-w-0">
            <TeamCrest team={match.awayTeam} size="md" />
            <span className="text-xs font-semibold text-white text-center truncate w-full">{match.awayTeam.shortName || match.awayTeam.name}</span>
          </div>
        </div>

        {/* Stadium / Time */}
        <div className="relative flex items-center justify-center gap-3 mt-3 text-emerald-100/70 text-[11px]">
          {match.stadium && <span>{match.stadium}</span>}
          {match.stadium && <span className="text-emerald-300/40">|</span>}
          <Clock className="size-3" />
          <span>{formatTime(match.matchDate)}</span>
        </div>
      </div>
    )
  }

  return (
    <div
      className={`bg-card rounded-xl overflow-hidden cursor-pointer transition-all duration-300 hover:shadow-lg hover:scale-[1.02] active:scale-[0.98] border ${
        isLive ? 'border-emerald-500/50 ring-1 ring-emerald-500/20' : 'border-border'
      }`}
      onClick={onClick}
    >
      {/* League Header */}
      <div className="flex items-center justify-between px-3 pt-2.5 pb-1.5 bg-muted/40">
        <div className="flex items-center gap-1.5">
          {match.league.logo ? (
            <img src={match.league.logo} alt="" className="w-4 h-4" />
          ) : (
            <Trophy className="w-3.5 h-3.5 text-muted-foreground" />
          )}
          <span className="text-[11px] text-muted-foreground font-medium truncate max-w-[120px]">
            {match.league.name}
          </span>
        </div>
        <Badge
          className={`text-[10px] px-1.5 py-0 h-5 ${getStatusColor(match.status)}`}
          variant="secondary"
        >
          {isLive && <Radio className="w-2.5 h-2.5 ml-0.5" />}
          {getStatusLabel(match.status)}
        </Badge>
      </div>

      {/* Teams & Score */}
      <div className="p-3 pt-2 pb-2.5">
        <div className="flex items-center gap-2">
          {/* Home Team */}
          <div className="flex-1 flex items-center gap-2 min-w-0">
            <TeamCrest team={match.homeTeam} size="sm" />
            <span className="text-sm font-medium truncate">{match.homeTeam.name}</span>
          </div>

          {/* Score / Time */}
          <div className="flex flex-col items-center justify-center shrink-0 min-w-[60px]">
            {isFinished || isLive ? (
              <div className={`text-lg font-bold tabular-nums ${isLive ? 'text-emerald-600 dark:text-emerald-400' : ''}`}>
                {match.homeScore} - {match.awayScore}
              </div>
            ) : (
              <div className="flex items-center gap-1 text-sm text-muted-foreground">
                <Clock className="w-3.5 h-3.5" />
                <span className="font-medium">{formatTime(match.matchDate)}</span>
              </div>
            )}
          </div>

          {/* Away Team */}
          <div className="flex-1 flex items-center gap-2 justify-end min-w-0">
            <span className="text-sm font-medium truncate text-left">{match.awayTeam.name}</span>
            <TeamCrest team={match.awayTeam} size="sm" />
          </div>
        </div>
      </div>
    </div>
  )
}

function LiveMatchSkeleton() {
  return (
    <div className="bg-gradient-to-br from-emerald-700/50 to-teal-800/50 rounded-2xl p-4 min-w-[300px] max-w-[340px]">
      <div className="flex items-center justify-between mb-4">
        <Skeleton className="h-3.5 w-24 bg-white/20" />
        <Skeleton className="h-5 w-16 rounded-full bg-white/20" />
      </div>
      <div className="flex items-center justify-between gap-2">
        <div className="flex flex-col items-center gap-1.5">
          <Skeleton className="size-11 rounded-full bg-white/20" />
          <Skeleton className="h-3 w-14 bg-white/20" />
        </div>
        <Skeleton className="h-10 w-24 rounded-xl bg-white/20" />
        <div className="flex flex-col items-center gap-1.5">
          <Skeleton className="size-11 rounded-full bg-white/20" />
          <Skeleton className="h-3 w-14 bg-white/20" />
        </div>
      </div>
    </div>
  )
}

function RegularMatchSkeleton() {
  return (
    <div className="bg-card rounded-xl overflow-hidden border border-border">
      <div className="flex items-center justify-between px-3 pt-2.5 pb-1.5 bg-muted/40">
        <Skeleton className="h-3.5 w-24" />
        <Skeleton className="h-5 w-14 rounded-full" />
      </div>
      <div className="p-3 pt-2 pb-2.5">
        <div className="flex items-center gap-2">
          <div className="flex-1 flex items-center gap-2">
            <Skeleton className="size-9 rounded-full" />
            <Skeleton className="h-4 w-16" />
          </div>
          <Skeleton className="h-6 w-14" />
          <div className="flex-1 flex items-center gap-2 justify-end">
            <Skeleton className="h-4 w-16" />
            <Skeleton className="size-9 rounded-full" />
          </div>
        </div>
      </div>
    </div>
  )
}

export default function LiveMatches() {
  const [matches, setMatches] = useState<MatchData[]>([])
  const [loading, setLoading] = useState(true)
  const [error, setError] = useState<string | null>(null)
  const router = useRouter()

  const fetchMatches = useCallback(async () => {
    try {
      const res = await fetch('/api/matches')
      if (!res.ok) throw new Error('فشل في جلب المباريات')
      const data = await res.json()
      setMatches(data.matches || [])
      setError(null)
    } catch {
      setError('فشل في تحميل المباريات')
    } finally {
      setLoading(false)
    }
  }, [])

  useEffect(() => {
    fetchMatches()
  }, [fetchMatches])

  // Auto-refresh every 60 seconds for live matches
  useEffect(() => {
    const hasLive = matches.some((m) => m.status === 'live' || m.status === 'halftime')
    if (!hasLive) return
    const interval = setInterval(fetchMatches, 60000)
    return () => clearInterval(interval)
  }, [matches, fetchMatches])

  const liveMatches = matches.filter((m) => m.status === 'live' || m.status === 'halftime')
  const upcomingMatches = matches.filter((m) => m.status === 'upcoming')
  const finishedMatches = matches.filter((m) => m.status === 'finished')

  const handleMatchClick = (matchId: string) => {
    router.push(`/matches/${matchId}`)
  }

  if (error) {
    return (
      <div className="space-y-4" dir="rtl">
        <div className="flex items-center gap-2">
          <Zap className="w-5 h-5 text-emerald-600" />
          <h2 className="text-lg font-bold">مباريات اليوم</h2>
        </div>
        <div className="bg-card border rounded-xl p-6 text-center text-muted-foreground">
          <p>{error}</p>
          <button
            onClick={fetchMatches}
            className="mt-2 text-emerald-600 hover:text-emerald-700 text-sm underline"
          >
            إعادة المحاولة
          </button>
        </div>
      </div>
    )
  }

  return (
    <div className="space-y-5" dir="rtl">
      {/* Section Header */}
      <div className="flex items-center justify-between">
        <div className="flex items-center gap-3">
          <div className="flex items-center justify-center size-10 rounded-xl bg-emerald-600 text-white shadow-lg shadow-emerald-600/30">
            <Zap className="size-5" />
          </div>
          <div>
            <h2 className="text-xl font-bold">مباريات اليوم</h2>
            <p className="text-xs text-muted-foreground">تابع المباريات مباشرة</p>
          </div>
          {liveMatches.length > 0 && (
            <Badge className="bg-red-500 text-white animate-pulse text-[10px] px-2 h-5 ml-2">
              <Radio className="w-2.5 h-2.5 ml-0.5" />
              {liveMatches.length} مباشر
            </Badge>
          )}
        </div>
        <button
          onClick={() => router.push('/matches')}
          className="flex items-center gap-1.5 text-sm text-emerald-600 hover:text-emerald-700 dark:text-emerald-400 dark:hover:text-emerald-300 font-semibold transition-colors bg-emerald-50 dark:bg-emerald-500/10 px-3 py-1.5 rounded-lg hover:bg-emerald-100 dark:hover:bg-emerald-500/20"
        >
          الكل
          <ChevronLeft className="w-4 h-4" />
        </button>
      </div>

      {/* Loading State */}
      {loading && (
        <div className="space-y-5">
          {/* Live skeleton */}
          <ScrollArea className="w-full">
            <div className="flex gap-3 pb-2">
              {Array.from({ length: 2 }).map((_, i) => (
                <LiveMatchSkeleton key={i} />
              ))}
            </div>
            <ScrollBar orientation="horizontal" />
          </ScrollArea>
          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-3">
            {Array.from({ length: 3 }).map((_, i) => (
              <RegularMatchSkeleton key={i} />
            ))}
          </div>
        </div>
      )}

      {/* No matches */}
      {!loading && matches.length === 0 && (
        <div className="bg-card border rounded-xl p-10 text-center">
          <Trophy className="w-12 h-12 mx-auto mb-3 text-muted-foreground/40" />
          <p className="font-semibold text-lg">لا توجد مباريات اليوم</p>
          <p className="text-sm mt-1 text-muted-foreground">تابع المباريات القادمة</p>
        </div>
      )}

      {/* Live Matches - Featured horizontal scroll */}
      {!loading && liveMatches.length > 0 && (
        <div className="space-y-3">
          <div className="flex items-center gap-2">
            <div className="w-2 h-2 rounded-full bg-red-500 animate-pulse" />
            <h3 className="text-sm font-bold text-red-600 dark:text-red-400">مباشر الآن</h3>
          </div>
          <ScrollArea className="w-full">
            <div className="flex gap-3 pb-2">
              {liveMatches.map((match) => (
                <MatchCard key={match.id} match={match} onClick={() => handleMatchClick(match.id)} variant="live" />
              ))}
            </div>
            <ScrollBar orientation="horizontal" />
          </ScrollArea>
        </div>
      )}

      {/* Upcoming Matches */}
      {!loading && upcomingMatches.length > 0 && (
        <div className="space-y-3">
          <div className="flex items-center gap-2">
            <Clock className="w-4 h-4 text-amber-500" />
            <h3 className="text-sm font-bold text-muted-foreground">قادمة</h3>
          </div>
          <ScrollArea className="w-full md:hidden">
            <div className="flex gap-3 pb-2">
              {upcomingMatches.map((match) => (
                <div key={match.id} className="min-w-[280px] max-w-[320px]">
                  <MatchCard match={match} onClick={() => handleMatchClick(match.id)} />
                </div>
              ))}
            </div>
            <ScrollBar orientation="horizontal" />
          </ScrollArea>
          <div className="hidden md:grid md:grid-cols-2 lg:grid-cols-3 gap-3">
            {upcomingMatches.map((match) => (
              <MatchCard key={match.id} match={match} onClick={() => handleMatchClick(match.id)} />
            ))}
          </div>
        </div>
      )}

      {/* Finished Matches */}
      {!loading && finishedMatches.length > 0 && (
        <div className="space-y-3">
          <div className="flex items-center gap-2">
            <Trophy className="w-4 h-4 text-emerald-600" />
            <h3 className="text-sm font-bold text-muted-foreground">انتهت</h3>
          </div>
          <ScrollArea className="w-full md:hidden">
            <div className="flex gap-3 pb-2">
              {finishedMatches.map((match) => (
                <div key={match.id} className="min-w-[280px] max-w-[320px]">
                  <MatchCard match={match} onClick={() => handleMatchClick(match.id)} />
                </div>
              ))}
            </div>
            <ScrollBar orientation="horizontal" />
          </ScrollArea>
          <div className="hidden md:grid md:grid-cols-2 lg:grid-cols-3 gap-3">
            {finishedMatches.map((match) => (
              <MatchCard key={match.id} match={match} onClick={() => handleMatchClick(match.id)} />
            ))}
          </div>
        </div>
      )}
    </div>
  )
}
