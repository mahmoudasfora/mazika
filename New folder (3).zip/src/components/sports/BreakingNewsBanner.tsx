'use client'

import { useEffect, useState, useCallback } from 'react'
import { motion, AnimatePresence } from 'framer-motion'
import { AlertTriangle } from 'lucide-react'
import { Badge } from '@/components/ui/badge'
import { useNavigation } from '@/lib/navigation-store'

interface BreakingArticle {
  id: string
  title: string
  slug: string
  category: string
  createdAt: string
}

export function BreakingNewsBanner() {
  const [articles, setArticles] = useState<BreakingArticle[]>([])
  const [currentIndex, setCurrentIndex] = useState(0)
  const [isLoading, setIsLoading] = useState(true)
  const navigate = useNavigation((s) => s.navigate)

  useEffect(() => {
    async function fetchBreaking() {
      try {
        const res = await fetch('/api/articles?isBreaking=true&status=published&limit=5')
        if (res.ok) {
          const data = await res.json()
          setArticles(data.articles || [])
        }
      } catch {
        // silently fail
      } finally {
        setIsLoading(false)
      }
    }
    fetchBreaking()
  }, [])

  const goToNext = useCallback(() => {
    if (articles.length <= 1) return
    setCurrentIndex((prev) => (prev + 1) % articles.length)
  }, [articles.length])

  useEffect(() => {
    if (articles.length <= 1) return
    const interval = setInterval(goToNext, 4000)
    return () => clearInterval(interval)
  }, [articles.length, goToNext])

  if (isLoading || articles.length === 0) return null

  const currentArticle = articles[currentIndex]

  return (
    <div
      dir="rtl"
      className="relative w-full bg-red-600 dark:bg-red-700 text-white overflow-hidden"
    >
      <div className="flex items-center h-9 max-w-7xl mx-auto px-4">
        {/* عاجل Badge */}
        <div className="flex items-center gap-2 shrink-0 z-10">
          <Badge className="bg-white text-red-600 dark:bg-white dark:text-red-700 font-bold text-xs px-2.5 py-0.5 animate-pulse border-0">
            <AlertTriangle className="size-3 ml-1" />
            عاجل
          </Badge>
        </div>

        {/* Scrolling News Items */}
        <div className="flex-1 overflow-hidden mr-3 relative h-full flex items-center">
          <AnimatePresence mode="wait">
            <motion.button
              key={currentArticle.id}
              initial={{ y: 20, opacity: 0 }}
              animate={{ y: 0, opacity: 1 }}
              exit={{ y: -20, opacity: 0 }}
              transition={{ duration: 0.3, ease: 'easeInOut' }}
              onClick={() => navigate('article', { articleId: currentArticle.id })}
              className="w-full text-right text-sm font-medium hover:underline cursor-pointer truncate whitespace-nowrap"
            >
              {currentArticle.title}
            </motion.button>
          </AnimatePresence>

          {/* Progress dots */}
          {articles.length > 1 && (
            <div className="absolute left-0 top-1/2 -translate-y-1/2 flex items-center gap-1">
              {articles.map((_, idx) => (
                <button
                  key={idx}
                  onClick={() => setCurrentIndex(idx)}
                  className={`block rounded-full transition-all duration-300 ${
                    idx === currentIndex
                      ? 'w-2 h-2 bg-white'
                      : 'w-1.5 h-1.5 bg-white/50 hover:bg-white/70'
                  }`}
                  aria-label={`عاجل ${idx + 1}`}
                />
              ))}
            </div>
          )}
        </div>
      </div>
    </div>
  )
}
