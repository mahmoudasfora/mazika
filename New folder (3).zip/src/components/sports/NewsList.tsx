'use client'

import { useEffect, useState, useCallback } from 'react'
import { motion, AnimatePresence } from 'framer-motion'
import { Eye, Clock, User, Search, Newspaper, ChevronLeft, ChevronRight, SlidersHorizontal, TrendingUp, Flame, X, Bookmark, Share2 } from 'lucide-react'
import { Card, CardContent } from '@/components/ui/card'
import { Badge } from '@/components/ui/badge'
import { Button } from '@/components/ui/button'
import { Input } from '@/components/ui/input'
import { Tabs, TabsList, TabsTrigger } from '@/components/ui/tabs'
import { Skeleton } from '@/components/ui/skeleton'
import { useRouter, useSearchParams } from 'next/navigation'
import { getCategoryLabel, getCategoryColor, truncateText, timeAgo, formatNumber } from '@/lib/sports-utils'

interface ArticleAuthor {
  id: string
  name: string
  avatar: string | null
  role: string
}

interface ArticleTag {
  id: string
  tag: string
}

interface ArticleTeamItem {
  id: string
  team: {
    id: string
    name: string
    nameEn: string | null
    shortName: string | null
    logo: string | null
  }
}

interface Article {
  id: string
  title: string
  slug: string
  summary: string | null
  content: string
  image: string | null
  category: string
  isBreaking: boolean
  isFeatured: boolean
  status: string
  authorId: string
  publishedAt: string | null
  views: number
  createdAt: string
  updatedAt: string
  author: ArticleAuthor
  tags: ArticleTag[]
  teams: ArticleTeamItem[]
}

interface PaginationInfo {
  page: number
  limit: number
  total: number
  totalPages: number
}

const CATEGORY_TABS = [
  { value: 'all', label: 'الكل', icon: '📰' },
  { value: 'general', label: 'أخبار عامة', icon: '🌐' },
  { value: 'transfer', label: 'انتقالات', icon: '🔄' },
  { value: 'analysis', label: 'تحليلات', icon: '📊' },
  { value: 'interview', label: 'مقابلات', icon: '🎤' },
  { value: 'report', label: 'تقارير', icon: '📝' },
]

function getCategoryGradient(category: string): string {
  const gradients: Record<string, string> = {
    general: 'from-blue-500 to-cyan-500',
    transfer: 'from-purple-500 to-pink-500',
    analysis: 'from-amber-500 to-orange-500',
    interview: 'from-teal-500 to-emerald-500',
    report: 'from-indigo-500 to-violet-500',
    breaking: 'from-red-500 to-rose-500',
  }
  return gradients[category] || 'from-emerald-500 to-green-600'
}

function ArticleImagePlaceholder({ category, className = '' }: { category: string; className?: string }) {
  return (
    <div className={`bg-gradient-to-br ${getCategoryGradient(category)} flex items-center justify-center ${className}`}>
      <Newspaper className="size-10 text-white/40" />
    </div>
  )
}

function NewsCardSkeleton() {
  return (
    <div className="bg-card border rounded-xl overflow-hidden h-full">
      <Skeleton className="h-44 w-full rounded-none" />
      <div className="p-4 space-y-3">
        <Skeleton className="h-5 w-20" />
        <Skeleton className="h-6 w-full" />
        <Skeleton className="h-4 w-3/4" />
        <div className="flex items-center gap-3">
          <Skeleton className="h-4 w-24" />
          <Skeleton className="h-4 w-20" />
          <Skeleton className="h-4 w-16" />
        </div>
      </div>
    </div>
  )
}

export default function NewsList() {
  const [articles, setArticles] = useState<Article[]>([])
  const [pagination, setPagination] = useState<PaginationInfo>({ page: 1, limit: 9, total: 0, totalPages: 0 })
  const [loading, setLoading] = useState(true)
  const [error, setError] = useState<string | null>(null)
  const [activeCategory, setActiveCategory] = useState('all')
  const [searchQuery, setSearchQuery] = useState('')
  const [searchDebounce, setSearchDebounce] = useState<NodeJS.Timeout | null>(null)
  const [isSearchFocused, setIsSearchFocused] = useState(false)
  const router = useRouter()
  const searchParams = useSearchParams()

  useEffect(() => {
    const cat = searchParams.get('category')
    if (cat) {
      setActiveCategory(cat)
    }
  }, [searchParams])

  const fetchArticles = useCallback(async (page: number = 1) => {
    try {
      setLoading(true)
      setError(null)

      const params = new URLSearchParams({
        status: 'published',
        limit: '9',
        page: page.toString(),
      })

      if (activeCategory !== 'all') {
        params.set('category', activeCategory)
      }

      if (searchQuery.trim()) {
        params.set('search', searchQuery.trim())
      }

      const res = await fetch(`/api/articles?${params.toString()}`)

      if (!res.ok) {
        throw new Error('فشل في جلب المقالات')
      }

      const data = await res.json()
      setArticles(data.articles || [])
      setPagination(data.pagination || { page: 1, limit: 9, total: 0, totalPages: 0 })
    } catch (err) {
      setError(err instanceof Error ? err.message : 'حدث خطأ غير متوقع')
    } finally {
      setLoading(false)
    }
  }, [activeCategory, searchQuery])

  useEffect(() => {
    fetchArticles(1)
  }, [fetchArticles])

  const handleSearchChange = (value: string) => {
    if (searchDebounce) {
      clearTimeout(searchDebounce)
    }
    const timeout = setTimeout(() => {
      setSearchQuery(value)
    }, 400)
    setSearchDebounce(timeout)
  }

  const handleCategoryChange = (value: string) => {
    setActiveCategory(value)
  }

  const handlePageChange = (page: number) => {
    fetchArticles(page)
    window.scrollTo({ top: 0, behavior: 'smooth' })
  }

  const renderPagination = () => {
    if (pagination.totalPages <= 1) return null

    const pages: number[] = []
    const currentPage = pagination.page
    const totalPages = pagination.totalPages

    if (totalPages <= 5) {
      for (let i = 1; i <= totalPages; i++) pages.push(i)
    } else {
      pages.push(1)
      if (currentPage > 3) pages.push(-1)
      for (let i = Math.max(2, currentPage - 1); i <= Math.min(totalPages - 1, currentPage + 1); i++) {
        pages.push(i)
      }
      if (currentPage < totalPages - 2) pages.push(-1)
      pages.push(totalPages)
    }

    return (
      <div className="flex items-center justify-center gap-2 mt-8">
        <Button
          variant="outline"
          size="icon"
          className="size-10 rounded-xl"
          disabled={currentPage <= 1}
          onClick={() => handlePageChange(currentPage - 1)}
        >
          <ChevronRight className="size-4" />
        </Button>

        {pages.map((page, idx) =>
          page === -1 ? (
            <span key={`ellipsis-${idx}`} className="px-2 text-muted-foreground">
              ...
            </span>
          ) : (
            <Button
              key={page}
              variant={page === currentPage ? 'default' : 'outline'}
              size="icon"
              className={`size-10 rounded-xl ${page === currentPage ? 'bg-emerald-600 hover:bg-emerald-700 text-white shadow-lg shadow-emerald-600/20' : ''}`}
              onClick={() => handlePageChange(page)}
            >
              {page}
            </Button>
          )
        )}

        <Button
          variant="outline"
          size="icon"
          className="size-10 rounded-xl"
          disabled={currentPage >= totalPages}
          onClick={() => handlePageChange(currentPage + 1)}
        >
          <ChevronLeft className="size-4" />
        </Button>
      </div>
    )
  }

  const heroArticle = articles[0]
  const restArticles = articles.slice(1)

  return (
    <section dir="rtl" className="space-y-6">
      {/* Hero Header */}
      <div className="relative bg-gradient-to-l from-emerald-600 via-emerald-700 to-teal-800 rounded-2xl p-6 md:p-8 overflow-hidden">
        <div className="absolute inset-0 bg-[radial-gradient(circle_at_80%_20%,rgba(255,255,255,0.12),transparent)]" />
        <div className="absolute inset-0 bg-[radial-gradient(circle_at_20%_80%,rgba(255,255,255,0.06),transparent)]" />
        <div className="relative flex items-center justify-between flex-wrap gap-4">
          <div className="flex items-center gap-3">
            <div className="flex items-center justify-center size-12 rounded-xl bg-white/20 backdrop-blur-sm shadow-lg">
              <Newspaper className="size-6 text-white" />
            </div>
            <div>
              <h1 className="text-2xl md:text-3xl font-bold text-white">آخر الأخبار</h1>
              <p className="text-emerald-100/80 text-sm mt-0.5">أحدث الأخبار والتقارير الرياضية</p>
            </div>
          </div>
          <div className="text-emerald-100/70 text-sm">
            {pagination.total > 0 && `${pagination.total} مقال متاح`}
          </div>
        </div>
      </div>

      {/* Search Bar - Full width */}
      <div className={`relative transition-all duration-300 ${isSearchFocused ? 'scale-[1.01]' : ''}`}>
        <Search className={`absolute right-4 top-1/2 -translate-y-1/2 size-5 transition-colors duration-200 ${isSearchFocused ? 'text-emerald-500' : 'text-muted-foreground'}`} />
        <Input
          placeholder="ابحث في الأخبار... (العنوان، المحتوى، الكاتب)"
          className={`pr-12 pl-10 h-12 text-right text-base rounded-xl border-2 transition-all duration-300 ${isSearchFocused ? 'border-emerald-500 shadow-lg shadow-emerald-500/10' : 'border-border'}`}
          onChange={(e) => handleSearchChange(e.target.value)}
          onFocus={() => setIsSearchFocused(true)}
          onBlur={() => setIsSearchFocused(false)}
        />
        {searchQuery && (
          <button
            onClick={() => { setSearchQuery(''); (document.querySelector('input') as HTMLInputElement).value = '' }}
            className="absolute left-4 top-1/2 -translate-y-1/2 text-muted-foreground hover:text-foreground transition-colors"
          >
            <X className="size-4" />
          </button>
        )}
      </div>

      {/* Category Tabs - Enhanced */}
      <Tabs value={activeCategory} onValueChange={handleCategoryChange}>
        <TabsList className="flex-wrap h-auto gap-1.5 p-1.5 bg-muted/50 rounded-xl">
          {CATEGORY_TABS.map((tab) => (
            <TabsTrigger
              key={tab.value}
              value={tab.value}
              className="text-xs sm:text-sm px-3 py-1.5 rounded-lg data-[state=active]:bg-emerald-600 data-[state=active]:text-white data-[state=active]:shadow-md data-[state=active]:shadow-emerald-600/20 transition-all duration-200"
            >
              <span className="ml-1">{tab.icon}</span>
              {tab.label}
            </TabsTrigger>
          ))}
        </TabsList>
      </Tabs>

      {/* Error State */}
      {error && (
        <Card className="p-6 text-center">
          <p className="text-muted-foreground">{error}</p>
          <Button
            variant="outline"
            className="mt-4"
            onClick={() => fetchArticles(pagination.page)}
          >
            إعادة المحاولة
          </Button>
        </Card>
      )}

      {/* Articles - Hero + Grid Layout */}
      {loading ? (
        <div className="space-y-6">
          <div className="grid grid-cols-1 lg:grid-cols-3 gap-4">
            <Skeleton className="h-80 lg:col-span-2 rounded-xl" />
            <div className="flex flex-col gap-4">
              <Skeleton className="h-[calc(50%-0.5rem)] rounded-xl" />
              <Skeleton className="h-[calc(50%-0.5rem)] rounded-xl" />
            </div>
          </div>
          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-4">
            {Array.from({ length: 6 }).map((_, i) => (
              <NewsCardSkeleton key={i} />
            ))}
          </div>
        </div>
      ) : articles.length === 0 ? (
        <Card className="p-10 text-center">
          <Newspaper className="size-16 text-muted-foreground/30 mx-auto mb-4" />
          <p className="text-lg font-semibold text-muted-foreground">لا توجد مقالات</p>
          <p className="text-sm mt-1 text-muted-foreground">لا توجد نتائج مطابقة لبحثك</p>
          <Button
            variant="outline"
            className="mt-4"
            onClick={() => { setActiveCategory('all'); setSearchQuery('') }}
          >
            عرض جميع الأخبار
          </Button>
        </Card>
      ) : (
        <div className="space-y-6">
          {/* Featured Hero Layout */}
          {heroArticle && !searchQuery && activeCategory === 'all' && (
            <div className="grid grid-cols-1 lg:grid-cols-3 gap-4">
              {/* Main Hero Article */}
              <motion.div
                initial={{ opacity: 0, y: 20 }}
                animate={{ opacity: 1, y: 0 }}
                transition={{ duration: 0.5 }}
                className="lg:col-span-2"
              >
                <div
                  className="relative bg-card border rounded-2xl overflow-hidden cursor-pointer group h-full min-h-[320px]"
                  onClick={() => router.push(`/news/${heroArticle.id}`)}
                >
                  <div className="absolute inset-0">
                    {heroArticle.image ? (
                      <img src={heroArticle.image} alt={heroArticle.title} className="w-full h-full object-cover group-hover:scale-105 transition-transform duration-700" />
                    ) : (
                      <ArticleImagePlaceholder category={heroArticle.category} className="w-full h-full" />
                    )}
                  </div>
                  <div className="absolute inset-0 bg-gradient-to-t from-black/80 via-black/30 to-transparent" />
                  <div className="absolute bottom-0 right-0 left-0 p-6">
                    <div className="flex items-center gap-2 mb-3">
                      <Badge className={`${getCategoryColor(heroArticle.category)} border-0`}>
                        {getCategoryLabel(heroArticle.category)}
                      </Badge>
                      {heroArticle.isBreaking && (
                        <Badge className="bg-red-500 text-white border-0 animate-pulse">عاجل</Badge>
                      )}
                    </div>
                    <h3 className="text-xl md:text-2xl font-bold text-white mb-2 line-clamp-2 group-hover:text-emerald-300 transition-colors leading-tight">
                      {heroArticle.title}
                    </h3>
                    {heroArticle.summary && (
                      <p className="text-white/75 text-sm line-clamp-2 mb-3 leading-relaxed">{heroArticle.summary}</p>
                    )}
                    <div className="flex items-center gap-3 text-white/60 text-xs">
                      <span className="flex items-center gap-1 bg-white/10 backdrop-blur-sm rounded-full px-2.5 py-1">
                        <User className="size-3" />{heroArticle.author.name}
                      </span>
                      {heroArticle.publishedAt && (
                        <span className="flex items-center gap-1 bg-white/10 backdrop-blur-sm rounded-full px-2.5 py-1">
                          <Clock className="size-3" />{timeAgo(heroArticle.publishedAt)}
                        </span>
                      )}
                      <span className="flex items-center gap-1 bg-white/10 backdrop-blur-sm rounded-full px-2.5 py-1">
                        <Eye className="size-3" />{formatNumber(heroArticle.views)}
                      </span>
                    </div>
                  </div>
                </div>
              </motion.div>

              {/* Side Articles */}
              {restArticles.length > 0 && (
                <div className="flex flex-col gap-4">
                  {restArticles.slice(0, 2).map((article, index) => (
                    <motion.div
                      key={article.id}
                      initial={{ opacity: 0, x: 20 }}
                      animate={{ opacity: 1, x: 0 }}
                      transition={{ duration: 0.4, delay: (index + 1) * 0.15 }}
                      className="flex-1"
                    >
                      <div
                        className="bg-card border rounded-xl overflow-hidden cursor-pointer group h-full flex"
                        onClick={() => router.push(`/news/${article.id}`)}
                      >
                        <div className="relative w-2/5 shrink-0 overflow-hidden">
                          {article.image ? (
                            <img src={article.image} alt={article.title} className="w-full h-full object-cover group-hover:scale-105 transition-transform duration-500" />
                          ) : (
                            <ArticleImagePlaceholder category={article.category} className="w-full h-full" />
                          )}
                        </div>
                        <div className="flex flex-col justify-center p-3 flex-1 min-w-0">
                          <Badge className={`${getCategoryColor(article.category)} text-[10px] px-1.5 py-0 h-4 w-fit mb-2`}>
                            {getCategoryLabel(article.category)}
                          </Badge>
                          <h3 className="font-bold text-sm text-foreground line-clamp-2 group-hover:text-emerald-600 dark:group-hover:text-emerald-400 transition-colors leading-relaxed">
                            {article.title}
                          </h3>
                          <div className="flex items-center gap-2 mt-2 text-[11px] text-muted-foreground">
                            {article.publishedAt && (
                              <span className="flex items-center gap-1"><Clock className="size-3" />{timeAgo(article.publishedAt)}</span>
                            )}
                            <span className="flex items-center gap-1"><Eye className="size-3" />{formatNumber(article.views)}</span>
                          </div>
                        </div>
                      </div>
                    </motion.div>
                  ))}
                </div>
              )}
            </div>
          )}

          {/* Articles Grid */}
          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-4">
            {(searchQuery || activeCategory !== 'all' ? articles : restArticles.slice(2)).map((article, index) => (
              <motion.div
                key={article.id}
                initial={{ opacity: 0, y: 20 }}
                animate={{ opacity: 1, y: 0 }}
                transition={{ duration: 0.4, delay: index * 0.05 }}
                whileHover={{ y: -6, transition: { duration: 0.2 } }}
              >
                <div
                  className="bg-card border rounded-xl overflow-hidden cursor-pointer group h-full flex flex-col hover:shadow-xl hover:border-emerald-200 dark:hover:border-emerald-800 transition-all duration-300"
                  onClick={() => router.push(`/news/${article.id}`)}
                >
                  <div className="relative overflow-hidden">
                    {article.image ? (
                      <img src={article.image} alt={article.title} className="w-full h-48 object-cover group-hover:scale-110 transition-transform duration-700" />
                    ) : (
                      <ArticleImagePlaceholder category={article.category} className="w-full h-48" />
                    )}
                    <div className="absolute inset-0 bg-gradient-to-t from-black/20 to-transparent opacity-0 group-hover:opacity-100 transition-opacity duration-300" />
                    <Badge className={`absolute top-3 right-3 ${getCategoryColor(article.category)} border-0 shadow-sm`}>
                      {getCategoryLabel(article.category)}
                    </Badge>
                    {article.isBreaking && (
                      <Badge className="absolute top-3 left-3 bg-red-500 text-white border-0 animate-pulse shadow-sm">عاجل</Badge>
                    )}
                  </div>
                  <div className="p-4 space-y-2.5 flex flex-col flex-1">
                    <h3 className="font-bold text-foreground line-clamp-2 group-hover:text-emerald-600 dark:group-hover:text-emerald-400 transition-colors leading-relaxed">
                      {article.title}
                    </h3>
                    {article.summary && (
                      <p className="text-sm text-muted-foreground line-clamp-2 flex-1 leading-relaxed">
                        {truncateText(article.summary, 120)}
                      </p>
                    )}
                    <div className="flex items-center justify-between text-xs text-muted-foreground pt-2 border-t border-border/50">
                      <div className="flex items-center gap-2">
                        <span className="flex items-center gap-1">
                          <User className="size-3" />
                          {article.author.name}
                        </span>
                        {article.publishedAt && (
                          <span className="flex items-center gap-1">
                            <Clock className="size-3" />
                            {timeAgo(article.publishedAt)}
                          </span>
                        )}
                      </div>
                      <span className="flex items-center gap-1">
                        <Eye className="size-3" />
                        {formatNumber(article.views)}
                      </span>
                    </div>
                  </div>
                </div>
              </motion.div>
            ))}
          </div>
        </div>
      )}

      {/* Pagination */}
      {!loading && renderPagination()}

      {/* Results count */}
      {!loading && pagination.total > 0 && (
        <p className="text-center text-sm text-muted-foreground">
          عرض {articles.length} من {pagination.total} مقال
        </p>
      )}
    </section>
  )
}
