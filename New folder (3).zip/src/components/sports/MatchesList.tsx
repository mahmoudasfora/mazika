'use client'

import { useEffect, useState, useCallback } from 'react'
import { Badge } from '@/components/ui/badge'
import { Skeleton } from '@/components/ui/skeleton'
import { Tabs, TabsList, TabsTrigger } from '@/components/ui/tabs'
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from '@/components/ui/select'
import { useRouter } from 'next/navigation'
import { formatTime, getStatusLabel, getStatusColor, formatMatchDate } from '@/lib/sports-utils'
import {
  Clock,
  Trophy,
  Radio,
  Filter,
  Zap,
  Calendar,
  MapPin,
  Tv,
  ArrowUpRight,
  ChevronLeft,
  Flame,
  Activity,
} from 'lucide-react'

interface TeamData {
  id: string
  name: string
  nameEn?: string
  shortName?: string
  logo?: string | null
  color?: string | null
}

interface LeagueData {
  id: string
  name: string
  nameEn?: string
  logo?: string | null
  type?: string
}

interface MatchData {
  id: string
  homeTeam: TeamData
  awayTeam: TeamData
  league: LeagueData
  homeScore: number | null
  awayScore: number | null
  status: string
  matchDate: string
  stadium?: string | null
}

interface LeagueOption {
  id: string
  name: string
}

function TeamBadge({ team, size = 'md' }: { team: TeamData; size?: 'sm' | 'md' | 'lg' }) {
  const sizeClasses = { sm: 'size-8 text-xs', md: 'size-11 text-sm', lg: 'size-14 text-base' }
  const color = team.color || '#10b981'
  const firstLetter = (team.shortName || team.name).charAt(0)
  return (
    <div className="relative">
      <div
        className={`${sizeClasses[size]} rounded-xl flex items-center justify-center font-bold text-white shrink-0 shadow-lg relative overflow-hidden`}
        style={{ backgroundColor: color }}
        title={team.name}
      >
        {team.logo ? (
          <img src={team.logo} alt={team.name} className="w-full h-full object-cover rounded-xl" />
        ) : (
          <>
            <span className="relative z-10">{firstLetter}</span>
            <div className="absolute inset-0 bg-gradient-to-br from-white/30 via-transparent to-transparent" />
          </>
        )}
      </div>
    </div>
  )
}

function MatchCard({ match, onClick }: { match: MatchData; onClick: () => void }) {
  const isLive = match.status === 'live' || match.status === 'halftime'
  const isFinished = match.status === 'finished'
  const isUpcoming = match.status === 'upcoming'

  return (
    <div
      className={`group relative bg-card border rounded-2xl overflow-hidden cursor-pointer transition-all duration-300 hover:shadow-lg hover:-translate-y-0.5 active:scale-[0.99] ${
        isLive
          ? 'border-red-500/30 shadow-red-500/5 shadow-md'
          : 'border-border hover:border-emerald-500/20'
      }`}
      onClick={onClick}
    >
      {/* Top Bar: League + Status */}
      <div className={`flex items-center justify-between px-3.5 py-2 ${
        isLive ? 'bg-red-500/5' : 'bg-muted/30'
      }`}>
        <div className="flex items-center gap-1.5">
          {match.league.logo ? (
            <img src={match.league.logo} alt="" className="w-4 h-4 rounded" />
          ) : (
            <div className="size-4 rounded bg-emerald-600/20 flex items-center justify-center">
              <Trophy className="w-2.5 h-2.5 text-emerald-600" />
            </div>
          )}
          <span className="text-[11px] font-semibold text-muted-foreground truncate max-w-[120px]">
            {match.league.name}
          </span>
        </div>
        <div className="flex items-center gap-1.5">
          {isLive && (
            <div className="flex items-center gap-1 bg-red-500 rounded-full px-2 py-0.5">
              <div className="w-1.5 h-1.5 rounded-full bg-white animate-pulse" />
              <span className="text-[9px] font-bold text-white">LIVE</span>
            </div>
          )}
          {!isLive && (
            <Badge className={`text-[10px] px-2 py-0 h-5 rounded-full font-semibold border-0 ${getStatusColor(match.status)}`} variant="secondary">
              {getStatusLabel(match.status)}
            </Badge>
          )}
        </div>
      </div>

      {/* Teams & Score */}
      <div className="px-4 py-4">
        <div className="flex items-center">
          {/* Home Team */}
          <div className="flex-1 flex items-center gap-2.5 min-w-0 justify-end">
            <div className="flex flex-col items-end">
              <span className="text-sm font-bold text-right truncate max-w-[130px] leading-tight">{match.homeTeam.name}</span>
              {match.stadium && isUpcoming && (
                <span className="text-[10px] text-muted-foreground flex items-center gap-0.5 mt-0.5">
                  <MapPin className="size-2.5" />{match.stadium}
                </span>
              )}
            </div>
            <TeamBadge team={match.homeTeam} size="md" />
          </div>

          {/* Score / Time */}
          <div className="flex flex-col items-center justify-center shrink-0 mx-3 min-w-[56px]">
            {isFinished || isLive ? (
              <div className="text-xl font-black tabular-nums tracking-wide">
                <span className={isLive ? 'text-red-600 dark:text-red-400' : ''}>{match.homeScore}</span>
                <span className="text-muted-foreground/40 mx-0.5">-</span>
                <span className={isLive ? 'text-red-600 dark:text-red-400' : ''}>{match.awayScore}</span>
              </div>
            ) : (
              <div className="flex flex-col items-center gap-0.5">
                <span className="text-base font-bold text-emerald-700 dark:text-emerald-400 tabular-nums">
                  {formatTime(match.matchDate)}
                </span>
                <span className="text-[9px] text-muted-foreground font-medium">
                  {formatMatchDate(match.matchDate)}
                </span>
              </div>
            )}
          </div>

          {/* Away Team */}
          <div className="flex-1 flex items-center gap-2.5 min-w-0">
            <TeamBadge team={match.awayTeam} size="md" />
            <div className="flex flex-col items-start">
              <span className="text-sm font-bold truncate max-w-[130px] leading-tight">{match.awayTeam.name}</span>
            </div>
          </div>
        </div>
      </div>

      {/* Bottom hover indicator */}
      <div className="absolute bottom-0 left-0 right-0 h-0.5 bg-gradient-to-l from-emerald-500 to-teal-500 opacity-0 group-hover:opacity-100 transition-opacity duration-300" />
    </div>
  )
}

function LiveMatchCard({ match, onClick }: { match: MatchData; onClick: () => void }) {
  const isLive = match.status === 'live' || match.status === 'halftime'
  if (!isLive) return null

  return (
    <div
      className="group relative bg-gradient-to-l from-red-600 via-red-700 to-red-800 rounded-2xl overflow-hidden cursor-pointer transition-all duration-300 hover:shadow-xl hover:shadow-red-500/20 hover:-translate-y-0.5 active:scale-[0.99]"
      onClick={onClick}
    >
      <div className="absolute inset-0 bg-[radial-gradient(circle_at_30%_30%,rgba(255,255,255,0.1),transparent_60%)]" />

      {/* Live Badge */}
      <div className="relative flex items-center justify-between px-4 py-2 bg-black/20">
        <div className="flex items-center gap-1.5">
          <Trophy className="w-3.5 h-3.5 text-white/60" />
          <span className="text-[11px] font-semibold text-white/80">{match.league.name}</span>
        </div>
        <div className="flex items-center gap-1 bg-white/20 backdrop-blur-sm rounded-full px-2.5 py-0.5">
          <div className="w-1.5 h-1.5 rounded-full bg-white animate-pulse" />
          <span className="text-[10px] font-bold text-white">مباشر</span>
        </div>
      </div>

      {/* Teams & Score */}
      <div className="relative px-5 py-5">
        <div className="flex items-center justify-center gap-4">
          <div className="flex flex-col items-center gap-2 flex-1 min-w-0">
            <div className="relative">
              <TeamBadge team={match.homeTeam} size="lg" />
              <div className="absolute inset-0 rounded-xl opacity-40 blur-md -z-10" style={{ backgroundColor: match.homeTeam.color || '#10b981' }} />
            </div>
            <span className="text-sm font-bold text-white text-center truncate w-full">{match.homeTeam.name}</span>
          </div>

          <div className="flex flex-col items-center shrink-0">
            <div className="flex items-center gap-2">
              <span className="text-4xl font-black text-white tabular-nums">{match.homeScore}</span>
              <span className="text-xl font-bold text-white/30">:</span>
              <span className="text-4xl font-black text-white tabular-nums">{match.awayScore}</span>
            </div>
          </div>

          <div className="flex flex-col items-center gap-2 flex-1 min-w-0">
            <div className="relative">
              <TeamBadge team={match.awayTeam} size="lg" />
              <div className="absolute inset-0 rounded-xl opacity-40 blur-md -z-10" style={{ backgroundColor: match.awayTeam.color || '#6366f1' }} />
            </div>
            <span className="text-sm font-bold text-white text-center truncate w-full">{match.awayTeam.name}</span>
          </div>
        </div>

        {match.stadium && (
          <div className="flex items-center justify-center gap-1 mt-3 text-white/50 text-[10px]">
            <MapPin className="size-3" />
            <span>{match.stadium}</span>
          </div>
        )}
      </div>
    </div>
  )
}

function MatchListSkeleton() {
  return (
    <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-3">
      {Array.from({ length: 6 }).map((_, i) => (
        <div key={i} className="bg-card border rounded-2xl overflow-hidden">
          <div className="flex items-center justify-between px-3.5 py-2 bg-muted/30">
            <Skeleton className="h-4 w-24 rounded-full" />
            <Skeleton className="h-5 w-14 rounded-full" />
          </div>
          <div className="px-4 py-4">
            <div className="flex items-center">
              <div className="flex-1 flex items-center gap-2 justify-end">
                <Skeleton className="h-4 w-20" />
                <Skeleton className="size-11 rounded-xl" />
              </div>
              <Skeleton className="h-8 w-14 mx-3" />
              <div className="flex-1 flex items-center gap-2">
                <Skeleton className="size-11 rounded-xl" />
                <Skeleton className="h-4 w-20" />
              </div>
            </div>
          </div>
        </div>
      ))}
    </div>
  )
}

function getDateForTab(tab: string): string | null {
  const today = new Date()
  switch (tab) {
    case 'today': return today.toISOString().split('T')[0]
    case 'tomorrow': {
      const d = new Date(today); d.setDate(d.getDate() + 1); return d.toISOString().split('T')[0]
    }
    case 'yesterday': {
      const d = new Date(today); d.setDate(d.getDate() - 1); return d.toISOString().split('T')[0]
    }
    case 'week': return null
    default: return today.toISOString().split('T')[0]
  }
}

export default function MatchesList() {
  const [matches, setMatches] = useState<MatchData[]>([])
  const [leagues, setLeagues] = useState<LeagueOption[]>([])
  const [loading, setLoading] = useState(true)
  const [error, setError] = useState<string | null>(null)
  const [dateTab, setDateTab] = useState('today')
  const [leagueFilter, setLeagueFilter] = useState('all')
  const [statusFilter, setStatusFilter] = useState('all')
  const router = useRouter()

  const fetchLeagues = useCallback(async () => {
    try {
      const res = await fetch('/api/leagues')
      if (!res.ok) return
      const data = await res.json()
      setLeagues((data.leagues || []).map((l: { id: string; name: string }) => ({ id: l.id, name: l.name })))
    } catch {}
  }, [])

  const fetchMatches = useCallback(async () => {
    setLoading(true)
    setError(null)
    try {
      const params = new URLSearchParams()
      const date = getDateForTab(dateTab)
      if (date) params.set('date', date)
      if (leagueFilter && leagueFilter !== 'all') params.set('leagueId', leagueFilter)
      if (statusFilter && statusFilter !== 'all') params.set('status', statusFilter)

      const queryString = params.toString()
      const url = queryString ? `/api/matches?${queryString}` : '/api/matches'
      const res = await fetch(url)
      if (!res.ok) throw new Error('فشل في جلب المباريات')
      const data = await res.json()
      setMatches(data.matches || [])
    } catch {
      setError('فشل في تحميل المباريات')
    } finally {
      setLoading(false)
    }
  }, [dateTab, leagueFilter, statusFilter])

  useEffect(() => { fetchLeagues() }, [fetchLeagues])
  useEffect(() => { fetchMatches() }, [fetchMatches])

  useEffect(() => {
    const hasLive = matches.some((m) => m.status === 'live' || m.status === 'halftime')
    if (!hasLive) return
    const interval = setInterval(fetchMatches, 60000)
    return () => clearInterval(interval)
  }, [matches, fetchMatches])

  const groupedMatches = matches.reduce<Record<string, { league: LeagueData; matches: MatchData[] }>>((acc, match) => {
    const leagueId = match.league.id
    if (!acc[leagueId]) acc[leagueId] = { league: match.league, matches: [] }
    acc[leagueId].matches.push(match)
    return acc
  }, {})

  const handleMatchClick = (matchId: string) => {
    router.push(`/matches/${matchId}`)
  }

  const liveMatches = matches.filter(m => m.status === 'live' || m.status === 'halftime')
  const otherMatches = matches.filter(m => m.status !== 'live' && m.status !== 'halftime')
  const liveCount = liveMatches.length
  const upcomingCount = matches.filter(m => m.status === 'upcoming').length
  const finishedCount = matches.filter(m => m.status === 'finished').length

  // Group non-live matches by league
  const otherGrouped = otherMatches.reduce<Record<string, { league: LeagueData; matches: MatchData[] }>>((acc, match) => {
    const leagueId = match.league.id
    if (!acc[leagueId]) acc[leagueId] = { league: match.league, matches: [] }
    acc[leagueId].matches.push(match)
    return acc
  }, {})

  return (
    <div className="space-y-6" dir="rtl">
      {/* ===== HERO HEADER ===== */}
      <div className="relative bg-gradient-to-l from-emerald-600 via-emerald-700 to-teal-800 rounded-3xl p-6 md:p-8 overflow-hidden">
        <div className="absolute inset-0 bg-[radial-gradient(circle_at_80%_20%,rgba(255,255,255,0.15),transparent_50%)]" />
        <div className="absolute inset-0 bg-[radial-gradient(circle_at_10%_90%,rgba(255,255,255,0.08),transparent_50%)]" />
        <div className="absolute top-0 right-0 w-40 h-40 bg-emerald-400/10 rounded-full translate-x-12 -translate-y-12 blur-2xl" />
        <div className="absolute bottom-0 left-0 w-32 h-32 bg-teal-400/10 rounded-full -translate-x-8 translate-y-8 blur-2xl" />

        <div className="relative">
          <div className="flex items-center justify-between flex-wrap gap-4">
            <div className="flex items-center gap-4">
              <div className="flex items-center justify-center size-14 rounded-2xl bg-white/20 backdrop-blur-sm shadow-xl">
                <Zap className="size-7 text-white" />
              </div>
              <div>
                <h1 className="text-3xl md:text-4xl font-black text-white tracking-tight">المباريات</h1>
                <p className="text-emerald-100/70 text-sm mt-0.5 font-medium">تابع كل المباريات لحظة بلحظة</p>
              </div>
            </div>

            <div className="flex items-center gap-2.5">
              {liveCount > 0 && (
                <div className="flex items-center gap-2 bg-red-500/25 backdrop-blur-sm rounded-full px-4 py-2 ring-1 ring-red-400/20">
                  <div className="relative">
                    <div className="size-2 rounded-full bg-red-400 animate-ping" />
                    <div className="absolute inset-0 size-2 rounded-full bg-red-400" />
                  </div>
                  <span className="text-sm font-bold text-white">{liveCount} مباشر</span>
                </div>
              )}
              <div className="flex items-center gap-2 bg-white/12 backdrop-blur-sm rounded-full px-4 py-2 ring-1 ring-white/10">
                <Activity className="size-3.5 text-white/70" />
                <span className="text-sm font-semibold text-white/90">{matches.length} مباراة</span>
              </div>
            </div>
          </div>

          {/* Quick Stats */}
          <div className="flex items-center gap-3 mt-5">
            <div className="flex items-center gap-2 bg-white/10 backdrop-blur-sm rounded-lg px-3 py-1.5 ring-1 ring-white/5">
              <div className="size-2 rounded-full bg-red-400" />
              <span className="text-xs font-semibold text-white/80">{liveCount} مباشر</span>
            </div>
            <div className="flex items-center gap-2 bg-white/10 backdrop-blur-sm rounded-lg px-3 py-1.5 ring-1 ring-white/5">
              <div className="size-2 rounded-full bg-amber-400" />
              <span className="text-xs font-semibold text-white/80">{upcomingCount} قادمة</span>
            </div>
            <div className="flex items-center gap-2 bg-white/10 backdrop-blur-sm rounded-lg px-3 py-1.5 ring-1 ring-white/5">
              <div className="size-2 rounded-full bg-emerald-400" />
              <span className="text-xs font-semibold text-white/80">{finishedCount} انتهت</span>
            </div>
          </div>
        </div>
      </div>

      {/* ===== FILTERS ===== */}
      <div className="space-y-3">
        <Tabs value={dateTab} onValueChange={setDateTab}>
          <TabsList className="w-full sm:w-auto bg-muted/40 p-1.5 rounded-xl ring-1 ring-border/50">
            <TabsTrigger value="today" className="flex-1 sm:flex-initial gap-1.5 text-xs data-[state=active]:bg-emerald-600 data-[state=active]:text-white data-[state=active]:shadow-lg data-[state=active]:shadow-emerald-600/25 rounded-lg px-4">
              <Calendar className="w-3.5 h-3.5" />اليوم
            </TabsTrigger>
            <TabsTrigger value="tomorrow" className="flex-1 sm:flex-initial text-xs data-[state=active]:bg-emerald-600 data-[state=active]:text-white data-[state=active]:shadow-lg data-[state=active]:shadow-emerald-600/25 rounded-lg px-4">
              غداً
            </TabsTrigger>
            <TabsTrigger value="yesterday" className="flex-1 sm:flex-initial text-xs data-[state=active]:bg-emerald-600 data-[state=active]:text-white data-[state=active]:shadow-lg data-[state=active]:shadow-emerald-600/25 rounded-lg px-4">
              أمس
            </TabsTrigger>
            <TabsTrigger value="week" className="flex-1 sm:flex-initial text-xs data-[state=active]:bg-emerald-600 data-[state=active]:text-white data-[state=active]:shadow-lg data-[state=active]:shadow-emerald-600/25 rounded-lg px-4">
              هذا الأسبوع
            </TabsTrigger>
          </TabsList>
        </Tabs>

        <div className="flex flex-wrap gap-2">
          <Select value={leagueFilter} onValueChange={setLeagueFilter}>
            <SelectTrigger className="w-[180px] rounded-xl border-border/50" size="sm">
              <Trophy className="w-3.5 h-3.5 text-emerald-600" />
              <SelectValue placeholder="البطولة" />
            </SelectTrigger>
            <SelectContent>
              <SelectItem value="all">كل البطولات</SelectItem>
              {leagues.map((league) => (
                <SelectItem key={league.id} value={league.id}>{league.name}</SelectItem>
              ))}
            </SelectContent>
          </Select>

          <Select value={statusFilter} onValueChange={setStatusFilter}>
            <SelectTrigger className="w-[140px] rounded-xl border-border/50" size="sm">
              <Filter className="w-3.5 h-3.5 text-emerald-600" />
              <SelectValue placeholder="الحالة" />
            </SelectTrigger>
            <SelectContent>
              <SelectItem value="all">الكل</SelectItem>
              <SelectItem value="live">مباشر</SelectItem>
              <SelectItem value="upcoming">لم تبدأ</SelectItem>
              <SelectItem value="finished">انتهت</SelectItem>
            </SelectContent>
          </Select>
        </div>
      </div>

      {/* Error State */}
      {error && (
        <div className="bg-card border border-red-200 dark:border-red-900/50 rounded-2xl p-10 text-center">
          <div className="size-16 rounded-full bg-red-100 dark:bg-red-900/30 flex items-center justify-center mx-auto mb-4">
            <Zap className="w-8 h-8 text-red-500" />
          </div>
          <p className="font-semibold text-lg">{error}</p>
          <button onClick={fetchMatches} className="mt-4 inline-flex items-center gap-2 bg-emerald-600 hover:bg-emerald-700 text-white rounded-xl px-6 py-2.5 text-sm font-semibold transition-colors">
            إعادة المحاولة
          </button>
        </div>
      )}

      {/* Loading State */}
      {loading && <MatchListSkeleton />}

      {/* No matches */}
      {!loading && !error && matches.length === 0 && (
        <div className="bg-card border rounded-2xl p-12 text-center">
          <div className="size-20 rounded-full bg-muted/50 flex items-center justify-center mx-auto mb-4">
            <Trophy className="w-10 h-10 text-muted-foreground/30" />
          </div>
          <p className="font-bold text-xl">لا توجد مباريات</p>
          <p className="text-sm mt-2 text-muted-foreground max-w-xs mx-auto">لا توجد مباريات تطابق الفلتر المحدد</p>
        </div>
      )}

      {/* ===== MATCHES CONTENT ===== */}
      {!loading && !error && matches.length > 0 && (
        <div className="space-y-6">
          {/* LIVE MATCHES SECTION */}
          {liveMatches.length > 0 && (
            <div>
              <div className="flex items-center gap-2 mb-4">
                <div className="flex items-center gap-1.5 bg-red-500 rounded-full px-3 py-1">
                  <div className="w-1.5 h-1.5 rounded-full bg-white animate-pulse" />
                  <span className="text-xs font-bold text-white">مباشر الآن</span>
                </div>
                <span className="text-xs text-muted-foreground font-medium">{liveMatches.length} مباراة جارية</span>
              </div>
              <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                {liveMatches.map((match) => (
                  <LiveMatchCard key={match.id} match={match} onClick={() => handleMatchClick(match.id)} />
                ))}
              </div>
            </div>
          )}

          {/* OTHER MATCHES BY LEAGUE */}
          {Object.keys(otherGrouped).length > 0 && (
            <div className="space-y-5">
              {Object.values(otherGrouped).map(({ league, matches: leagueMatches }) => (
                <div key={league.id}>
                  {/* League Header */}
                  <div className="flex items-center gap-3 mb-3 px-1">
                    <div className="flex items-center justify-center size-8 rounded-lg bg-gradient-to-br from-emerald-500 to-teal-600 shadow-md shadow-emerald-500/20">
                      {league.logo ? (
                        <img src={league.logo} alt="" className="w-5 h-5 rounded" />
                      ) : (
                        <Trophy className="w-4 h-4 text-white" />
                      )}
                    </div>
                    <span className="text-sm font-bold">{league.name}</span>
                    <Badge variant="outline" className="text-[10px] h-5 rounded-full px-2 border-emerald-200 dark:border-emerald-800 text-emerald-700 dark:text-emerald-400">
                      {leagueMatches.length}
                    </Badge>
                  </div>

                  {/* Match Cards Grid */}
                  <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-3">
                    {leagueMatches.map((match) => (
                      <MatchCard key={match.id} match={match} onClick={() => handleMatchClick(match.id)} />
                    ))}
                  </div>
                </div>
              ))}
            </div>
          )}
        </div>
      )}
    </div>
  )
}
