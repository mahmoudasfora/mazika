'use client'

import { useState, useEffect } from 'react'
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card'
import { Skeleton } from '@/components/ui/skeleton'
import { Award, ChevronLeft, Target } from 'lucide-react'
import { useRouter } from 'next/navigation'

interface League {
  id: string
  name: string
  nameEn: string | null
  country: string | null
  logo: string | null
  type: string
  season: string | null
  teamCount: number
}

interface TopScorer {
  id: string
  goals: number
  assists: number
  penaltyGoals: number
  player: {
    id: string
    name: string
    nameEn: string | null
    photo: string | null
    position: string | null
    number: number | null
    nationality: string | null
  }
  team: {
    id: string
    name: string
    nameEn: string | null
    shortName: string | null
    logo: string | null
  }
}

function TopScorersSkeleton() {
  return (
    <div className="space-y-2 px-3">
      {Array.from({ length: 5 }).map((_, i) => (
        <div key={i} className="flex items-center gap-3 py-2">
          <Skeleton className="size-7 rounded-full" />
          <div className="flex-1 space-y-1">
            <Skeleton className="h-3.5 w-24" />
            <Skeleton className="h-3 w-16" />
          </div>
          <Skeleton className="h-4 w-6" />
        </div>
      ))}
    </div>
  )
}

export default function TopScorersWidget() {
  const [leagues, setLeagues] = useState<League[]>([])
  const [selectedLeagueId, setSelectedLeagueId] = useState<string>('')
  const [topScorers, setTopScorers] = useState<TopScorer[]>([])
  const [loadingLeagues, setLoadingLeagues] = useState(true)
  const [loadingScorers, setLoadingScorers] = useState(false)
  const [error, setError] = useState<string | null>(null)
  const router = useRouter()

  useEffect(() => {
    async function fetchLeagues() {
      try {
        setLoadingLeagues(true)
        const res = await fetch('/api/leagues')
        if (!res.ok) throw new Error('فشل في جلب البطولات')
        const data = await res.json()
        setLeagues(data.leagues)
        if (data.leagues.length > 0) {
          setSelectedLeagueId(data.leagues[0].id)
        }
      } catch {
        setError('فشل في جلب البطولات')
      } finally {
        setLoadingLeagues(false)
      }
    }
    fetchLeagues()
  }, [])

  useEffect(() => {
    if (!selectedLeagueId) return
    async function fetchScorers() {
      try {
        setLoadingScorers(true)
        setError(null)
        const res = await fetch(`/api/topscorers?leagueId=${selectedLeagueId}`)
        if (!res.ok) throw new Error('فشل في جلب الهدافين')
        const data = await res.json()
        setTopScorers(data.topScorers)
      } catch {
        setError('فشل في جلب الهدافين')
        setTopScorers([])
      } finally {
        setLoadingScorers(false)
      }
    }
    fetchScorers()
  }, [selectedLeagueId])

  const top5 = topScorers.slice(0, 5)

  return (
    <Card className="overflow-hidden border shadow-sm hover:shadow-md transition-shadow duration-300">
      <CardHeader className="pb-2 bg-gradient-to-l from-amber-50 to-transparent dark:from-amber-950/20 dark:to-transparent">
        <CardTitle className="flex items-center gap-2 text-base font-bold">
          <div className="flex items-center justify-center size-8 rounded-lg bg-amber-500 text-white shadow-sm">
            <Award className="size-4" />
          </div>
          <span>الهدافون</span>
        </CardTitle>
      </CardHeader>
      <CardContent className="px-2 pb-4">
        {/* League Selector */}
        {loadingLeagues ? (
          <div className="flex gap-2 px-2 pb-3">
            {Array.from({ length: 4 }).map((_, i) => (
              <Skeleton key={i} className="h-6 w-16 rounded-full" />
            ))}
          </div>
        ) : (
          <div className="mb-3 flex flex-wrap gap-1 px-2" dir="rtl">
            {leagues.map((league) => (
              <button
                key={league.id}
                onClick={() => setSelectedLeagueId(league.id)}
                className={`rounded-full px-2.5 py-1 text-[11px] font-medium transition-colors ${
                  selectedLeagueId === league.id
                    ? 'bg-amber-500 text-white shadow-sm'
                    : 'bg-muted text-muted-foreground hover:bg-muted/80'
                }`}
              >
                {league.name}
              </button>
            ))}
          </div>
        )}

        {/* Top Scorers List */}
        {loadingScorers ? (
          <TopScorersSkeleton />
        ) : error ? (
          <div className="py-8 text-center text-sm text-red-500">{error}</div>
        ) : top5.length === 0 ? (
          <div className="py-8 text-center text-sm text-muted-foreground">
            لا توجد بيانات هدافين
          </div>
        ) : (
          <div className="space-y-1 px-1" dir="rtl">
            {top5.map((scorer, index) => (
              <div
                key={scorer.id}
                className={`flex items-center gap-2.5 rounded-lg px-2 py-2 transition-colors hover:bg-muted/50 ${
                  index === 0 ? 'bg-amber-50/50 dark:bg-amber-950/10' : ''
                }`}
              >
                {/* Position Badge */}
                <span
                  className={`flex size-7 shrink-0 items-center justify-center rounded-full text-xs font-bold ${
                    index === 0 ? 'bg-amber-500 text-white' :
                    index === 1 ? 'bg-gray-400 text-white' :
                    index === 2 ? 'bg-amber-700 text-white' :
                    'bg-muted text-muted-foreground'
                  }`}
                >
                  {index + 1}
                </span>

                {/* Player Info */}
                <div className="flex-1 min-w-0">
                  <p className="truncate text-sm font-semibold">{scorer.player.name}</p>
                  <p className="truncate text-[11px] text-muted-foreground">{scorer.team.shortName || scorer.team.name}</p>
                </div>

                {/* Stats */}
                <div className="flex items-center gap-3 text-xs">
                  <div className="flex flex-col items-center bg-emerald-50 dark:bg-emerald-950/20 rounded-lg px-2 py-1">
                    <span className="font-bold text-emerald-700 dark:text-emerald-400">{scorer.goals}</span>
                    <span className="text-[9px] text-muted-foreground">هدف</span>
                  </div>
                  <div className="flex flex-col items-center bg-muted/50 rounded-lg px-2 py-1">
                    <span className="font-medium text-muted-foreground">{scorer.assists}</span>
                    <span className="text-[9px] text-muted-foreground">تمريرة</span>
                  </div>
                </div>
              </div>
            ))}
          </div>
        )}

        {/* View All Link */}
        {topScorers.length > 0 && (
          <button
            onClick={() => router.push('/standings')}
            className="mt-3 flex w-full items-center justify-center gap-1 rounded-lg border border-amber-200 bg-amber-50 py-2 text-sm font-semibold text-amber-700 transition-colors hover:bg-amber-100 dark:border-amber-800 dark:bg-amber-950/30 dark:text-amber-400 dark:hover:bg-amber-950/50"
          >
            <span>عرض الكل</span>
            <ChevronLeft className="size-4" />
          </button>
        )}
      </CardContent>
    </Card>
  )
}
