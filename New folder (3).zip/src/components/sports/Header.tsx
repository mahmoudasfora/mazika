'use client'

import { useState, useEffect, useRef, useSyncExternalStore } from 'react'
import { useTheme } from 'next-themes'
import Link from 'next/link'
import { usePathname } from 'next/navigation'
import { Button } from '@/components/ui/button'
import { Input } from '@/components/ui/input'
import {
  Sheet,
  SheetContent,
  SheetHeader,
  SheetTitle,
  SheetTrigger,
} from '@/components/ui/sheet'
import {
  Search,
  Menu,
  Moon,
  Sun,
  Lock,
  Home,
  Newspaper,
  Trophy,
  BarChart3,
  Video,
  X,
} from 'lucide-react'
import { BreakingNewsBanner } from './BreakingNewsBanner'
import { cn } from '@/lib/utils'

interface NavItem {
  label: string
  href: string
  icon: React.ReactNode
}

const navItems: NavItem[] = [
  { label: 'الرئيسية', href: '/', icon: <Home className="size-4" /> },
  { label: 'الأخبار', href: '/news', icon: <Newspaper className="size-4" /> },
  { label: 'المباريات', href: '/matches', icon: <Trophy className="size-4" /> },
  { label: 'الترتيب', href: '/standings', icon: <BarChart3 className="size-4" /> },
  { label: 'الفيديوهات', href: '/videos', icon: <Video className="size-4" /> },
]

function isActive(pathname: string | null, href: string) {
  if (!pathname) return false
  if (href === '/') return pathname === '/'
  return pathname.startsWith(href)
}

export function Header() {
  const { theme, setTheme } = useTheme()
  const pathname = usePathname()
  const [isSearchOpen, setIsSearchOpen] = useState(false)
  const [searchQuery, setSearchQuery] = useState('')
  const [isMobileMenuOpen, setIsMobileMenuOpen] = useState(false)
  const searchInputRef = useRef<HTMLInputElement>(null)
  const [isScrolled, setIsScrolled] = useState(false)

  // Hydration-safe mount detection
  const mounted = useSyncExternalStore(
    () => () => {},
    () => true,
    () => false
  )

  useEffect(() => {
    const handleScroll = () => {
      setIsScrolled(window.scrollY > 10)
    }
    window.addEventListener('scroll', handleScroll, { passive: true })
    return () => window.removeEventListener('scroll', handleScroll)
  }, [])

  useEffect(() => {
    if (isSearchOpen && searchInputRef.current) {
      searchInputRef.current.focus()
    }
  }, [isSearchOpen])

  const handleSearch = (e: React.FormEvent) => {
    e.preventDefault()
    if (searchQuery.trim()) {
      window.location.href = `/news?search=${encodeURIComponent(searchQuery.trim())}`
      setSearchQuery('')
      setIsSearchOpen(false)
    }
  }

  const toggleTheme = () => {
    setTheme(theme === 'dark' ? 'light' : 'dark')
  }

  const activeNavIndex = navItems.findIndex((item) => isActive(pathname, item.href))

  return (
    <header
      dir="rtl"
      className={cn(
        'sticky top-0 z-50 w-full transition-all duration-300',
        isScrolled
          ? 'bg-background/95 backdrop-blur-md shadow-sm border-b border-border'
          : 'bg-background border-b border-border'
      )}
    >
      {/* Breaking News Ticker */}
      <BreakingNewsBanner />

      {/* Main Header Bar */}
      <div className="max-w-7xl mx-auto px-4">
        <div className="flex items-center justify-between h-14 md:h-16">
          {/* Logo */}
          <Link href="/" className="flex items-center gap-2 shrink-0 group">
            <div className="relative flex items-center justify-center size-9 md:size-10 rounded-xl overflow-hidden shadow-md group-hover:shadow-emerald-500/25 transition-shadow">
              <img src="/favicon.png" alt="سبورت بلس" className="size-full object-cover" />
            </div>
            <div className="flex flex-col">
              <span className="text-lg md:text-xl font-bold text-emerald-600 dark:text-emerald-400 leading-tight">
                سبورت بلس
              </span>
              <span className="text-[10px] text-muted-foreground leading-tight hidden md:block">
                أخبار الرياضة أولاً
              </span>
            </div>
          </Link>

          {/* Desktop Navigation */}
          <nav className="hidden md:flex items-center gap-1">
            {navItems.map((item) => (
              <Link
                key={item.href}
                href={item.href}
                className={cn(
                  'relative flex items-center gap-1.5 px-3 py-2 rounded-lg text-sm font-medium transition-all duration-200',
                  isActive(pathname, item.href)
                    ? 'text-emerald-600 dark:text-emerald-400 bg-emerald-50 dark:bg-emerald-500/10'
                    : 'text-muted-foreground hover:text-foreground hover:bg-accent'
                )}
              >
                {item.icon}
                {item.label}
                {isActive(pathname, item.href) && (
                  <span className="absolute bottom-0 right-0 left-0 h-0.5 bg-emerald-500 rounded-full" />
                )}
              </Link>
            ))}
          </nav>

          {/* Right Actions */}
          <div className="flex items-center gap-1">
            {/* Search */}
            <div className="relative flex items-center">
              {isSearchOpen && (
                <form onSubmit={handleSearch} className="flex items-center animate-in slide-in-from-left-5 fade-in duration-200">
                  <Input
                    ref={searchInputRef}
                    value={searchQuery}
                    onChange={(e) => setSearchQuery(e.target.value)}
                    placeholder="ابحث في الأخبار..."
                    className="w-40 lg:w-56 h-8 text-sm"
                    dir="rtl"
                  />
                  <Button
                    type="button"
                    variant="ghost"
                    size="icon"
                    className="size-8 mr-1"
                    onClick={() => {
                      setIsSearchOpen(false)
                      setSearchQuery('')
                    }}
                  >
                    <X className="size-4" />
                  </Button>
                </form>
              )}

              {!isSearchOpen && (
                <Button
                  variant="ghost"
                  size="icon"
                  onClick={() => setIsSearchOpen(true)}
                  className="text-muted-foreground hover:text-foreground"
                  aria-label="بحث"
                >
                  <Search className="size-5" />
                </Button>
              )}
            </div>

            {/* Dark Mode Toggle */}
            {mounted && (
              <Button
                variant="ghost"
                size="icon"
                onClick={toggleTheme}
                className="text-muted-foreground hover:text-foreground"
                aria-label={theme === 'dark' ? 'الوضع الفاتح' : 'الوضع الداكن'}
              >
                {theme === 'dark' ? (
                  <Sun className="size-5" />
                ) : (
                  <Moon className="size-5" />
                )}
              </Button>
            )}

            {/* Admin Link */}
            <Link href="/admin">
              <Button
                variant="ghost"
                size="icon"
                className={cn(
                  'text-muted-foreground hover:text-foreground',
                  pathname?.startsWith('/admin') && 'text-emerald-600 dark:text-emerald-400'
                )}
                aria-label="لوحة التحكم"
              >
                <Lock className="size-5" />
              </Button>
            </Link>

            {/* Mobile Menu Toggle */}
            <Sheet open={isMobileMenuOpen} onOpenChange={setIsMobileMenuOpen}>
              <SheetTrigger asChild>
                <Button
                  variant="ghost"
                  size="icon"
                  className="md:hidden text-muted-foreground hover:text-foreground"
                  aria-label="القائمة"
                >
                  <Menu className="size-5" />
                </Button>
              </SheetTrigger>
              <SheetContent side="right" className="w-72 p-0" dir="rtl">
                <SheetHeader className="p-4 border-b bg-emerald-50 dark:bg-emerald-500/10">
                  <SheetTitle className="flex items-center gap-2 text-right">
                    <span className="flex items-center justify-center size-8 rounded-lg overflow-hidden">
                      <img src="/favicon.png" alt="سبورت بلس" className="size-full object-cover" />
                    </span>
                    <span className="text-emerald-600 dark:text-emerald-400 font-bold">
                      سبورت بلس
                    </span>
                  </SheetTitle>
                </SheetHeader>
                <nav className="flex flex-col p-2">
                  {navItems.map((item) => (
                    <Link
                      key={item.href}
                      href={item.href}
                      onClick={() => setIsMobileMenuOpen(false)}
                      className={cn(
                        'flex items-center gap-3 px-4 py-3 rounded-lg text-sm font-medium transition-all',
                        isActive(pathname, item.href)
                          ? 'text-emerald-600 dark:text-emerald-400 bg-emerald-50 dark:bg-emerald-500/10'
                          : 'text-foreground hover:bg-accent'
                      )}
                    >
                      {item.icon}
                      {item.label}
                    </Link>
                  ))}
                  <div className="my-2 border-t" />
                  <Link
                    href="/admin"
                    onClick={() => setIsMobileMenuOpen(false)}
                    className={cn(
                      'flex items-center gap-3 px-4 py-3 rounded-lg text-sm font-medium transition-all',
                      pathname?.startsWith('/admin')
                        ? 'text-emerald-600 dark:text-emerald-400 bg-emerald-50 dark:bg-emerald-500/10'
                        : 'text-muted-foreground hover:bg-accent hover:text-foreground'
                    )}
                  >
                    <Lock className="size-4" />
                    لوحة التحكم
                  </Link>
                </nav>
              </SheetContent>
            </Sheet>
          </div>
        </div>
      </div>

      {/* Active page underline indicator - Desktop only */}
      {activeNavIndex >= 0 && (
        <div className="hidden md:block max-w-7xl mx-auto px-4">
          <div className="relative h-0.5">
            <div
              className="absolute h-full bg-emerald-500 transition-all duration-300 rounded-full"
              style={{
                width: `${100 / navItems.length}%`,
                right: `${(activeNavIndex / navItems.length) * 100}%`,
              }}
            />
          </div>
        </div>
      )}
    </header>
  )
}
