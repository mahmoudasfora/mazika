'use client'

import { useEffect, useState, useCallback } from 'react'
import { Plus, Pencil, Loader2 } from 'lucide-react'
import { Card, CardContent } from '@/components/ui/card'
import { Badge } from '@/components/ui/badge'
import { Button } from '@/components/ui/button'
import { Input } from '@/components/ui/input'
import { Skeleton } from '@/components/ui/skeleton'
import { Label } from '@/components/ui/label'
import {
  Table, TableBody, TableCell, TableHead, TableHeader, TableRow
} from '@/components/ui/table'
import {
  Dialog, DialogContent, DialogDescription, DialogFooter,
  DialogHeader, DialogTitle, DialogTrigger
} from '@/components/ui/dialog'
import {
  Select, SelectContent, SelectItem, SelectTrigger, SelectValue
} from '@/components/ui/select'
import { getStatusLabel, getStatusColor, formatFullDate } from '@/lib/sports-utils'
import type { Match, Team, League } from './types'
import { MATCH_STATUSES } from './constants'

export function AdminMatches() {
  const [matches, setMatches] = useState<Match[]>([])
  const [teams, setTeams] = useState<Team[]>([])
  const [leagues, setLeagues] = useState<League[]>([])
  const [loading, setLoading] = useState(true)
  const [dialogOpen, setDialogOpen] = useState(false)
  const [submitting, setSubmitting] = useState(false)
  const [editDialogOpen, setEditDialogOpen] = useState(false)
  const [editMatch, setEditMatch] = useState<Match | null>(null)

  // Create form state
  const [homeTeamId, setHomeTeamId] = useState('')
  const [awayTeamId, setAwayTeamId] = useState('')
  const [leagueId, setLeagueId] = useState('')
  const [matchDate, setMatchDate] = useState('')
  const [stadium, setStadium] = useState('')
  const [referee, setReferee] = useState('')
  const [broadcastChannels, setBroadcastChannels] = useState('')

  // Edit form state
  const [editHomeScore, setEditHomeScore] = useState('')
  const [editAwayScore, setEditAwayScore] = useState('')
  const [editStatus, setEditStatus] = useState('')

  const fetchData = useCallback(async () => {
    try {
      setLoading(true)
      const [matchesRes, teamsRes, leaguesRes] = await Promise.all([
        fetch('/api/matches?status=finished'),
        fetch('/api/teams'),
        fetch('/api/leagues'),
      ])
      const matchesData = await matchesRes.json()
      const teamsData = await teamsRes.json()
      const leaguesData = await leaguesRes.json()

      setMatches(matchesData.matches || [])
      setTeams(teamsData.teams || [])
      setLeagues(leaguesData.leagues || [])
    } catch {
      // silently fail
    } finally {
      setLoading(false)
    }
  }, [])

  useEffect(() => { fetchData() }, [fetchData])

  const resetCreateForm = () => {
    setHomeTeamId(''); setAwayTeamId(''); setLeagueId('')
    setMatchDate(''); setStadium(''); setReferee(''); setBroadcastChannels('')
  }

  const handleCreate = async () => {
    if (!homeTeamId || !awayTeamId || !leagueId || !matchDate) return
    setSubmitting(true)
    try {
      await fetch('/api/admin/matches', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          homeTeamId, awayTeamId, leagueId,
          matchDate, stadium, referee, broadcastChannels,
        }),
      })
      setDialogOpen(false)
      resetCreateForm()
      fetchData()
    } catch {
      // silently fail
    } finally {
      setSubmitting(false)
    }
  }

  const openEditDialog = (match: Match) => {
    setEditMatch(match)
    setEditHomeScore(match.homeScore?.toString() || '')
    setEditAwayScore(match.awayScore?.toString() || '')
    setEditStatus(match.status)
    setEditDialogOpen(true)
  }

  const handleEditSubmit = async () => {
    if (!editMatch) return
    setSubmitting(true)
    try {
      await fetch('/api/admin/matches', {
        method: 'PUT',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          id: editMatch.id,
          homeScore: editHomeScore !== '' ? parseInt(editHomeScore) : undefined,
          awayScore: editAwayScore !== '' ? parseInt(editAwayScore) : undefined,
          status: editStatus || undefined,
        }),
      })
      setEditDialogOpen(false)
      setEditMatch(null)
      fetchData()
    } catch {
      // silently fail
    } finally {
      setSubmitting(false)
    }
  }

  if (loading) {
    return (
      <div className="space-y-4">
        {Array.from({ length: 5 }).map((_, i) => (
          <Skeleton key={i} className="h-14 w-full" />
        ))}
      </div>
    )
  }

  return (
    <div className="space-y-4">
      <div className="flex items-center justify-between">
        <h2 className="text-xl font-bold">إدارة المباريات</h2>
        <Dialog open={dialogOpen} onOpenChange={setDialogOpen}>
          <DialogTrigger asChild>
            <Button className="bg-emerald-600 hover:bg-emerald-700" onClick={resetCreateForm}>
              <Plus className="size-4 ml-1" />
              مباراة جديدة
            </Button>
          </DialogTrigger>
          <DialogContent className="max-w-lg max-h-[90vh] overflow-y-auto" dir="rtl">
            <DialogHeader>
              <DialogTitle>مباراة جديدة</DialogTitle>
              <DialogDescription>أدخل بيانات المباراة الجديدة</DialogDescription>
            </DialogHeader>
            <div className="space-y-4">
              <div className="space-y-2">
                <Label>الدوري *</Label>
                <Select value={leagueId} onValueChange={setLeagueId}>
                  <SelectTrigger className="w-full"><SelectValue placeholder="اختر الدوري" /></SelectTrigger>
                  <SelectContent>
                    {leagues.map(l => (
                      <SelectItem key={l.id} value={l.id}>{l.name}</SelectItem>
                    ))}
                  </SelectContent>
                </Select>
              </div>
              <div className="grid grid-cols-2 gap-4">
                <div className="space-y-2">
                  <Label>الفريق المضيف *</Label>
                  <Select value={homeTeamId} onValueChange={setHomeTeamId}>
                    <SelectTrigger className="w-full"><SelectValue placeholder="اختر الفريق" /></SelectTrigger>
                    <SelectContent>
                      {teams.map(t => (
                        <SelectItem key={t.id} value={t.id}>{t.name}</SelectItem>
                      ))}
                    </SelectContent>
                  </Select>
                </div>
                <div className="space-y-2">
                  <Label>الفريق الضيف *</Label>
                  <Select value={awayTeamId} onValueChange={setAwayTeamId}>
                    <SelectTrigger className="w-full"><SelectValue placeholder="اختر الفريق" /></SelectTrigger>
                    <SelectContent>
                      {teams.map(t => (
                        <SelectItem key={t.id} value={t.id}>{t.name}</SelectItem>
                      ))}
                    </SelectContent>
                  </Select>
                </div>
              </div>
              <div className="space-y-2">
                <Label>تاريخ المباراة *</Label>
                <Input type="datetime-local" value={matchDate} onChange={(e) => setMatchDate(e.target.value)} />
              </div>
              <div className="space-y-2">
                <Label>الملعب</Label>
                <Input value={stadium} onChange={(e) => setStadium(e.target.value)} placeholder="اسم الملعب" />
              </div>
              <div className="space-y-2">
                <Label>الحكم</Label>
                <Input value={referee} onChange={(e) => setReferee(e.target.value)} placeholder="اسم الحكم" />
              </div>
              <div className="space-y-2">
                <Label>قنوات البث</Label>
                <Input value={broadcastChannels} onChange={(e) => setBroadcastChannels(e.target.value)} placeholder="beIN Sports, SSC" />
              </div>
            </div>
            <DialogFooter>
              <Button variant="outline" onClick={() => setDialogOpen(false)}>إلغاء</Button>
              <Button
                className="bg-emerald-600 hover:bg-emerald-700"
                onClick={handleCreate}
                disabled={submitting || !homeTeamId || !awayTeamId || !leagueId || !matchDate}
              >
                {submitting && <Loader2 className="size-4 ml-1 animate-spin" />}
                إنشاء
              </Button>
            </DialogFooter>
          </DialogContent>
        </Dialog>
      </div>

      {/* Matches Table */}
      <Card>
        <CardContent className="p-0">
          <Table>
            <TableHeader>
              <TableRow>
                <TableHead className="text-right">الفريق المضيف</TableHead>
                <TableHead className="text-right">الفريق الضيف</TableHead>
                <TableHead className="text-right">الدوري</TableHead>
                <TableHead className="text-right">النتيجة</TableHead>
                <TableHead className="text-right">الحالة</TableHead>
                <TableHead className="text-right">التاريخ</TableHead>
                <TableHead className="text-right">إجراءات</TableHead>
              </TableRow>
            </TableHeader>
            <TableBody>
              {matches.length === 0 ? (
                <TableRow>
                  <TableCell colSpan={7} className="text-center py-8 text-muted-foreground">لا توجد مباريات</TableCell>
                </TableRow>
              ) : (
                matches.map((match) => (
                  <TableRow key={match.id}>
                    <TableCell className="font-medium">{match.homeTeam.name}</TableCell>
                    <TableCell className="font-medium">{match.awayTeam.name}</TableCell>
                    <TableCell className="text-sm text-muted-foreground">{match.league.name}</TableCell>
                    <TableCell className="font-bold">
                      {match.homeScore ?? '-'} - {match.awayScore ?? '-'}
                    </TableCell>
                    <TableCell>
                      <Badge variant="secondary" className={`text-[10px] ${getStatusColor(match.status)}`}>
                        {getStatusLabel(match.status)}
                      </Badge>
                    </TableCell>
                    <TableCell className="text-xs text-muted-foreground">
                      {formatFullDate(match.matchDate)}
                    </TableCell>
                    <TableCell>
                      <Button variant="ghost" size="icon" className="size-8" onClick={() => openEditDialog(match)}>
                        <Pencil className="size-4" />
                      </Button>
                    </TableCell>
                  </TableRow>
                ))
              )}
            </TableBody>
          </Table>
        </CardContent>
      </Card>

      {/* Edit Match Dialog */}
      <Dialog open={editDialogOpen} onOpenChange={setEditDialogOpen}>
        <DialogContent className="max-w-md" dir="rtl">
          <DialogHeader>
            <DialogTitle>تعديل المباراة</DialogTitle>
            <DialogDescription>تحديث النتيجة والحالة</DialogDescription>
          </DialogHeader>
          {editMatch && (
            <div className="space-y-4">
              <div className="text-center">
                <p className="text-sm text-muted-foreground">
                  {editMatch.homeTeam.name} ضد {editMatch.awayTeam.name}
                </p>
              </div>
              <div className="grid grid-cols-2 gap-4">
                <div className="space-y-2">
                  <Label>نتيجة المضيف</Label>
                  <Input
                    type="number"
                    value={editHomeScore}
                    onChange={(e) => setEditHomeScore(e.target.value)}
                    placeholder="0"
                  />
                </div>
                <div className="space-y-2">
                  <Label>نتيجة الضيف</Label>
                  <Input
                    type="number"
                    value={editAwayScore}
                    onChange={(e) => setEditAwayScore(e.target.value)}
                    placeholder="0"
                  />
                </div>
              </div>
              <div className="space-y-2">
                <Label>الحالة</Label>
                <Select value={editStatus} onValueChange={setEditStatus}>
                  <SelectTrigger className="w-full"><SelectValue /></SelectTrigger>
                  <SelectContent>
                    {MATCH_STATUSES.map(s => (
                      <SelectItem key={s.value} value={s.value}>{s.label}</SelectItem>
                    ))}
                  </SelectContent>
                </Select>
              </div>
            </div>
          )}
          <DialogFooter>
            <Button variant="outline" onClick={() => setEditDialogOpen(false)}>إلغاء</Button>
            <Button className="bg-emerald-600 hover:bg-emerald-700" onClick={handleEditSubmit} disabled={submitting}>
              {submitting && <Loader2 className="size-4 ml-1 animate-spin" />}
              تحديث
            </Button>
          </DialogFooter>
        </DialogContent>
      </Dialog>
    </div>
  )
}
