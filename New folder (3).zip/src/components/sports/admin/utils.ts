// ===== دوال مساعدة للوحة التحكم =====

/** تحويل النص العربي إلى رابط صديق */
export function toSlug(text: string): string {
  return text
    .trim()
    .replace(/\s+/g, '-')
    .replace(/[^\u0621-\u064Aa-zA-Z0-9-]/g, '')
    .replace(/-+/g, '-')
    .toLowerCase()
}
