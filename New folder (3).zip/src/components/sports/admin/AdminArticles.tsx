'use client'

import { useEffect, useState, useCallback } from 'react'
import { Plus, Pencil, Trash2, Loader2 } from 'lucide-react'
import { Card, CardContent } from '@/components/ui/card'
import { Badge } from '@/components/ui/badge'
import { Button } from '@/components/ui/button'
import { Input } from '@/components/ui/input'
import { Textarea } from '@/components/ui/textarea'
import { Switch } from '@/components/ui/switch'
import { Skeleton } from '@/components/ui/skeleton'
import { Label } from '@/components/ui/label'
import {
  Table, TableBody, TableCell, TableHead, TableHeader, TableRow
} from '@/components/ui/table'
import {
  Dialog, DialogContent, DialogDescription, DialogFooter,
  DialogHeader, DialogTitle, DialogTrigger
} from '@/components/ui/dialog'
import {
  Select, SelectContent, SelectItem, SelectTrigger, SelectValue
} from '@/components/ui/select'
import { getCategoryLabel, getCategoryColor, formatFullDate } from '@/lib/sports-utils'
import type { Article } from './types'
import { ARTICLE_CATEGORIES, ARTICLE_STATUS_BADGE, ARTICLE_STATUS_LABEL } from './constants'
import { toSlug } from './utils'

export function AdminArticles() {
  const [articles, setArticles] = useState<Article[]>([])
  const [loading, setLoading] = useState(true)
  const [dialogOpen, setDialogOpen] = useState(false)
  const [submitting, setSubmitting] = useState(false)
  const [editId, setEditId] = useState<string | null>(null)

  // Form state
  const [formTitle, setFormTitle] = useState('')
  const [formSlug, setFormSlug] = useState('')
  const [formSummary, setFormSummary] = useState('')
  const [formContent, setFormContent] = useState('')
  const [formCategory, setFormCategory] = useState('general')
  const [formIsBreaking, setFormIsBreaking] = useState(false)
  const [formIsFeatured, setFormIsFeatured] = useState(false)
  const [formTags, setFormTags] = useState('')
  const [formImage, setFormImage] = useState('')

  const fetchArticles = useCallback(async () => {
    try {
      setLoading(true)
      const res = await fetch('/api/articles?status=&limit=50')
      const data = await res.json()
      setArticles(data.articles || [])
    } catch {
      // silently fail
    } finally {
      setLoading(false)
    }
  }, [])

  useEffect(() => { fetchArticles() }, [fetchArticles])

  const resetForm = () => {
    setFormTitle(''); setFormSlug(''); setFormSummary(''); setFormContent('')
    setFormCategory('general'); setFormIsBreaking(false); setFormIsFeatured(false)
    setFormTags(''); setFormImage(''); setEditId(null)
  }

  const openCreateDialog = () => {
    resetForm()
    setDialogOpen(true)
  }

  const openEditDialog = (article: Article) => {
    setEditId(article.id)
    setFormTitle(article.title)
    setFormSlug(article.slug)
    setFormSummary(article.summary || '')
    setFormContent(article.content)
    setFormCategory(article.category)
    setFormIsBreaking(article.isBreaking)
    setFormIsFeatured(article.isFeatured)
    setFormTags('')
    setFormImage(article.image || '')
    setDialogOpen(true)
  }

  const handleSubmit = async () => {
    if (!formTitle || !formContent) return
    setSubmitting(true)
    try {
      const tags = formTags.split(',').map(t => t.trim()).filter(Boolean)
      if (editId) {
        await fetch(`/api/articles/${editId}`, {
          method: 'PUT',
          headers: { 'Content-Type': 'application/json' },
          body: JSON.stringify({
            title: formTitle,
            slug: formSlug || toSlug(formTitle),
            summary: formSummary,
            content: formContent,
            category: formCategory,
            isBreaking: formIsBreaking,
            isFeatured: formIsFeatured,
            image: formImage || null,
          }),
        })
      } else {
        await fetch('/api/admin/articles', {
          method: 'POST',
          headers: { 'Content-Type': 'application/json' },
          body: JSON.stringify({
            title: formTitle,
            slug: formSlug || toSlug(formTitle),
            summary: formSummary,
            content: formContent,
            category: formCategory,
            isBreaking: formIsBreaking,
            isFeatured: formIsFeatured,
            status: 'draft',
            authorId: 'admin',
            tags,
            image: formImage || null,
          }),
        })
      }
      setDialogOpen(false)
      resetForm()
      fetchArticles()
    } catch {
      // silently fail
    } finally {
      setSubmitting(false)
    }
  }

  const handleDelete = async (id: string) => {
    if (!confirm('هل أنت متأكد من حذف هذا المقال؟')) return
    try {
      await fetch(`/api/articles/${id}`, { method: 'DELETE' })
      fetchArticles()
    } catch {
      // silently fail
    }
  }

  if (loading) {
    return (
      <div className="space-y-4">
        {Array.from({ length: 5 }).map((_, i) => (
          <Skeleton key={i} className="h-14 w-full" />
        ))}
      </div>
    )
  }

  return (
    <div className="space-y-4">
      {/* Header */}
      <div className="flex items-center justify-between">
        <h2 className="text-xl font-bold">إدارة المقالات</h2>
        <Dialog open={dialogOpen} onOpenChange={setDialogOpen}>
          <DialogTrigger asChild>
            <Button className="bg-emerald-600 hover:bg-emerald-700" onClick={openCreateDialog}>
              <Plus className="size-4 ml-1" />
              مقال جديد
            </Button>
          </DialogTrigger>
          <DialogContent className="max-w-2xl max-h-[90vh] overflow-y-auto" dir="rtl">
            <DialogHeader>
              <DialogTitle>{editId ? 'تعديل المقال' : 'مقال جديد'}</DialogTitle>
              <DialogDescription>
                {editId ? 'قم بتعديل بيانات المقال' : 'أدخل بيانات المقال الجديد'}
              </DialogDescription>
            </DialogHeader>
            <div className="space-y-4">
              <div className="space-y-2">
                <Label>العنوان *</Label>
                <Input
                  value={formTitle}
                  onChange={(e) => {
                    setFormTitle(e.target.value)
                    if (!editId) setFormSlug(toSlug(e.target.value))
                  }}
                  placeholder="عنوان المقال"
                />
              </div>
              <div className="space-y-2">
                <Label>الرابط (Slug)</Label>
                <Input
                  value={formSlug}
                  onChange={(e) => setFormSlug(e.target.value)}
                  placeholder="رابط-المقال"
                />
              </div>
              <div className="space-y-2">
                <Label>الملخص</Label>
                <Textarea
                  value={formSummary}
                  onChange={(e) => setFormSummary(e.target.value)}
                  placeholder="ملخص المقال"
                  rows={2}
                />
              </div>
              <div className="space-y-2">
                <Label>المحتوى *</Label>
                <Textarea
                  value={formContent}
                  onChange={(e) => setFormContent(e.target.value)}
                  placeholder="محتوى المقال"
                  rows={6}
                />
              </div>
              <div className="grid grid-cols-2 gap-4">
                <div className="space-y-2">
                  <Label>التصنيف</Label>
                  <Select value={formCategory} onValueChange={setFormCategory}>
                    <SelectTrigger className="w-full">
                      <SelectValue />
                    </SelectTrigger>
                    <SelectContent>
                      {ARTICLE_CATEGORIES.map(cat => (
                        <SelectItem key={cat.value} value={cat.value}>{cat.label}</SelectItem>
                      ))}
                    </SelectContent>
                  </Select>
                </div>
                <div className="space-y-2">
                  <Label>رابط الصورة</Label>
                  <Input
                    value={formImage}
                    onChange={(e) => setFormImage(e.target.value)}
                    placeholder="https://..."
                  />
                </div>
              </div>
              <div className="flex items-center gap-6">
                <div className="flex items-center gap-2">
                  <Switch checked={formIsBreaking} onCheckedChange={setFormIsBreaking} />
                  <Label>خبر عاجل</Label>
                </div>
                <div className="flex items-center gap-2">
                  <Switch checked={formIsFeatured} onCheckedChange={setFormIsFeatured} />
                  <Label>مقال مميز</Label>
                </div>
              </div>
              <div className="space-y-2">
                <Label>الوسوم (مفصولة بفواصل)</Label>
                <Input
                  value={formTags}
                  onChange={(e) => setFormTags(e.target.value)}
                  placeholder="كرة قدم، دوري، أهلي"
                />
              </div>
            </div>
            <DialogFooter>
              <Button variant="outline" onClick={() => setDialogOpen(false)}>إلغاء</Button>
              <Button
                className="bg-emerald-600 hover:bg-emerald-700"
                onClick={handleSubmit}
                disabled={submitting || !formTitle || !formContent}
              >
                {submitting && <Loader2 className="size-4 ml-1 animate-spin" />}
                {editId ? 'تحديث' : 'إنشاء'}
              </Button>
            </DialogFooter>
          </DialogContent>
        </Dialog>
      </div>

      {/* Articles Table */}
      <Card>
        <CardContent className="p-0">
          <Table>
            <TableHeader>
              <TableRow>
                <TableHead className="text-right">العنوان</TableHead>
                <TableHead className="text-right">التصنيف</TableHead>
                <TableHead className="text-right">الحالة</TableHead>
                <TableHead className="text-right">الكاتب</TableHead>
                <TableHead className="text-right">المشاهدات</TableHead>
                <TableHead className="text-right">التاريخ</TableHead>
                <TableHead className="text-right">إجراءات</TableHead>
              </TableRow>
            </TableHeader>
            <TableBody>
              {articles.length === 0 ? (
                <TableRow>
                  <TableCell colSpan={7} className="text-center py-8 text-muted-foreground">
                    لا توجد مقالات
                  </TableCell>
                </TableRow>
              ) : (
                articles.map((article) => (
                  <TableRow key={article.id}>
                    <TableCell className="max-w-[200px]">
                      <p className="truncate font-medium">{article.title}</p>
                      {article.isBreaking && (
                        <Badge className="bg-red-500 text-white text-[10px] mt-1">عاجل</Badge>
                      )}
                    </TableCell>
                    <TableCell>
                      <Badge variant="secondary" className={`text-[10px] ${getCategoryColor(article.category)}`}>
                        {getCategoryLabel(article.category)}
                      </Badge>
                    </TableCell>
                    <TableCell>
                      <Badge variant="secondary" className={`text-[10px] ${ARTICLE_STATUS_BADGE[article.status] || ''}`}>
                        {ARTICLE_STATUS_LABEL[article.status] || article.status}
                      </Badge>
                    </TableCell>
                    <TableCell className="text-sm text-muted-foreground">{article.author?.name || '-'}</TableCell>
                    <TableCell className="text-sm">{article.views}</TableCell>
                    <TableCell className="text-xs text-muted-foreground">
                      {article.createdAt ? formatFullDate(article.createdAt) : '-'}
                    </TableCell>
                    <TableCell>
                      <div className="flex items-center gap-1">
                        <Button variant="ghost" size="icon" className="size-8" onClick={() => openEditDialog(article)}>
                          <Pencil className="size-4" />
                        </Button>
                        <Button variant="ghost" size="icon" className="size-8 text-red-500 hover:text-red-600" onClick={() => handleDelete(article.id)}>
                          <Trash2 className="size-4" />
                        </Button>
                      </div>
                    </TableCell>
                  </TableRow>
                ))
              )}
            </TableBody>
          </Table>
        </CardContent>
      </Card>
    </div>
  )
}
