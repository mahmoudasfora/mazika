// ===== أنواع البيانات المشتركة في لوحة التحكم =====

export interface Stats {
  totalArticles: number
  totalMatches: number
  totalUsers: number
  liveMatches: number
  todaysMatches: number
  breakingNews: number
}

export interface ArticleAuthor {
  id: string
  name: string
  avatar: string | null
  role: string
}

export interface Article {
  id: string
  title: string
  slug: string
  summary: string | null
  content: string
  image: string | null
  category: string
  isBreaking: boolean
  isFeatured: boolean
  status: string
  authorId: string
  publishedAt: string | null
  views: number
  createdAt: string
  updatedAt: string
  author: ArticleAuthor
}

export interface MatchTeam {
  id: string
  name: string
  nameEn: string | null
  shortName: string | null
  logo: string | null
  color?: string | null
}

export interface MatchLeague {
  id: string
  name: string
  nameEn: string | null
  logo: string | null
}

export interface Match {
  id: string
  homeTeamId: string
  awayTeamId: string
  leagueId: string
  homeScore: number | null
  awayScore: number | null
  status: string
  matchDate: string
  stadium: string | null
  referee: string | null
  broadcastChannels: string | null
  createdAt: string
  homeTeam: MatchTeam
  awayTeam: MatchTeam
  league: MatchLeague
}

export interface League {
  id: string
  name: string
  nameEn: string | null
  country: string | null
  type: string
  season: string | null
  isActive: boolean
  teamCount: number
}

export interface Team {
  id: string
  name: string
  nameEn: string | null
  shortName: string | null
  country: string | null
  city: string | null
  stadium: string | null
  founded: number | null
  color: string | null
  playerCount: number
}
