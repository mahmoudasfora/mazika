import type { AdminTab } from '@/lib/navigation-store'
import {
  LayoutDashboard, FileText, Trophy, Users, Megaphone, Settings,
} from 'lucide-react'

// ===== قائمة الشريط الجانبي =====
export const SIDEBAR_ITEMS: { id: AdminTab; label: string; icon: React.ElementType }[] = [
  { id: 'dashboard', label: 'لوحة التحكم', icon: LayoutDashboard },
  { id: 'articles', label: 'المقالات', icon: FileText },
  { id: 'matches', label: 'المباريات', icon: Trophy },
  { id: 'leagues', label: 'البطولات', icon: Megaphone },
  { id: 'teams', label: 'الفرق', icon: Users },
  { id: 'settings', label: 'الإعدادات', icon: Settings },
]

// ===== تصنيفات المقالات =====
export const ARTICLE_CATEGORIES = [
  { value: 'general', label: 'أخبار عامة' },
  { value: 'transfer', label: 'انتقالات' },
  { value: 'analysis', label: 'تحليلات' },
  { value: 'interview', label: 'مقابلات' },
  { value: 'report', label: 'تقارير' },
]

// ===== حالات المباراة =====
export const MATCH_STATUSES = [
  { value: 'upcoming', label: 'لم تبدأ' },
  { value: 'live', label: 'مباشر' },
  { value: 'halftime', label: 'استراحة' },
  { value: 'finished', label: 'انتهت' },
  { value: 'postponed', label: 'مؤجلة' },
  { value: 'cancelled', label: 'ملغاة' },
]

// ===== ألوان حالات المقال =====
export const ARTICLE_STATUS_BADGE: Record<string, string> = {
  draft: 'bg-gray-100 text-gray-700 dark:bg-gray-800 dark:text-gray-300',
  review: 'bg-yellow-100 text-yellow-700 dark:bg-yellow-900 dark:text-yellow-300',
  published: 'bg-green-100 text-green-700 dark:bg-green-900 dark:text-green-300',
}

// ===== أسماء حالات المقال =====
export const ARTICLE_STATUS_LABEL: Record<string, string> = {
  draft: 'مسودة',
  review: 'قيد المراجعة',
  published: 'منشور',
}
