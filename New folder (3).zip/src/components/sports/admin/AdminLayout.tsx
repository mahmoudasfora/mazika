'use client'

import { useState } from 'react'
import { Menu, X, Radio } from 'lucide-react'
import { Badge } from '@/components/ui/badge'
import { Button } from '@/components/ui/button'
import { useNavigation } from '@/lib/navigation-store'
import { SIDEBAR_ITEMS } from './constants'

export function AdminLayout({ children }: { children: React.ReactNode }) {
  const { adminTab, setAdminTab } = useNavigation()
  const [sidebarOpen, setSidebarOpen] = useState(false)

  return (
    <div dir="rtl" className="flex min-h-[calc(100vh-4rem)] bg-background">
      {/* Mobile Overlay */}
      {sidebarOpen && (
        <div
          className="fixed inset-0 z-40 bg-black/50 lg:hidden"
          onClick={() => setSidebarOpen(false)}
        />
      )}

      {/* Sidebar */}
      <aside
        className={`
          fixed top-0 right-0 z-50 h-full w-64 bg-gray-900 text-white transform transition-transform duration-300
          lg:relative lg:translate-x-0 lg:z-auto
          ${sidebarOpen ? 'translate-x-0' : 'translate-x-full lg:translate-x-0'}
        `}
      >
        <div className="flex items-center justify-between p-4 border-b border-gray-800">
          <div className="flex items-center gap-2">
            <div className="size-8 rounded-lg bg-emerald-500 flex items-center justify-center font-bold text-sm">
              لو
            </div>
            <span className="font-bold text-lg">لوحة التحكم</span>
          </div>
          <Button
            variant="ghost"
            size="icon"
            className="text-gray-400 hover:text-white lg:hidden"
            onClick={() => setSidebarOpen(false)}
          >
            <X className="size-5" />
          </Button>
        </div>

        <nav className="p-3 space-y-1">
          {SIDEBAR_ITEMS.map((item) => {
            const Icon = item.icon
            const isActive = adminTab === item.id
            return (
              <button
                key={item.id}
                onClick={() => { setAdminTab(item.id); setSidebarOpen(false) }}
                className={`
                  w-full flex items-center gap-3 px-3 py-2.5 rounded-lg text-sm font-medium transition-all duration-200
                  ${isActive
                    ? 'bg-emerald-600 text-white shadow-lg shadow-emerald-600/25'
                    : 'text-gray-400 hover:text-white hover:bg-gray-800'
                  }
                `}
              >
                <Icon className="size-5" />
                {item.label}
              </button>
            )
          })}
        </nav>

        <div className="absolute bottom-0 left-0 right-0 p-4 border-t border-gray-800">
          <div className="flex items-center gap-3">
            <div className="size-9 rounded-full bg-emerald-500 flex items-center justify-center text-sm font-bold">
              م
            </div>
            <div>
              <p className="text-sm font-medium">المدير</p>
              <p className="text-xs text-gray-400">admin@sportpulse.com</p>
            </div>
          </div>
        </div>
      </aside>

      {/* Main Content */}
      <main className="flex-1 min-w-0">
        {/* Top Bar */}
        <div className="sticky top-0 z-30 bg-background/95 backdrop-blur border-b px-4 py-3 flex items-center justify-between">
          <Button
            variant="ghost"
            size="icon"
            className="lg:hidden"
            onClick={() => setSidebarOpen(true)}
          >
            <Menu className="size-5" />
          </Button>
          <h1 className="text-lg font-bold text-foreground">
            {SIDEBAR_ITEMS.find(i => i.id === adminTab)?.label || 'لوحة التحكم'}
          </h1>
          <div className="flex items-center gap-2">
            <Badge variant="outline" className="text-emerald-600 border-emerald-600">
              <Radio className="size-3 ml-1" />
              مباشر
            </Badge>
          </div>
        </div>

        {/* Content Area */}
        <div className="p-4 md:p-6">
          {children}
        </div>
      </main>
    </div>
  )
}
