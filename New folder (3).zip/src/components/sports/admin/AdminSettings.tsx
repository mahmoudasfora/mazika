'use client'

import { useState } from 'react'
import { BarChart3, Megaphone, Loader2 } from 'lucide-react'
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from '@/components/ui/card'
import { Button } from '@/components/ui/button'
import { Input } from '@/components/ui/input'
import { Textarea } from '@/components/ui/textarea'
import { Label } from '@/components/ui/label'

export function AdminSettings() {
  const [siteName, setSiteName] = useState('سبورت بلس')
  const [siteDescription, setSiteDescription] = useState('منصة الأخبار الرياضية العربية')
  const [saving, setSaving] = useState(false)

  const handleSave = async () => {
    setSaving(true)
    // Placeholder save — would call a real API
    await new Promise(resolve => setTimeout(resolve, 1000))
    setSaving(false)
  }

  return (
    <div className="space-y-6">
      <h2 className="text-xl font-bold">الإعدادات</h2>

      {/* General Settings */}
      <Card>
        <CardHeader>
          <CardTitle className="text-base">إعدادات عامة</CardTitle>
          <CardDescription>إعدادات الموقع الأساسية</CardDescription>
        </CardHeader>
        <CardContent className="space-y-4">
          <div className="space-y-2">
            <Label>اسم الموقع</Label>
            <Input value={siteName} onChange={(e) => setSiteName(e.target.value)} />
          </div>
          <div className="space-y-2">
            <Label>وصف الموقع</Label>
            <Textarea value={siteDescription} onChange={(e) => setSiteDescription(e.target.value)} rows={3} />
          </div>
          <div className="flex justify-end">
            <Button className="bg-emerald-600 hover:bg-emerald-700" onClick={handleSave} disabled={saving}>
              {saving && <Loader2 className="size-4 ml-1 animate-spin" />}
              حفظ الإعدادات
            </Button>
          </div>
        </CardContent>
      </Card>

      {/* SEO Settings */}
      <Card>
        <CardHeader>
          <CardTitle className="text-base flex items-center gap-2">
            <BarChart3 className="size-5 text-emerald-500" />
            إعدادات SEO
          </CardTitle>
          <CardDescription>تحسين محركات البحث</CardDescription>
        </CardHeader>
        <CardContent className="space-y-4">
          <div className="space-y-2">
            <Label>الكلمات المفتاحية</Label>
            <Input placeholder="أخبار رياضية، كرة قدم، دوري" />
          </div>
          <div className="space-y-2">
            <Label>وصف الميتا</Label>
            <Textarea placeholder="وصف مختصر للموقع لمحركات البحث" rows={2} />
          </div>
          <div className="flex justify-end">
            <Button variant="outline">حفظ</Button>
          </div>
        </CardContent>
      </Card>

      {/* Ad Management Placeholder */}
      <Card>
        <CardHeader>
          <CardTitle className="text-base flex items-center gap-2">
            <Megaphone className="size-5 text-emerald-500" />
            إدارة الإعلانات
          </CardTitle>
          <CardDescription>إدارة مواضع الإعلانات والبانرات</CardDescription>
        </CardHeader>
        <CardContent>
          <div className="text-center py-8 text-muted-foreground">
            <Megaphone className="size-12 mx-auto mb-3 opacity-30" />
            <p>قريباً - إدارة الإعلانات</p>
            <p className="text-sm mt-1">سيتم إضافة هذه الميزة قريباً</p>
          </div>
        </CardContent>
      </Card>
    </div>
  )
}
