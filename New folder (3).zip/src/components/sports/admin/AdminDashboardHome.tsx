'use client'

import { useEffect, useState } from 'react'
import {
  FileText, Trophy, Users, Plus, BarChart3, Eye,
  TrendingUp, Radio, AlertTriangle
} from 'lucide-react'
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card'
import { Badge } from '@/components/ui/badge'
import { Button } from '@/components/ui/button'
import { Skeleton } from '@/components/ui/skeleton'
import { useNavigation } from '@/lib/navigation-store'
import { getCategoryLabel, getCategoryColor, getStatusLabel, getStatusColor, formatFullDate, timeAgo } from '@/lib/sports-utils'
import { BarChart, Bar, XAxis, YAxis, CartesianGrid, Tooltip, ResponsiveContainer } from 'recharts'
import type { Stats, Article, Match } from './types'
import { ARTICLE_CATEGORIES } from './constants'

export function AdminDashboardHome() {
  const [stats, setStats] = useState<Stats | null>(null)
  const [loading, setLoading] = useState(true)
  const [recentArticles, setRecentArticles] = useState<Article[]>([])
  const [recentMatches, setRecentMatches] = useState<Match[]>([])
  const { setAdminTab } = useNavigation()

  useEffect(() => {
    async function fetchData() {
      try {
        const [statsRes, articlesRes, matchesRes] = await Promise.all([
          fetch('/api/stats'),
          fetch('/api/articles?status=published&limit=5'),
          fetch('/api/matches?status=finished'),
        ])
        const statsData = await statsRes.json()
        const articlesData = await articlesRes.json()
        const matchesData = await matchesRes.json()

        setStats(statsData.stats || null)
        setRecentArticles((articlesData.articles || []).slice(0, 5))
        setRecentMatches((matchesData.matches || []).slice(0, 5))
      } catch {
        // silently fail
      } finally {
        setLoading(false)
      }
    }
    fetchData()
  }, [])

  // Prepare chart data from articles
  const chartData = ARTICLE_CATEGORIES.map(cat => ({
    name: cat.label,
    count: recentArticles.filter(a => a.category === cat.value).length
  }))

  const statsCards = stats ? [
    { title: 'إجمالي المقالات', value: stats.totalArticles, icon: FileText, color: 'text-blue-500', bg: 'bg-blue-50 dark:bg-blue-950' },
    { title: 'إجمالي المباريات', value: stats.totalMatches, icon: Trophy, color: 'text-emerald-500', bg: 'bg-emerald-50 dark:bg-emerald-950' },
    { title: 'مباريات مباشرة', value: stats.liveMatches, icon: Radio, color: 'text-red-500', bg: 'bg-red-50 dark:bg-red-950' },
    { title: 'إجمالي المستخدمين', value: stats.totalUsers, icon: Users, color: 'text-purple-500', bg: 'bg-purple-50 dark:bg-purple-950' },
    { title: 'أخبار عاجلة', value: stats.breakingNews, icon: AlertTriangle, color: 'text-orange-500', bg: 'bg-orange-50 dark:bg-orange-950' },
    { title: 'مباريات اليوم', value: stats.todaysMatches, icon: TrendingUp, color: 'text-teal-500', bg: 'bg-teal-50 dark:bg-teal-950' },
  ] : []

  if (loading) {
    return (
      <div className="space-y-6">
        <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-4">
          {Array.from({ length: 6 }).map((_, i) => (
            <Card key={i} className="p-4">
              <div className="flex items-center gap-4">
                <Skeleton className="size-12 rounded-xl" />
                <div className="space-y-2 flex-1">
                  <Skeleton className="h-4 w-24" />
                  <Skeleton className="h-6 w-16" />
                </div>
              </div>
            </Card>
          ))}
        </div>
      </div>
    )
  }

  return (
    <div className="space-y-6">
      {/* Stats Cards */}
      <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-4">
        {statsCards.map((card) => {
          const Icon = card.icon
          return (
            <Card key={card.title} className="p-4">
              <div className="flex items-center gap-4">
                <div className={`size-12 rounded-xl ${card.bg} flex items-center justify-center`}>
                  <Icon className={`size-6 ${card.color}`} />
                </div>
                <div>
                  <p className="text-sm text-muted-foreground">{card.title}</p>
                  <p className="text-2xl font-bold text-foreground">{card.value}</p>
                </div>
              </div>
            </Card>
          )
        })}
      </div>

      {/* Quick Actions */}
      <div className="flex flex-wrap gap-3">
        <Button
          className="bg-emerald-600 hover:bg-emerald-700"
          onClick={() => setAdminTab('articles')}
        >
          <Plus className="size-4 ml-1" />
          مقال جديد
        </Button>
        <Button
          className="bg-emerald-600 hover:bg-emerald-700"
          onClick={() => setAdminTab('matches')}
        >
          <Plus className="size-4 ml-1" />
          مباراة جديدة
        </Button>
      </div>

      <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
        {/* Articles by Category Chart */}
        <Card>
          <CardHeader>
            <CardTitle className="flex items-center gap-2 text-base">
              <BarChart3 className="size-5 text-emerald-500" />
              المقالات حسب التصنيف
            </CardTitle>
          </CardHeader>
          <CardContent>
            <div className="h-64">
              <ResponsiveContainer width="100%" height="100%">
                <BarChart data={chartData} layout="vertical">
                  <CartesianGrid strokeDasharray="3 3" horizontal={false} />
                  <XAxis type="number" />
                  <YAxis dataKey="name" type="category" width={80} tick={{ fontSize: 12 }} />
                  <Tooltip />
                  <Bar dataKey="count" fill="#10b981" radius={[0, 4, 4, 0]} name="عدد المقالات" />
                </BarChart>
              </ResponsiveContainer>
            </div>
          </CardContent>
        </Card>

        {/* Recent Articles */}
        <Card>
          <CardHeader>
            <CardTitle className="flex items-center gap-2 text-base">
              <FileText className="size-5 text-emerald-500" />
              آخر المقالات
            </CardTitle>
          </CardHeader>
          <CardContent className="max-h-80 overflow-y-auto">
            {recentArticles.length === 0 ? (
              <p className="text-sm text-muted-foreground text-center py-4">لا توجد مقالات</p>
            ) : (
              <div className="space-y-3">
                {recentArticles.map((article) => (
                  <div
                    key={article.id}
                    className="flex items-start gap-3 p-2 rounded-lg hover:bg-muted/50 transition-colors"
                  >
                    <div className="flex-1 min-w-0">
                      <p className="text-sm font-medium text-foreground truncate">{article.title}</p>
                      <div className="flex items-center gap-2 mt-1">
                        <Badge variant="secondary" className={`text-[10px] px-1.5 py-0 ${getCategoryColor(article.category)}`}>
                          {getCategoryLabel(article.category)}
                        </Badge>
                        <span className="text-xs text-muted-foreground">{article.author.name}</span>
                        <span className="text-xs text-muted-foreground flex items-center gap-0.5">
                          <Eye className="size-3" />
                          {article.views}
                        </span>
                      </div>
                    </div>
                    <span className="text-xs text-muted-foreground whitespace-nowrap">
                      {article.publishedAt ? timeAgo(article.publishedAt) : ''}
                    </span>
                  </div>
                ))}
              </div>
            )}
          </CardContent>
        </Card>

        {/* Recent Matches */}
        <Card className="lg:col-span-2">
          <CardHeader>
            <CardTitle className="flex items-center gap-2 text-base">
              <Trophy className="size-5 text-emerald-500" />
              آخر المباريات
            </CardTitle>
          </CardHeader>
          <CardContent className="max-h-72 overflow-y-auto">
            {recentMatches.length === 0 ? (
              <p className="text-sm text-muted-foreground text-center py-4">لا توجد مباريات</p>
            ) : (
              <div className="space-y-2">
                {recentMatches.map((match) => (
                  <div
                    key={match.id}
                    className="flex items-center justify-between p-3 rounded-lg bg-muted/30 hover:bg-muted/50 transition-colors"
                  >
                    <div className="flex items-center gap-3 flex-1 min-w-0">
                      <div className="text-center min-w-[80px]">
                        <p className="text-sm font-medium truncate">{match.homeTeam.name}</p>
                      </div>
                      <div className="flex items-center gap-2 px-3">
                        <span className="text-lg font-bold text-foreground">{match.homeScore ?? '-'}</span>
                        <span className="text-muted-foreground">-</span>
                        <span className="text-lg font-bold text-foreground">{match.awayScore ?? '-'}</span>
                      </div>
                      <div className="text-center min-w-[80px]">
                        <p className="text-sm font-medium truncate">{match.awayTeam.name}</p>
                      </div>
                    </div>
                    <div className="flex items-center gap-2">
                      <Badge className={`text-[10px] ${getStatusColor(match.status)}`}>
                        {getStatusLabel(match.status)}
                      </Badge>
                      <span className="text-xs text-muted-foreground whitespace-nowrap">
                        {formatFullDate(match.matchDate)}
                      </span>
                    </div>
                  </div>
                ))}
              </div>
            )}
          </CardContent>
        </Card>
      </div>
    </div>
  )
}
