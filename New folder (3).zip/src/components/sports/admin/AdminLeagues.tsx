'use client'

import { useEffect, useState, useCallback } from 'react'
import { Plus, Pencil, Loader2 } from 'lucide-react'
import { Card, CardContent } from '@/components/ui/card'
import { Badge } from '@/components/ui/badge'
import { Button } from '@/components/ui/button'
import { Input } from '@/components/ui/input'
import { Switch } from '@/components/ui/switch'
import { Skeleton } from '@/components/ui/skeleton'
import { Label } from '@/components/ui/label'
import {
  Table, TableBody, TableCell, TableHead, TableHeader, TableRow
} from '@/components/ui/table'
import {
  Dialog, DialogContent, DialogDescription, DialogFooter,
  DialogHeader, DialogTitle, DialogTrigger
} from '@/components/ui/dialog'
import {
  Select, SelectContent, SelectItem, SelectTrigger, SelectValue
} from '@/components/ui/select'
import type { League } from './types'

export function AdminLeagues() {
  const [leagues, setLeagues] = useState<League[]>([])
  const [loading, setLoading] = useState(true)
  const [dialogOpen, setDialogOpen] = useState(false)
  const [submitting, setSubmitting] = useState(false)
  const [editId, setEditId] = useState<string | null>(null)

  const [formName, setFormName] = useState('')
  const [formNameEn, setFormNameEn] = useState('')
  const [formCountry, setFormCountry] = useState('')
  const [formType, setFormType] = useState('league')
  const [formSeason, setFormSeason] = useState('')
  const [formIsActive, setFormIsActive] = useState(true)

  const fetchLeagues = useCallback(async () => {
    try {
      setLoading(true)
      const res = await fetch('/api/leagues')
      const data = await res.json()
      setLeagues(data.leagues || [])
    } catch {
      // silently fail
    } finally {
      setLoading(false)
    }
  }, [])

  useEffect(() => { fetchLeagues() }, [fetchLeagues])

  const resetForm = () => {
    setFormName(''); setFormNameEn(''); setFormCountry('')
    setFormType('league'); setFormSeason(''); setFormIsActive(true); setEditId(null)
  }

  const openCreate = () => { resetForm(); setDialogOpen(true) }

  const openEdit = (league: League) => {
    setEditId(league.id)
    setFormName(league.name)
    setFormNameEn(league.nameEn || '')
    setFormCountry(league.country || '')
    setFormType(league.type)
    setFormSeason(league.season || '')
    setFormIsActive(league.isActive)
    setDialogOpen(true)
  }

  const handleSubmit = async () => {
    if (!formName) return
    setSubmitting(true)
    try {
      if (editId) {
        await fetch('/api/admin/leagues', {
          method: 'PUT',
          headers: { 'Content-Type': 'application/json' },
          body: JSON.stringify({
            id: editId, name: formName, nameEn: formNameEn,
            country: formCountry, type: formType, season: formSeason,
            isActive: formIsActive,
          }),
        })
      } else {
        await fetch('/api/admin/leagues', {
          method: 'POST',
          headers: { 'Content-Type': 'application/json' },
          body: JSON.stringify({
            name: formName, nameEn: formNameEn, country: formCountry,
            type: formType, season: formSeason, isActive: formIsActive,
          }),
        })
      }
      setDialogOpen(false)
      resetForm()
      fetchLeagues()
    } catch {
      // silently fail
    } finally {
      setSubmitting(false)
    }
  }

  if (loading) {
    return (
      <div className="space-y-4">
        {Array.from({ length: 5 }).map((_, i) => (
          <Skeleton key={i} className="h-14 w-full" />
        ))}
      </div>
    )
  }

  return (
    <div className="space-y-4">
      <div className="flex items-center justify-between">
        <h2 className="text-xl font-bold">إدارة البطولات</h2>
        <Dialog open={dialogOpen} onOpenChange={setDialogOpen}>
          <DialogTrigger asChild>
            <Button className="bg-emerald-600 hover:bg-emerald-700" onClick={openCreate}>
              <Plus className="size-4 ml-1" />
              بطولة جديدة
            </Button>
          </DialogTrigger>
          <DialogContent className="max-w-lg" dir="rtl">
            <DialogHeader>
              <DialogTitle>{editId ? 'تعديل البطولة' : 'بطولة جديدة'}</DialogTitle>
              <DialogDescription>{editId ? 'قم بتعديل بيانات البطولة' : 'أدخل بيانات البطولة الجديدة'}</DialogDescription>
            </DialogHeader>
            <div className="space-y-4">
              <div className="grid grid-cols-2 gap-4">
                <div className="space-y-2">
                  <Label>الاسم (عربي) *</Label>
                  <Input value={formName} onChange={(e) => setFormName(e.target.value)} placeholder="الدوري المصري" />
                </div>
                <div className="space-y-2">
                  <Label>الاسم (إنجليزي)</Label>
                  <Input value={formNameEn} onChange={(e) => setFormNameEn(e.target.value)} placeholder="Egyptian League" />
                </div>
              </div>
              <div className="grid grid-cols-2 gap-4">
                <div className="space-y-2">
                  <Label>الدولة</Label>
                  <Input value={formCountry} onChange={(e) => setFormCountry(e.target.value)} placeholder="مصر" />
                </div>
                <div className="space-y-2">
                  <Label>النوع</Label>
                  <Select value={formType} onValueChange={setFormType}>
                    <SelectTrigger className="w-full"><SelectValue /></SelectTrigger>
                    <SelectContent>
                      <SelectItem value="league">دوري</SelectItem>
                      <SelectItem value="cup">كأس</SelectItem>
                      <SelectItem value="tournament">بطولة</SelectItem>
                    </SelectContent>
                  </Select>
                </div>
              </div>
              <div className="grid grid-cols-2 gap-4">
                <div className="space-y-2">
                  <Label>الموسم</Label>
                  <Input value={formSeason} onChange={(e) => setFormSeason(e.target.value)} placeholder="2024-2025" />
                </div>
                <div className="flex items-center gap-2 pt-6">
                  <Switch checked={formIsActive} onCheckedChange={setFormIsActive} />
                  <Label>نشط</Label>
                </div>
              </div>
            </div>
            <DialogFooter>
              <Button variant="outline" onClick={() => setDialogOpen(false)}>إلغاء</Button>
              <Button className="bg-emerald-600 hover:bg-emerald-700" onClick={handleSubmit} disabled={submitting || !formName}>
                {submitting && <Loader2 className="size-4 ml-1 animate-spin" />}
                {editId ? 'تحديث' : 'إنشاء'}
              </Button>
            </DialogFooter>
          </DialogContent>
        </Dialog>
      </div>

      <Card>
        <CardContent className="p-0">
          <Table>
            <TableHeader>
              <TableRow>
                <TableHead className="text-right">الاسم</TableHead>
                <TableHead className="text-right">الدولة</TableHead>
                <TableHead className="text-right">النوع</TableHead>
                <TableHead className="text-right">الموسم</TableHead>
                <TableHead className="text-right">عدد الفرق</TableHead>
                <TableHead className="text-right">الحالة</TableHead>
                <TableHead className="text-right">إجراءات</TableHead>
              </TableRow>
            </TableHeader>
            <TableBody>
              {leagues.length === 0 ? (
                <TableRow>
                  <TableCell colSpan={7} className="text-center py-8 text-muted-foreground">لا توجد بطولات</TableCell>
                </TableRow>
              ) : (
                leagues.map((league) => (
                  <TableRow key={league.id}>
                    <TableCell>
                      <div>
                        <p className="font-medium">{league.name}</p>
                        {league.nameEn && <p className="text-xs text-muted-foreground">{league.nameEn}</p>}
                      </div>
                    </TableCell>
                    <TableCell className="text-sm">{league.country || '-'}</TableCell>
                    <TableCell className="text-sm">
                      {league.type === 'league' ? 'دوري' : league.type === 'cup' ? 'كأس' : 'بطولة'}
                    </TableCell>
                    <TableCell className="text-sm">{league.season || '-'}</TableCell>
                    <TableCell className="text-sm">{league.teamCount}</TableCell>
                    <TableCell>
                      <Badge variant="secondary" className={league.isActive ? 'bg-green-100 text-green-700 dark:bg-green-900 dark:text-green-300' : 'bg-gray-100 text-gray-700 dark:bg-gray-800 dark:text-gray-300'}>
                        {league.isActive ? 'نشط' : 'غير نشط'}
                      </Badge>
                    </TableCell>
                    <TableCell>
                      <Button variant="ghost" size="icon" className="size-8" onClick={() => openEdit(league)}>
                        <Pencil className="size-4" />
                      </Button>
                    </TableCell>
                  </TableRow>
                ))
              )}
            </TableBody>
          </Table>
        </CardContent>
      </Card>
    </div>
  )
}
