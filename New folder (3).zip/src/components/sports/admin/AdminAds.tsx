'use client'

import { Megaphone } from 'lucide-react'
import { Card, CardContent } from '@/components/ui/card'

export function AdminAds() {
  return (
    <div className="space-y-4">
      <h2 className="text-xl font-bold">إدارة الإعلانات</h2>
      <Card>
        <CardContent className="text-center py-12 text-muted-foreground">
          <Megaphone className="size-12 mx-auto mb-3 opacity-30" />
          <p>قريباً - إدارة الإعلانات</p>
          <p className="text-sm mt-1">سيتم إضافة هذه الميزة قريباً</p>
        </CardContent>
      </Card>
    </div>
  )
}
