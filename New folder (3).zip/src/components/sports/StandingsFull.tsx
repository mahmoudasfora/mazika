'use client'

import { useState, useEffect } from 'react'
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card'
import {
  Table,
  TableBody,
  TableCell,
  TableHead,
  TableHeader,
  TableRow,
} from '@/components/ui/table'
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from '@/components/ui/select'
import { Skeleton } from '@/components/ui/skeleton'
import { Trophy, TrendingUp, Award } from 'lucide-react'

interface League {
  id: string
  name: string
  nameEn: string | null
  country: string | null
  logo: string | null
  type: string
  season: string | null
  teamCount: number
}

interface Standing {
  id: string
  position: number
  played: number
  won: number
  drawn: number
  lost: number
  goalsFor: number
  goalsAgainst: number
  goalDifference: number
  points: number
  form: string | null
  team: {
    id: string
    name: string
    nameEn: string | null
    shortName: string | null
    logo: string | null
    color: string | null
  }
  league: {
    id: string
    name: string
    nameEn: string | null
    season: string | null
  }
}

interface TopScorer {
  id: string
  goals: number
  assists: number
  penaltyGoals: number
  player: {
    id: string
    name: string
    nameEn: string | null
    photo: string | null
    position: string | null
    number: number | null
    nationality: string | null
  }
  team: {
    id: string
    name: string
    nameEn: string | null
    shortName: string | null
    logo: string | null
  }
}

function FormCircles({ form }: { form: string | null }) {
  if (!form) return <span className="text-muted-foreground">—</span>

  const last5 = form.slice(-5).split('')
  return (
    <div className="flex items-center gap-1" dir="ltr">
      {last5.map((result, i) => (
        <span
          key={i}
          className={`inline-flex size-5 items-center justify-center rounded-full text-[10px] font-bold text-white ${
            result === 'W'
              ? 'bg-emerald-500'
              : result === 'D'
                ? 'bg-yellow-500'
                : 'bg-red-500'
          }`}
          title={
            result === 'W' ? 'فوز' : result === 'D' ? 'تعادل' : 'خسارة'
          }
        >
          {result === 'W' ? 'ف' : result === 'D' ? 'ت' : 'خ'}
        </span>
      ))}
    </div>
  )
}

function getZoneIndicator(position: number, totalTeams: number) {
  // Champion zone: top 1-4 (e.g., Champions League spots)
  if (position <= 4) return 'champion'
  // Relegation zone: bottom 3
  if (position > totalTeams - 3) return 'relegation'
  return null
}

function getZoneClassName(zone: string | null) {
  if (zone === 'champion')
    return 'border-r-4 border-r-emerald-500 bg-emerald-50/50 dark:bg-emerald-950/20'
  if (zone === 'relegation')
    return 'border-r-4 border-r-red-500 bg-red-50/50 dark:bg-red-950/20'
  return ''
}

function StandingsTableSkeleton() {
  return (
    <div className="space-y-2">
      {Array.from({ length: 10 }).map((_, i) => (
        <div key={i} className="flex items-center gap-3 px-2 py-2">
          <Skeleton className="size-6 rounded-full" />
          <Skeleton className="h-4 w-32" />
          <div className="flex-1" />
          {Array.from({ length: 8 }).map((_, j) => (
            <Skeleton key={j} className="h-4 w-8" />
          ))}
          <div className="flex gap-1">
            {Array.from({ length: 5 }).map((_, k) => (
              <Skeleton key={k} className="size-5 rounded-full" />
            ))}
          </div>
        </div>
      ))}
    </div>
  )
}

function TopScorersSkeleton() {
  return (
    <div className="space-y-2">
      {Array.from({ length: 5 }).map((_, i) => (
        <div key={i} className="flex items-center gap-3 px-2 py-2">
          <Skeleton className="size-6 rounded-full" />
          <Skeleton className="h-4 w-24" />
          <Skeleton className="h-4 w-20" />
          <div className="flex-1" />
          <Skeleton className="h-4 w-8" />
          <Skeleton className="h-4 w-8" />
          <Skeleton className="h-4 w-8" />
        </div>
      ))}
    </div>
  )
}

export default function StandingsFull() {
  const [leagues, setLeagues] = useState<League[]>([])
  const [selectedLeagueId, setSelectedLeagueId] = useState<string>('')
  const [standings, setStandings] = useState<Standing[]>([])
  const [topScorers, setTopScorers] = useState<TopScorer[]>([])
  const [loadingLeagues, setLoadingLeagues] = useState(true)
  const [loadingStandings, setLoadingStandings] = useState(false)
  const [loadingScorers, setLoadingScorers] = useState(false)
  const [error, setError] = useState<string | null>(null)

  // Fetch leagues on mount
  useEffect(() => {
    async function fetchLeagues() {
      try {
        setLoadingLeagues(true)
        const res = await fetch('/api/leagues')
        if (!res.ok) throw new Error('فشل في جلب البطولات')
        const data = await res.json()
        setLeagues(data.leagues)
        if (data.leagues.length > 0) {
          setSelectedLeagueId(data.leagues[0].id)
        }
      } catch {
        setError('فشل في جلب البطولات')
      } finally {
        setLoadingLeagues(false)
      }
    }
    fetchLeagues()
  }, [])

  // Fetch standings + top scorers when league changes
  useEffect(() => {
    if (!selectedLeagueId) return

    async function fetchData() {
      try {
        setLoadingStandings(true)
        setLoadingScorers(true)
        setError(null)

        const [standingsRes, scorersRes] = await Promise.all([
          fetch(`/api/standings?leagueId=${selectedLeagueId}`),
          fetch(`/api/topscorers?leagueId=${selectedLeagueId}`),
        ])

        if (standingsRes.ok) {
          const standingsData = await standingsRes.json()
          setStandings(standingsData.standings)
        } else {
          setStandings([])
        }

        if (scorersRes.ok) {
          const scorersData = await scorersRes.json()
          setTopScorers(scorersData.topScorers)
        } else {
          setTopScorers([])
        }
      } catch {
        setError('فشل في جلب البيانات')
        setStandings([])
        setTopScorers([])
      } finally {
        setLoadingStandings(false)
        setLoadingScorers(false)
      }
    }
    fetchData()
  }, [selectedLeagueId])

  const totalTeams = standings.length
  const selectedLeague = leagues.find((l) => l.id === selectedLeagueId)

  return (
    <div className="space-y-6" dir="rtl">
      {/* Header */}
      <div className="flex flex-col gap-4 sm:flex-row sm:items-center sm:justify-between">
        <h1 className="flex items-center gap-2 text-xl font-bold sm:text-2xl">
          <Trophy className="size-6 text-emerald-600" />
          ترتيب البطولات
        </h1>

        {/* League Selector */}
        {loadingLeagues ? (
          <Skeleton className="h-9 w-48" />
        ) : (
          <Select
            value={selectedLeagueId}
            onValueChange={setSelectedLeagueId}
          >
            <SelectTrigger className="w-full sm:w-56">
              <SelectValue placeholder="اختر البطولة" />
            </SelectTrigger>
            <SelectContent>
              {leagues.map((league) => (
                <SelectItem key={league.id} value={league.id}>
                  {league.name}
                  {league.season ? ` - ${league.season}` : ''}
                </SelectItem>
              ))}
            </SelectContent>
          </Select>
        )}
      </div>

      {/* Zone Legend */}
      {standings.length > 0 && (
        <div className="flex flex-wrap items-center gap-4 text-xs text-muted-foreground">
          <div className="flex items-center gap-1.5">
            <span className="inline-block size-3 rounded-sm border-r-4 border-emerald-500 bg-emerald-50 dark:bg-emerald-950/20" />
            <span>منطقة الأبطال</span>
          </div>
          <div className="flex items-center gap-1.5">
            <span className="inline-block size-3 rounded-sm border-r-4 border-red-500 bg-red-50 dark:bg-red-950/20" />
            <span>منطقة الهبوط</span>
          </div>
          {selectedLeague?.season && (
            <span className="mr-auto text-muted-foreground">
              الموسم: {selectedLeague.season}
            </span>
          )}
        </div>
      )}

      {/* Standings Table */}
      <Card>
        <CardHeader className="pb-2">
          <CardTitle className="flex items-center gap-2 text-lg">
            <TrendingUp className="size-5 text-emerald-600" />
            {selectedLeague?.name || 'الترتيب'}
          </CardTitle>
        </CardHeader>
        <CardContent className="p-2 sm:p-4">
          {loadingStandings ? (
            <StandingsTableSkeleton />
          ) : error ? (
            <div className="py-8 text-center text-sm text-red-500">{error}</div>
          ) : standings.length === 0 ? (
            <div className="py-8 text-center text-sm text-muted-foreground">
              لا توجد بيانات ترتيب لهذه البطولة
            </div>
          ) : (
            <Table dir="rtl">
              <TableHeader>
                <TableRow>
                  <TableHead className="w-10 text-center">#</TableHead>
                  <TableHead className="text-right">الفريق</TableHead>
                  <TableHead className="text-center">لعب</TableHead>
                  <TableHead className="text-center">فوز</TableHead>
                  <TableHead className="text-center">تعادل</TableHead>
                  <TableHead className="text-center">خسارة</TableHead>
                  <TableHead className="text-center">له</TableHead>
                  <TableHead className="text-center">عليه</TableHead>
                  <TableHead className="text-center">فرق</TableHead>
                  <TableHead className="text-center font-bold">نقاط</TableHead>
                  <TableHead className="text-center">آخر 5</TableHead>
                </TableRow>
              </TableHeader>
              <TableBody>
                {standings.map((row) => {
                  const zone = getZoneIndicator(row.position, totalTeams)
                  return (
                    <TableRow
                      key={row.id}
                      className={getZoneClassName(zone)}
                    >
                      <TableCell className="text-center font-medium">
                        {row.position}
                      </TableCell>
                      <TableCell>
                        <div className="flex items-center gap-2">
                          <span
                            className="inline-block size-6 shrink-0 rounded-full"
                            style={{
                              backgroundColor:
                                row.team.color || '#6b7280',
                            }}
                          />
                          <span className="font-medium">
                            {row.team.name}
                          </span>
                        </div>
                      </TableCell>
                      <TableCell className="text-center">
                        {row.played}
                      </TableCell>
                      <TableCell className="text-center">{row.won}</TableCell>
                      <TableCell className="text-center">
                        {row.drawn}
                      </TableCell>
                      <TableCell className="text-center">{row.lost}</TableCell>
                      <TableCell className="text-center">
                        {row.goalsFor}
                      </TableCell>
                      <TableCell className="text-center">
                        {row.goalsAgainst}
                      </TableCell>
                      <TableCell
                        className={`text-center font-medium ${
                          row.goalDifference > 0
                            ? 'text-emerald-600'
                            : row.goalDifference < 0
                              ? 'text-red-500'
                              : ''
                        }`}
                      >
                        {row.goalDifference > 0
                          ? `+${row.goalDifference}`
                          : row.goalDifference}
                      </TableCell>
                      <TableCell className="text-center font-bold text-emerald-700 dark:text-emerald-400">
                        {row.points}
                      </TableCell>
                      <TableCell>
                        <FormCircles form={row.form} />
                      </TableCell>
                    </TableRow>
                  )
                })}
              </TableBody>
            </Table>
          )}
        </CardContent>
      </Card>

      {/* Top Scorers */}
      <Card>
        <CardHeader className="pb-2">
          <CardTitle className="flex items-center gap-2 text-lg">
            <Award className="size-5 text-amber-500" />
            الهدافون
          </CardTitle>
        </CardHeader>
        <CardContent className="p-2 sm:p-4">
          {loadingScorers ? (
            <TopScorersSkeleton />
          ) : topScorers.length === 0 ? (
            <div className="py-8 text-center text-sm text-muted-foreground">
              لا توجد بيانات هدافين لهذه البطولة
            </div>
          ) : (
            <Table dir="rtl">
              <TableHeader>
                <TableRow>
                  <TableHead className="w-10 text-center">#</TableHead>
                  <TableHead className="text-right">اللاعب</TableHead>
                  <TableHead className="text-right">الفريق</TableHead>
                  <TableHead className="text-center">أهداف</TableHead>
                  <TableHead className="text-center">تمريرات</TableHead>
                  <TableHead className="text-center">ركلات جزاء</TableHead>
                </TableRow>
              </TableHeader>
              <TableBody>
                {topScorers.map((scorer, index) => (
                  <TableRow key={scorer.id}>
                    <TableCell className="text-center font-medium">
                      {index + 1}
                    </TableCell>
                    <TableCell>
                      <div className="flex items-center gap-2">
                        <span
                          className="flex size-7 shrink-0 items-center justify-center rounded-full bg-amber-100 text-xs font-bold text-amber-700 dark:bg-amber-900/40 dark:text-amber-400"
                        >
                          {scorer.player.number || index + 1}
                        </span>
                        <span className="font-medium">
                          {scorer.player.name}
                        </span>
                      </div>
                    </TableCell>
                    <TableCell className="text-muted-foreground">
                      {scorer.team.shortName || scorer.team.name}
                    </TableCell>
                    <TableCell className="text-center font-bold text-emerald-700 dark:text-emerald-400">
                      {scorer.goals}
                    </TableCell>
                    <TableCell className="text-center text-muted-foreground">
                      {scorer.assists}
                    </TableCell>
                    <TableCell className="text-center text-muted-foreground">
                      {scorer.penaltyGoals}
                    </TableCell>
                  </TableRow>
                ))}
              </TableBody>
            </Table>
          )}
        </CardContent>
      </Card>
    </div>
  )
}
