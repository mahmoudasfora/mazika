'use client'

import { useEffect, useState } from 'react'
import { motion } from 'framer-motion'
import { Share2, Copy, ArrowRight, Eye, Clock, User, Newspaper, Check } from 'lucide-react'
import { Card, CardContent } from '@/components/ui/card'
import { Badge } from '@/components/ui/badge'
import { Button } from '@/components/ui/button'
import { Separator } from '@/components/ui/separator'
import { Skeleton } from '@/components/ui/skeleton'
import { useRouter } from 'next/navigation'
import { getCategoryLabel, getCategoryColor, formatNumber, timeAgo, formatFullDate } from '@/lib/sports-utils'
import AdBanner from '@/components/sports/AdBanner'

interface ArticleAuthor {
  id: string
  name: string
  avatar: string | null
  role: string
  bio: string | null
}

interface ArticleTag {
  id: string
  tag: string
}

interface ArticleTeamItem {
  id: string
  team: {
    id: string
    name: string
    nameEn: string | null
    shortName: string | null
    logo: string | null
    color: string | null
  }
}

interface ArticleComment {
  id: string
  content: string
  isApproved: boolean
  createdAt: string
  user: {
    id: string
    name: string
    avatar: string | null
  }
}

interface Article {
  id: string
  title: string
  slug: string
  summary: string | null
  content: string
  image: string | null
  category: string
  isBreaking: boolean
  isFeatured: boolean
  status: string
  authorId: string
  publishedAt: string | null
  views: number
  createdAt: string
  updatedAt: string
  author: ArticleAuthor
  tags: ArticleTag[]
  teams: ArticleTeamItem[]
  comments: ArticleComment[]
}

function getCategoryGradient(category: string): string {
  const gradients: Record<string, string> = {
    general: 'from-blue-500 to-cyan-500',
    transfer: 'from-purple-500 to-pink-500',
    analysis: 'from-amber-500 to-orange-500',
    interview: 'from-teal-500 to-emerald-500',
    report: 'from-indigo-500 to-violet-500',
    breaking: 'from-red-500 to-rose-500',
  }
  return gradients[category] || 'from-emerald-500 to-green-600'
}

function DetailSkeleton() {
  return (
    <div dir="rtl" className="space-y-6">
      <Skeleton className="h-8 w-32" />
      <div className="space-y-4">
        <Skeleton className="h-5 w-24" />
        <Skeleton className="h-10 w-3/4" />
        <div className="flex gap-4">
          <Skeleton className="h-4 w-32" />
          <Skeleton className="h-4 w-28" />
          <Skeleton className="h-4 w-24" />
        </div>
        <Skeleton className="h-72 w-full rounded-xl" />
        <div className="space-y-3">
          <Skeleton className="h-4 w-full" />
          <Skeleton className="h-4 w-full" />
          <Skeleton className="h-4 w-5/6" />
          <Skeleton className="h-4 w-full" />
          <Skeleton className="h-4 w-3/4" />
        </div>
      </div>
    </div>
  )
}

export default function ArticleDetail({ articleId }: { articleId: string }) {
  const [article, setArticle] = useState<Article | null>(null)
  const [loading, setLoading] = useState(true)
  const [error, setError] = useState<string | null>(null)
  const [copied, setCopied] = useState(false)
  const router = useRouter()

  useEffect(() => {
    async function fetchArticle() {
      try {
        setLoading(true)
        setError(null)

        const res = await fetch(`/api/articles/${articleId}`)

        if (!res.ok) {
          throw new Error('فشل في جلب المقال')
        }

        const data = await res.json()
        setArticle(data.article || null)
      } catch (err) {
        setError(err instanceof Error ? err.message : 'حدث خطأ غير متوقع')
      } finally {
        setLoading(false)
      }
    }

    if (articleId) {
      fetchArticle()
    }
  }, [articleId])

  const handleCopyLink = async () => {
    try {
      await navigator.clipboard.writeText(window.location.href)
      setCopied(true)
      setTimeout(() => setCopied(false), 2000)
    } catch {
      // Fallback
      const textArea = document.createElement('textarea')
      textArea.value = window.location.href
      document.body.appendChild(textArea)
      textArea.select()
      document.execCommand('copy')
      document.body.removeChild(textArea)
      setCopied(true)
      setTimeout(() => setCopied(false), 2000)
    }
  }

  const handleShareTwitter = () => {
    if (!article) return
    const text = encodeURIComponent(article.title)
    const url = encodeURIComponent(window.location.href)
    window.open(`https://twitter.com/intent/tweet?text=${text}&url=${url}`, '_blank')
  }

  const handleShareFacebook = () => {
    if (!article) return
    const url = encodeURIComponent(window.location.href)
    window.open(`https://www.facebook.com/sharer/sharer.php?u=${url}`, '_blank')
  }

  if (loading) return <DetailSkeleton />

  if (error || !article) {
    return (
      <div dir="rtl" className="space-y-6">
        <Button
          variant="ghost"
          className="gap-2 text-muted-foreground hover:text-foreground"
          onClick={() => router.push('/news')}
        >
          <ArrowRight className="size-4" />
          العودة للأخبار
        </Button>
        <Card className="p-8 text-center">
          <Newspaper className="size-12 text-muted-foreground mx-auto mb-3" />
          <p className="text-muted-foreground text-lg">{error || 'المقال غير موجود'}</p>
          <Button
            variant="outline"
            className="mt-4"
            onClick={() => router.push('/news')}
          >
            العودة للأخبار
          </Button>
        </Card>
      </div>
    )
  }

  const contentParagraphs = article.content.split('\n').filter(p => p.trim())

  return (
    <motion.article
      dir="rtl"
      initial={{ opacity: 0 }}
      animate={{ opacity: 1 }}
      transition={{ duration: 0.5 }}
      className="space-y-6"
    >
      {/* Back Button */}
      <Button
        variant="ghost"
        className="gap-2 text-muted-foreground hover:text-foreground"
        onClick={() => router.push('/news')}
      >
        <ArrowRight className="size-4" />
        العودة للأخبار
      </Button>

      {/* إعلان أعلى المقال */}
      <AdBanner position="article_top" page="article" />

      {/* Article Header */}
      <div className="space-y-4">
        {/* Category & Breaking Badges */}
        <div className="flex items-center gap-2 flex-wrap">
          <Badge className={`${getCategoryColor(article.category)} text-sm px-3 py-1`}>
            {getCategoryLabel(article.category)}
          </Badge>
          {article.isBreaking && (
            <Badge className="bg-red-500 text-white animate-pulse text-sm px-3 py-1">
              عاجل
            </Badge>
          )}
          {article.isFeatured && (
            <Badge className="bg-emerald-500 text-white text-sm px-3 py-1">
              مميز
            </Badge>
          )}
        </div>

        {/* Title */}
        <h1 className="text-2xl md:text-3xl lg:text-4xl font-bold text-foreground leading-relaxed">
          {article.title}
        </h1>

        {/* Summary */}
        {article.summary && (
          <p className="text-lg text-muted-foreground leading-relaxed">
            {article.summary}
          </p>
        )}

        {/* Author & Meta Info */}
        <div className="flex flex-wrap items-center gap-4 text-sm text-muted-foreground">
          <div className="flex items-center gap-2">
            <div className="size-8 rounded-full bg-emerald-100 dark:bg-emerald-900 flex items-center justify-center">
              <User className="size-4 text-emerald-600 dark:text-emerald-400" />
            </div>
            <div>
              <span className="font-medium text-foreground">{article.author.name}</span>
              {article.author.bio && (
                <p className="text-xs text-muted-foreground">{article.author.bio}</p>
              )}
            </div>
          </div>
          <Separator orientation="vertical" className="h-4" />
          {article.publishedAt && (
            <span className="flex items-center gap-1">
              <Clock className="size-3.5" />
              {formatFullDate(article.publishedAt)}
            </span>
          )}
          <Separator orientation="vertical" className="h-4" />
          <span className="flex items-center gap-1">
            <Eye className="size-3.5" />
            {formatNumber(article.views)} مشاهدة
          </span>
        </div>
      </div>

      {/* Featured Image */}
      <div className="rounded-xl overflow-hidden">
        {article.image ? (
          <img
            src={article.image}
            alt={article.title}
            className="w-full h-64 md:h-96 object-cover"
          />
        ) : (
          <div className={`bg-gradient-to-br ${getCategoryGradient(article.category)} flex items-center justify-center w-full h-64 md:h-96`}>
            <Newspaper className="size-16 text-white/40" />
          </div>
        )}
      </div>

      {/* Article Content with ad in the middle */}
      <div className="prose prose-lg dark:prose-invert max-w-none">
        {contentParagraphs.map((paragraph, index) => (
          <div key={index}>
            <p className="text-foreground/90 leading-8 mb-4 text-base md:text-lg">
              {paragraph}
            </p>
            {/* إعلان وسط المقال - بعد الفقرة الثالثة */}
            {index === 2 && contentParagraphs.length > 4 && (
              <AdBanner position="article_middle" page="article" className="my-6" />
            )}
          </div>
        ))}
      </div>

      {/* إعلان أسفل المقال */}
      <AdBanner position="article_bottom" page="article" />

      <Separator />

      {/* Tags Section */}
      {article.tags && article.tags.length > 0 && (
        <div className="space-y-3">
          <h3 className="font-semibold text-foreground flex items-center gap-2">
            <span className="text-emerald-500">#</span>
            الوسوم
          </h3>
          <div className="flex flex-wrap gap-2">
            {article.tags.map((tag) => (
              <Badge
                key={tag.id}
                variant="outline"
                className="text-sm px-3 py-1 cursor-pointer hover:bg-emerald-50 hover:text-emerald-700 hover:border-emerald-300 dark:hover:bg-emerald-950 dark:hover:text-emerald-300 dark:hover:border-emerald-700 transition-colors"
                onClick={() => router.push(`/news?search=${tag.tag}`)}
              >
                {tag.tag}
              </Badge>
            ))}
          </div>
        </div>
      )}

      {/* Related Teams Section */}
      {article.teams && article.teams.length > 0 && (
        <div className="space-y-3">
          <h3 className="font-semibold text-foreground">الفرق ذات الصلة</h3>
          <div className="flex flex-wrap gap-3">
            {article.teams.map((articleTeam) => (
              <Card
                key={articleTeam.id}
                className="px-4 py-3 cursor-pointer hover:border-emerald-300 dark:hover:border-emerald-700 transition-colors flex items-center gap-3"
                onClick={() => router.push('/standings')}
              >
                <div
                  className="size-10 rounded-full flex items-center justify-center text-white font-bold text-sm shrink-0"
                  style={{
                    backgroundColor: articleTeam.team.color || '#10b981',
                  }}
                >
                  {articleTeam.team.shortName
                    ? articleTeam.team.shortName.substring(0, 2)
                    : articleTeam.team.name.substring(0, 2)}
                </div>
                <span className="font-medium text-sm text-foreground">
                  {articleTeam.team.name}
                </span>
              </Card>
            ))}
          </div>
        </div>
      )}

      <Separator />

      {/* Share Buttons */}
      <div className="space-y-3">
        <h3 className="font-semibold text-foreground flex items-center gap-2">
          <Share2 className="size-4 text-emerald-500" />
          مشاركة المقال
        </h3>
        <div className="flex items-center gap-3 flex-wrap">
          <Button
            variant="outline"
            size="sm"
            className="gap-2"
            onClick={handleCopyLink}
          >
            {copied ? (
              <>
                <Check className="size-4 text-emerald-500" />
                تم النسخ
              </>
            ) : (
              <>
                <Copy className="size-4" />
                نسخ الرابط
              </>
            )}
          </Button>
          <Button
            variant="outline"
            size="sm"
            className="gap-2 hover:bg-sky-50 hover:text-sky-600 hover:border-sky-300 dark:hover:bg-sky-950 dark:hover:text-sky-400 dark:hover:border-sky-700"
            onClick={handleShareTwitter}
          >
            <svg className="size-4" viewBox="0 0 24 24" fill="currentColor">
              <path d="M18.244 2.25h3.308l-7.227 8.26 8.502 11.24H16.17l-5.214-6.817L4.99 21.75H1.68l7.73-8.835L1.254 2.25H8.08l4.713 6.231zm-1.161 17.52h1.833L7.084 4.126H5.117z" />
            </svg>
            تويتر
          </Button>
          <Button
            variant="outline"
            size="sm"
            className="gap-2 hover:bg-blue-50 hover:text-blue-600 hover:border-blue-300 dark:hover:bg-blue-950 dark:hover:text-blue-400 dark:hover:border-blue-700"
            onClick={handleShareFacebook}
          >
            <svg className="size-4" viewBox="0 0 24 24" fill="currentColor">
              <path d="M24 12.073c0-6.627-5.373-12-12-12s-12 5.373-12 12c0 5.99 4.388 10.954 10.125 11.854v-8.385H7.078v-3.47h3.047V9.43c0-3.007 1.792-4.669 4.533-4.669 1.312 0 2.686.235 2.686.235v2.953H15.83c-1.491 0-1.956.925-1.956 1.874v2.25h3.328l-.532 3.47h-2.796v8.385C19.612 23.027 24 18.062 24 12.073z" />
            </svg>
            فيسبوك
          </Button>
        </div>
      </div>

      {/* Back to News */}
      <div className="pt-4">
        <Button
          variant="outline"
          className="gap-2"
          onClick={() => router.push('/news')}
        >
          <ArrowRight className="size-4" />
          العودة للأخبار
        </Button>
      </div>
    </motion.article>
  )
}
