'use client'

import { useEffect, useState, useCallback } from 'react'
import { Badge } from '@/components/ui/badge'
import { Separator } from '@/components/ui/separator'
import { Skeleton } from '@/components/ui/skeleton'
import { Button } from '@/components/ui/button'
import { useRouter } from 'next/navigation'
import { formatTime, formatFullDate, formatMatchDate, getStatusLabel, getStatusColor, getPositionLabel } from '@/lib/sports-utils'
import {
  ArrowRight,
  Trophy,
  Clock,
  MapPin,
  Calendar,
  Tv,
  CircleDot,
  AlertTriangle,
  ArrowLeftRight,
  Monitor,
  Users,
  BarChart3,
  Radio,
  Play,
  User,
  Flag,
  Gavel,
  BookOpen,
  Zap,
  Eye,
  MessageCircle,
  Tv2,
  Shield,
} from 'lucide-react'
import AdBanner from '@/components/sports/AdBanner'

interface TeamData {
  id: string
  name: string
  nameEn?: string
  shortName?: string
  logo?: string | null
  color?: string | null
  stadium?: string | null
}

interface LeagueData {
  id: string
  name: string
  nameEn?: string
  logo?: string | null
  type?: string
  season?: string | null
}

interface PlayerData {
  id: string
  name: string
  nameEn?: string
  photo?: string | null
  position?: string | null
  number?: number | null
}

interface MatchEventData {
  id: string
  type: string
  minute: number
  team: string
  detail?: string | null
  player?: PlayerData | null
  assistPlayer?: { id: string; name: string; nameEn?: string } | null
}

interface LineupData {
  id: string
  teamId: string
  position?: string | null
  isStarter: boolean
  shirtNumber?: number | null
  player: PlayerData
}

interface MatchData {
  id: string
  homeTeam: TeamData
  awayTeam: TeamData
  league: LeagueData
  homeScore: number | null
  awayScore: number | null
  status: string
  matchDate: string
  stadium?: string | null
  referee?: string | null
  round?: string | null
  matchday?: number | null
  homePossession?: number | null
  awayPossession?: number | null
  homeShots?: number | null
  awayShots?: number | null
  homeShotsOnTarget?: number | null
  awayShotsOnTarget?: number | null
  homeCorners?: number | null
  awayCorners?: number | null
  homeFouls?: number | null
  awayFouls?: number | null
  homeYellowCards?: number | null
  awayYellowCards?: number | null
  homeRedCards?: number | null
  awayRedCards?: number | null
  broadcastChannels?: string | null
  streamUrl?: string | null
  matchReport?: string | null
  events?: MatchEventData[]
  lineups?: LineupData[]
}

function getStatusBadgeClass(status: string): string {
  switch (status) {
    case 'live':
    case 'halftime':
      return 'bg-red-500 text-white shadow-lg shadow-red-500/40'
    case 'finished':
      return 'bg-green-500 text-white shadow-lg shadow-green-500/30'
    case 'upcoming':
      return 'bg-amber-500 text-white shadow-lg shadow-amber-500/30'
    case 'postponed':
      return 'bg-orange-500 text-white shadow-lg shadow-orange-500/30'
    case 'cancelled':
      return 'bg-red-600 text-white shadow-lg shadow-red-600/30'
    default:
      return 'bg-gray-500 text-white'
  }
}

function TeamCrest({ team, size = 'lg' }: { team: TeamData; size?: 'sm' | 'md' | 'lg' | 'xl' | '2xl' }) {
  const sizeClasses = {
    sm: 'size-8 text-xs',
    md: 'size-10 text-sm',
    lg: 'size-14 text-lg',
    xl: 'size-20 text-2xl',
    '2xl': 'size-28 text-4xl',
  }
  const color = team.color || '#10b981'
  const firstLetter = (team.shortName || team.name).charAt(0)
  return (
    <div className="relative group">
      <div
        className={`${sizeClasses[size]} rounded-2xl flex items-center justify-center font-bold text-white shrink-0 shadow-2xl ring-4 ring-white/10 transition-transform duration-300 group-hover:scale-105`}
        style={{ backgroundColor: color }}
        title={team.name}
      >
        {team.logo ? (
          <img src={team.logo} alt={team.name} className="w-full h-full object-cover rounded-2xl" />
        ) : (
          <>
            <span className="relative z-10">{firstLetter}</span>
            <div className="absolute inset-0 bg-gradient-to-br from-white/30 via-transparent to-transparent rounded-2xl" />
          </>
        )}
      </div>
      <div
        className="absolute inset-0 rounded-2xl opacity-30 blur-lg -z-10"
        style={{ backgroundColor: color }}
      />
    </div>
  )
}

function EventIcon({ type }: { type: string }) {
  switch (type) {
    case 'goal':
    case 'penalty':
      return <CircleDot className="w-4 h-4 text-emerald-600 dark:text-emerald-400" />
    case 'own_goal':
      return <CircleDot className="w-4 h-4 text-red-500" />
    case 'yellow_card':
      return <div className="w-3.5 h-5 bg-yellow-400 rounded-sm shadow-sm border border-yellow-500/50" />
    case 'red_card':
      return <div className="w-3.5 h-5 bg-red-500 rounded-sm shadow-sm border border-red-600/50" />
    case 'substitution':
      return <ArrowLeftRight className="w-4 h-4 text-blue-500" />
    case 'var':
      return <Monitor className="w-4 h-4 text-purple-500" />
    case 'halftime':
      return <Clock className="w-4 h-4 text-amber-500" />
    case 'fulltime':
      return <Trophy className="w-4 h-4 text-emerald-600" />
    default:
      return <CircleDot className="w-4 h-4 text-muted-foreground" />
  }
}

function getEventLabel(type: string): string {
  const labels: Record<string, string> = {
    goal: 'هدف',
    yellow_card: 'بطاقة صفراء',
    red_card: 'بطاقة حمراء',
    substitution: 'تبديل',
    var: 'حكم الفيديو',
    penalty: 'ركلة جزاء',
    own_goal: 'هدف عكسي',
    halftime: 'نهاية الشوط الأول',
    fulltime: 'نهاية المباراة',
  }
  return labels[type] || type
}

function StatBar({
  homeVal,
  awayVal,
  label,
  isPercentage = false,
}: {
  homeVal: number
  awayVal: number
  label: string
  isPercentage?: boolean
}) {
  const total = homeVal + awayVal || 1
  const homePercent = (homeVal / total) * 100
  const awayPercent = (awayVal / total) * 100
  const homeLeading = homeVal > awayVal
  const awayLeading = awayVal > homeVal

  return (
    <div className="space-y-2.5">
      <div className="flex items-center justify-between">
        <span
          className={`font-bold tabular-nums text-sm transition-colors duration-300 ${
            homeLeading ? 'text-emerald-600 dark:text-emerald-400' : 'text-muted-foreground'
          }`}
        >
          {homeVal}
          {isPercentage ? '%' : ''}
        </span>
        <span className="text-muted-foreground text-xs font-semibold">{label}</span>
        <span
          className={`font-bold tabular-nums text-sm transition-colors duration-300 ${
            awayLeading ? 'text-teal-600 dark:text-teal-400' : 'text-muted-foreground'
          }`}
        >
          {awayVal}
          {isPercentage ? '%' : ''}
        </span>
      </div>
      <div className="flex gap-1.5 h-2.5">
        <div className="flex-1 bg-muted/60 rounded-full overflow-hidden flex justify-end">
          <div
            className={`h-full rounded-full transition-all duration-700 ease-out ${
              homeLeading ? 'bg-emerald-500' : 'bg-emerald-500/50'
            }`}
            style={{ width: `${homePercent}%` }}
          />
        </div>
        <div className="flex-1 bg-muted/60 rounded-full overflow-hidden">
          <div
            className={`h-full rounded-full transition-all duration-700 ease-out ${
              awayLeading ? 'bg-teal-500' : 'bg-teal-500/50'
            }`}
            style={{ width: `${awayPercent}%` }}
          />
        </div>
      </div>
    </div>
  )
}

function MatchDetailSkeleton() {
  return (
    <div className="space-y-6" dir="rtl">
      <div className="flex items-center gap-3">
        <Skeleton className="size-9 rounded-xl" />
        <Skeleton className="h-5 w-32 rounded-lg" />
      </div>
      <div className="bg-gradient-to-l from-emerald-600 to-teal-800 rounded-3xl overflow-hidden">
        <div className="px-6 py-3 bg-black/20 flex items-center justify-between">
          <Skeleton className="h-5 w-48 bg-white/20 rounded" />
          <Skeleton className="h-6 w-20 bg-white/20 rounded-full" />
        </div>
        <div className="p-8 flex items-center justify-center gap-8">
          <div className="flex flex-col items-center gap-3">
            <Skeleton className="w-24 h-24 rounded-2xl bg-white/20" />
            <Skeleton className="h-5 w-28 bg-white/20 rounded" />
          </div>
          <Skeleton className="h-20 w-40 bg-white/20 rounded-xl" />
          <div className="flex flex-col items-center gap-3">
            <Skeleton className="w-24 h-24 rounded-2xl bg-white/20" />
            <Skeleton className="h-5 w-28 bg-white/20 rounded" />
          </div>
        </div>
      </div>
      <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
        <Skeleton className="h-40 rounded-2xl" />
        <Skeleton className="h-40 rounded-2xl" />
        <Skeleton className="h-40 rounded-2xl" />
      </div>
      <Skeleton className="h-12 rounded-xl" />
      <Skeleton className="h-96 rounded-2xl" />
      <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
        <Skeleton className="h-56 rounded-2xl" />
        <Skeleton className="h-56 rounded-2xl" />
        <Skeleton className="h-56 rounded-2xl" />
      </div>
    </div>
  )
}

type TabKey = 'stream' | 'events' | 'stats' | 'lineups'

export default function MatchDetail({ matchId }: { matchId: string }) {
  const [match, setMatch] = useState<MatchData | null>(null)
  const [loading, setLoading] = useState(true)
  const [error, setError] = useState<string | null>(null)
  const [activeTab, setActiveTab] = useState<TabKey>('events')
  const [showStream, setShowStream] = useState(false)
  const router = useRouter()

  const fetchMatch = useCallback(async () => {
    try {
      const res = await fetch(`/api/matches/${matchId}`)
      if (!res.ok) throw new Error('فشل في جلب بيانات المباراة')
      const data = await res.json()
      setMatch(data.match)
      setError(null)
    } catch {
      setError('فشل في تحميل بيانات المباراة')
    } finally {
      setLoading(false)
    }
  }, [matchId])

  useEffect(() => {
    setLoading(true)
    fetchMatch()
  }, [fetchMatch])

  useEffect(() => {
    if (!match) return
    const isLive = match.status === 'live' || match.status === 'halftime'
    if (!isLive) return
    const interval = setInterval(fetchMatch, 60000)
    return () => clearInterval(interval)
  }, [match, fetchMatch])

  if (loading) return <MatchDetailSkeleton />

  if (error || !match) {
    return (
      <div className="space-y-4" dir="rtl">
        <Button
          variant="ghost"
          onClick={() => router.push('/matches')}
          className="gap-2 rounded-xl"
        >
          <ArrowRight className="w-4 h-4" />
          العودة للمباريات
        </Button>
        <div className="bg-card border border-red-200 dark:border-red-900/50 rounded-2xl p-12 text-center">
          <div className="size-20 rounded-full bg-red-100 dark:bg-red-900/30 flex items-center justify-center mx-auto mb-4">
            <AlertTriangle className="w-10 h-10 text-red-500" />
          </div>
          <p className="font-bold text-lg">{error || 'المباراة غير موجودة'}</p>
          <p className="text-sm text-muted-foreground mt-2">
            حدث خطأ أثناء تحميل بيانات المباراة، يرجى المحاولة مرة أخرى
          </p>
          <button
            onClick={fetchMatch}
            className="mt-6 inline-flex items-center gap-2 bg-emerald-600 hover:bg-emerald-700 text-white rounded-xl px-6 py-2.5 text-sm font-semibold transition-colors shadow-lg shadow-emerald-600/25"
          >
            <Eye className="w-4 h-4" />
            إعادة المحاولة
          </button>
        </div>
      </div>
    )
  }

  const isLive = match.status === 'live' || match.status === 'halftime'
  const isFinished = match.status === 'finished'
  const isUpcoming = match.status === 'upcoming'
  const homeEvents = (match.events || []).filter((e) => e.team === 'home')
  const awayEvents = (match.events || []).filter((e) => e.team === 'away')
  const generalEvents = (match.events || []).filter(
    (e) => e.team !== 'home' && e.team !== 'away'
  )
  const homeLineups = (match.lineups || []).filter((l) => l.teamId === match.homeTeam.id)
  const awayLineups = (match.lineups || []).filter((l) => l.teamId === match.awayTeam.id)
  const homeStarters = homeLineups.filter((l) => l.isStarter)
  const homeSubs = homeLineups.filter((l) => !l.isStarter)
  const awayStarters = awayLineups.filter((l) => l.isStarter)
  const awaySubs = awayLineups.filter((l) => !l.isStarter)

  const hasStats =
    match.homePossession != null ||
    match.homeShots != null ||
    match.homeCorners != null ||
    match.homeFouls != null
  const channels = match.broadcastChannels
    ? match.broadcastChannels
        .split(',')
        .map((c) => c.trim())
        .filter(Boolean)
    : []

  const homeGoals = homeEvents.filter((e) => e.type === 'goal' || e.type === 'penalty')
  const awayGoals = awayEvents.filter((e) => e.type === 'goal' || e.type === 'penalty')
  const homeOwnGoals = homeEvents.filter((e) => e.type === 'own_goal')
  const awayOwnGoals = awayEvents.filter((e) => e.type === 'own_goal')
  const goalEvents = (match.events || []).filter(
    (e) => e.type === 'goal' || e.type === 'penalty' || e.type === 'own_goal'
  )
  const cardEvents = (match.events || []).filter(
    (e) => e.type === 'yellow_card' || e.type === 'red_card'
  )

  const tabs: { key: TabKey; label: string; icon: React.ReactNode }[] = [
    { key: 'events', label: 'الأحداث', icon: <CircleDot className="w-4 h-4" /> },
    { key: 'stats', label: 'الإحصائيات', icon: <BarChart3 className="w-4 h-4" /> },
    { key: 'lineups', label: 'التشكيلة', icon: <Users className="w-4 h-4" /> },
    ...(match.streamUrl || channels.length > 0
      ? [{ key: 'stream' as TabKey, label: 'البث المباشر', icon: <Radio className="w-4 h-4" /> }]
      : []),
  ]

  return (
    <div className="space-y-6" dir="rtl">
      {/* Back Navigation */}
      <Button
        variant="ghost"
        size="sm"
        onClick={() => router.push('/matches')}
        className="gap-2 text-muted-foreground hover:text-foreground rounded-xl transition-colors"
      >
        <ArrowRight className="w-4 h-4" />
        العودة للمباريات
      </Button>

      {/* ═══════════════════════════════════════════════════════════
          HERO SECTION - Full-width gradient header
      ═══════════════════════════════════════════════════════════ */}
      <div className="relative bg-gradient-to-l from-emerald-600 via-emerald-700 to-teal-800 rounded-3xl overflow-hidden shadow-2xl shadow-emerald-900/30">
        {/* Decorative background layers */}
        <div className="absolute inset-0 bg-[radial-gradient(circle_at_25%_15%,rgba(255,255,255,0.14),transparent_50%)]" />
        <div className="absolute inset-0 bg-[radial-gradient(circle_at_75%_85%,rgba(255,255,255,0.06),transparent_50%)]" />
        <div className="absolute top-0 left-0 w-64 h-64 bg-white/5 rounded-full -translate-x-24 -translate-y-24 blur-3xl" />
        <div className="absolute bottom-0 right-0 w-72 h-72 bg-emerald-400/10 rounded-full translate-x-24 translate-y-24 blur-3xl" />
        {/* Subtle diagonal pattern */}
        <div className="absolute inset-0 opacity-[0.03]" style={{ backgroundImage: 'repeating-linear-gradient(45deg, transparent, transparent 35px, white 35px, white 36px)' }} />

        {/* League & Status Top Bar */}
        <div className="relative flex items-center justify-between px-5 md:px-8 py-3 bg-black/20 backdrop-blur-sm border-b border-white/5">
          <div className="flex items-center gap-2.5">
            <div className="flex items-center justify-center size-7 rounded-lg bg-white/15 backdrop-blur-sm">
              {match.league.logo ? (
                <img src={match.league.logo} alt="" className="w-4 h-4" />
              ) : (
                <Trophy className="w-3.5 h-3.5 text-white/70" />
              )}
            </div>
            <span className="text-sm font-semibold text-white/90">{match.league.name}</span>
            {match.league.season && (
              <span className="text-xs text-white/50 font-medium">{match.league.season}</span>
            )}
            {match.round && (
              <span className="text-xs text-white/60 bg-white/10 backdrop-blur-sm rounded-full px-2.5 py-1 font-medium">
                الجولة {match.round}
              </span>
            )}
            {match.matchday && !match.round && (
              <span className="text-xs text-white/60 bg-white/10 backdrop-blur-sm rounded-full px-2.5 py-1 font-medium">
                اليوم {match.matchday}
              </span>
            )}
          </div>
          {/* Status Badge: live=red pulse, finished=green, upcoming=amber */}
          <div className={`flex items-center gap-1.5 text-xs font-bold rounded-full px-3.5 py-1.5 ${getStatusBadgeClass(match.status)}`}>
            {isLive && (
              <span className="relative flex size-2">
                <span className="animate-ping absolute inline-flex h-full w-full rounded-full bg-white opacity-75" />
                <span className="relative inline-flex rounded-full size-2 bg-white" />
              </span>
            )}
            {getStatusLabel(match.status)}
          </div>
        </div>

        {/* Main Score Area */}
        <div className="relative p-6 md:p-10">
          <div className="flex items-center justify-center gap-6 sm:gap-10 md:gap-16">
            {/* Home Team */}
            <div className="flex flex-col items-center gap-3 min-w-0 flex-1">
              <TeamCrest team={match.homeTeam} size="2xl" />
              <span className="text-lg sm:text-xl md:text-2xl font-black text-white text-center truncate w-full leading-tight">
                {match.homeTeam.name}
              </span>
              {match.homeTeam.shortName && match.homeTeam.shortName !== match.homeTeam.name && (
                <span className="text-xs text-white/40 font-semibold">{match.homeTeam.shortName}</span>
              )}
            </div>

            {/* Score / Time Display */}
            <div className="flex flex-col items-center shrink-0">
              {isFinished || isLive ? (
                <div className="flex flex-col items-center">
                  <div className="flex items-center gap-3 sm:gap-4">
                    <span
                      className={`text-5xl sm:text-6xl md:text-8xl font-black text-white tabular-nums drop-shadow-lg ${
                        isLive ? 'animate-pulse' : ''
                      }`}
                    >
                      {match.homeScore}
                    </span>
                    <div className="flex flex-col items-center gap-1">
                      <span className="text-3xl sm:text-4xl md:text-5xl font-bold text-white/20">-</span>
                    </div>
                    <span
                      className={`text-5xl sm:text-6xl md:text-8xl font-black text-white tabular-nums drop-shadow-lg ${
                        isLive ? 'animate-pulse' : ''
                      }`}
                    >
                      {match.awayScore}
                    </span>
                  </div>
                  {isLive && (
                    <div className="flex items-center gap-2 mt-4 bg-red-500/25 backdrop-blur-sm rounded-full px-4 py-1.5 ring-1 ring-red-400/30">
                      <span className="relative flex size-2.5">
                        <span className="animate-ping absolute inline-flex h-full w-full rounded-full bg-red-400 opacity-75" />
                        <span className="relative inline-flex rounded-full size-2.5 bg-red-400" />
                      </span>
                      <span className="text-xs font-bold text-white">مباشر</span>
                    </div>
                  )}
                  {isFinished && (
                    <div className="flex items-center gap-1.5 mt-3 text-emerald-300/60 text-xs font-medium">
                      <Trophy className="w-3 h-3" />
                      انتهت المباراة
                    </div>
                  )}
                </div>
              ) : (
                <div className="flex flex-col items-center gap-3">
                  <div className="flex items-center justify-center size-16 rounded-2xl bg-white/10 backdrop-blur-sm ring-1 ring-white/10">
                    <Clock className="w-8 h-8 text-white/50" />
                  </div>
                  <span className="text-2xl sm:text-3xl md:text-4xl font-black text-white tabular-nums">
                    {formatTime(match.matchDate)}
                  </span>
                  <span className="text-xs text-white/50 font-medium">{formatMatchDate(match.matchDate)}</span>
                </div>
              )}
            </div>

            {/* Away Team */}
            <div className="flex flex-col items-center gap-3 min-w-0 flex-1">
              <TeamCrest team={match.awayTeam} size="2xl" />
              <span className="text-lg sm:text-xl md:text-2xl font-black text-white text-center truncate w-full leading-tight">
                {match.awayTeam.name}
              </span>
              {match.awayTeam.shortName && match.awayTeam.shortName !== match.awayTeam.name && (
                <span className="text-xs text-white/40 font-semibold">{match.awayTeam.shortName}</span>
              )}
            </div>
          </div>

          {/* Goal Scorers Under Each Team */}
          {(homeGoals.length > 0 || awayGoals.length > 0 || homeOwnGoals.length > 0 || awayOwnGoals.length > 0) && (
            <div className="flex items-start justify-center gap-6 sm:gap-10 md:gap-16 mt-6">
              <div className="flex flex-col items-end gap-1.5 min-w-[120px] max-w-[180px]">
                {homeGoals.map((e) => (
                  <span key={e.id} className="flex items-center gap-1.5 text-white/70 text-xs font-medium">
                    <CircleDot className="size-3 text-emerald-300" />
                    {e.player?.name}
                    <span className="text-white/40 tabular-nums">{e.minute}&apos;</span>
                    {e.type === 'penalty' && <span className="text-amber-300/70 text-[9px]">(ج)</span>}
                  </span>
                ))}
                {homeOwnGoals.map((e) => (
                  <span key={e.id} className="flex items-center gap-1.5 text-red-300/60 text-xs font-medium">
                    <CircleDot className="size-3" />
                    {e.player?.name}
                    <span className="text-white/30 tabular-nums">{e.minute}&apos;</span>
                    <span className="text-[9px]">(عكسي)</span>
                  </span>
                ))}
              </div>
              <div className="w-px bg-white/15 min-h-[20px] self-stretch" />
              <div className="flex flex-col items-start gap-1.5 min-w-[120px] max-w-[180px]">
                {awayGoals.map((e) => (
                  <span key={e.id} className="flex items-center gap-1.5 text-white/70 text-xs font-medium">
                    <span className="text-white/40 tabular-nums">{e.minute}&apos;</span>
                    {e.player?.name}
                    <CircleDot className="size-3 text-emerald-300" />
                    {e.type === 'penalty' && <span className="text-amber-300/70 text-[9px]">(ج)</span>}
                  </span>
                ))}
                {awayOwnGoals.map((e) => (
                  <span key={e.id} className="flex items-center gap-1.5 text-red-300/60 text-xs font-medium">
                    <span className="text-[9px]">(عكسي)</span>
                    <span className="text-white/30 tabular-nums">{e.minute}&apos;</span>
                    {e.player?.name}
                    <CircleDot className="size-3" />
                  </span>
                ))}
              </div>
            </div>
          )}

          {/* Info Pills */}
          <div className="flex flex-wrap items-center justify-center gap-2.5 mt-8">
            <div className="flex items-center gap-1.5 bg-white/10 backdrop-blur-sm rounded-full px-3.5 py-2 ring-1 ring-white/5">
              <Calendar className="w-3.5 h-3.5 text-white/50" />
              <span className="text-xs font-medium text-white/70">{formatFullDate(match.matchDate)}</span>
            </div>
            <div className="flex items-center gap-1.5 bg-white/10 backdrop-blur-sm rounded-full px-3.5 py-2 ring-1 ring-white/5">
              <Clock className="w-3.5 h-3.5 text-white/50" />
              <span className="text-xs font-medium text-white/70">{formatTime(match.matchDate)}</span>
            </div>
            {match.stadium && (
              <div className="flex items-center gap-1.5 bg-white/10 backdrop-blur-sm rounded-full px-3.5 py-2 ring-1 ring-white/5">
                <MapPin className="w-3.5 h-3.5 text-white/50" />
                <span className="text-xs font-medium text-white/70">{match.stadium}</span>
              </div>
            )}
            {match.referee && (
              <div className="flex items-center gap-1.5 bg-white/10 backdrop-blur-sm rounded-full px-3.5 py-2 ring-1 ring-white/5">
                <Gavel className="w-3.5 h-3.5 text-white/50" />
                <span className="text-xs font-medium text-white/70">{match.referee}</span>
              </div>
            )}
          </div>
        </div>
      </div>

      {/* ═══════════════════════════════════════════════════════════
          AD BANNER - بعد قسم البطل
      ═══════════════════════════════════════════════════════════ */}
      <AdBanner position="match_banner" page="match_detail" />

      {/* ═══════════════════════════════════════════════════════════
          THREE FEATURE CARDS
      ═══════════════════════════════════════════════════════════ */}
      <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
        {/* Card 1: Match Details - Orange Icon */}
        <div className="bg-card border rounded-2xl overflow-hidden hover:shadow-lg hover:shadow-orange-500/5 transition-all duration-300">
          <div className="flex items-center gap-2.5 px-5 py-3.5 bg-gradient-to-l from-orange-50 to-transparent dark:from-orange-950/20 border-b">
            <div className="flex items-center justify-center size-8 rounded-xl bg-orange-500 text-white shadow-md shadow-orange-500/25">
              <Gavel className="w-4 h-4" />
            </div>
            <span className="font-bold text-sm">تفاصيل المباراة</span>
          </div>
          <div className="p-4 space-y-3">
            <div className="flex items-center justify-between text-sm">
              <span className="text-muted-foreground flex items-center gap-2">
                <Calendar className="w-3.5 h-3.5 text-orange-500" />التاريخ
              </span>
              <span className="font-semibold text-xs">{formatFullDate(match.matchDate)}</span>
            </div>
            <Separator />
            <div className="flex items-center justify-between text-sm">
              <span className="text-muted-foreground flex items-center gap-2">
                <Clock className="w-3.5 h-3.5 text-orange-500" />الوقت
              </span>
              <span className="font-semibold text-xs">{formatTime(match.matchDate)}</span>
            </div>
            {match.referee && (
              <>
                <Separator />
                <div className="flex items-center justify-between text-sm">
                  <span className="text-muted-foreground flex items-center gap-2">
                    <User className="w-3.5 h-3.5 text-orange-500" />الحكم
                  </span>
                  <span className="font-semibold text-xs">{match.referee}</span>
                </div>
              </>
            )}
            {match.stadium && (
              <>
                <Separator />
                <div className="flex items-center justify-between text-sm">
                  <span className="text-muted-foreground flex items-center gap-2">
                    <MapPin className="w-3.5 h-3.5 text-orange-500" />الملعب
                  </span>
                  <span className="font-semibold text-xs text-left max-w-[140px] truncate">{match.stadium}</span>
                </div>
              </>
            )}
            {match.round && (
              <>
                <Separator />
                <div className="flex items-center justify-between text-sm">
                  <span className="text-muted-foreground flex items-center gap-2">
                    <Flag className="w-3.5 h-3.5 text-orange-500" />الجولة
                  </span>
                  <span className="font-semibold text-xs">{match.round}</span>
                </div>
              </>
            )}
            {channels.length > 0 && (
              <>
                <Separator />
                <div className="flex items-center justify-between text-sm gap-2">
                  <span className="text-muted-foreground flex items-center gap-2 shrink-0">
                    <Tv2 className="w-3.5 h-3.5 text-orange-500" />البث
                  </span>
                  <div className="flex flex-wrap gap-1 justify-end">
                    {channels.slice(0, 3).map((ch, i) => (
                      <Badge key={i} variant="secondary" className="text-[10px] h-5 px-1.5 rounded-md font-medium">
                        {ch}
                      </Badge>
                    ))}
                    {channels.length > 3 && (
                      <Badge variant="secondary" className="text-[10px] h-5 px-1.5 rounded-md">
                        +{channels.length - 3}
                      </Badge>
                    )}
                  </div>
                </div>
              </>
            )}
          </div>
        </div>

        {/* Card 2: Live Broadcast - Purple Icon */}
        <div className="bg-card border rounded-2xl overflow-hidden hover:shadow-lg hover:shadow-purple-500/5 transition-all duration-300">
          <div className="flex items-center gap-2.5 px-5 py-3.5 bg-gradient-to-l from-purple-50 to-transparent dark:from-purple-950/20 border-b">
            <div className="flex items-center justify-center size-8 rounded-xl bg-purple-600 text-white shadow-md shadow-purple-500/25">
              <Tv className="w-4 h-4" />
            </div>
            <span className="font-bold text-sm">البث المباشر</span>
          </div>
          <div className="p-4">
            {channels.length > 0 ? (
              <div className="space-y-3">
                <div className="flex flex-wrap gap-2">
                  {channels.map((channel, i) => (
                    <div
                      key={i}
                      className="flex items-center gap-2 bg-purple-50 dark:bg-purple-950/30 rounded-xl px-3 py-2 border border-purple-100 dark:border-purple-900/50"
                    >
                      <div className="size-6 rounded-lg bg-purple-500/20 flex items-center justify-center">
                        <Tv2 className="w-3 h-3 text-purple-600 dark:text-purple-400" />
                      </div>
                      <span className="text-sm font-semibold">{channel}</span>
                    </div>
                  ))}
                </div>
                {match.streamUrl && (
                  <button
                    onClick={() => {
                      setActiveTab('stream')
                      setShowStream(true)
                    }}
                    className="flex items-center justify-center gap-2 w-full bg-purple-600 hover:bg-purple-700 text-white rounded-xl py-2.5 text-sm font-bold transition-colors shadow-lg shadow-purple-500/20"
                  >
                    <Play className="w-4 h-4" />
                    مشاهدة الآن
                  </button>
                )}
              </div>
            ) : match.streamUrl ? (
              <div className="space-y-3">
                <div className="flex items-center justify-center py-3">
                  <div className="flex items-center gap-2 bg-red-50 dark:bg-red-950/30 rounded-xl px-4 py-2.5 border border-red-100 dark:border-red-900/50">
                    <div className="w-2 h-2 rounded-full bg-red-500 animate-pulse" />
                    <span className="text-sm font-bold text-red-600 dark:text-red-400">بث متاح</span>
                  </div>
                </div>
                <button
                  onClick={() => {
                    setActiveTab('stream')
                    setShowStream(true)
                  }}
                  className="flex items-center justify-center gap-2 w-full bg-purple-600 hover:bg-purple-700 text-white rounded-xl py-2.5 text-sm font-bold transition-colors shadow-lg shadow-purple-500/20"
                >
                  <Play className="w-4 h-4" />
                  مشاهدة البث
                </button>
              </div>
            ) : (
              <div className="text-center py-6">
                <div className="size-12 rounded-full bg-muted/50 flex items-center justify-center mx-auto mb-3">
                  <Tv className="w-6 h-6 text-muted-foreground/30" />
                </div>
                <p className="text-xs text-muted-foreground">لم يتم تحديد قنوات البث بعد</p>
              </div>
            )}
          </div>
        </div>

        {/* Card 3: Match Comments - Green Icon */}
        <div className="bg-card border rounded-2xl overflow-hidden hover:shadow-lg hover:shadow-emerald-500/5 transition-all duration-300">
          <div className="flex items-center gap-2.5 px-5 py-3.5 bg-gradient-to-l from-emerald-50 to-transparent dark:from-emerald-950/20 border-b">
            <div className="flex items-center justify-center size-8 rounded-xl bg-emerald-600 text-white shadow-md shadow-emerald-500/25">
              <MessageCircle className="w-4 h-4" />
            </div>
            <span className="font-bold text-sm">تعليقات المباراة</span>
          </div>
          <div className="p-4">
            <div className="text-center py-6">
              <div className="size-12 rounded-full bg-emerald-50 dark:bg-emerald-950/30 flex items-center justify-center mx-auto mb-3">
                <MessageCircle className="w-6 h-6 text-emerald-400/50" />
              </div>
              <p className="text-sm font-semibold text-muted-foreground">التعليقات قريباً</p>
              <p className="text-xs text-muted-foreground/70 mt-1">
                ستتمكن من التفاعل والتعليق على أحداث المباراة
              </p>
              <div className="flex items-center justify-center gap-2 mt-4">
                <Shield className="w-3.5 h-3.5 text-emerald-500/50" />
                <span className="text-[11px] text-emerald-600/70 dark:text-emerald-400/70 font-medium">ميزة قادمة في سبورت بلس</span>
              </div>
            </div>
          </div>
        </div>
      </div>

      {/* ═══════════════════════════════════════════════════════════
          LIVE STREAM BANNER
      ═══════════════════════════════════════════════════════════ */}
      {(match.streamUrl || channels.length > 0) && isLive && (
        <div className="bg-gradient-to-l from-red-600/10 via-red-500/5 to-transparent border border-red-500/20 rounded-2xl p-4 flex items-center justify-between flex-wrap gap-3">
          <div className="flex items-center gap-3">
            <div className="flex items-center justify-center size-10 rounded-xl bg-red-500/20">
              <Radio className="w-5 h-5 text-red-500" />
            </div>
            <div>
              <p className="font-bold text-sm">البث المباشر متاح الآن</p>
              <div className="flex items-center gap-1.5 mt-0.5">
                {channels.map((ch, i) => (
                  <Badge
                    key={i}
                    variant="secondary"
                    className="text-[10px] h-5 rounded-full px-2 bg-red-500/10 text-red-600 dark:text-red-400 border-0"
                  >
                    <Tv className="w-2.5 h-2.5 ml-0.5" />
                    {ch}
                  </Badge>
                ))}
              </div>
            </div>
          </div>
          {match.streamUrl && (
            <button
              onClick={() => {
                setActiveTab('stream')
                setShowStream(true)
              }}
              className="flex items-center gap-2 bg-red-500 hover:bg-red-600 text-white rounded-xl px-5 py-2.5 text-sm font-bold transition-colors shadow-lg shadow-red-500/25"
            >
              <Play className="w-4 h-4" />
              مشاهدة البث
            </button>
          )}
        </div>
      )}

      {/* ═══════════════════════════════════════════════════════════
          QUICK SUMMARY - Badges for goals and cards
      ═══════════════════════════════════════════════════════════ */}
      {(goalEvents.length > 0 || cardEvents.length > 0) && (
        <div className="bg-card border rounded-2xl p-4">
          <div className="flex items-center gap-2 mb-3">
            <div className="flex items-center justify-center size-7 rounded-lg bg-emerald-600 text-white">
              <Zap className="w-3.5 h-3.5" />
            </div>
            <span className="text-sm font-bold">ملخص سريع</span>
            <Separator orientation="vertical" className="h-4 mx-1" />
            <span className="text-[11px] text-muted-foreground">
              {goalEvents.length} أهداف
              {cardEvents.length > 0 && ` · ${cardEvents.length} بطاقات`}
            </span>
          </div>
          <div className="flex flex-wrap gap-2">
            {goalEvents.map((e) => (
              <div
                key={e.id}
                className={`flex items-center gap-1.5 px-3 py-1.5 rounded-full text-xs font-semibold transition-colors ${
                  e.team === 'home'
                    ? 'bg-emerald-500/10 text-emerald-700 dark:text-emerald-400 hover:bg-emerald-500/20'
                    : 'bg-teal-500/10 text-teal-700 dark:text-teal-400 hover:bg-teal-500/20'
                }`}
              >
                <CircleDot className="w-3 h-3" />
                {e.player?.name} {e.minute}&apos;
                {e.type === 'penalty' && <span className="text-[9px] opacity-60">(جزاء)</span>}
                {e.type === 'own_goal' && <span className="text-[9px] opacity-60">(عكسي)</span>}
              </div>
            ))}
            {cardEvents.map((e) => (
              <div
                key={e.id}
                className={`flex items-center gap-1.5 px-3 py-1.5 rounded-full text-xs font-semibold transition-colors ${
                  e.type === 'yellow_card'
                    ? 'bg-yellow-500/10 text-yellow-700 dark:text-yellow-400 hover:bg-yellow-500/20'
                    : 'bg-red-500/10 text-red-700 dark:text-red-400 hover:bg-red-500/20'
                }`}
              >
                {e.type === 'yellow_card' ? (
                  <div className="w-2.5 h-3.5 bg-yellow-400 rounded-sm" />
                ) : (
                  <div className="w-2.5 h-3.5 bg-red-500 rounded-sm" />
                )}
                {e.player?.name} {e.minute}&apos;
              </div>
            ))}
          </div>
        </div>
      )}

      {/* ═══════════════════════════════════════════════════════════
          TABS SECTION
      ═══════════════════════════════════════════════════════════ */}
      <div className="space-y-4">
        {/* Professional Tab Buttons */}
        <div className="flex gap-1.5 bg-muted/40 p-1.5 rounded-xl ring-1 ring-border/50 overflow-x-auto">
          {tabs.map((tab) => (
            <button
              key={tab.key}
              onClick={() => setActiveTab(tab.key)}
              className={`flex items-center gap-2 px-4 py-2.5 rounded-lg text-xs font-semibold whitespace-nowrap transition-all duration-200 ${
                activeTab === tab.key
                  ? 'bg-emerald-600 text-white shadow-lg shadow-emerald-600/25'
                  : 'text-muted-foreground hover:text-foreground hover:bg-muted/60'
              }`}
            >
              {tab.icon}
              {tab.label}
            </button>
          ))}
        </div>

        {/* ═══════════════════════════════════════════════════════
            EVENTS TAB
        ═══════════════════════════════════════════════════════ */}
        {activeTab === 'events' && (
          <div className="space-y-4">
            {match.events && match.events.length > 0 ? (
              <div className="bg-card border rounded-2xl overflow-hidden">
                <div className="flex items-center gap-2 px-5 py-3.5 bg-gradient-to-l from-emerald-50 to-transparent dark:from-emerald-950/20 border-b">
                  <div className="flex items-center justify-center size-8 rounded-lg bg-emerald-600 text-white">
                    <CircleDot className="w-4 h-4" />
                  </div>
                  <span className="font-bold">أحداث المباراة</span>
                  <Badge variant="outline" className="text-[10px] h-5 mr-auto rounded-full">
                    {match.events.length} حدث
                  </Badge>
                </div>

                <div className="p-5">
                  {/* General Events (halftime, fulltime, VAR) */}
                  {generalEvents.length > 0 && (
                    <div className="space-y-2 mb-5">
                      {generalEvents.map((event) => (
                        <div key={event.id} className="flex items-center justify-center py-2">
                          <div className="flex items-center gap-2.5 px-5 py-2.5 bg-muted/80 rounded-full text-xs font-semibold border border-border/50">
                            <EventIcon type={event.type} />
                            <span className="font-bold tabular-nums">{event.minute}&apos;</span>
                            <span>{getEventLabel(event.type)}</span>
                          </div>
                        </div>
                      ))}
                    </div>
                  )}

                  {/* Team Events Grid */}
                  <div className="grid grid-cols-1 sm:grid-cols-2 gap-6">
                    {/* Home Team Events */}
                    <div className="space-y-1">
                      <div className="flex items-center gap-2.5 mb-3 pb-2 border-b border-border/50">
                        <div
                          className="size-6 rounded-lg shrink-0 flex items-center justify-center"
                          style={{ backgroundColor: match.homeTeam.color || '#10b981' }}
                        >
                          <span className="text-[10px] font-bold text-white">
                            {(match.homeTeam.shortName || match.homeTeam.name).charAt(0)}
                          </span>
                        </div>
                        <span className="text-xs font-bold">{match.homeTeam.shortName || match.homeTeam.name}</span>
                      </div>
                      {homeEvents.length > 0 ? (
                        homeEvents.map((event) => (
                          <div
                            key={event.id}
                            className="flex items-start gap-2.5 py-2 px-3 rounded-xl hover:bg-muted/30 transition-colors"
                          >
                            <div className="flex items-center justify-center size-6 rounded-full bg-muted shrink-0 mt-0.5">
                              <span className="text-[10px] font-bold text-muted-foreground tabular-nums">
                                {event.minute}&apos;
                              </span>
                            </div>
                            <div className="mt-0.5">
                              <EventIcon type={event.type} />
                            </div>
                            <div className="flex flex-col min-w-0">
                              <span className="text-sm font-semibold">
                                {event.player?.name || getEventLabel(event.type)}
                              </span>
                              {event.assistPlayer && (
                                <span className="text-[11px] text-emerald-600 dark:text-emerald-400 font-medium">
                                  صناعة: {event.assistPlayer.name}
                                </span>
                              )}
                              {event.type === 'penalty' && (
                                <span className="text-[10px] text-amber-600 font-medium">ركلة جزاء</span>
                              )}
                              {event.type === 'own_goal' && (
                                <span className="text-[10px] text-red-500 font-medium">هدف عكسي</span>
                              )}
                              {event.detail && event.type === 'var' && (
                                <span className="text-[10px] text-purple-600 dark:text-purple-400 font-medium">{event.detail}</span>
                              )}
                            </div>
                          </div>
                        ))
                      ) : (
                        <p className="text-xs text-muted-foreground text-center py-6">لا أحداث</p>
                      )}
                    </div>

                    {/* Away Team Events */}
                    <div className="space-y-1">
                      <div className="flex items-center gap-2.5 mb-3 pb-2 border-b border-border/50">
                        <div
                          className="size-6 rounded-lg shrink-0 flex items-center justify-center"
                          style={{ backgroundColor: match.awayTeam.color || '#6366f1' }}
                        >
                          <span className="text-[10px] font-bold text-white">
                            {(match.awayTeam.shortName || match.awayTeam.name).charAt(0)}
                          </span>
                        </div>
                        <span className="text-xs font-bold">{match.awayTeam.shortName || match.awayTeam.name}</span>
                      </div>
                      {awayEvents.length > 0 ? (
                        awayEvents.map((event) => (
                          <div
                            key={event.id}
                            className="flex items-start gap-2.5 py-2 px-3 rounded-xl hover:bg-muted/30 transition-colors"
                          >
                            <div className="flex items-center justify-center size-6 rounded-full bg-muted shrink-0 mt-0.5">
                              <span className="text-[10px] font-bold text-muted-foreground tabular-nums">
                                {event.minute}&apos;
                              </span>
                            </div>
                            <div className="mt-0.5">
                              <EventIcon type={event.type} />
                            </div>
                            <div className="flex flex-col min-w-0">
                              <span className="text-sm font-semibold">
                                {event.player?.name || getEventLabel(event.type)}
                              </span>
                              {event.assistPlayer && (
                                <span className="text-[11px] text-emerald-600 dark:text-emerald-400 font-medium">
                                  صناعة: {event.assistPlayer.name}
                                </span>
                              )}
                              {event.type === 'penalty' && (
                                <span className="text-[10px] text-amber-600 font-medium">ركلة جزاء</span>
                              )}
                              {event.type === 'own_goal' && (
                                <span className="text-[10px] text-red-500 font-medium">هدف عكسي</span>
                              )}
                              {event.detail && event.type === 'var' && (
                                <span className="text-[10px] text-purple-600 dark:text-purple-400 font-medium">{event.detail}</span>
                              )}
                            </div>
                          </div>
                        ))
                      ) : (
                        <p className="text-xs text-muted-foreground text-center py-6">لا أحداث</p>
                      )}
                    </div>
                  </div>
                </div>
              </div>
            ) : (
              <div className="bg-card border rounded-2xl p-12 text-center">
                <div className="size-16 rounded-full bg-muted/50 flex items-center justify-center mx-auto mb-4">
                  <CircleDot className="w-8 h-8 text-muted-foreground/30" />
                </div>
                <p className="font-semibold">لا توجد أحداث حتى الآن</p>
                <p className="text-sm text-muted-foreground mt-1">ستظهر الأحداث هنا بمجرد بدء المباراة</p>
              </div>
            )}
          </div>
        )}

        {/* ═══════════════════════════════════════════════════════
            STATISTICS TAB
        ═══════════════════════════════════════════════════════ */}
        {activeTab === 'stats' && (
          <div className="space-y-4">
            {hasStats ? (
              <div className="bg-card border rounded-2xl overflow-hidden">
                <div className="flex items-center gap-2 px-5 py-3.5 bg-gradient-to-l from-teal-50 to-transparent dark:from-teal-950/20 border-b">
                  <div className="flex items-center justify-center size-8 rounded-lg bg-teal-600 text-white">
                    <BarChart3 className="w-4 h-4" />
                  </div>
                  <span className="font-bold">إحصائيات المباراة</span>
                </div>

                <div className="p-6 space-y-6">
                  {/* Team Headers */}
                  <div className="flex items-center justify-between pb-3 border-b">
                    <div className="flex items-center gap-3">
                      <div
                        className="size-8 rounded-lg flex items-center justify-center"
                        style={{ backgroundColor: match.homeTeam.color || '#10b981' }}
                      >
                        <span className="text-xs font-bold text-white">
                          {(match.homeTeam.shortName || match.homeTeam.name).charAt(0)}
                        </span>
                      </div>
                      <span className="text-sm font-bold">
                        {match.homeTeam.shortName || match.homeTeam.name}
                      </span>
                    </div>
                    <div className="flex items-center gap-3">
                      <span className="text-sm font-bold">
                        {match.awayTeam.shortName || match.awayTeam.name}
                      </span>
                      <div
                        className="size-8 rounded-lg flex items-center justify-center"
                        style={{ backgroundColor: match.awayTeam.color || '#6366f1' }}
                      >
                        <span className="text-xs font-bold text-white">
                          {(match.awayTeam.shortName || match.awayTeam.name).charAt(0)}
                        </span>
                      </div>
                    </div>
                  </div>

                  {match.homePossession != null && match.awayPossession != null && (
                    <StatBar
                      homeVal={match.homePossession}
                      awayVal={match.awayPossession}
                      label="الاستحواذ"
                      isPercentage
                    />
                  )}
                  {match.homeShots != null && match.awayShots != null && (
                    <StatBar
                      homeVal={match.homeShots}
                      awayVal={match.awayShots}
                      label="التسديدات"
                    />
                  )}
                  {match.homeShotsOnTarget != null && match.awayShotsOnTarget != null && (
                    <StatBar
                      homeVal={match.homeShotsOnTarget}
                      awayVal={match.awayShotsOnTarget}
                      label="على المرمى"
                    />
                  )}
                  {match.homeCorners != null && match.awayCorners != null && (
                    <StatBar
                      homeVal={match.homeCorners}
                      awayVal={match.awayCorners}
                      label="الركنيات"
                    />
                  )}
                  {match.homeFouls != null && match.awayFouls != null && (
                    <StatBar
                      homeVal={match.homeFouls}
                      awayVal={match.awayFouls}
                      label="الأخطاء"
                    />
                  )}
                  {match.homeYellowCards != null && match.awayYellowCards != null && (
                    <StatBar
                      homeVal={match.homeYellowCards}
                      awayVal={match.awayYellowCards}
                      label="البطاقات الصفراء"
                    />
                  )}
                  {match.homeRedCards != null && match.awayRedCards != null && (
                    <StatBar
                      homeVal={match.homeRedCards}
                      awayVal={match.awayRedCards}
                      label="البطاقات الحمراء"
                    />
                  )}
                </div>
              </div>
            ) : (
              <div className="bg-card border rounded-2xl p-12 text-center">
                <div className="size-16 rounded-full bg-muted/50 flex items-center justify-center mx-auto mb-4">
                  <BarChart3 className="w-8 h-8 text-muted-foreground/30" />
                </div>
                <p className="font-semibold">لا توجد إحصائيات</p>
                <p className="text-sm text-muted-foreground mt-1">ستظهر الإحصائيات بعد بدء المباراة</p>
              </div>
            )}
          </div>
        )}

        {/* ═══════════════════════════════════════════════════════
            LINEUPS TAB
        ═══════════════════════════════════════════════════════ */}
        {activeTab === 'lineups' && (
          <div className="space-y-4">
            {match.lineups && match.lineups.length > 0 ? (
              <div className="bg-card border rounded-2xl overflow-hidden">
                <div className="flex items-center gap-2 px-5 py-3.5 bg-gradient-to-l from-cyan-50 to-transparent dark:from-cyan-950/20 border-b">
                  <div className="flex items-center justify-center size-8 rounded-lg bg-cyan-600 text-white">
                    <Users className="w-4 h-4" />
                  </div>
                  <span className="font-bold">التشكيلة</span>
                  <Badge variant="outline" className="text-[10px] h-5 mr-auto rounded-full">
                    {homeStarters.length + awayStarters.length} أساسي
                  </Badge>
                </div>

                <div className="p-5">
                  <div className="grid grid-cols-1 sm:grid-cols-2 gap-8">
                    {/* Home Team Lineup */}
                    <div className="space-y-4">
                      <div className="flex items-center gap-3 pb-3 border-b border-border/50">
                        <TeamCrest team={match.homeTeam} size="md" />
                        <div>
                          <span className="font-bold text-sm">{match.homeTeam.name}</span>
                          <p className="text-[11px] text-emerald-600 dark:text-emerald-400 font-medium">
                            التشكيل الأساسي ({homeStarters.length})
                          </p>
                        </div>
                      </div>

                      {homeStarters.length > 0 && (
                        <div className="space-y-2">
                          {['GK', 'DEF', 'MID', 'FWD'].map((pos) => {
                            const posPlayers = homeStarters.filter((l) => l.position === pos)
                            if (posPlayers.length === 0) return null
                            return (
                              <div key={pos}>
                                <div className="flex items-center gap-1.5 mb-1.5">
                                  <Badge
                                    variant="outline"
                                    className="text-[9px] h-4 px-1.5 rounded-full border-cyan-200 dark:border-cyan-800 text-cyan-700 dark:text-cyan-400"
                                  >
                                    {getPositionLabel(pos)}
                                  </Badge>
                                </div>
                                {posPlayers.map((l) => (
                                  <div
                                    key={l.id}
                                    className="flex items-center gap-2.5 text-sm py-1.5 px-2 rounded-lg hover:bg-emerald-50 dark:hover:bg-emerald-950/20 transition-colors"
                                  >
                                    <span className="text-xs font-bold text-emerald-600 dark:text-emerald-400 tabular-nums w-6 text-center bg-emerald-100 dark:bg-emerald-900/30 rounded-md py-0.5">
                                      {l.shirtNumber || ''}
                                    </span>
                                    <span className="font-medium">{l.player.name}</span>
                                  </div>
                                ))}
                              </div>
                            )
                          })}
                        </div>
                      )}

                      {homeSubs.length > 0 && (
                        <div className="mt-3 pt-3 border-t border-dashed border-border/50">
                          <div className="flex items-center gap-1.5 mb-2">
                            <ArrowLeftRight className="w-3 h-3 text-blue-500" />
                            <span className="text-[11px] text-muted-foreground font-semibold">البدلاء</span>
                          </div>
                          <div className="space-y-1">
                            {homeSubs.map((l) => (
                              <div
                                key={l.id}
                                className="flex items-center gap-2.5 text-sm py-1.5 px-2 rounded-lg text-muted-foreground hover:bg-muted/30 transition-colors"
                              >
                                <span className="text-xs font-bold tabular-nums w-6 text-center bg-muted rounded-md py-0.5">
                                  {l.shirtNumber || ''}
                                </span>
                                <span>{l.player.name}</span>
                              </div>
                            ))}
                          </div>
                        </div>
                      )}
                    </div>

                    {/* Away Team Lineup */}
                    <div className="space-y-4">
                      <div className="flex items-center gap-3 pb-3 border-b border-border/50">
                        <TeamCrest team={match.awayTeam} size="md" />
                        <div>
                          <span className="font-bold text-sm">{match.awayTeam.name}</span>
                          <p className="text-[11px] text-teal-600 dark:text-teal-400 font-medium">
                            التشكيل الأساسي ({awayStarters.length})
                          </p>
                        </div>
                      </div>

                      {awayStarters.length > 0 && (
                        <div className="space-y-2">
                          {['GK', 'DEF', 'MID', 'FWD'].map((pos) => {
                            const posPlayers = awayStarters.filter((l) => l.position === pos)
                            if (posPlayers.length === 0) return null
                            return (
                              <div key={pos}>
                                <div className="flex items-center gap-1.5 mb-1.5">
                                  <Badge
                                    variant="outline"
                                    className="text-[9px] h-4 px-1.5 rounded-full border-teal-200 dark:border-teal-800 text-teal-700 dark:text-teal-400"
                                  >
                                    {getPositionLabel(pos)}
                                  </Badge>
                                </div>
                                {posPlayers.map((l) => (
                                  <div
                                    key={l.id}
                                    className="flex items-center gap-2.5 text-sm py-1.5 px-2 rounded-lg hover:bg-teal-50 dark:hover:bg-teal-950/20 transition-colors"
                                  >
                                    <span className="text-xs font-bold text-teal-600 dark:text-teal-400 tabular-nums w-6 text-center bg-teal-100 dark:bg-teal-900/30 rounded-md py-0.5">
                                      {l.shirtNumber || ''}
                                    </span>
                                    <span className="font-medium">{l.player.name}</span>
                                  </div>
                                ))}
                              </div>
                            )
                          })}
                        </div>
                      )}

                      {awaySubs.length > 0 && (
                        <div className="mt-3 pt-3 border-t border-dashed border-border/50">
                          <div className="flex items-center gap-1.5 mb-2">
                            <ArrowLeftRight className="w-3 h-3 text-blue-500" />
                            <span className="text-[11px] text-muted-foreground font-semibold">البدلاء</span>
                          </div>
                          <div className="space-y-1">
                            {awaySubs.map((l) => (
                              <div
                                key={l.id}
                                className="flex items-center gap-2.5 text-sm py-1.5 px-2 rounded-lg text-muted-foreground hover:bg-muted/30 transition-colors"
                              >
                                <span className="text-xs font-bold tabular-nums w-6 text-center bg-muted rounded-md py-0.5">
                                  {l.shirtNumber || ''}
                                </span>
                                <span>{l.player.name}</span>
                              </div>
                            ))}
                          </div>
                        </div>
                      )}
                    </div>
                  </div>
                </div>
              </div>
            ) : (
              <div className="bg-card border rounded-2xl p-12 text-center">
                <div className="size-16 rounded-full bg-muted/50 flex items-center justify-center mx-auto mb-4">
                  <Users className="w-8 h-8 text-muted-foreground/30" />
                </div>
                <p className="font-semibold">لم يتم الإعلان عن التشكيلة بعد</p>
                <p className="text-sm text-muted-foreground mt-1">ستظهر التشكيلة قبل بداية المباراة</p>
              </div>
            )}
          </div>
        )}

        {/* ═══════════════════════════════════════════════════════
            LIVE STREAM TAB
        ═══════════════════════════════════════════════════════ */}
        {activeTab === 'stream' && (
          <div className="space-y-4">
            <div className="bg-card border rounded-2xl overflow-hidden">
              <div className="flex items-center gap-2 px-5 py-3.5 bg-gradient-to-l from-red-50 to-transparent dark:from-red-950/20 border-b">
                <div className="flex items-center justify-center size-8 rounded-lg bg-red-500 text-white">
                  <Radio className="w-4 h-4" />
                </div>
                <span className="font-bold">البث المباشر</span>
              </div>

              <div className="p-5">
                {match.streamUrl ? (
                  <div className="space-y-4">
                    {showStream ? (
                      <div className="relative w-full aspect-video bg-black rounded-xl overflow-hidden shadow-inner">
                        <iframe
                          src={match.streamUrl}
                          className="w-full h-full"
                          allowFullScreen
                          allow="autoplay; encrypted-media"
                          title="البث المباشر"
                        />
                      </div>
                    ) : (
                      <div className="relative w-full aspect-video bg-gradient-to-br from-gray-900 via-gray-800 to-gray-900 rounded-xl overflow-hidden flex flex-col items-center justify-center gap-4 shadow-inner">
                        {/* Animated background pulse */}
                        <div className="absolute inset-0 bg-[radial-gradient(circle_at_50%_50%,rgba(239,68,68,0.12),transparent_70%)]" />
                        <div className="absolute inset-0 opacity-[0.02]" style={{ backgroundImage: 'repeating-linear-gradient(0deg, transparent, transparent 30px, white 30px, white 31px)' }} />

                        <div className="relative">
                          <div className="absolute inset-0 rounded-full bg-red-500/10 animate-ping" style={{ animationDuration: '2s' }} />
                          <button
                            className="relative flex items-center justify-center size-20 rounded-full bg-red-500/20 ring-4 ring-red-500/20 cursor-pointer hover:bg-red-500/30 hover:ring-red-500/30 transition-all duration-300"
                            onClick={() => setShowStream(true)}
                          >
                            <Play className="w-10 h-10 text-red-400 mr-[-3px]" />
                          </button>
                        </div>
                        <p className="relative text-white/80 font-semibold text-lg">اضغط للمشاهدة</p>
                        <div className="flex items-center gap-2 bg-red-500/20 rounded-full px-3.5 py-1.5 ring-1 ring-red-500/20">
                          <div className="w-2 h-2 rounded-full bg-red-500 animate-pulse" />
                          <span className="text-xs text-red-400 font-bold">مباشر</span>
                        </div>
                      </div>
                    )}

                    {channels.length > 0 && (
                      <div className="flex items-center gap-3 pt-3 border-t">
                        <Tv className="w-4 h-4 text-muted-foreground shrink-0" />
                        <span className="text-xs text-muted-foreground font-medium shrink-0">قنوات البث:</span>
                        <div className="flex flex-wrap gap-2">
                          {channels.map((ch, i) => (
                            <Badge key={i} variant="secondary" className="text-xs py-1 px-3 rounded-lg font-semibold">
                              {ch}
                            </Badge>
                          ))}
                        </div>
                      </div>
                    )}
                  </div>
                ) : channels.length > 0 ? (
                  <div className="text-center py-8">
                    <div className="size-16 rounded-full bg-muted/50 flex items-center justify-center mx-auto mb-4">
                      <Tv className="w-8 h-8 text-muted-foreground/40" />
                    </div>
                    <p className="font-semibold mb-3">قنوات البث الناقلة</p>
                    <div className="flex flex-wrap justify-center gap-2">
                      {channels.map((ch, i) => (
                        <Badge key={i} variant="secondary" className="text-sm py-1.5 px-4 rounded-lg font-semibold">
                          {ch}
                        </Badge>
                      ))}
                    </div>
                    <p className="text-xs text-muted-foreground mt-4">لا يتوفر بث مباشر على المنصة حالياً</p>
                  </div>
                ) : (
                  <div className="text-center py-8">
                    <div className="size-16 rounded-full bg-muted/50 flex items-center justify-center mx-auto mb-4">
                      <Radio className="w-8 h-8 text-muted-foreground/30" />
                    </div>
                    <p className="font-semibold">لا يتوفر بث مباشر</p>
                    <p className="text-xs text-muted-foreground mt-1">لم يتم تحديد قنوات البث بعد</p>
                  </div>
                )}
              </div>
            </div>
          </div>
        )}
      </div>

      {/* ═══════════════════════════════════════════════════════════
          MATCH INFO GRID - 3 cards at bottom
      ═══════════════════════════════════════════════════════════ */}
      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-4">
        {/* Match Details Card */}
        <div className="bg-card border rounded-2xl overflow-hidden">
          <div className="flex items-center gap-2 px-5 py-3.5 bg-gradient-to-l from-emerald-50 to-transparent dark:from-emerald-950/20 border-b">
            <div className="flex items-center justify-center size-7 rounded-lg bg-emerald-600 text-white">
              <Gavel className="w-3.5 h-3.5" />
            </div>
            <span className="text-sm font-bold">معلومات المباراة</span>
          </div>
          <div className="p-4 space-y-3">
            <div className="flex items-center justify-between text-sm">
              <span className="text-muted-foreground flex items-center gap-2">
                <Calendar className="w-4 h-4 text-emerald-600" />التاريخ
              </span>
              <span className="font-semibold">{formatFullDate(match.matchDate)}</span>
            </div>
            <Separator />
            <div className="flex items-center justify-between text-sm">
              <span className="text-muted-foreground flex items-center gap-2">
                <Clock className="w-4 h-4 text-emerald-600" />الوقت
              </span>
              <span className="font-semibold">{formatTime(match.matchDate)}</span>
            </div>
            <Separator />
            {match.stadium && (
              <>
                <div className="flex items-center justify-between text-sm">
                  <span className="text-muted-foreground flex items-center gap-2">
                    <MapPin className="w-4 h-4 text-emerald-600" />الملعب
                  </span>
                  <span className="font-semibold text-left text-xs max-w-[150px] truncate">{match.stadium}</span>
                </div>
                <Separator />
              </>
            )}
            {match.referee && (
              <>
                <div className="flex items-center justify-between text-sm">
                  <span className="text-muted-foreground flex items-center gap-2">
                    <User className="w-4 h-4 text-emerald-600" />الحكم
                  </span>
                  <span className="font-semibold">{match.referee}</span>
                </div>
                <Separator />
              </>
            )}
            {match.round && (
              <>
                <div className="flex items-center justify-between text-sm">
                  <span className="text-muted-foreground flex items-center gap-2">
                    <Flag className="w-4 h-4 text-emerald-600" />الجولة
                  </span>
                  <span className="font-semibold">{match.round}</span>
                </div>
                <Separator />
              </>
            )}
            <div className="flex items-center justify-between text-sm">
              <span className="text-muted-foreground flex items-center gap-2">
                <Trophy className="w-4 h-4 text-emerald-600" />البطولة
              </span>
              <span className="font-semibold">{match.league.name}</span>
            </div>
          </div>
        </div>

        {/* Broadcast Info Card */}
        <div className="bg-card border rounded-2xl overflow-hidden">
          <div className="flex items-center gap-2 px-5 py-3.5 bg-gradient-to-l from-purple-50 to-transparent dark:from-purple-950/20 border-b">
            <div className="flex items-center justify-center size-7 rounded-lg bg-purple-600 text-white">
              <Tv className="w-3.5 h-3.5" />
            </div>
            <span className="text-sm font-bold">قنوات البث</span>
          </div>
          <div className="p-4">
            {channels.length > 0 ? (
              <div className="space-y-3">
                <div className="flex flex-wrap gap-2">
                  {channels.map((channel, i) => (
                    <Badge key={i} variant="secondary" className="text-sm py-1.5 px-4 rounded-xl font-semibold">
                      {channel}
                    </Badge>
                  ))}
                </div>
                {match.streamUrl && (
                  <a
                    href={match.streamUrl}
                    target="_blank"
                    rel="noopener noreferrer"
                    className="flex items-center justify-center gap-2 mt-3 bg-red-500 hover:bg-red-600 text-white rounded-xl py-3 text-sm font-bold transition-colors shadow-lg shadow-red-500/20"
                  >
                    <Play className="w-4 h-4" />
                    مشاهدة البث المباشر
                  </a>
                )}
              </div>
            ) : (
              <div className="text-center py-4">
                <Tv className="w-8 h-8 mx-auto mb-2 text-muted-foreground/30" />
                <p className="text-xs text-muted-foreground">لم يتم تحديد قنوات البث</p>
              </div>
            )}
          </div>
        </div>

        {/* Match Report Card */}
        <div className="bg-card border rounded-2xl overflow-hidden">
          <div className="flex items-center gap-2 px-5 py-3.5 bg-gradient-to-l from-amber-50 to-transparent dark:from-amber-950/20 border-b">
            <div className="flex items-center justify-center size-7 rounded-lg bg-amber-500 text-white">
              <BookOpen className="w-3.5 h-3.5" />
            </div>
            <span className="text-sm font-bold">تقرير المباراة</span>
          </div>
          <div className="p-4">
            {match.matchReport ? (
              <div className="text-sm leading-relaxed text-muted-foreground whitespace-pre-line max-h-48 overflow-y-auto">
                {match.matchReport}
              </div>
            ) : (
              <div className="text-center py-4">
                <BookOpen className="w-8 h-8 mx-auto mb-2 text-muted-foreground/30" />
                <p className="text-xs text-muted-foreground">لا يوجد تقرير بعد</p>
              </div>
            )}
          </div>
        </div>
      </div>
    </div>
  )
}
