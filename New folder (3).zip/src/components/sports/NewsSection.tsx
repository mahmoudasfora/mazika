'use client'

import { useEffect, useState } from 'react'
import { motion, AnimatePresence } from 'framer-motion'
import { Eye, Clock, User, ArrowLeft, Newspaper, TrendingUp, Flame, Bookmark, Share2 } from 'lucide-react'
import { Card, CardContent } from '@/components/ui/card'
import { Badge } from '@/components/ui/badge'
import { Button } from '@/components/ui/button'
import { Skeleton } from '@/components/ui/skeleton'
import { useRouter } from 'next/navigation'
import { getCategoryLabel, getCategoryColor, truncateText, timeAgo, formatNumber } from '@/lib/sports-utils'

interface ArticleAuthor {
  id: string
  name: string
  avatar: string | null
  role: string
}

interface ArticleTag {
  id: string
  tag: string
}

interface ArticleTeamItem {
  id: string
  team: {
    id: string
    name: string
    nameEn: string | null
    shortName: string | null
    logo: string | null
  }
}

interface Article {
  id: string
  title: string
  slug: string
  summary: string | null
  content: string
  image: string | null
  category: string
  isBreaking: boolean
  isFeatured: boolean
  status: string
  authorId: string
  publishedAt: string | null
  views: number
  createdAt: string
  updatedAt: string
  author: ArticleAuthor
  tags: ArticleTag[]
  teams: ArticleTeamItem[]
}

function getCategoryGradient(category: string): string {
  const gradients: Record<string, string> = {
    general: 'from-blue-500 to-cyan-500',
    transfer: 'from-purple-500 to-pink-500',
    analysis: 'from-amber-500 to-orange-500',
    interview: 'from-teal-500 to-emerald-500',
    report: 'from-indigo-500 to-violet-500',
    breaking: 'from-red-500 to-rose-500',
  }
  return gradients[category] || 'from-emerald-500 to-green-600'
}

function ArticleImagePlaceholder({ category, className = '' }: { category: string; className?: string }) {
  return (
    <div className={`bg-gradient-to-br ${getCategoryGradient(category)} flex items-center justify-center ${className}`}>
      <Newspaper className="size-10 text-white/40" />
    </div>
  )
}

function NewsCardSkeleton() {
  return (
    <div className="bg-card border rounded-xl overflow-hidden">
      <Skeleton className="h-48 w-full rounded-none" />
      <div className="p-4 space-y-3">
        <Skeleton className="h-5 w-20" />
        <Skeleton className="h-6 w-full" />
        <Skeleton className="h-4 w-3/4" />
        <div className="flex items-center gap-3">
          <Skeleton className="h-4 w-24" />
          <Skeleton className="h-4 w-20" />
          <Skeleton className="h-4 w-16" />
        </div>
      </div>
    </div>
  )
}

function HeroSkeleton() {
  return (
    <div className="bg-card border rounded-2xl overflow-hidden">
      <Skeleton className="h-72 md:h-96 w-full rounded-none" />
      <div className="p-6 space-y-4">
        <Skeleton className="h-6 w-24" />
        <Skeleton className="h-8 w-3/4" />
        <Skeleton className="h-5 w-full" />
        <Skeleton className="h-5 w-2/3" />
        <div className="flex items-center gap-4">
          <Skeleton className="h-4 w-28" />
          <Skeleton className="h-4 w-24" />
          <Skeleton className="h-4 w-20" />
        </div>
      </div>
    </div>
  )
}

export default function NewsSection() {
  const [featuredArticles, setFeaturedArticles] = useState<Article[]>([])
  const [latestArticles, setLatestArticles] = useState<Article[]>([])
  const [loading, setLoading] = useState(true)
  const [error, setError] = useState<string | null>(null)
  const router = useRouter()

  useEffect(() => {
    async function fetchData() {
      try {
        setLoading(true)
        const [featuredRes, latestRes] = await Promise.all([
          fetch('/api/articles?isFeatured=true&status=published&limit=6'),
          fetch('/api/articles?status=published&limit=12'),
        ])

        if (!featuredRes.ok || !latestRes.ok) {
          throw new Error('فشل في جلب الأخبار')
        }

        const featuredData = await featuredRes.json()
        const latestData = await latestRes.json()

        setFeaturedArticles(featuredData.articles || [])
        setLatestArticles(latestData.articles || [])
      } catch (err) {
        setError(err instanceof Error ? err.message : 'حدث خطأ غير متوقع')
      } finally {
        setLoading(false)
      }
    }
    fetchData()
  }, [])

  const heroArticle = featuredArticles[0]
  const sideArticles = featuredArticles.length > 1 ? featuredArticles.slice(1, 3) : []
  const gridArticles = featuredArticles.length > 3
    ? featuredArticles.slice(3).concat(latestArticles.filter(a => !featuredArticles.some(f => f.id === a.id)))
    : latestArticles.filter(a => !featuredArticles.some(f => f.id === a.id))

  if (error) {
    return (
      <section dir="rtl" className="space-y-6">
        <div className="flex items-center justify-between">
          <h2 className="text-2xl font-bold text-foreground flex items-center gap-2">
            <Newspaper className="size-6 text-emerald-500" />
            آخر الأخبار
          </h2>
        </div>
        <Card className="p-6 text-center">
          <p className="text-muted-foreground">{error}</p>
          <Button
            variant="outline"
            className="mt-4"
            onClick={() => window.location.reload()}
          >
            إعادة المحاولة
          </Button>
        </Card>
      </section>
    )
  }

  return (
    <section dir="rtl" className="space-y-6">
      {/* Section Header */}
      <div className="flex items-center justify-between">
        <div className="flex items-center gap-3">
          <div className="flex items-center justify-center size-10 rounded-xl bg-emerald-600 text-white shadow-lg shadow-emerald-600/30">
            <Newspaper className="size-5" />
          </div>
          <div>
            <h2 className="text-xl font-bold">آخر الأخبار</h2>
            <p className="text-xs text-muted-foreground">أحدث الأخبار والتقارير الرياضية</p>
          </div>
        </div>
        <Button
          variant="ghost"
          className="text-emerald-600 hover:text-emerald-700 dark:text-emerald-400 dark:hover:text-emerald-300 gap-1 font-semibold bg-emerald-50 dark:bg-emerald-500/10 px-3 hover:bg-emerald-100 dark:hover:bg-emerald-500/20"
          onClick={() => router.push('/news')}
        >
          عرض الكل
          <ArrowLeft className="size-4" />
        </Button>
      </div>

      {loading ? (
        <div className="space-y-6">
          <HeroSkeleton />
          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-4">
            {Array.from({ length: 6 }).map((_, i) => (
              <NewsCardSkeleton key={i} />
            ))}
          </div>
        </div>
      ) : (
        <div className="space-y-6">
          {/* Hero + Side Articles Layout */}
          {heroArticle && (
            <div className="grid grid-cols-1 lg:grid-cols-3 gap-4">
              {/* Main Hero Article */}
              <motion.div
                initial={{ opacity: 0, y: 20 }}
                animate={{ opacity: 1, y: 0 }}
                transition={{ duration: 0.5 }}
                className="lg:col-span-2"
              >
                <div
                  className="relative bg-card border rounded-2xl overflow-hidden cursor-pointer group h-full min-h-[400px]"
                  onClick={() => router.push(`/news/${heroArticle.id}`)}
                >
                  {/* Image */}
                  <div className="absolute inset-0">
                    {heroArticle.image ? (
                      <img
                        src={heroArticle.image}
                        alt={heroArticle.title}
                        className="w-full h-full object-cover group-hover:scale-105 transition-transform duration-700"
                      />
                    ) : (
                      <ArticleImagePlaceholder
                        category={heroArticle.category}
                        className="w-full h-full"
                      />
                    )}
                  </div>

                  {/* Gradient Overlay */}
                  <div className="absolute inset-0 bg-gradient-to-t from-black/80 via-black/40 to-transparent" />

                  {/* Content */}
                  <div className="absolute bottom-0 right-0 left-0 p-6 md:p-8">
                    <div className="flex items-center gap-2 mb-3">
                      <Badge className={`${getCategoryColor(heroArticle.category)} border-0`}>
                        {getCategoryLabel(heroArticle.category)}
                      </Badge>
                      {heroArticle.isBreaking && (
                        <Badge className="bg-red-500 text-white border-0 animate-pulse">
                          عاجل
                        </Badge>
                      )}
                    </div>
                    <h3 className="text-2xl md:text-3xl font-bold text-white mb-3 line-clamp-2 group-hover:text-emerald-300 transition-colors leading-tight">
                      {heroArticle.title}
                    </h3>
                    {heroArticle.summary && (
                      <p className="text-white/80 text-sm md:text-base line-clamp-2 mb-4 leading-relaxed">
                        {heroArticle.summary}
                      </p>
                    )}
                    <div className="flex items-center gap-4 text-white/70 text-sm">
                      <span className="flex items-center gap-1.5 bg-white/10 backdrop-blur-sm rounded-full px-3 py-1">
                        <User className="size-3.5" />
                        {heroArticle.author.name}
                      </span>
                      {heroArticle.publishedAt && (
                        <span className="flex items-center gap-1.5 bg-white/10 backdrop-blur-sm rounded-full px-3 py-1">
                          <Clock className="size-3.5" />
                          {timeAgo(heroArticle.publishedAt)}
                        </span>
                      )}
                      <span className="flex items-center gap-1.5 bg-white/10 backdrop-blur-sm rounded-full px-3 py-1">
                        <Eye className="size-3.5" />
                        {formatNumber(heroArticle.views)}
                      </span>
                    </div>
                  </div>
                </div>
              </motion.div>

              {/* Side Articles Stack */}
              {sideArticles.length > 0 && (
                <div className="flex flex-col gap-4">
                  {sideArticles.map((article, index) => (
                    <motion.div
                      key={article.id}
                      initial={{ opacity: 0, x: 20 }}
                      animate={{ opacity: 1, x: 0 }}
                      transition={{ duration: 0.4, delay: (index + 1) * 0.15 }}
                      className="flex-1"
                    >
                      <div
                        className="bg-card border rounded-xl overflow-hidden cursor-pointer group h-full flex"
                        onClick={() => router.push(`/news/${article.id}`)}
                      >
                        {/* Image */}
                        <div className="relative w-2/5 shrink-0">
                          {article.image ? (
                            <img
                              src={article.image}
                              alt={article.title}
                              className="w-full h-full object-cover group-hover:scale-105 transition-transform duration-500"
                            />
                          ) : (
                            <ArticleImagePlaceholder
                              category={article.category}
                              className="w-full h-full"
                            />
                          )}
                        </div>

                        {/* Content */}
                        <div className="flex flex-col justify-center p-3 flex-1 min-w-0">
                          <Badge className={`${getCategoryColor(article.category)} text-[10px] px-1.5 py-0 h-4 w-fit mb-2`}>
                            {getCategoryLabel(article.category)}
                          </Badge>
                          <h3 className="font-bold text-sm text-foreground line-clamp-2 group-hover:text-emerald-600 dark:group-hover:text-emerald-400 transition-colors leading-relaxed">
                            {article.title}
                          </h3>
                          <div className="flex items-center gap-2 mt-2 text-[11px] text-muted-foreground">
                            {article.publishedAt && (
                              <span className="flex items-center gap-1">
                                <Clock className="size-3" />
                                {timeAgo(article.publishedAt)}
                              </span>
                            )}
                            <span className="flex items-center gap-1">
                              <Eye className="size-3" />
                              {formatNumber(article.views)}
                            </span>
                          </div>
                        </div>
                      </div>
                    </motion.div>
                  ))}
                </div>
              )}
            </div>
          )}

          {/* Trending Bar */}
          {gridArticles.length > 0 && (
            <div className="flex items-center gap-3 bg-gradient-to-r from-amber-50 to-orange-50 dark:from-amber-950/20 dark:to-orange-950/20 rounded-xl p-3 border border-amber-200/50 dark:border-amber-800/30">
              <div className="flex items-center gap-1.5 shrink-0">
                <Flame className="size-4 text-amber-500" />
                <span className="text-xs font-bold text-amber-700 dark:text-amber-400">الأكثر قراءة</span>
              </div>
              <div className="flex-1 overflow-hidden">
                <div className="flex items-center gap-4 text-sm text-foreground overflow-x-auto whitespace-nowrap scrollbar-none">
                  {gridArticles.slice(0, 4).map((article, i) => (
                    <button
                      key={article.id}
                      onClick={() => router.push(`/news/${article.id}`)}
                      className="hover:text-emerald-600 dark:hover:text-emerald-400 transition-colors shrink-0"
                    >
                      {article.title}
                    </button>
                  ))}
                </div>
              </div>
            </div>
          )}

          {/* Articles Grid */}
          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-4">
            {gridArticles.slice(0, 6).map((article, index) => (
              <motion.div
                key={article.id}
                initial={{ opacity: 0, y: 20 }}
                animate={{ opacity: 1, y: 0 }}
                transition={{ duration: 0.4, delay: (index + 1) * 0.08 }}
                whileHover={{ y: -6, transition: { duration: 0.2 } }}
              >
                <div
                  className="bg-card border rounded-xl overflow-hidden cursor-pointer group h-full flex flex-col hover:shadow-xl hover:border-emerald-200 dark:hover:border-emerald-800 transition-all duration-300"
                  onClick={() => router.push(`/news/${article.id}`)}
                >
                  <div className="relative overflow-hidden">
                    {article.image ? (
                      <img
                        src={article.image}
                        alt={article.title}
                        className="w-full h-48 object-cover group-hover:scale-110 transition-transform duration-700"
                      />
                    ) : (
                      <ArticleImagePlaceholder
                        category={article.category}
                        className="w-full h-48"
                      />
                    )}
                    <div className="absolute inset-0 bg-gradient-to-t from-black/20 to-transparent opacity-0 group-hover:opacity-100 transition-opacity duration-300" />
                    <Badge className={`absolute top-3 right-3 ${getCategoryColor(article.category)} border-0 shadow-sm`}>
                      {getCategoryLabel(article.category)}
                    </Badge>
                    {article.isBreaking && (
                      <Badge className="absolute top-3 left-3 bg-red-500 text-white border-0 animate-pulse shadow-sm">
                        عاجل
                      </Badge>
                    )}
                  </div>
                  <div className="p-4 space-y-2.5 flex flex-col flex-1">
                    <h3 className="font-bold text-foreground line-clamp-2 group-hover:text-emerald-600 dark:group-hover:text-emerald-400 transition-colors leading-relaxed">
                      {article.title}
                    </h3>
                    {article.summary && (
                      <p className="text-sm text-muted-foreground line-clamp-2 flex-1 leading-relaxed">
                        {truncateText(article.summary, 100)}
                      </p>
                    )}
                    <div className="flex items-center justify-between text-xs text-muted-foreground pt-2 border-t border-border/50">
                      <div className="flex items-center gap-3">
                        <span className="flex items-center gap-1">
                          <User className="size-3" />
                          {article.author.name}
                        </span>
                        {article.publishedAt && (
                          <span className="flex items-center gap-1">
                            <Clock className="size-3" />
                            {timeAgo(article.publishedAt)}
                          </span>
                        )}
                      </div>
                      <span className="flex items-center gap-1">
                        <Eye className="size-3" />
                        {formatNumber(article.views)}
                      </span>
                    </div>
                  </div>
                </div>
              </motion.div>
            ))}
          </div>

          {/* View All Button */}
          <div className="flex justify-center pt-2">
            <Button
              className="bg-emerald-600 hover:bg-emerald-700 text-white gap-2 px-8 py-2.5 rounded-xl shadow-lg shadow-emerald-600/20 hover:shadow-emerald-600/40 transition-all duration-300"
              onClick={() => router.push('/news')}
            >
              عرض جميع الأخبار
              <ArrowLeft className="size-4" />
            </Button>
          </div>
        </div>
      )}
    </section>
  )
}
