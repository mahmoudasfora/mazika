'use client'

import { useNavigation } from '@/lib/navigation-store'
import { AdminLayout } from './admin/AdminLayout'
import { AdminDashboardHome } from './admin/AdminDashboardHome'
import { AdminArticles } from './admin/AdminArticles'
import { AdminMatches } from './admin/AdminMatches'
import { AdminLeagues } from './admin/AdminLeagues'
import { AdminTeams } from './admin/AdminTeams'
import { AdminSettings } from './admin/AdminSettings'
import { AdminUsers } from './admin/AdminUsers'
import { AdminAds } from './admin/AdminAds'

export default function AdminDashboard() {
  const { adminTab } = useNavigation()

  const renderTab = () => {
    switch (adminTab) {
      case 'dashboard': return <AdminDashboardHome />
      case 'articles': return <AdminArticles />
      case 'matches': return <AdminMatches />
      case 'leagues': return <AdminLeagues />
      case 'teams': return <AdminTeams />
      case 'settings': return <AdminSettings />
      case 'users': return <AdminUsers />
      case 'ads': return <AdminAds />
      default: return <AdminDashboardHome />
    }
  }

  return (
    <AdminLayout>
      {renderTab()}
    </AdminLayout>
  )
}
