'use client'

import { useState, useEffect } from 'react'
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card'
import { Tabs, TabsList, TabsTrigger } from '@/components/ui/tabs'
import { Skeleton } from '@/components/ui/skeleton'
import { ScrollArea, ScrollBar } from '@/components/ui/scroll-area'
import { useRouter } from 'next/navigation'
import { Trophy, ChevronLeft, TrendingUp } from 'lucide-react'

interface League {
  id: string
  name: string
  nameEn: string | null
  country: string | null
  logo: string | null
  type: string
  season: string | null
  teamCount: number
}

interface Standing {
  id: string
  position: number
  played: number
  won: number
  drawn: number
  lost: number
  goalsFor: number
  goalsAgainst: number
  goalDifference: number
  points: number
  form: string | null
  team: {
    id: string
    name: string
    nameEn: string | null
    shortName: string | null
    logo: string | null
    color: string | null
  }
}

function FormCircles({ form }: { form: string | null }) {
  if (!form) return null
  const last5 = form.slice(-5).split('')
  return (
    <div className="flex items-center gap-0.5" dir="ltr">
      {last5.map((result, i) => (
        <span
          key={i}
          className={`inline-block size-4 rounded-full text-[9px] font-bold leading-4 text-center text-white ${
            result === 'W' ? 'bg-emerald-500' : result === 'D' ? 'bg-yellow-500' : 'bg-red-500'
          }`}
        >
          {result === 'W' ? 'ف' : result === 'D' ? 'ت' : 'خ'}
        </span>
      ))}
    </div>
  )
}

function StandingsSkeleton() {
  return (
    <div className="space-y-2 px-3">
      {Array.from({ length: 5 }).map((_, i) => (
        <div key={i} className="flex items-center gap-3 py-2">
          <Skeleton className="size-6 rounded-full" />
          <Skeleton className="h-4 w-20" />
          <div className="flex-1" />
          <Skeleton className="h-4 w-6" />
          <Skeleton className="h-4 w-6" />
          <Skeleton className="h-4 w-6" />
        </div>
      ))}
    </div>
  )
}

export default function StandingsWidget() {
  const [leagues, setLeagues] = useState<League[]>([])
  const [selectedLeagueId, setSelectedLeagueId] = useState<string>('')
  const [standings, setStandings] = useState<Standing[]>([])
  const [loadingLeagues, setLoadingLeagues] = useState(true)
  const [loadingStandings, setLoadingStandings] = useState(false)
  const [error, setError] = useState<string | null>(null)
  const router = useRouter()

  useEffect(() => {
    async function fetchLeagues() {
      try {
        setLoadingLeagues(true)
        const res = await fetch('/api/leagues')
        if (!res.ok) throw new Error('فشل في جلب البطولات')
        const data = await res.json()
        setLeagues(data.leagues)
        if (data.leagues.length > 0) {
          setSelectedLeagueId(data.leagues[0].id)
        }
      } catch {
        setError('فشل في جلب البطولات')
      } finally {
        setLoadingLeagues(false)
      }
    }
    fetchLeagues()
  }, [])

  useEffect(() => {
    if (!selectedLeagueId) return
    async function fetchStandings() {
      try {
        setLoadingStandings(true)
        setError(null)
        const res = await fetch(`/api/standings?leagueId=${selectedLeagueId}`)
        if (!res.ok) throw new Error('فشل في جلب الترتيب')
        const data = await res.json()
        setStandings(data.standings)
      } catch {
        setError('فشل في جلب الترتيب')
        setStandings([])
      } finally {
        setLoadingStandings(false)
      }
    }
    fetchStandings()
  }, [selectedLeagueId])

  const top5 = standings.slice(0, 5)

  return (
    <Card className="overflow-hidden border shadow-sm hover:shadow-md transition-shadow duration-300">
      <CardHeader className="pb-2 bg-gradient-to-l from-emerald-50 to-transparent dark:from-emerald-950/20 dark:to-transparent">
        <CardTitle className="flex items-center gap-2 text-base font-bold">
          <div className="flex items-center justify-center size-8 rounded-lg bg-emerald-600 text-white shadow-sm">
            <Trophy className="size-4" />
          </div>
          <span>ترتيب الدوري</span>
        </CardTitle>
      </CardHeader>
      <CardContent className="px-2 pb-4">
        {/* League Selector Tabs */}
        {loadingLeagues ? (
          <div className="flex gap-2 px-2 pb-3">
            {Array.from({ length: 4 }).map((_, i) => (
              <Skeleton key={i} className="h-7 w-16 rounded-full" />
            ))}
          </div>
        ) : (
          <ScrollArea className="w-full" dir="rtl">
            <Tabs value={selectedLeagueId} onValueChange={setSelectedLeagueId} dir="rtl">
              <TabsList className="mb-3 h-7 w-full justify-start gap-1 bg-muted/50 p-0.5">
                {leagues.map((league) => (
                  <TabsTrigger
                    key={league.id}
                    value={league.id}
                    className="h-6 px-2.5 text-[11px] data-[state=active]:bg-emerald-600 data-[state=active]:text-white rounded-full"
                  >
                    {league.name}
                  </TabsTrigger>
                ))}
              </TabsList>
            </Tabs>
            <ScrollBar orientation="horizontal" />
          </ScrollArea>
        )}

        {/* Standings List */}
        {loadingStandings ? (
          <StandingsSkeleton />
        ) : error ? (
          <div className="py-8 text-center text-sm text-red-500">{error}</div>
        ) : top5.length === 0 ? (
          <div className="py-8 text-center text-sm text-muted-foreground">
            لا توجد بيانات ترتيب
          </div>
        ) : (
          <div className="space-y-0.5">
            {top5.map((row, index) => (
              <div
                key={row.id}
                className={`flex items-center gap-2 px-2 py-2 rounded-lg transition-colors hover:bg-muted/50 ${
                  index === 0 ? 'bg-amber-50/50 dark:bg-amber-950/10' : ''
                }`}
              >
                {/* Position */}
                <span className={`flex size-6 shrink-0 items-center justify-center rounded-full text-xs font-bold ${
                  index === 0 ? 'bg-amber-500 text-white' : 
                  index === 1 ? 'bg-gray-400 text-white' :
                  index === 2 ? 'bg-amber-700 text-white' :
                  'bg-muted text-muted-foreground'
                }`}>
                  {row.position}
                </span>

                {/* Team */}
                <div className="flex items-center gap-2 flex-1 min-w-0">
                  <span
                    className="inline-block size-5 rounded-full shrink-0 ring-1 ring-white/20 shadow-sm"
                    style={{ backgroundColor: row.team.color || '#6b7280' }}
                  />
                  <span className="truncate text-sm font-medium">{row.team.shortName || row.team.name}</span>
                </div>

                {/* Form */}
                <FormCircles form={row.form} />

                {/* Points */}
                <span className="text-sm font-bold text-emerald-700 dark:text-emerald-400 min-w-[20px] text-center">
                  {row.points}
                </span>
              </div>
            ))}
          </div>
        )}

        {/* View All Link */}
        {standings.length > 0 && (
          <button
            onClick={() => router.push('/standings')}
            className="mt-3 flex w-full items-center justify-center gap-1 rounded-lg border border-emerald-200 bg-emerald-50 py-2 text-sm font-semibold text-emerald-700 transition-colors hover:bg-emerald-100 dark:border-emerald-800 dark:bg-emerald-950/30 dark:text-emerald-400 dark:hover:bg-emerald-950/50"
          >
            <span>عرض الترتيب الكامل</span>
            <ChevronLeft className="size-4" />
          </button>
        )}
      </CardContent>
    </Card>
  )
}
