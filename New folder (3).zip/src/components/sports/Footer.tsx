'use client'

import Link from 'next/link'
import { Separator } from '@/components/ui/separator'
import {
  Home,
  Newspaper,
  Trophy,
  BarChart3,
  Video,
  Twitter,
  Facebook,
  Instagram,
  Youtube,
} from 'lucide-react'
import { cn } from '@/lib/utils'

interface FooterLink {
  label: string
  href: string
  icon: React.ReactNode
}

const quickLinks: FooterLink[] = [
  { label: 'الرئيسية', href: '/', icon: <Home className="size-4" /> },
  { label: 'الأخبار', href: '/news', icon: <Newspaper className="size-4" /> },
  { label: 'المباريات', href: '/matches', icon: <Trophy className="size-4" /> },
  { label: 'الترتيب', href: '/standings', icon: <BarChart3 className="size-4" /> },
  { label: 'الفيديوهات', href: '/videos', icon: <Video className="size-4" /> },
]

const socialLinks = [
  { label: 'تويتر', icon: <Twitter className="size-5" />, href: '#' },
  { label: 'فيسبوك', icon: <Facebook className="size-5" />, href: '#' },
  { label: 'انستغرام', icon: <Instagram className="size-5" />, href: '#' },
  { label: 'يوتيوب', icon: <Youtube className="size-5" />, href: '#' },
]

const categories = [
  { label: 'أخبار عامة', href: '/news?category=general' },
  { label: 'انتقالات', href: '/news?category=transfer' },
  { label: 'تحليلات', href: '/news?category=analysis' },
  { label: 'مقابلات', href: '/news?category=interview' },
  { label: 'تقارير', href: '/news?category=report' },
]

export function Footer() {
  return (
    <footer dir="rtl" className="bg-gray-900 dark:bg-gray-950 text-gray-300">
      <div className="max-w-7xl mx-auto px-4 py-10">
        <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-8">
          {/* Brand Section */}
          <div className="sm:col-span-2 lg:col-span-1">
            <Link
              href="/"
              className="flex items-center gap-2 mb-4 group"
            >
              <div className="flex items-center justify-center size-10 rounded-xl overflow-hidden shadow-md group-hover:shadow-emerald-500/25 transition-shadow">
                <img src="/favicon.png" alt="سبورت بلس" className="size-full object-cover" />
              </div>
              <div className="flex flex-col">
                <span className="text-xl font-bold text-emerald-400 leading-tight">
                  سبورت بلس
                </span>
                <span className="text-[10px] text-gray-500 leading-tight">
                  أخبار الرياضة أولاً
                </span>
              </div>
            </Link>
            <p className="text-sm text-gray-400 leading-relaxed max-w-xs">
              منصتك الأولى للأخبار الرياضية. نغطي أهم الأحداث الرياضية في العالم العربي
              والعالم مع تحليلات معمقة وتقارير حصرية.
            </p>

            {/* Social Media */}
            <div className="flex items-center gap-2 mt-5">
              {socialLinks.map((social) => (
                <a
                  key={social.label}
                  href={social.href}
                  target="_blank"
                  rel="noopener noreferrer"
                  className={cn(
                    'flex items-center justify-center size-9 rounded-lg',
                    'bg-gray-800 text-gray-400 hover:bg-emerald-500 hover:text-white',
                    'transition-all duration-200'
                  )}
                  aria-label={social.label}
                >
                  {social.icon}
                </a>
              ))}
            </div>
          </div>

          {/* Quick Links */}
          <div>
            <h3 className="text-white font-semibold text-sm mb-4 flex items-center gap-2">
              <span className="w-1 h-4 bg-emerald-500 rounded-full" />
              روابط سريعة
            </h3>
            <ul className="space-y-2">
              {quickLinks.map((link) => (
                <li key={link.href}>
                  <Link
                    href={link.href}
                    className="flex items-center gap-2 text-sm text-gray-400 hover:text-emerald-400 transition-colors"
                  >
                    {link.icon}
                    {link.label}
                  </Link>
                </li>
              ))}
            </ul>
          </div>

          {/* Categories */}
          <div>
            <h3 className="text-white font-semibold text-sm mb-4 flex items-center gap-2">
              <span className="w-1 h-4 bg-emerald-500 rounded-full" />
              الأقسام
            </h3>
            <ul className="space-y-2">
              {categories.map((cat) => (
                <li key={cat.href}>
                  <Link
                    href={cat.href}
                    className="text-sm text-gray-400 hover:text-emerald-400 transition-colors"
                  >
                    {cat.label}
                  </Link>
                </li>
              ))}
            </ul>
          </div>

          {/* About / Contact */}
          <div>
            <h3 className="text-white font-semibold text-sm mb-4 flex items-center gap-2">
              <span className="w-1 h-4 bg-emerald-500 rounded-full" />
              معلومات
            </h3>
            <ul className="space-y-2">
              <li>
                <Link href="/page/about" className="text-sm text-gray-400 hover:text-emerald-400 transition-colors">
                  من نحن
                </Link>
              </li>
              <li>
                <Link href="/page/privacy" className="text-sm text-gray-400 hover:text-emerald-400 transition-colors">
                  سياسة الخصوصية
                </Link>
              </li>
              <li>
                <Link href="/page/terms" className="text-sm text-gray-400 hover:text-emerald-400 transition-colors">
                  شروط الاستخدام
                </Link>
              </li>
              <li>
                <Link href="/page/contact" className="text-sm text-gray-400 hover:text-emerald-400 transition-colors">
                  اتصل بنا
                </Link>
              </li>
            </ul>
          </div>
        </div>

        <Separator className="my-8 bg-gray-800" />

        {/* Copyright */}
        <div className="flex flex-col sm:flex-row items-center justify-between gap-4 text-sm text-gray-500">
          <p>
            © {new Date().getFullYear()} سبورت بلس. جميع الحقوق محفوظة.
          </p>
          <p className="flex items-center gap-1">
            صُنع بـ
            <span className="text-red-500">❤</span>
            لمحبي الرياضة العرب
          </p>
        </div>
      </div>
    </footer>
  )
}
