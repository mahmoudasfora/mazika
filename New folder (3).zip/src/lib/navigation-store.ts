import { create } from 'zustand'

export type Page = 'home' | 'news' | 'matches' | 'standings' | 'article' | 'match' | 'team' | 'videos' | 'admin'
export type AdminTab = 'dashboard' | 'articles' | 'matches' | 'leagues' | 'teams' | 'users' | 'ads' | 'settings'

interface NavigationState {
  currentPage: Page
  selectedArticleId: string | null
  selectedMatchId: string | null
  selectedTeamId: string | null
  selectedLeagueId: string | null
  selectedCategory: string | null
  adminTab: AdminTab
  navigate: (page: Page, options?: { articleId?: string; matchId?: string; teamId?: string; leagueId?: string; category?: string }) => void
  setAdminTab: (tab: AdminTab) => void
}

export const useNavigation = create<NavigationState>((set) => ({
  currentPage: 'home',
  selectedArticleId: null,
  selectedMatchId: null,
  selectedTeamId: null,
  selectedLeagueId: null,
  selectedCategory: null,
  adminTab: 'dashboard',
  navigate: (page, options = {}) => {
    set({
      currentPage: page,
      selectedArticleId: options.articleId || null,
      selectedMatchId: options.matchId || null,
      selectedTeamId: options.teamId || null,
      selectedLeagueId: options.leagueId || null,
      selectedCategory: options.category || null,
    })
    window.scrollTo({ top: 0, behavior: 'smooth' })
  },
  setAdminTab: (tab) => set({ adminTab: tab }),
}))
