export function formatMatchDate(dateStr: string): string {
  const date = new Date(dateStr)
  const now = new Date()
  const today = new Date(now.getFullYear(), now.getMonth(), now.getDate())
  const matchDay = new Date(date.getFullYear(), date.getMonth(), date.getDate())
  
  const diff = matchDay.getTime() - today.getTime()
  const days = Math.round(diff / (1000 * 60 * 60 * 24))
  
  if (days === 0) return 'اليوم'
  if (days === 1) return 'غداً'
  if (days === -1) return 'أمس'
  
  return date.toLocaleDateString('ar-EG', { 
    weekday: 'short', 
    day: 'numeric', 
    month: 'short' 
  })
}

export function formatTime(dateStr: string): string {
  const date = new Date(dateStr)
  return date.toLocaleTimeString('ar-EG', { 
    hour: '2-digit', 
    minute: '2-digit',
    hour12: true 
  })
}

export function formatFullDate(dateStr: string): string {
  const date = new Date(dateStr)
  return date.toLocaleDateString('ar-EG', { 
    weekday: 'long', 
    year: 'numeric', 
    month: 'long', 
    day: 'numeric' 
  })
}

export function getStatusLabel(status: string): string {
  const labels: Record<string, string> = {
    upcoming: 'لم تبدأ',
    live: 'مباشر',
    halftime: 'استراحة',
    finished: 'انتهت',
    postponed: 'مؤجلة',
    cancelled: 'ملغاة',
  }
  return labels[status] || status
}

export function getStatusColor(status: string): string {
  const colors: Record<string, string> = {
    upcoming: 'bg-gray-100 text-gray-700 dark:bg-gray-800 dark:text-gray-300',
    live: 'bg-red-500 text-white animate-pulse',
    halftime: 'bg-yellow-500 text-white',
    finished: 'bg-green-100 text-green-700 dark:bg-green-900 dark:text-green-300',
    postponed: 'bg-orange-100 text-orange-700 dark:bg-orange-900 dark:text-orange-300',
    cancelled: 'bg-red-100 text-red-700 dark:bg-red-900 dark:text-red-300',
  }
  return colors[status] || 'bg-gray-100 text-gray-700'
}

export function getCategoryLabel(category: string): string {
  const labels: Record<string, string> = {
    general: 'أخبار عامة',
    transfer: 'انتقالات',
    analysis: 'تحليلات',
    interview: 'مقابلات',
    report: 'تقارير',
    breaking: 'عاجل',
  }
  return labels[category] || category
}

export function getCategoryColor(category: string): string {
  const colors: Record<string, string> = {
    general: 'bg-blue-100 text-blue-700 dark:bg-blue-900 dark:text-blue-300',
    transfer: 'bg-purple-100 text-purple-700 dark:bg-purple-900 dark:text-purple-300',
    analysis: 'bg-amber-100 text-amber-700 dark:bg-amber-900 dark:text-amber-300',
    interview: 'bg-teal-100 text-teal-700 dark:bg-teal-900 dark:text-teal-300',
    report: 'bg-indigo-100 text-indigo-700 dark:bg-indigo-900 dark:text-indigo-300',
    breaking: 'bg-red-500 text-white',
  }
  return colors[category] || 'bg-gray-100 text-gray-700'
}

export function getPositionLabel(position: string): string {
  const labels: Record<string, string> = {
    GK: 'حارس مرمى',
    DEF: 'مدافع',
    MID: 'وسط',
    FWD: 'مهاجم',
  }
  return labels[position] || position
}

export function getEventIcon(type: string): string {
  const icons: Record<string, string> = {
    goal: '⚽',
    yellow_card: '🟨',
    red_card: '🟥',
    substitution: '🔄',
    var: '📺',
    penalty: '⚽🎯',
    own_goal: '⚽😟',
    halftime: '⏸️',
    fulltime: '🏁',
  }
  return icons[type] || '📌'
}

export function truncateText(text: string, maxLength: number): string {
  if (text.length <= maxLength) return text
  return text.substring(0, maxLength) + '...'
}

export function formatNumber(num: number): string {
  if (num >= 1000000) return (num / 1000000).toFixed(1) + 'M'
  if (num >= 1000) return (num / 1000).toFixed(1) + 'K'
  return num.toString()
}

export function timeAgo(dateStr: string): string {
  const date = new Date(dateStr)
  const now = new Date()
  const diff = now.getTime() - date.getTime()
  
  const minutes = Math.floor(diff / (1000 * 60))
  const hours = Math.floor(diff / (1000 * 60 * 60))
  const days = Math.floor(diff / (1000 * 60 * 60 * 24))
  
  if (minutes < 1) return 'الآن'
  if (minutes < 60) return `منذ ${minutes} دقيقة`
  if (hours < 24) return `منذ ${hours} ساعة`
  if (days < 7) return `منذ ${days} يوم`
  
  return formatFullDate(dateStr)
}
