---
Task ID: 1
Agent: Main Agent
Task: Build professional Ads management system for سبورت بلس

Work Log:
- Restarted dev server (was inactive due to memory pressure)
- Read and analyzed existing ads infrastructure: schema (AdSlot model), API routes, admin page, AdBanner component
- Fixed critical bug in `/api/ads/route.ts` - double OR clause in Prisma query (second OR was overwriting first). Changed to use AND with nested OR clauses
- Added AdBanner integration to match detail page (`app/(public)/matches/[id]/page.tsx`) - header_banner + footer_banner
- Added AdBanner integration to article detail page (`app/(public)/news/[id]/page.tsx`) - header_banner + footer_banner
- Enhanced AdBanner component with close button, loading state, better animations
- Rebuilt admin ads page with professional features:
  - 3-tab interface: List view, Position Map, Analytics
  - Position Map showing visual layout of all ad placements with counts
  - Analytics tab with performance by position and top performing ads
  - Expired/scheduled ad alerts
  - Duplicate ad feature
  - Enhanced filtering with clear filters button
  - CTR color coding (green > 2%, amber > 0.5%)
  - Better form with icons in select dropdowns
- Updated old ad position values in database (header -> header_banner, sidebar -> sidebar_top, match_page -> match_banner)
- Tested all CRUD operations via API: CREATE (201), READ (200), UPDATE (200), DELETE (200)
- Verified public API returns ads correctly with fixed AND/OR query

Stage Summary:
- All ads API endpoints working correctly
- Admin ads page rebuilt with professional UI including 3 tabs, position map, analytics
- AdBanner component enhanced with close button and better UX
- Ads now display on ALL public pages: home, news, matches, match detail, article detail
- Fixed critical Prisma query bug that prevented date-based ad filtering
